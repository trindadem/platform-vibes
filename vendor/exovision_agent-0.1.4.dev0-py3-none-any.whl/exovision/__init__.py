"""EXOVISION-I — SDK agêntico do exovisionlab.

O pacote instalável que contém tudo o que um agente de IA carrega ou pode
carregar. `exovision.harness` é o kernel agêntico; tudo o mais é módulo dele:

    exovision.harness            — laço, provedor, ferramentas, instrução, skills,
                                   governança, orçamento, sessão durável, traço
    exovision.harness.mcp        — o protocolo MCP inteiro, dos dois lados
    exovision.harness.subagents  — delegação com orçamento de árvore
    exovision.harness.batch      — Message Batches API e rollouts
    exovision.harness.specialize — especialização profunda, medida
    exovision.harness.memory     — memória de agente de nível laboratorial (21 categorias)
    exovision.harness.rag        — recuperação aumentada: vetores, esparso, grafo
    exovision.harness.tasks      — tarefas paralelas, duráveis e resilientes (fila, lease,
                                   retomada), agendas cron e gatilhos — tudo embarcado
    exovision.harness.bus        — barramento embarcado (assuntos, curingas, consumidores duráveis)
    exovision.harness.plugins    — tools em três níveis, plugins, confiança por verificação, Evolve
    exovision.harness.agents     — perfis duráveis (AGENT.md) e equipes fixas (TEAM.md): compromissos,
                                   canais, Contract Net, artefatos com CAS, um ator por perfil
"""

__version__ = "0.1.4.dev0"
