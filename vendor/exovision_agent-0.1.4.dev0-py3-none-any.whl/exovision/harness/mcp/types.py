"""Os tipos do MCP, já sanitizados na fronteira.

Cada `from_wire` é o ponto em que texto de servidor deixa de ser bytes
arbitrários e vira dado do harness: a ocultação Unicode é contada e removida
ali, uma vez, e não em cada lugar que exibe a string. O que sobrar de
suspeito fica em `concealed`, para quem decide (o `MCPToolset`) poder recusar.
"""

from __future__ import annotations

from collections.abc import Mapping
from dataclasses import dataclass, field
from typing import Any

from .wire import conceal_scan, fingerprint, sanitize

__all__ = [
    "TASK_TERMINAL",
    "Elicitation",
    "MCPTool",
    "Prompt",
    "PromptArgument",
    "PromptMessage",
    "Resource",
    "ResourceContent",
    "ResourceTemplate",
    "Root",
    "Task",
]

#: Estados terminais de uma tarefa. `input_required` **não** é terminal: é o
#: sinal de que o receptor tem um pedido para o requisitante.
TASK_TERMINAL = frozenset({"completed", "failed", "cancelled"})


def _scan(*textos: str) -> dict[str, int]:
    achado: dict[str, int] = {}
    for t in textos:
        for k, v in conceal_scan(t).items():
            achado[k] = achado.get(k, 0) + v
    return achado


@dataclass(frozen=True, slots=True)
class MCPTool:
    """Uma ferramenta anunciada por um servidor, já sanitizada e pinada."""

    name: str
    description: str
    input_schema: dict[str, Any]
    annotations: dict[str, Any] = field(default_factory=dict)
    output_schema: dict[str, Any] | None = None
    title: str = ""
    digest: str = ""
    concealed: dict[str, int] = field(default_factory=dict)
    #: `forbidden` (padrão) | `optional` | `required` — negociação por ferramenta
    #: da execução como tarefa (`execution.taskSupport`).
    task_support: str = "forbidden"

    @classmethod
    def from_wire(cls, raw: Mapping[str, Any]) -> MCPTool:
        name = str(raw.get("name", ""))
        raw_desc = str(raw.get("description") or raw.get("title") or "")
        schema = dict(raw.get("inputSchema") or {"type": "object"})
        import json as _json

        concealed = _scan(raw_desc)
        concealed.update(
            {
                f"schema_{k}": v
                for k, v in conceal_scan(_json.dumps(schema, ensure_ascii=False)).items()
            }
        )
        description = sanitize(raw_desc)
        execution = raw.get("execution") or {}
        return cls(
            name=name,
            description=description,
            input_schema=schema,
            annotations=dict(raw.get("annotations") or {}),
            output_schema=dict(raw["outputSchema"]) if raw.get("outputSchema") else None,
            title=sanitize(str(raw.get("title") or "")),
            digest=fingerprint(name, description, schema),
            concealed=concealed,
            task_support=str(execution.get("taskSupport") or "forbidden"),
        )


@dataclass(frozen=True, slots=True)
class Resource:
    """Um recurso anunciado: identidade (URI) e metadado. O conteúdo vem depois."""

    uri: str
    name: str = ""
    title: str = ""
    description: str = ""
    mime_type: str = ""
    size: int | None = None
    annotations: dict[str, Any] = field(default_factory=dict)
    concealed: dict[str, int] = field(default_factory=dict)

    @property
    def priority(self) -> float:
        """0..1; 1 é "praticamente obrigatório". Ausente vira 0.5 — nem lixo nem lei."""
        try:
            return float(self.annotations.get("priority", 0.5))
        except (TypeError, ValueError):
            return 0.5

    @property
    def audience(self) -> tuple[str, ...]:
        aud = self.annotations.get("audience")
        return tuple(str(a) for a in aud) if isinstance(aud, (list, tuple)) else ()

    def for_model(self) -> bool:
        """Sem `audience` declarada, serve aos dois. Com ela, respeita-se."""
        return not self.audience or "assistant" in self.audience

    @classmethod
    def from_wire(cls, raw: Mapping[str, Any]) -> Resource:
        desc = str(raw.get("description") or "")
        name = str(raw.get("name") or "")
        return cls(
            uri=str(raw.get("uri") or ""),
            name=sanitize(name),
            title=sanitize(str(raw.get("title") or "")),
            description=sanitize(desc),
            mime_type=str(raw.get("mimeType") or ""),
            size=int(raw["size"]) if isinstance(raw.get("size"), int) else None,
            annotations=dict(raw.get("annotations") or {}),
            concealed=_scan(name, desc),
        )


@dataclass(frozen=True, slots=True)
class ResourceTemplate:
    """Recurso parametrizado por um URI Template (RFC 6570)."""

    uri_template: str
    name: str = ""
    title: str = ""
    description: str = ""
    mime_type: str = ""

    @property
    def variables(self) -> tuple[str, ...]:
        """Os nomes entre chaves. Expansão simples é o que se usa na prática."""
        import re

        return tuple(
            v.strip()
            for grupo in re.findall(r"\{([^}]*)\}", self.uri_template)
            for v in grupo.lstrip("+#./;?&").split(",")
            if v.strip()
        )

    def expand(self, **valores: Any) -> str:
        """Substitui `{var}` pelos valores, com percent-encoding. Falta variável, erro."""
        from urllib.parse import quote

        out = self.uri_template
        for var in self.variables:
            if var not in valores:
                raise KeyError(f"template {self.uri_template!r} exige {var!r}")
            out = out.replace("{" + var + "}", quote(str(valores[var]), safe="/"))
            out = out.replace("{+" + var + "}", quote(str(valores[var]), safe="/:"))
        return out

    @classmethod
    def from_wire(cls, raw: Mapping[str, Any]) -> ResourceTemplate:
        return cls(
            uri_template=str(raw.get("uriTemplate") or ""),
            name=sanitize(str(raw.get("name") or "")),
            title=sanitize(str(raw.get("title") or "")),
            description=sanitize(str(raw.get("description") or "")),
            mime_type=str(raw.get("mimeType") or ""),
        )


@dataclass(frozen=True, slots=True)
class ResourceContent:
    """O conteúdo lido: texto, ou binário em base64. Nunca os dois."""

    uri: str
    mime_type: str = ""
    text: str | None = None
    blob: str | None = None

    @property
    def is_text(self) -> bool:
        return self.text is not None

    def render(self, limit: int = 60_000) -> str:
        """O que vai para o modelo. Binário vira menção honesta, não base64 no prompt."""
        if self.text is None:
            tamanho = len(self.blob or "")
            return f"[{self.uri}] binário {self.mime_type or 'desconhecido'}, {tamanho} B em base64"
        corpo = self.text
        if len(corpo) > limit:
            corpo = corpo[:limit] + f"\n… [truncado: {len(self.text)} caracteres]"
        return f"[{self.uri}]\n{corpo}"

    @classmethod
    def from_wire(cls, raw: Mapping[str, Any]) -> ResourceContent:
        texto = raw.get("text")
        return cls(
            uri=str(raw.get("uri") or ""),
            mime_type=str(raw.get("mimeType") or ""),
            text=sanitize(str(texto)) if texto is not None else None,
            blob=str(raw["blob"]) if raw.get("blob") is not None else None,
        )


@dataclass(frozen=True, slots=True)
class PromptArgument:
    name: str
    description: str = ""
    required: bool = False


@dataclass(frozen=True, slots=True)
class Prompt:
    """Um modelo de conversa que o servidor oferece. Controlado pelo usuário, não pelo modelo."""

    name: str
    title: str = ""
    description: str = ""
    arguments: tuple[PromptArgument, ...] = ()
    concealed: dict[str, int] = field(default_factory=dict)

    @property
    def required(self) -> tuple[str, ...]:
        return tuple(a.name for a in self.arguments if a.required)

    @classmethod
    def from_wire(cls, raw: Mapping[str, Any]) -> Prompt:
        desc = str(raw.get("description") or "")
        args = tuple(
            PromptArgument(
                name=str(a.get("name") or ""),
                description=sanitize(str(a.get("description") or "")),
                required=bool(a.get("required")),
            )
            for a in (raw.get("arguments") or [])
            if isinstance(a, Mapping)
        )
        return cls(
            name=str(raw.get("name") or ""),
            title=sanitize(str(raw.get("title") or "")),
            description=sanitize(desc),
            arguments=args,
            concealed=_scan(desc),
        )


@dataclass(frozen=True, slots=True)
class PromptMessage:
    """Uma mensagem do prompt renderizado. `role` é `user` ou `assistant`."""

    role: str
    blocks: tuple[dict[str, Any], ...] = ()

    @property
    def text(self) -> str:
        return "\n".join(
            str(b.get("text", "")) for b in self.blocks if b.get("type") == "text"
        ).strip()

    @classmethod
    def from_wire(cls, raw: Mapping[str, Any]) -> PromptMessage:
        content = raw.get("content")
        bruto = content if isinstance(content, list) else [content]
        blocos: list[dict[str, Any]] = []
        for b in bruto:
            if not isinstance(b, Mapping):
                continue
            bloco = dict(b)
            if bloco.get("type") == "text":
                bloco["text"] = sanitize(str(bloco.get("text", "")))
            if bloco.get("type") == "resource":
                recurso = dict(bloco.get("resource") or {})
                if recurso.get("text") is not None:
                    recurso["text"] = sanitize(str(recurso["text"]))
                bloco["resource"] = recurso
            blocos.append(bloco)
        return cls(role=str(raw.get("role") or "user"), blocks=tuple(blocos))


@dataclass(frozen=True, slots=True)
class Task:
    """O estado durável de um pedido que não cabe numa resposta síncrona."""

    task_id: str
    status: str = "working"
    status_message: str = ""
    created_at: str = ""
    last_updated_at: str = ""
    ttl: int | None = None
    poll_interval: int | None = None

    @property
    def terminal(self) -> bool:
        return self.status in TASK_TERMINAL

    @property
    def ok(self) -> bool:
        return self.status == "completed"

    @classmethod
    def from_wire(cls, raw: Mapping[str, Any]) -> Task:
        return cls(
            task_id=str(raw.get("taskId") or ""),
            status=str(raw.get("status") or "working"),
            status_message=sanitize(str(raw.get("statusMessage") or "")),
            created_at=str(raw.get("createdAt") or ""),
            last_updated_at=str(raw.get("lastUpdatedAt") or ""),
            ttl=int(raw["ttl"]) if isinstance(raw.get("ttl"), int) else None,
            poll_interval=(
                int(raw["pollInterval"]) if isinstance(raw.get("pollInterval"), int) else None
            ),
        )


@dataclass(frozen=True, slots=True)
class Root:
    """Uma fronteira de sistema de arquivos que o cliente expõe ao servidor.

    A especificação exige `file://`. Um root que não é `file://` é recusado na
    montagem: dizer ao servidor que ele pode operar em `https://` é convite.
    """

    uri: str
    name: str = ""

    def __post_init__(self) -> None:
        if not self.uri.startswith("file://"):
            raise ValueError(f"root precisa ser file:// nesta especificação: {self.uri!r}")

    @classmethod
    def of_path(cls, path: Any, name: str = "") -> Root:
        from pathlib import Path

        p = Path(path).resolve()
        return cls(uri=p.as_uri(), name=name or p.name)

    def to_wire(self) -> dict[str, Any]:
        out: dict[str, Any] = {"uri": self.uri}
        if self.name:
            out["name"] = self.name
        return out


@dataclass(frozen=True, slots=True)
class Elicitation:
    """Um pedido de informação ao usuário, vindo do servidor."""

    mode: str
    message: str
    requested_schema: dict[str, Any] = field(default_factory=dict)
    url: str = ""
    elicitation_id: str = ""
    server: str = ""

    @classmethod
    def from_wire(cls, raw: Mapping[str, Any], *, server: str = "") -> Elicitation:
        return cls(
            mode=str(raw.get("mode") or "form"),
            message=sanitize(str(raw.get("message") or "")),
            requested_schema=dict(raw.get("requestedSchema") or {}),
            url=str(raw.get("url") or ""),
            elicitation_id=str(raw.get("elicitationId") or ""),
            server=server,
        )
