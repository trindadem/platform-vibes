"""MCP (Model Context Protocol) inteiro — e não só as ferramentas.

Um servidor MCP oferece quatro coisas ao cliente e pede três de volta. O laço
já tratava a primeira; aqui estão as sete, cada uma pelo modelo de interação
que a especificação define para ela (revisão `2025-11-25`).

    servidor -> cliente            cliente -> servidor (o servidor pede)
    ─────────────────────          ────────────────────────────────────
    tools       model-controlled   sampling      o seu modelo, a sua fatura
    resources   application-driven elicitation   a sua caixa de diálogo
    prompts     user-controlled    roots         o seu sistema de arquivos
    tasks       requestor-driven

A lista da direita é a parte perigosa, e é onde o padrão deste cliente é
**negar**: nenhuma dessas capacidades é declarada sem uma implementação
explícita. A da esquerda é a parte útil, e cada uma entra no harness pela
superfície que corresponde ao seu modelo de controle:

    módulo       o que traz
    ──────       ──────────
    wire         JSON-RPC, transportes (stdio, Streamable HTTP, loopback),
                 despacho bidirecional, sanitização de texto não confiável
    types        MCPTool, Resource, Prompt, Task, Root — sanitizados na fronteira
    handlers     ProviderSampler, CallbackElicitor, StaticRoots + orçamento e recusas
    client       MCPClient: a sessão completa, incluindo o que o servidor pede
    toolset      MCPToolset: ferramentas com piso de risco, pino e descoberta ativa
    bridge       ResourceToolset, PromptLibrary: recursos e prompts no harness

Exemplo — tudo ligado, com as recusas no lugar:

    from exovision.harness.mcp import (
        MCPToolset, ResourceToolset, PromptLibrary,
        ProviderSampler, SamplingBudget, CallbackElicitor, StaticRoots,
    )

    servidor = MCPToolset.stdio(
        ["npx", "-y", "@exemplo/servidor"],
        sampler=ProviderSampler(provider, budget=SamplingBudget(max_calls=4)),
        elicitor=CallbackElicitor(form=pergunta_no_terminal),
        roots=StaticRoots(["."]),
        use_tasks=True,
    )
    recursos = ResourceToolset(servidor.client)
    prompts = PromptLibrary(servidor.client)

    agente = Agent(provider=provider, toolset=Composite(Workbench("."), servidor, recursos),
                   skills=SkillLibrary(prompts.skills()))
"""

from __future__ import annotations

from .bridge import (
    PromptLibrary,
    ResourceToolset,
    prompt_as_instruction,
    resources_as_context,
    watch_resources,
)
from .client import (
    CLIENT_NAME,
    CLIENT_VERSION,
    PROTOCOL_VERSION,
    RELATED_TASK,
    SUPPORTED_PROTOCOLS,
    MCPClient,
    related_task,
    task_id_of,
)
from .handlers import (
    SECRETISH,
    CallbackElicitor,
    Elicitor,
    ProviderSampler,
    RootsProvider,
    Sampler,
    SamplingBudget,
    StaticRoots,
    looks_like_secret,
    validate_form,
)
from .toolset import MCPToolset, blocks_to_result
from .types import (
    TASK_TERMINAL,
    Elicitation,
    MCPTool,
    Prompt,
    PromptArgument,
    PromptMessage,
    Resource,
    ResourceContent,
    ResourceTemplate,
    Root,
    Task,
)
from .wire import (
    ERR_INTERNAL,
    ERR_INVALID_PARAMS,
    ERR_METHOD_NOT_FOUND,
    ERR_RESOURCE_NOT_FOUND,
    ERR_URL_ELICITATION_REQUIRED,
    ERR_USER_REJECTED,
    LoopbackTransport,
    MCPDenied,
    MCPError,
    MCPIntegrityError,
    StdioTransport,
    StreamableHTTPTransport,
    Transport,
    conceal_scan,
    fingerprint,
    sanitize,
)

__all__ = [
    "CLIENT_NAME",
    "CLIENT_VERSION",
    "ERR_INTERNAL",
    "ERR_INVALID_PARAMS",
    "ERR_METHOD_NOT_FOUND",
    "ERR_RESOURCE_NOT_FOUND",
    "ERR_URL_ELICITATION_REQUIRED",
    "ERR_USER_REJECTED",
    "PROTOCOL_VERSION",
    "RELATED_TASK",
    "SECRETISH",
    "SUPPORTED_PROTOCOLS",
    "TASK_TERMINAL",
    "CallbackElicitor",
    "Elicitation",
    "Elicitor",
    "LoopbackTransport",
    "MCPClient",
    "MCPDenied",
    "MCPError",
    "MCPIntegrityError",
    "MCPTool",
    "MCPToolset",
    "Prompt",
    "PromptArgument",
    "PromptLibrary",
    "PromptMessage",
    "ProviderSampler",
    "Resource",
    "ResourceContent",
    "ResourceTemplate",
    "ResourceToolset",
    "Root",
    "RootsProvider",
    "Sampler",
    "SamplingBudget",
    "StaticRoots",
    "StdioTransport",
    "StreamableHTTPTransport",
    "Task",
    "Transport",
    "blocks_to_result",
    "conceal_scan",
    "fingerprint",
    "looks_like_secret",
    "prompt_as_instruction",
    "related_task",
    "resources_as_context",
    "sanitize",
    "task_id_of",
    "validate_form",
    "watch_resources",
]
