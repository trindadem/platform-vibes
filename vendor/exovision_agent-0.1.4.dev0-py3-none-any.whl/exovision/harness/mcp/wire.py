"""O fio do MCP: JSON-RPC 2.0, transportes e o texto que não se pode confiar.

Este módulo não sabe o que é uma ferramenta nem um recurso. Sabe entregar
mensagens nos dois sentidos e sabe que **descrição de servidor é dado, não
instrução**.

## Bidirecionalidade não é enfeite

Até `tools/call`, o cliente só falava: pedia e esperava. `sampling`,
`elicitation` e `roots` invertem a direção — o **servidor** pede ao cliente,
e a especificação é explícita em que esses pedidos acontecem *aninhados*
dentro de outra chamada ("nested inside other MCP server features"). O
transporte, portanto, precisa despachar mensagens que chegam **enquanto** se
espera uma resposta.

O despacho é um gancho (`transport.dispatch`), não uma thread de leitura em
segundo plano. A razão é a forma do tráfego: o servidor pede ao cliente
enquanto processa o pedido do cliente. Uma thread leitora exigiria fila,
sincronização e um caminho de erro para cada uma — complexidade que só se
paga se houver pedidos do servidor com o cliente ocioso. Para esse caso há
`pump(timeout)`, explícito: drenar notificações pendentes é decisão de quem
usa, não um efeito de fundo.

## O que chega de um servidor é dado

`conceal_scan` conta o que não se vê: bloco TAG (U+E0000 a U+E007F),
controles bidirecionais, largura zero e demais `Cf`. `sanitize` remove, para
que a tela de aprovação do operador e o prompt do modelo tenham os mesmos
bytes — a lacuna medida em arXiv:2607.05744. `fingerprint` é o pino que
transforma redefinição silenciosa em evento observável (arXiv:2506.01333).
"""

from __future__ import annotations

import contextlib
import hashlib
import json
import os
import shutil
import subprocess
import threading
import time
import unicodedata
import urllib.error
import urllib.request
from collections.abc import Callable, Mapping, Sequence
from typing import Any, Protocol, runtime_checkable

__all__ = [
    "ERR_INTERNAL",
    "ERR_INVALID_PARAMS",
    "ERR_METHOD_NOT_FOUND",
    "ERR_RESOURCE_NOT_FOUND",
    "ERR_URL_ELICITATION_REQUIRED",
    "ERR_USER_REJECTED",
    "LoopbackTransport",
    "MCPDenied",
    "MCPError",
    "MCPIntegrityError",
    "StdioTransport",
    "StreamableHTTPTransport",
    "Transport",
    "conceal_scan",
    "error_response",
    "fingerprint",
    "result_response",
    "sanitize",
]

DEFAULT_TIMEOUT = 60.0

#: Códigos de erro que a especificação nomeia. Usar o número certo importa:
#: o servidor decide o que fazer a seguir por ele.
ERR_USER_REJECTED = -1  # cliente/usuário recusou (sampling)
ERR_RESOURCE_NOT_FOUND = -32002
ERR_URL_ELICITATION_REQUIRED = -32042
ERR_INVALID_PARAMS = -32602
ERR_METHOD_NOT_FOUND = -32601
ERR_INTERNAL = -32603


class MCPError(RuntimeError):
    """Falha de transporte ou de protocolo — infraestrutura, derruba a montagem."""


class MCPIntegrityError(MCPError):
    """A definição de uma ferramenta mudou depois do pino (rug pull)."""


class MCPDenied(MCPError):
    """Um pedido do servidor ao cliente foi recusado (política, orçamento, operador)."""


# --------------------------------------------------------------------------
# Texto não confiável: ocultação em Unicode
# --------------------------------------------------------------------------

#: Bloco TAG: caracteres sem glifo que sobrevivem a copiar-e-colar e não
#: aparecem na tela de aprovação (arXiv:2607.05744).
_TAG_LO, _TAG_HI = 0xE0000, 0xE007F
#: Controles bidirecionais: reordenam visualmente o texto sem mudar os bytes.
_BIDI = frozenset({0x202A, 0x202B, 0x202C, 0x202D, 0x202E, 0x2066, 0x2067, 0x2068, 0x2069})
#: Largura zero / junção: usados para quebrar casamento de padrões.
_ZERO_WIDTH = frozenset({0x200B, 0x200C, 0x200D, 0x2060, 0xFEFF})


def conceal_scan(text: str) -> dict[str, int]:
    """Conta caracteres de ocultação por família. `{}` quando o texto é limpo."""
    out: dict[str, int] = {}
    for ch in text:
        cp = ord(ch)
        if _TAG_LO <= cp <= _TAG_HI:
            out["tag"] = out.get("tag", 0) + 1
        elif cp in _BIDI:
            out["bidi"] = out.get("bidi", 0) + 1
        elif cp in _ZERO_WIDTH:
            out["zero_width"] = out.get("zero_width", 0) + 1
        elif unicodedata.category(ch) == "Cf":
            out["format"] = out.get("format", 0) + 1
    return out


def sanitize(text: str) -> str:
    """Remove a ocultação. O que o operador vê e o que o modelo lê viram o mesmo texto."""
    keep: list[str] = []
    for ch in text:
        cp = ord(ch)
        if _TAG_LO <= cp <= _TAG_HI or cp in _BIDI or cp in _ZERO_WIDTH:
            continue
        if unicodedata.category(ch) == "Cf":
            continue
        keep.append(ch)
    return "".join(keep)


def fingerprint(name: str, description: str, schema: Mapping[str, Any]) -> str:
    """SHA-256 curto do que o modelo *vê* de uma ferramenta. O pino contra rug pull."""
    canonical = json.dumps(
        {"name": name, "description": description, "schema": schema},
        sort_keys=True,
        ensure_ascii=False,
        separators=(",", ":"),
        default=str,
    )
    return hashlib.sha256(canonical.encode("utf-8")).hexdigest()[:16]


# --------------------------------------------------------------------------
# Respostas JSON-RPC (o cliente também responde, agora)
# --------------------------------------------------------------------------


def result_response(request_id: Any, result: Mapping[str, Any]) -> dict[str, Any]:
    return {"jsonrpc": "2.0", "id": request_id, "result": dict(result)}


def error_response(
    request_id: Any, code: int, message: str, data: Mapping[str, Any] | None = None
) -> dict[str, Any]:
    err: dict[str, Any] = {"code": int(code), "message": str(message)}
    if data is not None:
        err["data"] = dict(data)
    return {"jsonrpc": "2.0", "id": request_id, "error": err}


# --------------------------------------------------------------------------
# Transportes
# --------------------------------------------------------------------------


@runtime_checkable
class Transport(Protocol):
    """Canal JSON-RPC bidirecional.

    `dispatch` é instalado pelo cliente: recebe uma mensagem vinda do servidor
    (requisição ou notificação) e devolve a resposta a escrever de volta, ou
    `None` quando não há o que responder.
    """

    dispatch: Callable[[dict[str, Any]], dict[str, Any] | None] | None

    def request(self, payload: dict[str, Any], timeout: float) -> dict[str, Any]: ...

    def notify(self, payload: dict[str, Any]) -> None: ...

    def pump(self, timeout: float) -> int: ...

    def close(self) -> None: ...


class _Dispatching:
    """A parte comum: despachar o que chega do servidor sem derrubar a sessão."""

    dispatch: Callable[[dict[str, Any]], dict[str, Any] | None] | None = None

    def _handle_incoming(self, message: Mapping[str, Any]) -> dict[str, Any] | None:
        """Requisição ou notificação do servidor -> resposta a devolver, ou None."""
        if self.dispatch is None:
            if message.get("id") is not None and message.get("method"):
                return error_response(
                    message["id"],
                    ERR_METHOD_NOT_FOUND,
                    f"este cliente não implementa {message.get('method')!r}",
                )
            return None
        try:
            return self.dispatch(dict(message))
        except Exception as erro:  # um handler quebrado não fecha a sessão
            if message.get("id") is not None:
                return error_response(message["id"], ERR_INTERNAL, f"{type(erro).__name__}: {erro}")
            return None


class LoopbackTransport(_Dispatching):
    """Servidor MCP em processo: um dicionário de handlers. Sem rede, sem subprocesso.

    Um handler pode falar de volta com o cliente chamando
    `transport.server_request("sampling/createMessage", params)` — é assim que
    os testes exercitam a inversão de direção sem subir processo nenhum.
    """

    def __init__(self, handlers: Mapping[str, Callable[[dict[str, Any]], Any]]) -> None:
        self.handlers = dict(handlers)
        self.sent: list[dict[str, Any]] = []
        self.notifications: list[dict[str, Any]] = []
        self.inbound: list[dict[str, Any]] = []
        self.pending: list[dict[str, Any]] = []
        self.closed = False
        self._id = 0

    # ---------------------------------------------- cliente -> servidor
    def request(self, payload: dict[str, Any], timeout: float) -> dict[str, Any]:
        self.sent.append(payload)
        method = str(payload.get("method", ""))
        handler = self.handlers.get(method)
        if handler is None:
            return error_response(
                payload.get("id"), ERR_METHOD_NOT_FOUND, f"Method not found: {method}"
            )
        try:
            result = handler(payload.get("params") or {})
        except Exception as erro:  # o servidor falhou: erro de protocolo
            return error_response(payload.get("id"), ERR_INTERNAL, f"{type(erro).__name__}: {erro}")
        if isinstance(result, dict) and ("error" in result or "result" in result):
            return {"jsonrpc": "2.0", "id": payload.get("id"), **result}
        return result_response(payload.get("id"), result if isinstance(result, dict) else {})

    def notify(self, payload: dict[str, Any]) -> None:
        self.notifications.append(payload)

    # ---------------------------------------------- servidor -> cliente
    def server_request(self, method: str, params: Mapping[str, Any]) -> dict[str, Any]:
        """O servidor pede algo ao cliente. Devolve a resposta JSON-RPC completa."""
        self._id += 1
        message = {
            "jsonrpc": "2.0",
            "id": f"srv-{self._id}",
            "method": method,
            "params": dict(params),
        }
        self.inbound.append(message)
        answer = self._handle_incoming(message)
        return answer or error_response(message["id"], ERR_INTERNAL, "sem resposta")

    def server_notify(self, method: str, params: Mapping[str, Any] | None = None) -> None:
        """Enfileira uma notificação; `pump` a entrega."""
        self.pending.append({"jsonrpc": "2.0", "method": method, "params": dict(params or {})})

    def pump(self, timeout: float = 0.0) -> int:
        entregues = 0
        while self.pending:
            message = self.pending.pop(0)
            self.inbound.append(message)
            self._handle_incoming(message)
            entregues += 1
        return entregues

    def close(self) -> None:
        self.closed = True


class StdioTransport(_Dispatching):
    """O servidor é um subprocesso; as mensagens são linhas em stdin/stdout.

    A especificação é dura aqui e por bons motivos: mensagens delimitadas por
    nova linha e **sem** nova linha embutida; `stdout` do servidor não carrega
    nada que não seja mensagem MCP; `stderr` é log e **não** indica erro. Um
    servidor que imprime banner no stdout quebra o enquadramento — por isso a
    linha que não decodifica é registrada e ignorada, e não derruba a sessão.
    """

    def __init__(
        self,
        command: Sequence[str],
        *,
        env: Mapping[str, str] | None = None,
        cwd: str | None = None,
        stderr_sink: Callable[[str], None] | None = None,
    ) -> None:
        if not command:
            raise MCPError("comando vazio para transporte stdio")
        exe = shutil.which(command[0]) or command[0]
        environment = {**os.environ, **(env or {})}
        try:
            self.proc = subprocess.Popen(
                [exe, *command[1:]],
                stdin=subprocess.PIPE,
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,
                env=environment,
                cwd=cwd,
                text=True,
                encoding="utf-8",
                bufsize=1,
            )
        except OSError as erro:
            raise MCPError(f"não foi possível iniciar {command[0]!r}: {erro}") from erro
        self.stderr_lines: list[str] = []
        self._sink = stderr_sink
        self._lock = threading.RLock()
        self._noise: list[str] = []
        self._drain = threading.Thread(target=self._drain_stderr, daemon=True)
        self._drain.start()

    def _drain_stderr(self) -> None:
        stream = self.proc.stderr
        if stream is None:  # pragma: no cover
            return
        for line in stream:
            line = line.rstrip("\n")
            self.stderr_lines.append(line)
            if self._sink:
                self._sink(line)

    def _write(self, payload: Mapping[str, Any]) -> None:
        if self.proc.poll() is not None:
            raise MCPError(
                f"o servidor MCP saiu com código {self.proc.returncode}; "
                f"stderr: {' | '.join(self.stderr_lines[-3:]) or '(vazio)'}"
            )
        line = json.dumps(payload, ensure_ascii=False, default=str)
        if "\n" in line:  # pragma: no cover — json.dumps já escapa
            raise MCPError("mensagem com nova linha embutida")
        assert self.proc.stdin is not None
        self.proc.stdin.write(line + "\n")
        self.proc.stdin.flush()

    def _consume(self, line: str, wanted: Any) -> dict[str, Any] | None:
        """Uma linha do servidor: a resposta esperada, ou algo a despachar."""
        line = line.strip()
        if not line:
            return None
        try:
            message = json.loads(line)
        except json.JSONDecodeError:
            # stdout sujo: o servidor violou a especificação. Registrar e
            # seguir é melhor que perder a sessão por um banner.
            self._noise.append(line[:200])
            return None
        if not isinstance(message, dict):
            self._noise.append(line[:200])
            return None
        if message.get("method"):
            # Requisição ou notificação do servidor.
            self._noise.append(line[:200])
            answer = self._handle_incoming(message)
            if answer is not None:
                self._write(answer)
            return None
        if wanted is not None and message.get("id") == wanted:
            return message
        self._noise.append(line[:200])  # resposta de outro id
        return None

    def request(self, payload: dict[str, Any], timeout: float) -> dict[str, Any]:
        with self._lock:
            self._write(payload)
            wanted = payload.get("id")
            deadline = time.monotonic() + timeout
            assert self.proc.stdout is not None
            while True:
                if time.monotonic() > deadline:
                    raise MCPError(f"tempo esgotado ({timeout}s) esperando {payload.get('method')}")
                line = self.proc.stdout.readline()
                if line == "":
                    raise MCPError(
                        "o servidor MCP fechou stdout; "
                        f"stderr: {' | '.join(self.stderr_lines[-3:]) or '(vazio)'}"
                    )
                message = self._consume(line, wanted)
                if message is not None:
                    return message

    def notify(self, payload: dict[str, Any]) -> None:
        with self._lock:
            self._write(payload)

    def pump(self, timeout: float = 0.1) -> int:
        """Drena e despacha o que o servidor mandou com o cliente ocioso.

        Usa `select` no descritor do stdout. Em plataforma onde `select` não
        aceita pipe (Windows), devolve 0 em vez de bloquear — e é melhor não
        drenar do que travar o laço do agente.
        """
        import select

        entregues = 0
        with self._lock:
            stream = self.proc.stdout
            if stream is None:  # pragma: no cover
                return 0
            deadline = time.monotonic() + max(0.0, timeout)
            while True:
                restante = deadline - time.monotonic()
                if restante <= 0:
                    return entregues
                try:
                    pronto, _, _ = select.select([stream], [], [], restante)
                except (OSError, ValueError):  # pragma: no cover — pipe sem select
                    return entregues
                if not pronto:
                    return entregues
                line = stream.readline()
                if line == "":
                    return entregues
                self._consume(line, None)
                entregues += 1

    @property
    def notices(self) -> list[str]:
        """O que veio do servidor e não era a resposta esperada: notificações e ruído."""
        return list(self._noise)

    def close(self) -> None:
        # A ordem é a da especificação: fechar stdin, esperar, TERM, KILL.
        with contextlib.suppress(Exception):  # fechar nunca derruba a execução
            if self.proc.stdin and not self.proc.stdin.closed:
                self.proc.stdin.close()
            try:
                self.proc.wait(timeout=2.0)
            except subprocess.TimeoutExpired:
                self.proc.terminate()
                try:
                    self.proc.wait(timeout=2.0)
                except subprocess.TimeoutExpired:  # pragma: no cover
                    self.proc.kill()


class StreamableHTTPTransport(_Dispatching):
    """Um endpoint HTTP, POST para enviar, SSE quando o servidor preferir streaming.

    `Accept` lista os dois tipos porque a especificação deixa a escolha com o
    servidor; `MCP-Session-Id` é ecoado quando o servidor o emite no
    `InitializeResult`; `MCP-Protocol-Version` acompanha toda requisição depois
    da negociação. 404 numa sessão significa sessão expirada — e a reação certa
    é reinicializar, não repetir.

    Requisição do servidor chega **dentro** do fluxo SSE aberto pelo POST; a
    resposta do cliente volta num POST novo, como manda o transporte.
    """

    def __init__(
        self,
        url: str,
        *,
        headers: Mapping[str, str] | None = None,
        opener: Callable[[urllib.request.Request, float], Any] | None = None,
    ) -> None:
        self.url = url
        self.headers = dict(headers or {})
        self.session_id = ""
        self.protocol_version = ""
        self._open = opener or (lambda req, timeout: urllib.request.urlopen(req, timeout=timeout))

    def _headers(self) -> dict[str, str]:
        h = {
            "Content-Type": "application/json",
            "Accept": "application/json, text/event-stream",
            **self.headers,
        }
        if self.session_id:
            h["MCP-Session-Id"] = self.session_id
        if self.protocol_version:
            h["MCP-Protocol-Version"] = self.protocol_version
        return h

    def _post(self, payload: Mapping[str, Any], timeout: float) -> tuple[int, dict[str, str], str]:
        body = json.dumps(payload, ensure_ascii=False, default=str).encode("utf-8")
        req = urllib.request.Request(self.url, data=body, headers=self._headers(), method="POST")
        try:
            with self._open(req, timeout) as resp:
                raw = resp.read()
                text = raw.decode("utf-8") if isinstance(raw, bytes) else str(raw)
                headers = {k.lower(): v for k, v in dict(resp.headers).items()}
                return int(resp.status), headers, text
        except urllib.error.HTTPError as erro:  # 4xx/5xx trazem corpo útil
            text = erro.read().decode("utf-8", "replace")
            headers = {k.lower(): v for k, v in dict(erro.headers or {}).items()}
            return int(erro.code), headers, text
        except OSError as erro:
            raise MCPError(f"falha de rede falando com {self.url}: {erro}") from erro

    def _consume_sse(self, text: str, wanted: Any) -> dict[str, Any] | None:
        """Percorre o fluxo: despacha o que o servidor pediu, devolve a resposta esperada."""
        achado: dict[str, Any] | None = None
        for block in text.split("\n\n"):
            data = "".join(
                line[5:].lstrip() for line in block.splitlines() if line.startswith("data:")
            )
            if not data:
                continue
            try:
                message = json.loads(data)
            except json.JSONDecodeError:
                continue
            if not isinstance(message, dict):
                continue
            if message.get("method"):
                answer = self._handle_incoming(message)
                if answer is not None:
                    self._post(answer, DEFAULT_TIMEOUT)
                continue
            if achado is None and message.get("id") == wanted:
                achado = message
        return achado

    def request(self, payload: dict[str, Any], timeout: float) -> dict[str, Any]:
        status, headers, text = self._post(payload, timeout)
        if status == 404 and self.session_id:
            raise MCPError("sessão MCP expirada (HTTP 404): é preciso reinicializar")
        if status >= 400:
            raise MCPError(f"HTTP {status} de {self.url}: {text[:300]}")
        sid = headers.get("mcp-session-id")
        if sid:
            self.session_id = sid
        ctype = headers.get("content-type", "")
        if "text/event-stream" in ctype:
            message = self._consume_sse(text, payload.get("id"))
            if message is None:
                raise MCPError(f"fluxo SSE sem resposta para id={payload.get('id')!r}")
            return message
        return dict(json.loads(text))

    def notify(self, payload: dict[str, Any]) -> None:
        status, _headers, text = self._post(payload, DEFAULT_TIMEOUT)
        # A especificação manda 202 Accepted sem corpo para notificações.
        if status >= 400:
            raise MCPError(f"HTTP {status} ao notificar {payload.get('method')}: {text[:200]}")

    def pump(self, timeout: float = 0.0) -> int:
        """GET com SSE para ouvir o servidor com o cliente ocioso.

        Não implementado: exige manter um fluxo aberto em paralelo, e um fluxo
        pendurado é pior que nenhum. Requisições do servidor continuam sendo
        atendidas dentro do POST que as provoca — que é o caso da
        especificação (`nested inside other MCP server features`).
        """
        return 0

    def close(self) -> None:
        if not self.session_id:
            return
        req = urllib.request.Request(self.url, headers=self._headers(), method="DELETE")
        # 405 Method Not Allowed é resposta legítima: o servidor não deixa o
        # cliente encerrar a sessão. Encerrar nunca derruba a execução.
        with contextlib.suppress(Exception):
            self._open(req, 5.0).close()
