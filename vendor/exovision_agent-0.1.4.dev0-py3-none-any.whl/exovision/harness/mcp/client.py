"""A sessão MCP inteira: ferramentas, recursos, prompts, tarefas — e o retorno.

O cliente antigo só falava. Este também **responde**: `sampling/createMessage`,
`elicitation/create` e `roots/list` chegam do servidor, e o despacho acontece
dentro da própria espera, que é onde a especificação diz que eles acontecem
(*"nested inside other MCP server features"*).

## O que é declarado é o que é atendido

`initialize` anuncia exatamente as capacidades que têm implementação:
`sampling` só com um `Sampler`, `elicitation` só com um `Elicitor` (e só os
modos que ele tem), `roots` só com uma lista. Declarar o que não se atende
ensina o servidor a contar com o que não existe — e a especificação usa o
anúncio como contrato: o servidor **não deve** mandar o que o cliente não
declarou.

## Três superfícies, três modelos de interação

A especificação separa por quem controla:

- **Ferramentas** são *model-controlled*: o modelo escolhe e chama.
- **Recursos** são *application-driven*: a aplicação decide o que entra no
  contexto. Num agente, a aplicação é o harness — daí `ResourceToolset`
  (o modelo puxa sob demanda) e `resources_as_context` (o operador injeta),
  em `bridge.py`.
- **Prompts** são *user-controlled*: aparecem como comando, não como
  ferramenta. `PromptLibrary` serve ao operador; quem quiser expô-los ao
  modelo faz isso explicitamente, via skills.

Misturar os três num só balde é o erro que faz um agente chamar um prompt
achando que é ferramenta.

## Tarefas

Um pedido caro vira estado durável: `tools/call` com `task` no params devolve
um `CreateTaskResult`, e o resultado sai depois em `tasks/result`. A
negociação é em duas camadas — capacidade do servidor
(`tasks.requests.tools.call`) **e** `execution.taskSupport` por ferramenta —
e as duas são conferidas aqui, porque usar tarefa onde o servidor não suporta
é `-32601` na cara do modelo.
"""

from __future__ import annotations

import contextlib
import time
from collections.abc import Callable, Mapping
from typing import Any

from ... import __version__
from .handlers import Elicitor, RootsProvider, Sampler
from .types import (
    Elicitation,
    MCPTool,
    Prompt,
    PromptMessage,
    Resource,
    ResourceContent,
    ResourceTemplate,
    Task,
)
from .wire import (
    DEFAULT_TIMEOUT,
    ERR_INTERNAL,
    ERR_INVALID_PARAMS,
    ERR_METHOD_NOT_FOUND,
    ERR_USER_REJECTED,
    MCPDenied,
    MCPError,
    StreamableHTTPTransport,
    Transport,
    error_response,
    result_response,
    sanitize,
)

__all__ = [
    "CLIENT_NAME",
    "CLIENT_VERSION",
    "PROTOCOL_VERSION",
    "RELATED_TASK",
    "SUPPORTED_PROTOCOLS",
    "MCPClient",
    "related_task",
    "task_id_of",
]

#: Versão do protocolo que este cliente fala. Enviada em `initialize`; se o
#: servidor responder outra, ela é aceita quando conhecida e recusada quando
#: não (MCP 2025-11-25, `basic/lifecycle#version-negotiation`).
PROTOCOL_VERSION = "2025-11-25"
SUPPORTED_PROTOCOLS: tuple[str, ...] = (
    "2025-11-25",
    "2025-06-18",
    "2025-03-26",
    "2024-11-05",
)

CLIENT_NAME = "exovision-agent"
CLIENT_VERSION = __version__  # o que o servidor vê em `clientInfo` é a versão do pacote

#: Chave de `_meta` que amarra toda mensagem de uma tarefa à tarefa.
RELATED_TASK = "io.modelcontextprotocol/related-task"


class MCPClient:
    """Sessão MCP: inicializa, negocia, pede — e atende o que o servidor pedir."""

    def __init__(
        self,
        transport: Transport,
        *,
        timeout: float = DEFAULT_TIMEOUT,
        client_name: str = CLIENT_NAME,
        client_version: str = CLIENT_VERSION,
        sampler: Sampler | None = None,
        elicitor: Elicitor | None = None,
        roots: RootsProvider | None = None,
    ) -> None:
        self.transport = transport
        self.timeout = timeout
        self.client_name = client_name
        self.client_version = client_version
        self.sampler = sampler
        self.elicitor = elicitor
        self.roots = roots
        self.server_info: dict[str, Any] = {}
        self.capabilities: dict[str, Any] = {}
        self.instructions = ""
        self.protocol_version = ""
        self.notifications: list[dict[str, Any]] = []
        self._listeners: list[tuple[str, Callable[[dict[str, Any]], None]]] = []
        self._id = 0
        self._initialized = False
        transport.dispatch = self._dispatch

    # ------------------------------------------------------------ fio
    def _next_id(self) -> int:
        self._id += 1
        return self._id

    def call(
        self,
        method: str,
        params: dict[str, Any] | None = None,
        *,
        timeout: float | None = None,
    ) -> dict[str, Any]:
        """Uma requisição JSON-RPC. Erro de protocolo vira `MCPError`."""
        payload: dict[str, Any] = {"jsonrpc": "2.0", "id": self._next_id(), "method": method}
        if params is not None:
            payload["params"] = params
        message = self.transport.request(payload, timeout if timeout is not None else self.timeout)
        if "error" in message:
            err = message["error"] or {}
            raise MCPError(
                f"{method}: [{err.get('code', '?')}] {err.get('message', 'erro sem mensagem')}"
            )
        result = message.get("result")
        return dict(result) if isinstance(result, dict) else {}

    def notify(self, method: str, params: Mapping[str, Any] | None = None) -> None:
        payload: dict[str, Any] = {"jsonrpc": "2.0", "method": method}
        if params is not None:
            payload["params"] = dict(params)
        self.transport.notify(payload)

    # ------------------------------------------------- servidor -> cliente
    def on(self, method: str, listener: Callable[[dict[str, Any]], None]) -> None:
        """Escuta uma notificação do servidor (`notifications/...`), ou `*`."""
        self._listeners.append((method, listener))

    def pump(self, timeout: float = 0.1) -> int:
        """Drena notificações pendentes com o cliente ocioso."""
        return self.transport.pump(timeout)

    def _server_name(self) -> str:
        return str(self.server_info.get("name") or "servidor MCP")

    def _dispatch(self, message: Mapping[str, Any]) -> dict[str, Any] | None:
        method = str(message.get("method") or "")
        params = message.get("params") or {}
        request_id = message.get("id")

        if request_id is None:  # notificação
            self.notifications.append(dict(message))
            for wanted, listener in self._listeners:
                if wanted in ("*", method):
                    with contextlib.suppress(Exception):  # observar não é participar
                        listener(dict(message))
            return None

        if method == "ping":
            return result_response(request_id, {})

        if method == "roots/list":
            if self.roots is None:
                return error_response(
                    request_id, ERR_METHOD_NOT_FOUND, "este cliente não expõe roots"
                )
            return result_response(request_id, {"roots": [r.to_wire() for r in self.roots()]})

        if method == "sampling/createMessage":
            if self.sampler is None:
                return error_response(
                    request_id, ERR_METHOD_NOT_FOUND, "este cliente não implementa sampling"
                )
            try:
                out = self.sampler(params, server=self._server_name())
            except MCPDenied as erro:
                return error_response(request_id, ERR_USER_REJECTED, str(erro))
            except Exception as erro:
                return error_response(request_id, ERR_INTERNAL, f"{type(erro).__name__}: {erro}")
            return result_response(request_id, out)

        if method == "elicitation/create":
            if self.elicitor is None:
                return error_response(
                    request_id, ERR_METHOD_NOT_FOUND, "este cliente não implementa elicitation"
                )
            pedido = Elicitation.from_wire(params, server=self._server_name())
            declarado = self.elicitor.capability
            if pedido.mode not in declarado:
                return error_response(
                    request_id,
                    ERR_INVALID_PARAMS,
                    f"modo {pedido.mode!r} não declarado por este cliente",
                )
            try:
                acao, conteudo = self.elicitor(pedido)
            except MCPDenied as erro:
                return error_response(request_id, ERR_USER_REJECTED, str(erro))
            except Exception as erro:
                return error_response(request_id, ERR_INTERNAL, f"{type(erro).__name__}: {erro}")
            saida: dict[str, Any] = {"action": acao}
            if acao == "accept" and pedido.mode == "form":
                saida["content"] = conteudo
            return result_response(request_id, saida)

        return error_response(
            request_id, ERR_METHOD_NOT_FOUND, f"este cliente não implementa {method!r}"
        )

    # ------------------------------------------------------------- ciclo
    def client_capabilities(self) -> dict[str, Any]:
        """Só o que tem implementação. Declarar a mais é mentir por omissão."""
        cap: dict[str, Any] = {}
        if self.roots is not None:
            cap["roots"] = {"listChanged": bool(getattr(self.roots, "list_changed", False))}
        if self.sampler is not None:
            cap["sampling"] = dict(self.sampler.capability)
        if self.elicitor is not None:
            modos = dict(self.elicitor.capability)
            if not modos:
                raise MCPError("o elicitor precisa declarar ao menos um modo (form ou url)")
            cap["elicitation"] = modos
        return cap

    def initialize(self) -> dict[str, Any]:
        result = self.call(
            "initialize",
            {
                "protocolVersion": PROTOCOL_VERSION,
                "capabilities": self.client_capabilities(),
                "clientInfo": {"name": self.client_name, "version": self.client_version},
            },
        )
        negotiated = str(result.get("protocolVersion") or "")
        if negotiated and negotiated not in SUPPORTED_PROTOCOLS:
            raise MCPError(
                f"o servidor respondeu protocolo {negotiated!r}, que este cliente não fala "
                f"(suportados: {list(SUPPORTED_PROTOCOLS)})"
            )
        self.protocol_version = negotiated or PROTOCOL_VERSION
        self.server_info = dict(result.get("serverInfo") or {})
        self.capabilities = dict(result.get("capabilities") or {})
        self.instructions = sanitize(str(result.get("instructions") or ""))
        if isinstance(self.transport, StreamableHTTPTransport):
            self.transport.protocol_version = self.protocol_version
        self.notify("notifications/initialized")
        self._initialized = True
        return result

    def ensure(self) -> None:
        if not self._initialized:
            self.initialize()

    def supports(self, *caminho: str) -> bool:
        """`supports("resources", "subscribe")` — capacidade aninhada do servidor."""
        atual: Any = self.capabilities
        for parte in caminho:
            if not isinstance(atual, Mapping) or parte not in atual:
                return False
            atual = atual[parte]
        return True

    def _paginate(self, method: str, chave: str, params: dict[str, Any] | None = None) -> list[Any]:
        """Percorre `nextCursor` até o fim. Cursor repetido é servidor em laço."""
        self.ensure()
        itens: list[Any] = []
        cursor: str | None = None
        vistos: set[str] = set()
        while True:
            corpo = dict(params or {})
            if cursor:
                corpo["cursor"] = cursor
            result = self.call(method, corpo)
            itens.extend(result.get(chave) or [])
            cursor = result.get("nextCursor") or None
            if not cursor or cursor in vistos:
                break
            vistos.add(cursor)
        return itens

    # -------------------------------------------------------- ferramentas
    def list_tools(self) -> list[MCPTool]:
        self.ensure()
        if self.capabilities and not self.supports("tools"):
            return []
        return [
            MCPTool.from_wire(raw)
            for raw in self._paginate("tools/list", "tools")
            if isinstance(raw, Mapping) and raw.get("name")
        ]

    def call_tool(self, name: str, arguments: Mapping[str, Any]) -> dict[str, Any]:
        self.ensure()
        return self.call("tools/call", {"name": name, "arguments": dict(arguments)})

    # ----------------------------------------------------------- recursos
    def list_resources(self) -> list[Resource]:
        self.ensure()
        if self.capabilities and not self.supports("resources"):
            return []
        return [
            Resource.from_wire(raw)
            for raw in self._paginate("resources/list", "resources")
            if isinstance(raw, Mapping) and raw.get("uri")
        ]

    def list_resource_templates(self) -> list[ResourceTemplate]:
        if self.capabilities and not self.supports("resources"):
            return []
        try:
            brutos = self._paginate("resources/templates/list", "resourceTemplates")
        except MCPError:
            # Servidor com recursos mas sem templates devolve -32601. Ausência
            # de templates não é falha de sessão.
            return []
        return [
            ResourceTemplate.from_wire(raw)
            for raw in brutos
            if isinstance(raw, Mapping) and raw.get("uriTemplate")
        ]

    def read_resource(self, uri: str) -> list[ResourceContent]:
        self.ensure()
        result = self.call("resources/read", {"uri": uri})
        return [
            ResourceContent.from_wire(raw)
            for raw in (result.get("contents") or [])
            if isinstance(raw, Mapping)
        ]

    def subscribe_resource(self, uri: str) -> bool:
        """`resources/subscribe`. Falso quando o servidor não declarou `subscribe`."""
        self.ensure()
        if not self.supports("resources", "subscribe"):
            return False
        self.call("resources/subscribe", {"uri": uri})
        return True

    def unsubscribe_resource(self, uri: str) -> bool:
        self.ensure()
        if not self.supports("resources", "subscribe"):
            return False
        self.call("resources/unsubscribe", {"uri": uri})
        return True

    # ------------------------------------------------------------ prompts
    def list_prompts(self) -> list[Prompt]:
        self.ensure()
        if self.capabilities and not self.supports("prompts"):
            return []
        return [
            Prompt.from_wire(raw)
            for raw in self._paginate("prompts/list", "prompts")
            if isinstance(raw, Mapping) and raw.get("name")
        ]

    def get_prompt(
        self, name: str, arguments: Mapping[str, Any] | None = None
    ) -> tuple[str, list[PromptMessage]]:
        """`(descrição, mensagens)` do prompt renderizado pelo servidor."""
        self.ensure()
        params: dict[str, Any] = {"name": name}
        if arguments:
            params["arguments"] = {k: str(v) for k, v in arguments.items()}
        result = self.call("prompts/get", params)
        mensagens = [
            PromptMessage.from_wire(m)
            for m in (result.get("messages") or [])
            if isinstance(m, Mapping)
        ]
        return sanitize(str(result.get("description") or "")), mensagens

    # ----------------------------------------------------------- completar
    def complete(
        self,
        ref: Mapping[str, Any],
        argument_name: str,
        argument_value: str,
        *,
        context: Mapping[str, Any] | None = None,
    ) -> dict[str, Any]:
        """`completion/complete` para argumento de prompt ou variável de template."""
        self.ensure()
        if not self.supports("completions"):
            return {"values": [], "total": 0, "hasMore": False}
        params: dict[str, Any] = {
            "ref": dict(ref),
            "argument": {"name": argument_name, "value": argument_value},
        }
        if context:
            params["context"] = {"arguments": dict(context)}
        result = self.call("completion/complete", params)
        completion = dict(result.get("completion") or {})
        completion["values"] = [sanitize(str(v)) for v in (completion.get("values") or [])][:100]
        return completion

    # ------------------------------------------------------------ tarefas
    def task_calls_supported(self, tool: MCPTool | None = None) -> bool:
        """As duas camadas da negociação: capacidade do servidor e da ferramenta."""
        if not self.supports("tasks", "requests", "tools", "call"):
            return False
        if tool is None:
            return True
        return tool.task_support in ("optional", "required")

    def call_tool_task(
        self, name: str, arguments: Mapping[str, Any], *, ttl_ms: int | None = None
    ) -> Task:
        """`tools/call` aumentado com tarefa. Devolve o `Task`, não o resultado."""
        self.ensure()
        params: dict[str, Any] = {"name": name, "arguments": dict(arguments)}
        params["task"] = {"ttl": int(ttl_ms)} if ttl_ms else {}
        result = self.call("tools/call", params)
        bruto = result.get("task")
        if not isinstance(bruto, Mapping):
            raise MCPError(
                f"o servidor aceitou a tarefa mas não devolveu CreateTaskResult: {result!r}"
            )
        return Task.from_wire(bruto)

    def get_task(self, task_id: str) -> Task:
        self.ensure()
        return Task.from_wire(self.call("tasks/get", {"taskId": task_id}))

    def task_result(self, task_id: str, *, timeout: float | None = None) -> dict[str, Any]:
        """`tasks/result`. Bloqueia até o estado terminal — é assim por especificação."""
        self.ensure()
        return self.call("tasks/result", {"taskId": task_id}, timeout=timeout)

    def list_tasks(self) -> list[Task]:
        self.ensure()
        if not self.supports("tasks", "list"):
            return []
        return [
            Task.from_wire(raw)
            for raw in self._paginate("tasks/list", "tasks")
            if isinstance(raw, Mapping)
        ]

    def cancel_task(self, task_id: str) -> Task:
        self.ensure()
        if not self.supports("tasks", "cancel"):
            raise MCPError("o servidor não declarou `tasks.cancel`")
        return Task.from_wire(self.call("tasks/cancel", {"taskId": task_id}))

    def await_task(
        self,
        task: Task | str,
        *,
        max_wait_s: float = 300.0,
        poll_s: float | None = None,
        sleep: Callable[[float], None] = time.sleep,
        on_poll: Callable[[Task], None] | None = None,
    ) -> dict[str, Any]:
        """Acompanha até o fim e devolve o resultado do pedido original.

        `input_required` **não** é terminal: é o servidor dizendo que tem um
        pedido para o cliente. A reação certa é chamar `tasks/result`, que é
        onde esse pedido chega — e o despacho do transporte o atende.
        """
        estado = task if isinstance(task, Task) else self.get_task(task)
        task_id = estado.task_id
        limite = time.monotonic() + max_wait_s
        while True:
            if on_poll:
                on_poll(estado)
            if estado.terminal or estado.status == "input_required":
                return self.task_result(task_id)
            if time.monotonic() > limite:
                raise MCPError(
                    f"tarefa {task_id} não terminou em {max_wait_s}s (status {estado.status!r})"
                )
            intervalo = poll_s
            if intervalo is None:
                intervalo = (estado.poll_interval or 500) / 1000.0
            sleep(max(0.0, min(intervalo, max(0.0, limite - time.monotonic()))))
            estado = self.get_task(task_id)

    # ------------------------------------------------------------- outros
    def ping(self) -> bool:
        try:
            self.call("ping", {})
            return True
        except MCPError:
            return False

    def set_log_level(self, level: str) -> bool:
        """`logging/setLevel`. Falso quando o servidor não declarou `logging`."""
        self.ensure()
        if not self.supports("logging"):
            return False
        self.call("logging/setLevel", {"level": level})
        return True

    def close(self) -> None:
        self.transport.close()


def related_task(task_id: str) -> dict[str, Any]:
    """O `_meta` que amarra uma mensagem à tarefa dela."""
    return {RELATED_TASK: {"taskId": task_id}}


def task_id_of(meta: Mapping[str, Any] | None) -> str:
    """Lê `io.modelcontextprotocol/related-task` de um `_meta`, se houver."""
    if not isinstance(meta, Mapping):
        return ""
    bloco = meta.get(RELATED_TASK)
    return str(bloco.get("taskId") or "") if isinstance(bloco, Mapping) else ""
