"""As ferramentas de um servidor MCP com a superfície `Toolset` do harness.

O laço exige de qualquer ferramentaria apenas `definitions()` e `__call__`.
Um servidor MCP é, do ponto de vista do laço, mais uma ferramentaria — e é
isso que impede o laço de ganhar um `if` por origem de ferramenta.

## A fronteira de confiança é o centro deste módulo

A especificação é explícita: *"clients **MUST** consider tool annotations to
be untrusted unless they come from trusted servers"* (MCP 2025-11-25,
`server/tools`). A literatura mediu o custo de ignorar: Tool Poisoning
(arXiv:2508.14925, até 72,8% de sucesso em 353 ferramentas de 45 servidores
reais), rug pull (arXiv:2506.01333) e ocultação em Unicode, onde a tela de
aprovação e o prompt divergem (arXiv:2607.05744).

Três defesas estruturais, não heurísticas de prompt:

1. **Anotação não reduz risco.** `risk_floor` (padrão `external`) é piso; as
   anotações só sobem.
2. **Pino de integridade.** SHA-256 de (descrição, schema) na conexão;
   redefinição põe em quarentena (ou levanta, com `strict_pin`).
3. **Ocultação é recusa.** Caractere invisível quarentena a ferramenta; o que
   chega ao prompt é sempre o texto sanitizado.

## Descoberta ativa

Injetar o catálogo inteiro custa caro: ~3.000 ferramentas ≈ 248.100 tokens de
prefixo, e a descoberta sob demanda corta ~98% disso (MCP-Zero,
arXiv:2506.01056; ScaleMCP, arXiv:2505.06416). `expose="index"` publica
`mcp_find` e `mcp_call`; `catalog_chars()` mede os dois regimes.

## Tarefas

`execution.taskSupport` por ferramenta e `tasks.requests.tools.call` do
servidor são as duas camadas da negociação. Uma ferramenta que **exige**
tarefa e um cliente que não as usa não combinam: em vez de deixar o modelo
chamar e tomar `-32601`, a ferramenta entra em quarentena com a razão.
"""

from __future__ import annotations

import json
from collections.abc import Iterable, Mapping, Sequence
from typing import Any

from ..tools import RISK_LEVELS, ToolResult
from .client import MCPClient
from .types import MCPTool
from .wire import (
    DEFAULT_TIMEOUT,
    MCPError,
    MCPIntegrityError,
    StdioTransport,
    StreamableHTTPTransport,
    sanitize,
)

__all__ = ["MCPToolset"]

_MAX_TEXT = 60_000


def _clean_name(name: str) -> str:
    """Nome de ferramenta MCP (`admin.tools.list`) -> nome aceito pela Messages API."""
    out = "".join(c if (c.isalnum() or c in "_-") else "_" for c in name)
    return out[:120] or "tool"


def blocks_to_result(result: Mapping[str, Any], *, tool: str) -> ToolResult:
    """`content` MCP -> `ToolResult`. Texto para o modelo, estado para o runtime."""
    is_error = bool(result.get("isError"))
    texts: list[str] = []
    blocks: list[dict[str, Any]] = []
    for raw in result.get("content") or []:
        if not isinstance(raw, Mapping):
            continue
        kind = raw.get("type")
        if kind == "text":
            texts.append(sanitize(str(raw.get("text", ""))))
        elif kind in ("image", "audio") and raw.get("data"):
            # Imagem volta como bloco de fio; áudio não tem bloco equivalente
            # na Messages API e vira menção textual honesta.
            if kind == "image":
                blocks.append(
                    {
                        "type": "image",
                        "source": {
                            "type": "base64",
                            "media_type": str(raw.get("mimeType") or "image/png"),
                            "data": str(raw.get("data")),
                        },
                    }
                )
            else:
                texts.append(f"[áudio {raw.get('mimeType', '?')}, {len(str(raw.get('data')))} B]")
        elif kind == "resource_link":
            texts.append(f"[recurso] {raw.get('uri', '')} {sanitize(str(raw.get('name') or ''))}")
        elif kind == "resource":
            res = raw.get("resource") or {}
            body = res.get("text")
            if body is None:
                texts.append(f"[recurso binário] {res.get('uri', '')}")
            else:
                texts.append(f"[{res.get('uri', '')}]\n{sanitize(str(body))}")
    structured = result.get("structuredContent")
    if structured is not None and not texts:
        texts.append(json.dumps(structured, ensure_ascii=False, default=str))
    text = "\n".join(t for t in texts if t)
    if len(text) > _MAX_TEXT:
        text = text[:_MAX_TEXT] + f"\n… [truncado: {len(text)} caracteres]"
    if blocks and text:
        blocks.insert(0, {"type": "text", "text": text})
    metadata: dict[str, Any] = {"mcp_tool": tool}
    if structured is not None:
        metadata["structured"] = structured
    return ToolResult(
        text=text or ("(sem conteúdo)" if not blocks else ""),
        ok=not is_error,
        code=1 if is_error else 0,
        metadata=metadata,
        blocks=tuple(blocks),
    )


def _risk_from_annotations(ann: Mapping[str, Any], floor: str) -> str:
    """Anotação do servidor, com piso. A anotação só sobe o risco, nunca desce."""
    floor_i = RISK_LEVELS.index(floor)
    if ann.get("destructiveHint") is True:
        derived = RISK_LEVELS.index("irreversible")
    elif ann.get("readOnlyHint") is True:
        derived = RISK_LEVELS.index("read")
    elif ann.get("openWorldHint") is True:
        derived = RISK_LEVELS.index("external")
    else:
        derived = RISK_LEVELS.index("write")
    return RISK_LEVELS[max(floor_i, derived)]


class MCPToolset:
    """Um servidor MCP com a superfície `Toolset` — e a fronteira de confiança fechada.

    Argumentos que decidem postura (e que são, deliberadamente, explícitos):

    - `risk_floor` (padrão `external`): o piso de risco de toda ferramenta
      deste servidor. Um servidor MCP é código de terceiro falando com o mundo;
      tratá-lo como `read` porque ele mesmo se declarou `readOnlyHint` é
      confiar no réu.
    - `trust_annotations` (padrão `False`): quando `True`, as anotações podem
      *subir* o risco acima do piso e marcar `parallel_safe`.
    - `pin` (padrão `True`): guarda o digest de cada definição; mudança
      posterior põe em quarentena. `strict_pin=True` troca a quarentena por
      `MCPIntegrityError`.
    - `reject_concealed` (padrão `True`): descrição com caractere invisível
      entra em quarentena.
    - `expose` (`"all"` | `"index"`): catálogo no prefixo ou descoberta ativa.
    - `use_tasks` (padrão `False`): usa execução como tarefa quando as duas
      camadas da negociação permitem.
    """

    def __init__(
        self,
        client: MCPClient,
        *,
        prefix: str = "",
        risk_floor: str = "external",
        trust_annotations: bool = False,
        pin: bool = True,
        strict_pin: bool = False,
        reject_concealed: bool = True,
        allow: Iterable[str] | None = None,
        deny: Iterable[str] = (),
        expose: str = "all",
        use_tasks: bool = False,
        task_ttl_ms: int = 300_000,
        task_max_wait_s: float = 300.0,
        connect: bool = True,
    ) -> None:
        if risk_floor not in RISK_LEVELS:
            raise MCPError(f"risco {risk_floor!r} fora de {RISK_LEVELS}")
        if expose not in ("all", "index"):
            raise MCPError(f"expose {expose!r}: use 'all' ou 'index'")
        self.client = client
        self.prefix = prefix
        self.risk_floor = risk_floor
        self.trust_annotations = trust_annotations
        self.pin = pin
        self.strict_pin = strict_pin
        self.reject_concealed = reject_concealed
        self.allow = frozenset(allow) if allow is not None else None
        self.deny = frozenset(deny)
        self.expose = expose
        self.use_tasks = use_tasks
        self.task_ttl_ms = task_ttl_ms
        self.task_max_wait_s = task_max_wait_s
        self.tools: dict[str, MCPTool] = {}
        self.remote_name: dict[str, str] = {}
        self.pinned: dict[str, str] = {}
        self.quarantined: dict[str, str] = {}
        self.tasks_run: list[str] = []
        if connect:
            self.refresh()

    # ------------------------------------------------------- catálogo
    def _local(self, remote: str) -> str:
        base = _clean_name(remote)
        return f"{self.prefix}_{base}" if self.prefix else base

    def refresh(self) -> dict[str, str]:
        """(Re)lista o servidor. Devolve as quarentenas abertas nesta passada."""
        opened: dict[str, str] = {}
        tools: dict[str, MCPTool] = {}
        remote_name: dict[str, str] = {}
        for t in self.client.list_tools():
            if self.allow is not None and t.name not in self.allow:
                continue
            if t.name in self.deny:
                continue
            local = self._local(t.name)
            if local in tools:
                opened[local] = f"nome duplicado no servidor: {t.name!r}"
                self.quarantined[local] = opened[local]
                continue
            if self.reject_concealed and t.concealed:
                opened[local] = (
                    "descrição com caractere de ocultação Unicode "
                    f"({t.concealed}); a tela de aprovação e o prompt divergiriam"
                )
                self.quarantined[local] = opened[local]
                continue
            if t.task_support == "required" and not self._task_ready(t):
                opened[local] = (
                    "a ferramenta exige execução como tarefa (`execution.taskSupport: "
                    "required`) e esta sessão não a usa; chamá-la daria -32601"
                )
                self.quarantined[local] = opened[local]
                continue
            known = self.pinned.get(local)
            if self.pin and known is not None and known != t.digest:
                opened[local] = (
                    f"definição mudou depois do pino ({known} -> {t.digest}): "
                    "possível rug pull; reconecte explicitamente para aceitar"
                )
                if self.strict_pin:
                    raise MCPIntegrityError(f"{t.name!r}: {opened[local]}")
                self.quarantined[local] = opened[local]
                continue
            tools[local] = t
            remote_name[local] = t.name
            self.pinned.setdefault(local, t.digest)
            self.quarantined.pop(local, None)
        self.tools = tools
        self.remote_name = remote_name
        return opened

    def _task_ready(self, tool: MCPTool) -> bool:
        return self.use_tasks and self.client.task_calls_supported(tool)

    def catalog_chars(self) -> dict[str, int]:
        """Custo do catálogo nos dois regimes — a medida que justifica `expose`."""
        full = sum(
            len(json.dumps(self._definition(local, t), ensure_ascii=False))
            for local, t in self.tools.items()
        )
        index = sum(len(json.dumps(d, ensure_ascii=False)) for d in self._index_definitions())
        return {"all": full, "index": index, "tools": len(self.tools)}

    # ---------------------------------------------------- superfície
    def _definition(self, local: str, t: MCPTool) -> dict[str, Any]:
        schema = t.input_schema if isinstance(t.input_schema, dict) else {"type": "object"}
        if schema.get("type") != "object":
            schema = {"type": "object", "properties": {}}
        return {
            "name": local,
            "description": t.description or f"Ferramenta {t.name} do servidor MCP.",
            "input_schema": schema,
        }

    def _index_definitions(self) -> list[dict[str, Any]]:
        find = f"{self.prefix}_mcp_find" if self.prefix else "mcp_find"
        call = f"{self.prefix}_mcp_call" if self.prefix else "mcp_call"
        return [
            {
                "name": find,
                "description": (
                    "Procura ferramentas disponíveis no servidor MCP por palavra-chave e "
                    "devolve nome, descrição e schema das que casam. Use antes de mcp_call "
                    "quando não souber o nome exato."
                ),
                "input_schema": {
                    "type": "object",
                    "properties": {
                        "query": {"type": "string", "description": "palavras-chave"},
                        "limit": {"type": "integer", "description": "máximo de resultados"},
                    },
                    "required": ["query"],
                },
            },
            {
                "name": call,
                "description": (
                    "Executa uma ferramenta do servidor MCP pelo nome exato devolvido por "
                    "mcp_find, com os argumentos exigidos pelo schema dela."
                ),
                "input_schema": {
                    "type": "object",
                    "properties": {
                        "name": {"type": "string", "description": "nome exato da ferramenta"},
                        "arguments": {"type": "object", "description": "argumentos da ferramenta"},
                    },
                    "required": ["name"],
                },
            },
        ]

    def definitions(self) -> list[dict[str, Any]]:
        if self.expose == "index":
            return self._index_definitions()
        return [self._definition(local, t) for local, t in self.tools.items()]

    def names(self) -> list[str]:
        return list(self.tools)

    def parallel_safe(self, name: str) -> bool:
        if self.expose == "index":
            return name.endswith("mcp_find")
        t = self.tools.get(name)
        if t is None or not self.trust_annotations:
            return False
        return bool(t.annotations.get("readOnlyHint") is True)

    def risk(self, name: str) -> str:
        if self.expose == "index":
            return "read" if name.endswith("mcp_find") else self.risk_floor
        t = self.tools.get(name)
        if t is None:
            return "irreversible"
        if not self.trust_annotations:
            return self.risk_floor
        return _risk_from_annotations(t.annotations, self.risk_floor)

    # ---------------------------------------------------- execução
    def _find(self, query: str, limit: int = 5) -> ToolResult:
        terms = [w for w in str(query).lower().split() if w]
        scored: list[tuple[int, str, MCPTool]] = []
        for local, t in self.tools.items():
            hay = f"{local} {t.name} {t.title} {t.description}".lower()
            score = sum(hay.count(w) for w in terms)
            if score or not terms:
                scored.append((score, local, t))
        scored.sort(key=lambda x: (-x[0], x[1]))
        chosen = scored[: max(1, int(limit or 5))]
        if not chosen:
            return ToolResult(
                text=f"nenhuma ferramenta casa {query!r}. Disponíveis: {', '.join(self.tools)}",
                metadata={"matches": 0},
            )
        payload = [
            {"name": local, "description": t.description, "input_schema": t.input_schema}
            for _score, local, t in chosen
        ]
        return ToolResult(
            text=json.dumps(payload, ensure_ascii=False, indent=2),
            metadata={"matches": len(chosen), "of": len(self.tools)},
        )

    def invoke(self, local: str, arguments: dict[str, Any]) -> ToolResult:
        """Chama uma ferramenta pelo nome local. Falha vira resultado, não exceção."""
        if local in self.quarantined:
            return ToolResult.error(
                f"ferramenta {local!r} em quarentena: {self.quarantined[local]}",
                code=409,
                quarantine=self.quarantined[local],
            )
        remote = self.remote_name.get(local)
        if remote is None:
            return ToolResult.error(
                f"ferramenta desconhecida no servidor MCP: {local!r}. "
                f"Disponíveis: {', '.join(self.tools) or '(nenhuma)'}",
                code=404,
            )
        tool = self.tools[local]
        try:
            if self._task_ready(tool):
                tarefa = self.client.call_tool_task(
                    remote, dict(arguments), ttl_ms=self.task_ttl_ms
                )
                self.tasks_run.append(tarefa.task_id)
                raw = self.client.await_task(tarefa, max_wait_s=self.task_max_wait_s)
                resultado = blocks_to_result(raw, tool=remote)
                return ToolResult(
                    text=resultado.text,
                    ok=resultado.ok,
                    code=resultado.code,
                    metadata={**resultado.metadata, "task_id": tarefa.task_id},
                    blocks=resultado.blocks,
                )
            raw = self.client.call_tool(remote, dict(arguments))
        except MCPError as erro:
            # Erro de protocolo: o modelo dificilmente conserta, mas perder a
            # execução por isso seria pior. Volta como resultado, marcado.
            return ToolResult.error(f"erro de protocolo MCP em {remote!r}: {erro}", code=502)
        return blocks_to_result(raw, tool=remote)

    def __call__(self, name: str, arguments: dict[str, Any]) -> ToolResult:
        if self.expose == "index":
            if name.endswith("mcp_find"):
                return self._find(str(arguments.get("query", "")), int(arguments.get("limit", 5)))
            if name.endswith("mcp_call"):
                wanted = str(arguments.get("name", ""))
                inner = arguments.get("arguments") or {}
                if not isinstance(inner, dict):
                    return ToolResult.error("`arguments` precisa ser um objeto", code=422)
                local = wanted if wanted in self.tools else self._local(wanted)
                return self.invoke(local, inner)
            return ToolResult.error(f"ferramenta desconhecida: {name!r}", code=404)
        return self.invoke(name, arguments)

    def __len__(self) -> int:
        return len(self.definitions())

    def close(self) -> None:
        self.client.close()

    def __enter__(self) -> MCPToolset:
        return self

    def __exit__(self, *exc: object) -> None:
        self.close()

    # -------------------------------------------------------- fábricas
    @staticmethod
    def _split_client_kw(kw: dict[str, Any]) -> dict[str, Any]:
        return {
            k: kw.pop(k)
            for k in ("sampler", "elicitor", "roots", "client_name", "client_version")
            if k in kw
        }

    @classmethod
    def stdio(cls, command: Sequence[str] | str, **kw: Any) -> MCPToolset:
        """`MCPToolset.stdio(["npx", "-y", "@modelcontextprotocol/server-everything"])`."""
        argv = command.split() if isinstance(command, str) else list(command)
        env = kw.pop("env", None)
        cwd = kw.pop("cwd", None)
        timeout = kw.pop("timeout", DEFAULT_TIMEOUT)
        client_kw = cls._split_client_kw(kw)
        client = MCPClient(StdioTransport(argv, env=env, cwd=cwd), timeout=timeout, **client_kw)
        return cls(client, **kw)

    @classmethod
    def http(cls, url: str, **kw: Any) -> MCPToolset:
        """`MCPToolset.http("https://exemplo.com/mcp", headers={...})`."""
        headers = kw.pop("headers", None)
        timeout = kw.pop("timeout", DEFAULT_TIMEOUT)
        client_kw = cls._split_client_kw(kw)
        client = MCPClient(
            StreamableHTTPTransport(url, headers=headers), timeout=timeout, **client_kw
        )
        return cls(client, **kw)
