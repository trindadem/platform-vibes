"""Recursos e prompts entrando no harness — cada um pelo modelo de interação dele.

A especificação separa as três superfícies por **quem controla**, e a
separação não é burocrática: é o que impede um agente de chamar um prompt
achando que é ferramenta.

| superfície | controle | onde entra aqui |
|---|---|---|
| ferramentas | modelo | `MCPToolset` — o modelo escolhe e chama |
| recursos | aplicação | `ResourceToolset` (o modelo puxa) ou `resources_as_context` (o operador injeta) |
| prompts | usuário | `PromptLibrary` — instrução ou skill, decisão de quem monta |

## Recursos: puxar ou injetar

*Application-driven* quer dizer que a aplicação decide o que entra no
contexto. Num agente, a aplicação é o harness, e há duas formas honestas:

- **Puxar**: `ResourceToolset` publica `resource_list` e `resource_read`. O
  modelo vê o índice e lê o que precisa — é divulgação progressiva, a mesma
  razão pela qual uma skill entra como índice e não como corpo.
- **Injetar**: `resources_as_context` monta um bloco de texto com os recursos
  que o operador escolheu, para `Agent.system_extra`. Serve para o punhado de
  recursos que o agente sempre precisa; usar isso para o catálogo inteiro é
  pagar prefixo por recurso que nunca será lido.

A anotação `priority` (0..1) e `audience` (`user`/`assistant`) guiam a
seleção — são dicas do servidor, portanto entram como ordenação, nunca como
autorização.

## Prompts: instrução ou skill, nunca ferramenta silenciosa

Um prompt do servidor é texto de terceiro que vira **instrução do agente**.
Isso é exatamente o vetor que a literatura chama de tool poisoning, um nível
acima: não é a descrição de uma ferramenta, é o prompt inteiro. Por isso
`PromptLibrary.instruction()` existe mas exige o nome explícito de quem
monta, e o corpo chega sanitizado e com a origem carimbada (`mcp:servidor`),
para que o digest da instrução registre *qual* texto rodou.
"""

from __future__ import annotations

from collections.abc import Callable, Iterable, Mapping, Sequence
from typing import Any

from ..instruction import Instruction
from ..skills import Skill
from ..tools import RISK_LEVELS, ToolResult
from .client import MCPClient
from .types import Prompt, PromptMessage, Resource, ResourceTemplate

__all__ = [
    "PromptLibrary",
    "ResourceToolset",
    "prompt_as_instruction",
    "resources_as_context",
    "watch_resources",
]


# --------------------------------------------------------------------------
# Recursos
# --------------------------------------------------------------------------


def _render_index(recursos: Sequence[Resource], templates: Sequence[ResourceTemplate]) -> str:
    linhas: list[str] = []
    for r in recursos:
        rotulo = r.title or r.name or r.uri
        desc = f" — {r.description}" if r.description else ""
        tipo = f" [{r.mime_type}]" if r.mime_type else ""
        linhas.append(f"- {r.uri} ({rotulo}){tipo}{desc}")
    for t in templates:
        desc = f" — {t.description}" if t.description else ""
        linhas.append(
            f"- {t.uri_template} (modelo: {', '.join(t.variables) or 'sem variável'}){desc}"
        )
    return "\n".join(linhas)


class ResourceToolset:
    """`resources/*` com a superfície `Toolset`: o modelo lista e lê sob demanda.

    O piso de risco é o mesmo raciocínio das ferramentas: ler recurso de
    servidor de terceiro é entrada não confiável chegando ao contexto. O
    padrão é `external`; `read` só quando quem monta decide que aquele
    servidor é de casa.
    """

    def __init__(
        self,
        client: MCPClient,
        *,
        prefix: str = "",
        risk_floor: str = "external",
        max_chars: int = 60_000,
        connect: bool = True,
    ) -> None:
        if risk_floor not in RISK_LEVELS:
            raise ValueError(f"risco {risk_floor!r} fora de {RISK_LEVELS}")
        self.client = client
        self.prefix = prefix
        self.risk_floor = risk_floor
        self.max_chars = max_chars
        self.resources: list[Resource] = []
        self.templates: list[ResourceTemplate] = []
        self.reads: list[str] = []
        if connect:
            self.refresh()

    def refresh(self) -> int:
        self.resources = self.client.list_resources()
        self.templates = self.client.list_resource_templates()
        return len(self.resources)

    def _name(self, base: str) -> str:
        return f"{self.prefix}_{base}" if self.prefix else base

    def index(self) -> str:
        return _render_index(self.resources, self.templates)

    def definitions(self) -> list[dict[str, Any]]:
        if not self.resources and not self.templates:
            return []
        return [
            {
                "name": self._name("resource_list"),
                "description": (
                    "Lista os recursos que o servidor MCP oferece (URI, nome, tipo e "
                    "descrição), incluindo modelos de URI parametrizados. Use antes de "
                    "resource_read quando não souber o URI exato."
                ),
                "input_schema": {
                    "type": "object",
                    "properties": {
                        "query": {
                            "type": "string",
                            "description": "filtra por palavra-chave; vazio lista tudo",
                        }
                    },
                },
            },
            {
                "name": self._name("resource_read"),
                "description": (
                    "Lê o conteúdo de um recurso do servidor MCP pelo URI exato. "
                    "Conteúdo binário não é devolvido; apenas a menção ao tipo e ao tamanho."
                ),
                "input_schema": {
                    "type": "object",
                    "properties": {
                        "uri": {"type": "string", "description": "URI exato do recurso"}
                    },
                    "required": ["uri"],
                },
            },
        ]

    def parallel_safe(self, name: str) -> bool:
        return name.endswith(("resource_list", "resource_read"))

    def risk(self, name: str) -> str:
        return "read" if name.endswith("resource_list") else self.risk_floor

    def __len__(self) -> int:
        return len(self.definitions())

    def _list(self, query: str = "") -> ToolResult:
        termos = [t for t in str(query).lower().split() if t]
        if termos:
            recursos = [
                r
                for r in self.resources
                if any(t in f"{r.uri} {r.name} {r.title} {r.description}".lower() for t in termos)
            ]
            templates = [
                t
                for t in self.templates
                if any(w in f"{t.uri_template} {t.name} {t.description}".lower() for w in termos)
            ]
        else:
            recursos, templates = self.resources, self.templates
        recursos = sorted(recursos, key=lambda r: -r.priority)
        texto = _render_index(recursos, templates)
        return ToolResult(
            text=texto or "o servidor não oferece recursos que casem essa busca",
            metadata={"resources": len(recursos), "templates": len(templates)},
        )

    def _read(self, uri: str) -> ToolResult:
        if not uri:
            return ToolResult.error("`uri` é obrigatório", code=422)
        try:
            conteudos = self.client.read_resource(uri)
        except Exception as erro:
            return ToolResult.error(f"não foi possível ler {uri!r}: {erro}", code=502)
        if not conteudos:
            return ToolResult.error(f"o servidor não devolveu conteúdo para {uri!r}", code=404)
        self.reads.append(uri)
        texto = "\n\n".join(c.render(self.max_chars) for c in conteudos)
        return ToolResult(
            text=texto,
            metadata={
                "uri": uri,
                "parts": len(conteudos),
                "binary": sum(1 for c in conteudos if not c.is_text),
            },
        )

    def __call__(self, name: str, arguments: dict[str, Any]) -> ToolResult:
        if name.endswith("resource_list"):
            return self._list(str(arguments.get("query", "")))
        if name.endswith("resource_read"):
            return self._read(str(arguments.get("uri", "")))
        return ToolResult.error(f"ferramenta desconhecida: {name!r}", code=404)


def resources_as_context(
    client: MCPClient,
    *,
    uris: Iterable[str] | None = None,
    min_priority: float = 0.0,
    max_chars: int = 8_000,
    for_model_only: bool = True,
) -> str:
    """Um bloco de texto com recursos escolhidos, para `Agent.system_extra`.

    Sem `uris`, escolhe pela anotação: `audience` que inclua `assistant` e
    `priority >= min_priority`, do mais prioritário ao menos. O corte por
    `max_chars` é duro e dito no texto — contexto silenciosamente truncado é
    pior que contexto faltando, porque ninguém vai procurar o que sumiu.
    """
    escolhidos: list[str]
    if uris is not None:
        escolhidos = list(uris)
    else:
        candidatos = [
            r
            for r in client.list_resources()
            if r.priority >= min_priority and (r.for_model() or not for_model_only)
        ]
        escolhidos = [r.uri for r in sorted(candidatos, key=lambda r: -r.priority)]
    partes: list[str] = []
    usado = 0
    cortados = 0
    for uri in escolhidos:
        try:
            conteudos = client.read_resource(uri)
        except Exception:
            continue
        for c in conteudos:
            pedaco = c.render(max_chars)
            if usado + len(pedaco) > max_chars:
                cortados += 1
                continue
            partes.append(pedaco)
            usado += len(pedaco)
    if not partes and not cortados:
        return ""
    cabeca = "<mcp-resources>"
    rodape = "</mcp-resources>"
    if cortados:
        # Nem tudo coube. Dizer isso é o ponto: contexto truncado em silêncio é
        # pior que contexto faltando, porque ninguém procura o que sumiu.
        cabeca += f"\n[{cortados} recurso(s) omitido(s) por orçamento de contexto]"
    return "\n".join([cabeca, *partes, rodape])


def watch_resources(
    client: MCPClient,
    uris: Iterable[str],
    on_update: Callable[[str], None],
) -> list[str]:
    """Assina os URIs e chama `on_update(uri)` a cada `notifications/resources/updated`.

    Devolve os URIs efetivamente assinados — vazio quando o servidor não
    declarou `resources.subscribe`. As notificações chegam quando o cliente
    fala com o servidor, ou quando alguém chama `client.pump()`.
    """
    assinados: list[str] = []
    for uri in uris:
        if client.subscribe_resource(uri):
            assinados.append(uri)
    if not assinados:
        return []

    def _ouvinte(message: Mapping[str, Any]) -> None:
        uri = str((message.get("params") or {}).get("uri") or "")
        if uri in assinados:
            on_update(uri)

    client.on("notifications/resources/updated", _ouvinte)
    return assinados


# --------------------------------------------------------------------------
# Prompts
# --------------------------------------------------------------------------


def _messages_to_text(mensagens: Sequence[PromptMessage]) -> str:
    partes: list[str] = []
    for m in mensagens:
        corpo = m.text
        for b in m.blocks:
            if b.get("type") == "resource":
                recurso = b.get("resource") or {}
                texto = recurso.get("text")
                marca = f"[{recurso.get('uri', '')}]"
                corpo = f"{corpo}\n{marca}\n{texto}" if texto is not None else f"{corpo}\n{marca}"
            elif b.get("type") in ("image", "audio"):
                corpo = f"{corpo}\n[{b.get('type')} {b.get('mimeType', '')} omitido]"
        corpo = corpo.strip()
        if not corpo:
            continue
        partes.append(corpo if m.role == "user" else f"[assistente] {corpo}")
    return "\n\n".join(partes)


def prompt_as_instruction(
    client: MCPClient,
    name: str,
    arguments: Mapping[str, Any] | None = None,
) -> Instruction:
    """Um prompt do servidor como instrução do agente — com a origem carimbada.

    O digest da `Instruction` é do corpo que rodou, então trocar o prompt no
    servidor muda o digest no traço. É o mesmo pino das ferramentas, aplicado
    ao texto que mais importa.
    """
    descricao, mensagens = client.get_prompt(name, arguments)
    corpo = _messages_to_text(mensagens)
    if not corpo:
        raise ValueError(f"o prompt {name!r} não produziu texto")
    origem = str(client.server_info.get("name") or "mcp")
    cabecalho = f"<!-- prompt MCP {name!r} de {origem}: {descricao or 'sem descrição'} -->"
    return Instruction.inline(f"{cabecalho}\n{corpo}", name=f"mcp:{origem}/{name}")


class PromptLibrary:
    """Os prompts de um servidor, para quem monta o agente — não para o modelo.

    A especificação os chama de *user-controlled*: comando de usuário, não
    ferramenta. `skills()` existe para quem decide, explicitamente, expô-los
    ao modelo pelo índice de skills — aí eles seguem a mesma divulgação
    progressiva do resto (índice no prompt, corpo sob demanda).
    """

    def __init__(self, client: MCPClient, *, connect: bool = True) -> None:
        self.client = client
        self.prompts: dict[str, Prompt] = {}
        if connect:
            self.refresh()

    def refresh(self) -> int:
        self.prompts = {p.name: p for p in self.client.list_prompts()}
        return len(self.prompts)

    def names(self) -> list[str]:
        return list(self.prompts)

    def get(self, name: str) -> Prompt | None:
        return self.prompts.get(name)

    def __len__(self) -> int:
        return len(self.prompts)

    def __contains__(self, name: str) -> bool:
        return name in self.prompts

    def index(self) -> str:
        if not self.prompts:
            return ""
        linhas = ["Prompts do servidor MCP:"]
        for p in self.prompts.values():
            obrigatorios = f" (exige: {', '.join(p.required)})" if p.required else ""
            linhas.append(f"- {p.name}: {p.description or p.title}{obrigatorios}")
        return "\n".join(linhas)

    def render(self, name: str, arguments: Mapping[str, Any] | None = None) -> list[PromptMessage]:
        prompt = self.get(name)
        if prompt is None:
            raise ValueError(
                f"prompt desconhecido: {name!r}. Disponíveis: {', '.join(self.prompts) or '(nenhum)'}"
            )
        faltando = [a for a in prompt.required if a not in (arguments or {})]
        if faltando:
            # Cobrado aqui, antes do fio: o servidor devolveria -32602, e um
            # erro de protocolo diz menos do que o nome do argumento que falta.
            raise ValueError(f"o prompt {name!r} exige {faltando}")
        _descricao, mensagens = self.client.get_prompt(name, arguments)
        return mensagens

    def text(self, name: str, arguments: Mapping[str, Any] | None = None) -> str:
        return _messages_to_text(self.render(name, arguments))

    def instruction(self, name: str, arguments: Mapping[str, Any] | None = None) -> Instruction:
        return prompt_as_instruction(self.client, name, arguments)

    def skills(self, arguments: Mapping[str, Mapping[str, Any]] | None = None) -> list[Skill]:
        """Os prompts como `Skill`: índice no prompt, corpo pela ferramenta `skill`.

        Só entram os que não exigem argumento — ou cujos argumentos quem monta
        forneceu em `arguments`. Uma skill que não pode ser renderizada é uma
        entrada de índice que sempre falha.
        """
        args = dict(arguments or {})
        origem = str(self.client.server_info.get("name") or "mcp")
        out: list[Skill] = []
        for p in self.prompts.values():
            dados = args.get(p.name, {})
            if any(a not in dados for a in p.required):
                continue
            try:
                corpo = self.text(p.name, dados)
            except Exception:
                continue
            descricao = p.description or p.title or f"Prompt {p.name} do servidor {origem}."
            out.append(
                Skill(
                    name=p.name,
                    description=descricao,
                    body=corpo,
                    path=f"mcp://{origem}/prompts/{p.name}",
                    meta={"source": "mcp", "server": origem},
                )
            )
        return out
