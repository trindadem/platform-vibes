"""O que o cliente faz quando é o **servidor** que pede.

`sampling`, `elicitation` e `roots` invertem a direção do protocolo, e cada um
entrega ao servidor algo que o servidor não tinha:

| capacidade | o que o servidor ganha | o que pode dar errado |
|---|---|---|
| `sampling` | o seu modelo, a sua chave e a sua fatura | gasto sem teto; o servidor usa o modelo para trabalho dele |
| `elicitation` | uma caixa de diálogo com o seu usuário | phishing, coleta de segredo, consentimento fabricado |
| `roots` | o desenho do seu sistema de arquivos | reconhecimento para um servidor hostil |

Por isso o **padrão é negar**, e negar de forma estrutural: um handler ausente
não é um `if` no meio do despacho, é uma **capacidade não declarada** no
`initialize`. A especificação é clara de que o servidor não deve mandar o que
o cliente não declarou; um cliente que declara o que não pretende atender
ensina o servidor a contar com o que não existe.

## Sampling é uma superfície de cobrança

O ponto que a literatura de MCP chama de *confused deputy* (arXiv:2508.14925,
arXiv:2506.01333) tem aqui a sua forma mais direta: um servidor com sampling
liberado pode emitir chamadas ao modelo indefinidamente, pagas por quem roda o
agente. `SamplingBudget` é o teto — chamadas, tokens de saída e custo — e é
verificado **antes** de cada chamada, não depois. Estourou, o servidor recebe
`-1` (*user rejected*), que é o código que a especificação reserva para
recusa, e o laço do agente segue.

## Elicitation em modo formulário não pede segredo

A especificação diz que o servidor **MUST NOT** pedir senha, chave de API,
token ou dado de pagamento em modo formulário — deve usar modo URL. Confiar
que todo servidor obedece é a mesma aposta que a `readOnlyHint` perdeu. Aqui o
**cliente** verifica: um `requestedSchema` cujos campos cheiram a credencial é
recusado com `decline` e a razão, sem nunca chegar ao usuário.

## Modo URL não abre nada

O cliente **MUST NOT** pré-buscar a URL, **MUST NOT** abri-la sem
consentimento explícito e **MUST** mostrá-la inteira. Aqui isso é o tipo do
gancho: o handler recebe a URL e o host destacado e devolve
`accept`/`decline`/`cancel`. Abrir navegador é decisão da aplicação, e este
módulo não abre nenhum.
"""

from __future__ import annotations

import re
import threading
from collections.abc import Callable, Iterable, Mapping, Sequence
from dataclasses import dataclass, field
from typing import Any, Protocol, runtime_checkable
from urllib.parse import urlsplit

from ..models.provider import Provider, Request, estimate_cost_usd
from .types import Elicitation, Root
from .wire import MCPDenied, sanitize

__all__ = [
    "SECRETISH",
    "CallbackElicitor",
    "Elicitor",
    "ProviderSampler",
    "RootsProvider",
    "Sampler",
    "SamplingBudget",
    "StaticRoots",
    "looks_like_secret",
    "split_identifier",
    "validate_form",
]


# --------------------------------------------------------------------------
# Sampling
# --------------------------------------------------------------------------


@dataclass
class SamplingBudget:
    """O teto do que um servidor pode gastar com o seu modelo.

    Verificado **antes** da chamada. Um teto conferido depois é um teto que já
    foi ultrapassado.
    """

    max_calls: int = 8
    max_output_tokens: int | None = 20_000
    max_cost_usd: float | None = 1.0
    #: teto de `maxTokens` por chamada; o pedido do servidor é aparado por ele.
    max_tokens_per_call: int = 4_096
    calls: int = 0
    output_tokens: int = 0
    cost_usd: float = 0.0
    _lock: threading.Lock = field(default_factory=threading.Lock, repr=False)

    def exhausted(self) -> str | None:
        if self.max_calls is not None and self.calls >= self.max_calls:
            return f"max_calls={self.max_calls}"
        if self.max_output_tokens is not None and self.output_tokens >= self.max_output_tokens:
            return f"max_output_tokens={self.max_output_tokens}"
        if self.max_cost_usd is not None and self.cost_usd >= self.max_cost_usd:
            return f"max_cost_usd={self.max_cost_usd}"
        return None

    def charge(self, usage: Mapping[str, int], model: str) -> None:
        with self._lock:
            self.calls += 1
            self.output_tokens += int(usage.get("output_tokens", 0) or 0)
            self.cost_usd += estimate_cost_usd(model, dict(usage))

    def cap(self, pedido: Any) -> int:
        try:
            pedido_i = int(pedido)
        except (TypeError, ValueError):
            pedido_i = self.max_tokens_per_call
        return max(1, min(self.max_tokens_per_call, pedido_i or self.max_tokens_per_call))

    def to_dict(self) -> dict[str, Any]:
        return {
            "calls": self.calls,
            "output_tokens": self.output_tokens,
            "cost_usd": round(self.cost_usd, 6),
        }


@runtime_checkable
class Sampler(Protocol):
    """Atende `sampling/createMessage`. Levanta `MCPDenied` para recusar."""

    #: sub-capacidades declaradas junto de `sampling` (ex.: `{"tools": {}}`).
    capability: dict[str, Any]

    def __call__(self, params: Mapping[str, Any], *, server: str = "") -> dict[str, Any]: ...


_STOP_REASON = {
    "end_turn": "endTurn",
    "max_tokens": "maxTokens",
    "stop_sequence": "stopSequence",
    "tool_use": "toolUse",
    "refusal": "refusal",
}


def _mcp_blocks_to_wire(content: Any) -> list[dict[str, Any]]:
    """Blocos MCP -> blocos da Messages API. `toolUseId` vira `tool_use_id`."""
    bruto = content if isinstance(content, list) else [content]
    out: list[dict[str, Any]] = []
    for b in bruto:
        if not isinstance(b, Mapping):
            continue
        kind = b.get("type")
        if kind == "text":
            out.append({"type": "text", "text": sanitize(str(b.get("text", "")))})
        elif kind == "image":
            out.append(
                {
                    "type": "image",
                    "source": {
                        "type": "base64",
                        "media_type": str(b.get("mimeType") or "image/png"),
                        "data": str(b.get("data") or ""),
                    },
                }
            )
        elif kind == "tool_use":
            out.append(
                {
                    "type": "tool_use",
                    "id": str(b.get("id") or ""),
                    "name": str(b.get("name") or ""),
                    "input": dict(b.get("input") or {}),
                }
            )
        elif kind == "tool_result":
            interno = b.get("content")
            texto = "\n".join(
                sanitize(str(x.get("text", "")))
                for x in (interno if isinstance(interno, list) else [interno])
                if isinstance(x, Mapping) and x.get("type") == "text"
            )
            out.append(
                {
                    "type": "tool_result",
                    "tool_use_id": str(b.get("toolUseId") or b.get("tool_use_id") or ""),
                    "content": texto,
                }
            )
        elif kind == "audio":
            out.append({"type": "text", "text": f"[áudio {b.get('mimeType', '?')} omitido]"})
    return out


def _wire_blocks_to_mcp(content: Sequence[Mapping[str, Any]]) -> Any:
    """Resposta do modelo -> `content` do `CreateMessageResult`.

    Um bloco de texto sozinho volta como objeto (a forma canônica do exemplo
    da especificação); uso de ferramenta volta como lista, que é o que o
    servidor precisa para casar `toolUseId`.
    """
    usos = [b for b in content if b.get("type") == "tool_use"]
    if usos:
        return [
            {
                "type": "tool_use",
                "id": str(b.get("id") or ""),
                "name": str(b.get("name") or ""),
                "input": dict(b.get("input") or {}),
            }
            for b in usos
        ]
    texto = "\n".join(str(b.get("text", "")) for b in content if b.get("type") == "text")
    return {"type": "text", "text": texto}


@dataclass
class ProviderSampler:
    """`sampling/createMessage` atendido pelo provedor do próprio agente.

    Três coisas o separam de simplesmente repassar o pedido:

    1. **Orçamento.** `SamplingBudget` é conferido antes; estourado, recusa com
       `-1` e diz qual eixo fechou.
    2. **Portão.** `approve(params, server) -> bool` é o humano no laço que a
       especificação pede. `None` significa "sem portão", e isso é uma decisão
       consciente de quem monta, não um descuido.
    3. **Teto por chamada.** `maxTokens` do servidor é aparado; um servidor
       pedindo 200.000 tokens de saída não recebe 200.000.

    `allow_tools=True` declara `sampling.tools` e repassa as ferramentas do
    servidor ao modelo, devolvendo os blocos `tool_use` para o servidor
    executar. Sem ele, a sub-capacidade não é declarada e a especificação
    proíbe o servidor de mandar ferramentas.
    """

    provider: Provider
    budget: SamplingBudget = field(default_factory=SamplingBudget)
    approve: Callable[[Mapping[str, Any], str], bool] | None = None
    allow_tools: bool = False
    #: modelos que as dicas (`modelPreferences.hints`) podem escolher. Vazio
    #: significa: a dica é ignorada e usa-se o modelo do provedor.
    allowed_models: tuple[str, ...] = ()
    calls: list[dict[str, Any]] = field(default_factory=list)

    @property
    def capability(self) -> dict[str, Any]:
        return {"tools": {}} if self.allow_tools else {}

    def _model_for(self, prefs: Mapping[str, Any]) -> str:
        """Dica é conselho, não ordem: só escolhe dentro do que o operador liberou."""
        atual = str(getattr(self.provider, "model", ""))
        if not self.allowed_models:
            return atual
        for hint in prefs.get("hints") or []:
            if not isinstance(hint, Mapping):
                continue
            nome = str(hint.get("name") or "")
            if not nome:
                continue
            for permitido in self.allowed_models:
                if nome in permitido:
                    return permitido
        return atual

    def __call__(self, params: Mapping[str, Any], *, server: str = "") -> dict[str, Any]:
        fechado = self.budget.exhausted()
        if fechado:
            raise MCPDenied(
                f"orçamento de sampling do servidor {server or '?'} fechado ({fechado})"
            )
        tools = params.get("tools") or []
        if tools and not self.allow_tools:
            raise MCPDenied(
                "este cliente não declarou `sampling.tools`; o servidor não deveria "
                "mandar ferramentas em sampling"
            )
        if self.approve is not None and not self.approve(params, server):
            raise MCPDenied("o operador não aprovou o pedido de sampling do servidor")

        mensagens = [
            {"role": str(m.get("role") or "user"), "content": _mcp_blocks_to_wire(m.get("content"))}
            for m in (params.get("messages") or [])
            if isinstance(m, Mapping)
        ]
        if not mensagens:
            raise MCPDenied("pedido de sampling sem mensagens")
        system: list[dict[str, Any]] = []
        if params.get("systemPrompt"):
            system = [{"type": "text", "text": sanitize(str(params["systemPrompt"]))}]

        pedido = Request(
            system=system,
            messages=mensagens,
            tools=(
                [
                    {
                        "name": str(t.get("name") or ""),
                        "description": sanitize(str(t.get("description") or "")),
                        "input_schema": dict(t.get("inputSchema") or {"type": "object"}),
                    }
                    for t in tools
                    if isinstance(t, Mapping)
                ]
                if self.allow_tools
                else []
            ),
            max_tokens=self.budget.cap(params.get("maxTokens")),
        )
        modelo = self._model_for(params.get("modelPreferences") or {})
        resposta = self.provider.complete(pedido)
        self.budget.charge(resposta.usage, resposta.model or modelo)
        self.calls.append(
            {"server": server, "model": resposta.model or modelo, "usage": dict(resposta.usage)}
        )
        return {
            "role": "assistant",
            "content": _wire_blocks_to_mcp(resposta.content),
            "model": resposta.model or modelo,
            "stopReason": _STOP_REASON.get(resposta.stop_reason, resposta.stop_reason),
        }


# --------------------------------------------------------------------------
# Elicitation
# --------------------------------------------------------------------------

#: Nomes de campo que denunciam pedido de credencial. A especificação proíbe
#: pedi-los em modo formulário; o cliente é quem verifica.
SECRETISH = re.compile(
    r"(?i)\b("
    r"pass(word|wd|phrase)?|senha|secret|segredo|api[_\- ]?key|apikey|chave"
    r"|token|bearer|credential|credencial|private[_\- ]?key|ssh[_\- ]?key"
    r"|card(_?number)?|cartao|cart[ãa]o|cvv|cvc|pin|ssn|cpf|otp|mfa|2fa"
    r")\b"
)


def split_identifier(nome: str) -> str:
    """`access_token`, `accessToken` e `access-token` viram `access token`.

    Sem isto, `\btoken\b` não casa dentro de `access_token`: `_` é caractere
    de palavra, então não há fronteira ali. O ataque mais barato contra uma
    lista de nomes proibidos é escrever o nome de outro jeito.
    """
    trocado = re.sub(r"[_\-.\s]+", " ", nome)
    return re.sub(r"(?<=[a-z0-9])(?=[A-Z])", " ", trocado)


def looks_like_secret(schema: Mapping[str, Any]) -> list[str]:
    """Campos do `requestedSchema` que parecem pedir credencial."""
    suspeitos: list[str] = []
    for nome, sub in (schema.get("properties") or {}).items():
        titulo = str(sub.get("title", "")) if isinstance(sub, Mapping) else ""
        descricao = str(sub.get("description", "")) if isinstance(sub, Mapping) else ""
        texto = " ".join(
            split_identifier(parte) for parte in (str(nome), titulo, descricao) if parte
        )
        formato = str(sub.get("format", "")).lower() if isinstance(sub, Mapping) else ""
        if SECRETISH.search(texto) or formato == "password":
            suspeitos.append(str(nome))
    return suspeitos


def validate_form(schema: Mapping[str, Any], content: Mapping[str, Any]) -> list[str]:
    """Confere a resposta contra o subconjunto de JSON Schema que o modo formulário aceita.

    A especificação restringe o schema a objeto plano de primitivos; validar
    aqui evita devolver ao servidor um objeto que ele vai rejeitar depois — e,
    mais importante, evita devolver **mais** do que foi pedido.
    """
    erros: list[str] = []
    props = schema.get("properties") or {}
    for req in schema.get("required") or []:
        if req not in content:
            erros.append(f"campo obrigatório ausente: {req!r}")
    for nome, valor in content.items():
        sub = props.get(nome)
        if not isinstance(sub, Mapping):
            erros.append(f"campo não pedido no schema: {nome!r}")
            continue
        tipo = str(sub.get("type") or "")
        if tipo == "string" and not isinstance(valor, str):
            erros.append(f"{nome!r} deveria ser string")
        elif tipo == "integer" and not isinstance(valor, int):
            erros.append(f"{nome!r} deveria ser inteiro")
        elif tipo == "number" and not isinstance(valor, (int, float)):
            erros.append(f"{nome!r} deveria ser número")
        elif tipo == "boolean" and not isinstance(valor, bool):
            erros.append(f"{nome!r} deveria ser booleano")
        elif tipo == "array" and not isinstance(valor, list):
            erros.append(f"{nome!r} deveria ser lista")
        escolhas = sub.get("enum")
        if isinstance(escolhas, list) and valor not in escolhas:
            erros.append(f"{nome!r} fora de {escolhas}")
        if isinstance(valor, str):
            if isinstance(sub.get("minLength"), int) and len(valor) < sub["minLength"]:
                erros.append(f"{nome!r} menor que minLength")
            if isinstance(sub.get("maxLength"), int) and len(valor) > sub["maxLength"]:
                erros.append(f"{nome!r} maior que maxLength")
        if isinstance(valor, (int, float)) and not isinstance(valor, bool):
            if isinstance(sub.get("minimum"), (int, float)) and valor < sub["minimum"]:
                erros.append(f"{nome!r} abaixo do mínimo")
            if isinstance(sub.get("maximum"), (int, float)) and valor > sub["maximum"]:
                erros.append(f"{nome!r} acima do máximo")
    return erros


@runtime_checkable
class Elicitor(Protocol):
    """Atende `elicitation/create`. Devolve `(action, content)`."""

    capability: dict[str, Any]

    def __call__(self, pedido: Elicitation) -> tuple[str, dict[str, Any]]: ...


@dataclass
class CallbackElicitor:
    """Modo formulário e modo URL, cada um com o seu gancho — e as recusas de ofício.

    `form(elicitation) -> (action, content)` e `url(elicitation, host) -> action`
    são da aplicação: terminal, UI, fila de aprovação. O que este objeto
    garante, antes de chamar qualquer gancho:

    - formulário pedindo credencial é recusado (`decline`), com o campo nomeado;
    - resposta de formulário é validada contra o `requestedSchema`, e o que não
      foi pedido não é devolvido;
    - URL nunca é buscada nem aberta aqui; `http://` é recusado por padrão e
      host em Punycode é sinalizado ao gancho;
    - há teto de pedidos (`max_calls`), porque a especificação pede limitação
      de taxa e um servidor que abre mil diálogos é o mesmo ataque de sempre.
    """

    form: Callable[[Elicitation], tuple[str, dict[str, Any]]] | None = None
    url: Callable[[Elicitation, str], str] | None = None
    max_calls: int = 20
    allow_insecure_url: bool = False
    calls: int = 0
    log: list[dict[str, Any]] = field(default_factory=list)

    @property
    def capability(self) -> dict[str, Any]:
        cap: dict[str, Any] = {}
        if self.form is not None:
            cap["form"] = {}
        if self.url is not None:
            cap["url"] = {}
        return cap

    def _registra(self, pedido: Elicitation, acao: str, razao: str = "") -> None:
        self.log.append(
            {"mode": pedido.mode, "message": pedido.message, "action": acao, "reason": razao}
        )

    def __call__(self, pedido: Elicitation) -> tuple[str, dict[str, Any]]:
        self.calls += 1
        if self.calls > self.max_calls:
            self._registra(pedido, "decline", "teto de pedidos de elicitação")
            raise MCPDenied(f"o servidor excedeu {self.max_calls} pedidos de elicitação")

        if pedido.mode == "url":
            if self.url is None:
                raise MCPDenied("este cliente não declarou o modo `url` de elicitação")
            alvo = urlsplit(pedido.url)
            if not alvo.scheme or not alvo.netloc:
                self._registra(pedido, "cancel", "URL inválida")
                return "cancel", {}
            if alvo.scheme != "https" and not self.allow_insecure_url:
                self._registra(pedido, "decline", f"esquema {alvo.scheme!r} não é https")
                return "decline", {}
            host = alvo.netloc
            if "xn--" in host.lower():  # Punycode: sinalizar, não decidir sozinho
                host = f"{host} [PUNYCODE — verifique]"
            acao = str(self.url(pedido, host) or "cancel")
            self._registra(pedido, acao)
            return (acao if acao in ("accept", "decline", "cancel") else "cancel"), {}

        if self.form is None:
            raise MCPDenied("este cliente não declarou o modo `form` de elicitação")
        suspeitos = looks_like_secret(pedido.requested_schema)
        if suspeitos:
            self._registra(pedido, "decline", f"campos de credencial: {suspeitos}")
            return "decline", {}
        acao, conteudo = self.form(pedido)
        acao = str(acao)
        if acao != "accept":
            self._registra(pedido, acao if acao in ("decline", "cancel") else "cancel")
            return (acao if acao in ("decline", "cancel") else "cancel"), {}
        conteudo = dict(conteudo or {})
        erros = validate_form(pedido.requested_schema, conteudo)
        if erros:
            self._registra(pedido, "cancel", f"resposta não casa o schema: {erros}")
            return "cancel", {}
        self._registra(pedido, "accept")
        return "accept", conteudo


# --------------------------------------------------------------------------
# Roots
# --------------------------------------------------------------------------


@runtime_checkable
class RootsProvider(Protocol):
    """Atende `roots/list`."""

    def __call__(self) -> list[Root]: ...


@dataclass
class StaticRoots:
    """As fronteiras que o operador decidiu expor. Nada é descoberto sozinho."""

    roots: tuple[Root, ...] = ()
    list_changed: bool = False

    def __init__(self, roots: Iterable[Root | str] = (), *, list_changed: bool = False) -> None:
        normalizados: list[Root] = []
        for r in roots:
            normalizados.append(r if isinstance(r, Root) else Root.of_path(r))
        self.roots = tuple(normalizados)
        self.list_changed = list_changed

    def __call__(self) -> list[Root]:
        return list(self.roots)
