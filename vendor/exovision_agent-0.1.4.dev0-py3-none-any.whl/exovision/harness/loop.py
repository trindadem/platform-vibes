"""O laço: pede, executa, devolve, repete — até o modelo parar de pedir.

Cada volta atravessa as costuras (`llm.request`, `llm.response`,
`policy.decision`, `tool.call`, `tool.result`, `turn.end`); `startup` e
`shutdown` disparam uma vez; `memory.recall` antes da primeira volta e
`memory.commit` no fim. Não há caminho que contorne: é por isso que o traço
serve de medição.

## Erro de ferramenta volta como resultado, nunca como exceção

Um `old_str` que não casou é informação para o modelo corrigir, não motivo
para perder a execução inteira. O que derruba o laço é falha de
infraestrutura — credencial, rede, recusa do modelo, roteiro esgotado.

## Resposta vazia não é sucesso

Uma volta sem texto e sem ferramenta (um modelo pequeno cuja chamada
malformada o servidor engoliu; `content` vazio com tokens de saída) fecha o
laço com `stop_reason="empty"` e `error` — não com `end_turn` e texto vazio
disfarçado de resposta. O último texto útil, se houve, fica no `Outcome`.

## Chamadas paralelas

Uma resposta pode pedir várias ferramentas. Chamadas contíguas marcadas
`parallel_safe` rodam em threads; as demais, uma por vez, em ordem. **Todos**
os resultados voltam numa única mensagem de usuário, na ordem dos pedidos —
dividi-los em várias mensagens ensinaria o modelo a parar de paralelizar.

## Durabilidade

A resposta e todas as intenções ficam no disco ANTES do primeiro efeito.
Depois de crash, `planned` roda; `completed` é reutilizado sem repetir o
efeito; `running` é ambíguo e exige intervenção (`StateConflict`).

## A janela

O histórico é **append-only**: os blocos de pensamento estão ligados ao
prefixo que os produziu, e editar uma volta anterior invalida os posteriores.
Com `Agent.window`, o laço estima o pedido antes de cada `llm.request`; se
não cabe, **compacta por resumo e reinício** — uma chamada de resumo (papel
`compaction`), uma mensagem nova, geração nova no journal (a anterior fica
arquivada em `meta`), e o traço registra em `context.assemble`. Nunca no
meio de uma rodada de ferramenta: a compactação acontece com as ferramentas
já respondidas, antes de pedir a próxima volta.
"""

from __future__ import annotations

import time
from collections.abc import Callable
from concurrent.futures import ThreadPoolExecutor
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

from .budget import Budget, Meter
from .context import assemble_system, assemble_task
from .instruction import Instruction
from .memory.bridge import MemoryPort, NullMemory, Recall
from .models.provider import Provider, ProviderError, Reply, Request
from .models.window import Window
from .policy import AllowAll, Policy
from .seams import Event, Seams
from .session import SessionState, StateConflict, StateStore
from .skills import SkillLibrary
from .tools import Composite, Registry, ToolCall, ToolResult, Toolset, normalize

__all__ = ["Agent", "Outcome", "run"]


@dataclass(slots=True)
class Outcome:
    """O que a execução deixou."""

    text: str
    turns: int
    stop_reason: str
    session: str = "-"
    usage: dict[str, int] = field(default_factory=dict)
    cost_usd: float = 0.0
    tool_calls: int = 0
    error: str = ""
    recalled: list[str] = field(default_factory=list)
    seams: dict[str, int] = field(default_factory=dict)

    @property
    def ok(self) -> bool:
        return not self.error

    def to_dict(self) -> dict[str, Any]:
        return {
            "text": self.text,
            "turns": self.turns,
            "stop_reason": self.stop_reason,
            "session": self.session,
            "usage": dict(self.usage),
            "cost_usd": self.cost_usd,
            "tool_calls": self.tool_calls,
            "error": self.error,
            "recalled": list(self.recalled),
            "seams": dict(self.seams),
        }

    @classmethod
    def from_dict(cls, d: dict[str, Any]) -> Outcome:
        return cls(
            text=d.get("text", ""),
            turns=int(d.get("turns", 0)),
            stop_reason=str(d.get("stop_reason", "")),
            session=str(d.get("session", "-")),
            usage=dict(d.get("usage") or {}),
            cost_usd=float(d.get("cost_usd", 0.0)),
            tool_calls=int(d.get("tool_calls", 0)),
            error=str(d.get("error", "")),
            recalled=list(d.get("recalled") or []),
            seams=dict(d.get("seams") or {}),
        )


@dataclass
class Agent:
    """Tudo o que um agente carrega. Ausências são objetos nulos, não `None`."""

    provider: Provider
    instruction: Instruction | str = ""
    name: str = "agent"
    toolset: Toolset = field(default_factory=Registry)
    policy: Policy = field(default_factory=AllowAll)
    memory: MemoryPort = field(default_factory=NullMemory)
    skills: SkillLibrary | None = None
    budget: Budget = field(default_factory=Budget)
    workspace: Path | str | None = None
    #: texto extra no fim do system (ex.: contrato do operador). Estável na sessão.
    system_extra: str = ""
    max_parallel: int = 8
    cache_system: bool = True
    #: janela do cliente: compactação simples quando o pedido não cabe.
    #: `None` = confiar no servidor (ou na janela do modelo).
    window: Window | None = None

    def resolved_instruction(self) -> Instruction:
        if isinstance(self.instruction, Instruction):
            return self.instruction
        return Instruction.inline(
            str(self.instruction) or "Você é um agente útil e preciso.", name=self.name
        )

    def resolved_toolset(self) -> Toolset:
        if self.skills is not None and len(self.skills):
            return Composite(self.toolset, Registry([self.skills.tool()]))
        return self.toolset


def _names(defs: list[dict[str, Any]]) -> list[str]:
    return [str(d.get("name", "")) for d in defs]


def _parallel_safe(toolset: Any, name: str) -> bool:
    fn = getattr(toolset, "parallel_safe", None)
    return bool(fn(name)) if callable(fn) else False


def _risk(toolset: Any, name: str) -> str:
    fn = getattr(toolset, "risk", None)
    return str(fn(name)) if callable(fn) else "irreversible"


def _result_to_dict(r: ToolResult) -> dict[str, Any]:
    return {
        "text": r.text,
        "ok": r.ok,
        "code": r.code,
        "metadata": dict(r.metadata),
        "blocks": list(r.blocks),
    }


def _result_from_dict(d: dict[str, Any]) -> ToolResult:
    return ToolResult(
        text=d.get("text", ""),
        ok=bool(d.get("ok", True)),
        code=int(d.get("code", 0)),
        metadata=dict(d.get("metadata") or {}),
        blocks=tuple(d.get("blocks") or ()),
    )


def run(
    agent: Agent,
    task: str,
    *,
    session: str = "-",
    state_store: StateStore | None = None,
    resume: bool = False,
    seams: Seams | None = None,
    on_event: Callable[[Event], None] | None = None,
) -> Outcome:
    """Roda a tarefa até o modelo parar de chamar ferramenta, ou o orçamento fechar."""
    seams = seams if seams is not None else Seams(session)  # Seams vazio é falsy
    if on_event is not None:
        seams.on("*", on_event)
    instruction = agent.resolved_instruction()
    toolset = agent.resolved_toolset()
    tools = toolset.definitions()
    meter = Meter(
        budget=agent.budget,
        model=getattr(agent.provider, "model", ""),
        # Em lote a cobrança é metade; quem sabe disso é o provedor.
        discount=float(getattr(agent.provider, "cost_discount", 1.0)),
    )
    meter.start()

    # ------------------------------------------------------- sessão/estado
    previous = state_store.load(session) if (state_store and resume) else None
    if previous is not None and previous.status == "completed" and previous.outcome:
        return Outcome.from_dict(previous.outcome)

    recall = Recall()
    if previous is not None:
        # Retomada reproduz exatamente o contexto original.
        system = previous.system
    else:
        t0 = time.perf_counter()
        recall = agent.memory.recall(task, session=session, actor=agent.name)
        seams.emit(
            "memory.recall",
            items=len(recall.items),
            tokens=recall.tokens,
            dropped=recall.dropped,
            per_subsystem=recall.per_subsystem,
            ms=round((time.perf_counter() - t0) * 1000, 2),
        )
        system = assemble_system(
            instruction,
            skills_index=agent.skills.index() if agent.skills else "",
            workspace=agent.workspace,
            extra=agent.system_extra,
            cache=agent.cache_system,
        )
        seams.emit(
            "context.assemble",
            system_chars=sum(len(b.get("text", "")) for b in system),
            tools=len(tools),
            memory_chars=len(recall.text),
        )

    state: SessionState | None = (
        state_store.begin(session, task, system, resume) if state_store else None
    )
    messages: list[dict[str, Any]] = (
        state.messages
        if (state and state.messages)
        else [{"role": "user", "content": assemble_task(task, recall)}]
    )
    if state and not state.messages:
        state.messages = messages
    usage_seed = dict(state.usage) if state else {}
    meter.add_usage(usage_seed)
    meter.turns = state.turn if state else 0
    if agent.window is not None and state is not None:
        agent.window.compactions = len(state.meta.get("compactions") or [])

    seams.emit(
        "startup",
        agent=agent.name,
        instruction=instruction.ref,
        digest=instruction.short_digest,
        model=getattr(agent.provider, "model", ""),
        effort=getattr(agent.provider, "effort", ""),
        tools=_names(tools),
        policy=getattr(agent.policy, "name", type(agent.policy).__name__),
        memory=type(agent.memory).__name__,
        budget=agent.budget.__dict__ if hasattr(agent.budget, "__dict__") else str(agent.budget),
        resume=previous is not None,
    )
    if previous is None:
        agent.memory.observe("task", task, session=session, turn=0)

    def checkpoint(status: str = "running", outcome: Outcome | None = None) -> None:
        if state_store and state:
            state.messages = messages
            state.turn = meter.turns
            state.usage = dict(meter.usage)
            state.status = status
            state.outcome = outcome.to_dict() if outcome else None
            state_store.save(state)

    def finish(text: str, stop_reason: str, *, error: str = "") -> Outcome:
        status = "failed" if error else "completed"
        if not error:
            agent.memory.observe("assistant", text, session=session, turn=meter.turns)
        commit = agent.memory.commit()
        seams.emit(
            "memory.commit",
            subsystems=list(commit) if isinstance(commit, dict) else [],
            report=commit,
        )
        seams.emit(
            "shutdown", status=status, stop_reason=stop_reason, meter=meter.to_dict(), error=error
        )
        outcome = Outcome(
            text=text,
            turns=meter.turns,
            stop_reason=stop_reason,
            session=session,
            usage=dict(meter.usage),
            cost_usd=round(meter.cost_usd, 6),
            tool_calls=meter.tool_calls,
            error=error,
            recalled=recall.ids(),
            seams=seams.counts(),
        )
        checkpoint(status, outcome)
        return outcome

    last_text = ""
    while True:
        # ----------------------------------------------------- orçamento
        exhausted = meter.exhausted()
        if exhausted:
            return finish(last_text, f"budget:{exhausted}")
        turn = meter.turns + 1
        seams.turn = turn

        # ---------------------------------------------- retomada de journal
        recovering = state is not None and bool(state.pending_calls)
        if recovering and state is not None:
            ambiguous = state.ambiguous_calls()
            if ambiguous:
                raise StateConflict(
                    "retomada pausada: efeito de ferramenta ambíguo em " + ", ".join(ambiguous)
                )
            reply = Reply(
                content=[
                    {"type": "tool_use", "id": c["id"], "name": c["name"], "input": c["arguments"]}
                    for c in state.pending_calls
                ],
                stop_reason="tool_use",
            )
        else:
            # ------------------------------------------------ janela
            if agent.window is not None:
                pedido = Request(system=system, messages=messages, tools=tools)
                if agent.window.plan(pedido) == "compact":
                    try:
                        novas, comp = agent.window.compact(
                            agent.provider, system, messages, task=task,
                            metadata={"session": session, "agent": agent.name, "turn": turn},
                        )
                    except ProviderError as erro:
                        meter.turns = turn
                        return finish(last_text, "error", error=f"compactação: {erro}")
                    meter.add_usage(comp.usage)
                    arquivo = {
                        "turn": turn,
                        "generation": comp.generation,
                        "archived": messages[:],
                        "summary": comp.summary,
                        "estimated_before": comp.estimated_before,
                        "estimated_after": comp.estimated_after,
                    }
                    messages[:] = novas
                    if state is not None:
                        state.meta.setdefault("compactions", []).append(arquivo)
                        checkpoint()
                    seams.emit(
                        "context.assemble",
                        compaction=comp.generation,
                        archived_messages=comp.archived_messages,
                        estimated_before=comp.estimated_before,
                        estimated_after=comp.estimated_after,
                        summary_chars=len(comp.summary),
                    )
            seams.emit(
                "llm.request",
                messages=len(messages),
                tools=len(tools),
                model=getattr(agent.provider, "model", ""),
                effort=getattr(agent.provider, "effort", ""),
            )
            try:
                reply = agent.provider.complete(
                    Request(
                        system=system,
                        messages=messages,
                        tools=tools,
                        metadata={"session": session, "agent": agent.name, "turn": turn, "role": "loop"},
                    )
                )
            except ProviderError as erro:
                meter.turns = turn
                return finish(last_text, "error", error=str(erro))
            except Exception as erro:
                meter.turns = turn
                return finish(last_text, "error", error=f"{type(erro).__name__}: {erro}")
            meter.add_usage(reply.usage)
            seams.emit(
                "llm.response",
                stop_reason=reply.stop_reason,
                tool_uses=len(reply.tool_uses),
                usage=reply.usage,
                chars=len(reply.text),
                request_id=reply.request_id,
            )

            # Recusa é 200 com stop_reason=refusal: ler `content` sem conferir
            # entregaria vazio como se fosse resposta.
            if reply.stop_reason == "refusal":
                meter.turns = turn
                detail = (
                    (reply.stop_details or {}).get("explanation")
                    or (reply.stop_details or {}).get("category")
                    or "sem detalhe"
                )
                return finish("", "refusal", error=f"o modelo recusou: {detail}")

            messages.append({"role": "assistant", "content": reply.content})
            if reply.text.strip():
                last_text = reply.text

            # Ferramenta de servidor bateu no teto dela: reenviar continua.
            if reply.stop_reason == "pause_turn":
                meter.turns = turn
                checkpoint()
                seams.emit("turn.end", stop_reason="pause_turn")
                continue

        calls = [ToolCall(tu.id, tu.name, tu.input) for tu in reply.tool_uses]
        if not calls:
            meter.turns = turn
            if not reply.text.strip():
                # Nem texto nem ferramenta: uma chamada malformada engolida
                # pelo servidor, um modelo pequeno que "terminou" sem dizer
                # nada. Não é sucesso: é `empty`, com o que o traço sabe.
                seams.emit("turn.end", stop_reason="empty")
                return finish(
                    last_text,
                    "empty",
                    error=(
                        f"o modelo devolveu resposta vazia (stop_reason={reply.stop_reason}, "
                        f"{int(reply.usage.get('output_tokens', 0))} tokens de saída, "
                        f"{len(reply.content)} blocos)"
                    ),
                )
            seams.emit("turn.end", stop_reason=reply.stop_reason)
            return finish(reply.text, reply.stop_reason)

        # ------------------------------------------------ journal durável
        if state is not None and not recovering:
            state.plan_calls(
                [{"id": c.id, "name": c.name, "arguments": c.arguments} for c in calls]
            )
            checkpoint()
        journal = {c["id"]: c for c in state.pending_calls} if state is not None else {}

        def one(call: ToolCall, journal: dict[str, dict[str, Any]] = journal) -> ToolResult:
            """Uma chamada: reusa o confirmado, ou decide, executa e confirma.

            Roda em thread quando o grupo é paralelo: aqui não se toca em
            `messages`, `state` nem `seams` — isso fica com o laço, em ordem.
            """
            entry = journal.get(call.id)
            if entry and entry["status"] == "completed" and entry.get("result") is not None:
                return _result_from_dict(entry["result"])
            try:
                return normalize(toolset(call.name, call.arguments))
            except Exception as erro:
                return ToolResult.error(f"{type(erro).__name__}: {erro}", code=500)

        # ------------------------------------------- decidir (governança)
        decided: list[tuple[ToolCall, ToolResult | None]] = []
        for call in calls:
            risk = _risk(toolset, call.name)
            d = agent.policy.before_tool(call, risk)
            seams.emit(
                "policy.decision",
                tool=call.name,
                id=call.id,
                risk=risk,
                allow=d.allow,
                reason=d.reason,
                policy=d.policy,
            )
            if not d.allow:
                decided.append((call, d.to_result()))
            else:
                decided.append(
                    (
                        ToolCall(
                            call.id,
                            call.name,
                            d.arguments if d.arguments is not None else call.arguments,
                        ),
                        None,
                    )
                )

        # ------------------------------------------------- executar em grupos
        results: dict[str, ToolResult] = {}
        i = 0
        while i < len(decided):
            call, denied = decided[i]
            if denied is not None:
                results[call.id] = denied
                i += 1
                continue
            group = [call]
            j = i + 1
            if _parallel_safe(toolset, call.name):
                while (
                    j < len(decided)
                    and decided[j][1] is None
                    and _parallel_safe(toolset, decided[j][0].name)
                ):
                    group.append(decided[j][0])
                    j += 1
            for c in group:
                seams.emit(
                    "tool.call",
                    tool=c.name,
                    id=c.id,
                    arguments=c.arguments,
                    parallel=len(group) > 1,
                )
                if state is not None and journal.get(c.id, {}).get("status") != "completed":
                    state.mark(c.id, "running")
            if state is not None:
                checkpoint()
            t0 = time.perf_counter()
            if len(group) == 1:
                outs = [one(group[0])]
            else:
                with ThreadPoolExecutor(max_workers=min(agent.max_parallel, len(group))) as pool:
                    outs = list(pool.map(one, group))
            ms = round((time.perf_counter() - t0) * 1000, 2)
            for c, r in zip(group, outs, strict=True):
                r = agent.policy.after_tool(c, r)
                results[c.id] = r
                if state is not None:
                    state.mark(c.id, "completed", _result_to_dict(r))
                seams.emit(
                    "tool.result",
                    tool=c.name,
                    id=c.id,
                    ok=r.ok,
                    code=r.code,
                    chars=len(r.text),
                    ms=ms,
                    **({"metadata": r.metadata} if r.metadata else {}),
                )
                agent.memory.observe(
                    "tool",
                    f"[{c.name}] {_brief(c.arguments)} -> {r.text}",
                    session=session,
                    turn=turn,
                    tool=c.name,
                    ok=r.ok,
                )
            if state is not None:
                checkpoint()
            i = j if len(group) > 1 else i + 1

        meter.tool_calls += len(calls)
        # Todos os resultados numa única mensagem, na ordem dos pedidos.
        messages.append({"role": "user", "content": [results[c.id].to_block(c.id) for c in calls]})
        meter.turns = turn
        if state is not None:
            state.clear_calls()
        checkpoint()
        seams.emit("turn.end", stop_reason="tool_use", tool_calls=len(calls))


def _brief(arguments: dict[str, Any], limit: int = 160) -> str:
    s = ", ".join(f"{k}={str(v)[:60]!r}" for k, v in arguments.items())
    return s if len(s) <= limit else s[:limit] + "…"
