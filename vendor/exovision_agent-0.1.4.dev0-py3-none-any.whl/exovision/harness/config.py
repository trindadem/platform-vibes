"""Configuração: onde a credencial mora, e como chega ao ambiente.

A regra é a do *twelve-factor* (Wiggins, 2017, III. Config): configuração no
ambiente. Os drivers já leem `ANTHROPIC_API_KEY`, `OPENAI_API_KEY`,
`GEMINI_API_KEY`, `EXOVISION_*` de `os.environ`; este módulo cuida só de
**como a variável chega lá** sem `set -a; source .env` à mão:

    $XDG_CONFIG_HOME/exovision/env     o arquivo global do usuário (XDG; 0600)
    ./.env                              o do projeto, quando existe
    <perfil>/.env                       o do diretório de perfil/equipe, se o subcomando recebe um

Ordem de precedência, da maior para a menor: **o ambiente já posto** (o que o
operador exportou de propósito nunca é sobrescrito por um arquivo esquecido),
o `.env` do perfil, o `./.env`, o global. `EXOVISION_CONFIG_DIR` troca o
diretório global (é o que os testes usam); `EXOVISION_NO_ENV=1` desliga tudo.

Parser stdlib: `CHAVE=valor`, `export CHAVE=valor`, `#` comentário, aspas
simples ou duplas (dentro de aspas duplas valem `\\n`, `\\t`, `\\"`, `\\\\`);
sem interpolação, sem multilinha — é o subconjunto que um arquivo de segredos
precisa, e não puxa dependência.
"""

from __future__ import annotations

import contextlib
import json
import os
import re
import stat
from collections.abc import Iterable, Mapping, MutableMapping
from pathlib import Path

__all__ = [
    "ENV_FILE",
    "STATE_FILE",
    "config_dir",
    "data_dir",
    "env_file",
    "env_file_mode_ok",
    "load_env",
    "load_env_file",
    "load_state",
    "parse_env",
    "save_state",
    "state_path",
    "write_env_file",
]

ENV_FILE = "env"
_LINE = re.compile(r"^\s*(?:export\s+)?([A-Za-z_][A-Za-z0-9_]*)\s*=\s*(.*?)\s*$")
_ESCAPES = {"n": "\n", "t": "\t", "r": "\r", '"': '"', "\\": "\\"}


def config_dir() -> Path:
    """`$EXOVISION_CONFIG_DIR`, senão `$XDG_CONFIG_HOME/exovision`, senão `~/.config/exovision`."""
    override = os.environ.get("EXOVISION_CONFIG_DIR")
    if override:
        return Path(override).expanduser()
    base = os.environ.get("XDG_CONFIG_HOME") or str(Path.home() / ".config")
    return Path(base).expanduser() / "exovision"


def data_dir() -> Path:
    """`$XDG_DATA_HOME/exovision` (padrão `~/.local/share/exovision`): onde ficam bancos que não são de um projeto."""
    override = os.environ.get("EXOVISION_DATA_DIR")
    if override:
        return Path(override).expanduser()
    base = os.environ.get("XDG_DATA_HOME") or str(Path.home() / ".local" / "share")
    return Path(base).expanduser() / "exovision"


def env_file() -> Path:
    return config_dir() / ENV_FILE


def _unquote(raw: str) -> str:
    v = raw
    if v[:1] == '"':
        out: list[str] = []
        i = 1
        while i < len(v):
            ch = v[i]
            if ch == "\\" and i + 1 < len(v) and v[i + 1] in _ESCAPES:
                out.append(_ESCAPES[v[i + 1]])
                i += 2
                continue
            if ch == '"':
                return "".join(out)  # o que vem depois da aspa que fecha (comentário) é ignorado
            out.append(ch)
            i += 1
        return v  # aspa sem par: vale literal
    if v[:1] == "'":
        fim = v.find("'", 1)
        return v[1:fim] if fim > 0 else v
    # sem aspas: o `#` depois de espaço é comentário
    m = re.match(r"^(.*?)(?:\s+#.*)?$", v)
    return (m.group(1) if m else v).strip()


def parse_env(text: str) -> dict[str, str]:
    """Texto de um `.env` -> dict. Linhas malformadas são ignoradas (um segredo nunca vira erro na tela)."""
    out: dict[str, str] = {}
    for line in text.splitlines():
        s = line.strip()
        if not s or s.startswith("#"):
            continue
        m = _LINE.match(line)
        if not m:
            continue
        out[m.group(1)] = _unquote(m.group(2))
    return out


def load_env_file(path: Path | str, *, override: bool = False, environ: MutableMapping[str, str] | None = None) -> list[str]:
    """Carrega `path` em `environ` (padrão `os.environ`); devolve as chaves postas. Sem `override`, o que já está no ambiente fica."""
    p = Path(path).expanduser()
    if not p.is_file():
        return []
    env = os.environ if environ is None else environ
    postas: list[str] = []
    try:
        pares = parse_env(p.read_text(encoding="utf-8"))
    except OSError:
        return []
    for k, v in pares.items():
        if override or k not in env:
            env[k] = v
            postas.append(k)
    return postas


def load_env(*, cwd: Path | str | None = None, profile_dir: Path | str | None = None, environ: MutableMapping[str, str] | None = None) -> dict[str, list[str]]:
    """A ordem inteira: perfil, `./.env`, global — o mais específico primeiro, e o ambiente já posto sempre ganha.

    Devolve `{caminho: [chaves postas]}` para o `doctor` mostrar de onde veio o quê (nunca o valor).
    """
    env = os.environ if environ is None else environ
    if env.get("EXOVISION_NO_ENV"):
        return {}
    ordem: list[Path] = []
    if profile_dir:
        ordem.append(Path(profile_dir).expanduser() / ".env")
    ordem.append(Path(cwd or os.getcwd()) / ".env")
    ordem.append(env_file() if environ is None else _env_file_from(env))
    vistos: set[Path] = set()
    resultado: dict[str, list[str]] = {}
    for p in ordem:
        rp = p.resolve() if p.exists() else p
        if rp in vistos:
            continue
        vistos.add(rp)
        postas = load_env_file(p, environ=env)
        if postas:
            resultado[str(p)] = postas
    return resultado


def _env_file_from(env: Mapping[str, str]) -> Path:
    override = env.get("EXOVISION_CONFIG_DIR")
    if override:
        return Path(override).expanduser() / ENV_FILE
    base = env.get("XDG_CONFIG_HOME") or str(Path.home() / ".config")
    return Path(base).expanduser() / "exovision" / ENV_FILE


def env_file_mode_ok(path: Path | str) -> bool:
    """`True` se só o dono lê o arquivo (0600 ou mais fechado). No Windows não há bits: `True`."""
    p = Path(path)
    if os.name != "posix" or not p.exists():
        return True
    mode = stat.S_IMODE(p.stat().st_mode)
    return not (mode & (stat.S_IRWXG | stat.S_IRWXO))


def write_env_file(path: Path | str, pairs: Mapping[str, str], *, keep: Iterable[str] = ()) -> Path:
    """Grava/atualiza `path` com `pairs`, nascendo 0600; mantém as chaves já lá que não estão em `pairs`.

    Nunca imprime nada: o valor é segredo. Aspas duplas quando o valor tem espaço, `#` ou aspas.
    """
    p = Path(path).expanduser()
    p.parent.mkdir(parents=True, exist_ok=True)
    atuais: dict[str, str] = parse_env(p.read_text(encoding="utf-8")) if p.is_file() else {}
    atuais.update(pairs)
    for k in keep:
        atuais.setdefault(k, "")
    linhas = ["# exovision-agent — credenciais e padrões. Só o dono lê este arquivo (0600).", "# O ambiente já exportado tem precedência sobre o que está aqui."]
    for k, v in atuais.items():
        linhas.append(f"{k}={_quote(v)}")
    tmp = p.with_name(p.name + ".tmp")
    fd = os.open(tmp, os.O_WRONLY | os.O_CREAT | os.O_TRUNC, 0o600)
    with os.fdopen(fd, "w", encoding="utf-8") as f:
        f.write("\n".join(linhas) + "\n")
    os.replace(tmp, p)
    if os.name == "posix":
        os.chmod(p, 0o600)
    return p


def _quote(v: str) -> str:
    if v == "" or re.search(r"[\s#'\"\\]", v):
        esc = v.replace("\\", "\\\\").replace('"', '\\"').replace("\n", "\\n")
        return f'"{esc}"'
    return v


# ---------------------------------------------------------------- o que a CLI lembra

STATE_FILE = "state.json"


def state_path() -> Path:
    """`$XDG_CONFIG_HOME/exovision/state.json`: preferências entre execuções.

    Nada de segredo aqui (esse é o `env`): só o último agente e a última
    sessão, para que `exovision-agent` sozinho abra onde o usuário parou.
    """
    return config_dir() / STATE_FILE


def load_state() -> dict[str, str]:
    p = state_path()
    if not p.is_file():
        return {}
    try:
        data = json.loads(p.read_text(encoding="utf-8"))
    except (OSError, ValueError):
        return {}
    return {str(k): str(v) for k, v in data.items()} if isinstance(data, dict) else {}


def save_state(**pairs: str) -> Path:
    """Atualiza o que já estava lá. Falha em silêncio: lembrar é conveniência, não função."""
    p = state_path()
    atual = load_state()
    atual.update({k: str(v) for k, v in pairs.items() if v})
    with contextlib.suppress(OSError):
        p.parent.mkdir(parents=True, exist_ok=True)
        tmp = p.with_name(p.name + ".tmp")
        tmp.write_text(json.dumps(atual, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
        os.replace(tmp, p)
    return p
