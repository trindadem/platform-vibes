"""O barramento embarcado: assuntos hierárquicos, curingas, consumidores duráveis — em SQLite.

`Event.subject` já nasce hierárquico e compatível com NATS
(`seam.<sessão>.<costura>`); o que faltava era um barramento que entendesse
isso **sem um serviço a mais**. Este módulo é essa transposição: um arquivo
(ou `:memory:`), uma tabela de mensagens com número de sequência monotônico,
e consumidores nomeados com cursor durável. A semântica de assunto é a do
NATS (nats.io, *Subject-Based Messaging*): tokens separados por `.`, `*`
casa exatamente um token, `>` casa um ou mais tokens no fim.

    bus = Bus(".exovision/bus.db")
    bus.publish("agente.revisor.pronto", {"pr": 42})
    sub = bus.subscribe("agente.*.pronto", name="redator")   # cursor durável
    for m in sub.pull():  ...; sub.ack(m.seq)

    bus.attach(seams)      # todo evento do traço vira mensagem: seam.<sessão>.<costura>
    BusToolset(bus)        # `bus_publish` e `bus_read`: agentes conversam pelo barramento

O que ele é: entrega **pelo menos uma vez** a consumidores que puxam
(`pull`) e confirmam (`ack`); vários processos no mesmo arquivo; ordem total
por `seq`. O que ele não é: um serviço de rede. Um nó, N processos — é o
alcance de um arquivo, e é dito.
"""

from __future__ import annotations

import contextlib
import json
import sqlite3
import threading
import time
from collections.abc import Callable, Iterator
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

from .seams import Event, Seams
from .session import enable_wal
from .tools import Registry, Tool, ToolResult

__all__ = ["Bus", "BusToolset", "Message", "Subscription", "match", "valid_subject"]


# --------------------------------------------------------------------------
# assuntos
# --------------------------------------------------------------------------


def valid_subject(subject: str, *, pattern: bool = False) -> bool:
    """Tokens não vazios separados por `.`; sem espaço. `*`/`>` só em padrões."""
    if not subject or " " in subject or subject.startswith(".") or subject.endswith("."):
        return False
    tokens = subject.split(".")
    for i, t in enumerate(tokens):
        if not t:
            return False
        if t in ("*", ">"):
            if not pattern:
                return False
            if t == ">" and i != len(tokens) - 1:
                return False
        elif "*" in t or ">" in t:
            return False
    return True


def match(pattern: str, subject: str) -> bool:
    """Casamento NATS: `*` = um token; `>` = um ou mais tokens, só no fim."""
    p = pattern.split(".")
    s = subject.split(".")
    for i, tok in enumerate(p):
        if tok == ">":
            return len(s) > i
        if i >= len(s):
            return False
        if tok != "*" and tok != s[i]:
            return False
    return len(s) == len(p)


def _sql_prefilter(pattern: str) -> tuple[str, list[Any]]:
    """Reduz o SELECT pelo prefixo literal do padrão; o casamento exato é em Python."""
    literal: list[str] = []
    for tok in pattern.split("."):
        if tok in ("*", ">"):
            break
        literal.append(tok)
    if not literal:
        return "1=1", []
    prefix = ".".join(literal)
    if len(literal) == len(pattern.split(".")):
        return "subject = ?", [prefix]
    return "subject LIKE ? ESCAPE '\\'", [prefix.replace("%", "\\%").replace("_", "\\_") + ".%"]


# --------------------------------------------------------------------------
# mensagens
# --------------------------------------------------------------------------


@dataclass(frozen=True, slots=True)
class Message:
    seq: int
    subject: str
    data: dict[str, Any]
    at: float

    def to_dict(self) -> dict[str, Any]:
        return {"seq": self.seq, "subject": self.subject, "data": self.data, "at": self.at}


_SCHEMA = """
CREATE TABLE IF NOT EXISTS messages (
    seq INTEGER PRIMARY KEY AUTOINCREMENT,
    subject TEXT NOT NULL,
    data TEXT NOT NULL,
    at REAL NOT NULL
);
CREATE INDEX IF NOT EXISTS messages_subject ON messages(subject, seq);
CREATE TABLE IF NOT EXISTS consumers (
    name TEXT PRIMARY KEY,
    pattern TEXT NOT NULL,
    cursor INTEGER NOT NULL DEFAULT 0,
    updated_at REAL NOT NULL
);
"""


class Bus:
    """Um arquivo, duas tabelas. `publish` é um INSERT confirmado; `seq` é a ordem."""

    def __init__(
        self,
        path: str | Path = ":memory:",
        *,
        keep: int | None = 100_000,
        clock: Callable[[], float] = time.time,
        busy_timeout_s: float = 30.0,
    ) -> None:
        self.path = str(path)
        self.keep = keep
        self._clock = clock
        self._lock = threading.RLock()
        if self.path != ":memory:":
            Path(self.path).parent.mkdir(parents=True, exist_ok=True)
        self._conn = sqlite3.connect(
            self.path, isolation_level=None, check_same_thread=False, timeout=busy_timeout_s
        )
        self._conn.row_factory = sqlite3.Row
        with self._lock:
            self._conn.execute(f"PRAGMA busy_timeout={int(busy_timeout_s * 1000)}")
            if self.path != ":memory:":
                enable_wal(self._conn, timeout_s=busy_timeout_s)
            self._conn.executescript(_SCHEMA)
        self._published = 0

    @contextlib.contextmanager
    def _tx(self) -> Iterator[sqlite3.Connection]:
        with self._lock:
            self._conn.execute("BEGIN IMMEDIATE")
            try:
                yield self._conn
            except BaseException:
                self._conn.execute("ROLLBACK")
                raise
            else:
                self._conn.execute("COMMIT")

    # ------------------------------------------------------------ publicar
    def publish(self, subject: str, data: dict[str, Any] | None = None) -> Message:
        if not valid_subject(subject):
            raise ValueError(f"assunto inválido: {subject!r} (tokens por '.', sem '*'/'>' nem espaço)")
        now = self._clock()
        blob = json.dumps(data or {}, ensure_ascii=False, sort_keys=True, default=str)
        with self._tx() as conn:
            cur = conn.execute(
                "INSERT INTO messages(subject, data, at) VALUES (?, ?, ?)", (subject, blob, now)
            )
            seq = int(cur.lastrowid or 0)
            self._published += 1
            if self.keep is not None and self._published % 1000 == 0:
                self._prune(conn)
        return Message(seq=seq, subject=subject, data=json.loads(blob), at=now)

    def _prune(self, conn: sqlite3.Connection) -> None:
        """Retenção por quantidade — nunca abaixo do cursor mais atrasado de um consumidor."""
        if self.keep is None:
            return
        row = conn.execute("SELECT MAX(seq) FROM messages").fetchone()
        top = int(row[0] or 0)
        floor = top - self.keep
        low = conn.execute("SELECT MIN(cursor) FROM consumers").fetchone()[0]
        if low is not None:
            floor = min(floor, int(low))
        if floor > 0:
            conn.execute("DELETE FROM messages WHERE seq <= ?", (floor,))

    def prune(self) -> None:
        with self._tx() as conn:
            self._prune(conn)

    # ---------------------------------------------------------------- ler
    def read(self, pattern: str = ">", *, after: int = 0, limit: int = 100) -> list[Message]:
        """Leitura sem estado: mensagens com `seq > after` que casam o padrão."""
        if not valid_subject(pattern, pattern=True):
            raise ValueError(f"padrão inválido: {pattern!r}")
        where, params = _sql_prefilter(pattern)
        out: list[Message] = []
        with self._lock:
            rows = self._conn.execute(
                f"SELECT seq, subject, data, at FROM messages WHERE seq > ? AND {where} ORDER BY seq",
                [after, *params],
            )
            for r in rows:
                if match(pattern, r["subject"]):
                    out.append(Message(int(r["seq"]), r["subject"], json.loads(r["data"]), float(r["at"])))
                    if len(out) >= limit:
                        break
        return out

    def last_seq(self) -> int:
        with self._lock:
            row = self._conn.execute("SELECT MAX(seq) FROM messages").fetchone()
        return int(row[0] or 0)

    def subscribe(self, pattern: str, *, name: str, start: str | int = "new") -> Subscription:
        """Consumidor durável: o cursor fica no arquivo, sob `name`.

        `start`: `"new"` (só o que chegar depois), `"all"` (desde o início) ou
        um `seq`. Só vale na criação; um consumidor que já existe retoma de onde parou.
        """
        if not valid_subject(pattern, pattern=True):
            raise ValueError(f"padrão inválido: {pattern!r}")
        with self._tx() as conn:
            row = conn.execute("SELECT cursor FROM consumers WHERE name = ?", (name,)).fetchone()
            if row is None:
                if start == "new":
                    cursor = int(conn.execute("SELECT MAX(seq) FROM messages").fetchone()[0] or 0)
                elif start == "all":
                    cursor = 0
                else:
                    cursor = int(start)
                conn.execute(
                    "INSERT INTO consumers(name, pattern, cursor, updated_at) VALUES (?,?,?,?)",
                    (name, pattern, cursor, self._clock()),
                )
            else:
                conn.execute("UPDATE consumers SET pattern = ? WHERE name = ?", (pattern, name))
        return Subscription(self, name, pattern)

    def _cursor(self, name: str) -> int:
        with self._lock:
            row = self._conn.execute("SELECT cursor FROM consumers WHERE name = ?", (name,)).fetchone()
        return int(row[0]) if row else 0

    def _ack(self, name: str, seq: int) -> bool:
        """Avança o cursor — só para a frente (CAS): dois processos não o recuam."""
        with self._tx() as conn:
            cur = conn.execute(
                "UPDATE consumers SET cursor = ?, updated_at = ? WHERE name = ? AND cursor < ?",
                (seq, self._clock(), name, seq),
            )
            return cur.rowcount == 1

    def consumers(self) -> list[dict[str, Any]]:
        with self._lock:
            rows = self._conn.execute(
                "SELECT name, pattern, cursor, updated_at FROM consumers ORDER BY name"
            ).fetchall()
        return [dict(r) for r in rows]

    def unsubscribe(self, name: str) -> bool:
        with self._tx() as conn:
            return conn.execute("DELETE FROM consumers WHERE name = ?", (name,)).rowcount == 1

    # -------------------------------------------------------------- traço
    def attach(self, seams: Seams, *, subject: Callable[[Event], str] | None = None) -> None:
        """Todo evento do traço vira mensagem durável: `seam.<sessão>.<costura>` por padrão."""

        def publica(e: Event) -> None:
            self.publish((subject or (lambda ev: ev.subject))(e), e.to_dict())

        seams.on("*", publica)

    def close(self) -> None:
        with self._lock:
            self._conn.close()


@dataclass
class Subscription:
    """Puxa e confirma. Sem `ack`, a mensagem volta na próxima `pull` (pelo menos uma vez)."""

    bus: Bus
    name: str
    pattern: str
    _pending: list[Message] = field(default_factory=list, repr=False)

    @property
    def cursor(self) -> int:
        return self.bus._cursor(self.name)

    def pull(self, limit: int = 100) -> list[Message]:
        return self.bus.read(self.pattern, after=self.cursor, limit=limit)

    def ack(self, seq: int) -> bool:
        return self.bus._ack(self.name, seq)

    def __iter__(self) -> Iterator[Message]:
        """Itera confirmando cada mensagem depois de entregue ao corpo do laço."""
        while True:
            batch = self.pull()
            if not batch:
                return
            for m in batch:
                yield m
                self.ack(m.seq)


# --------------------------------------------------------------------------
# ferramentas: agentes conversam pelo barramento
# --------------------------------------------------------------------------


class BusToolset(Registry):
    """`bus_publish(subject, text)` e `bus_read(pattern, after, limit)` como ferramentas.

    Publicar é `write`; ler é `read` e paralelo. O que um agente lê do
    barramento é resultado de ferramenta — `UNTRUSTED` na memória, como tudo
    o que vem de fora do laço.
    """

    def __init__(self, bus: Bus, *, prefix: str = "bus", max_chars: int = 4000) -> None:
        self.bus = bus

        def bus_publish(subject: str, text: str, data: dict[str, Any] | None = None) -> ToolResult:
            try:
                m = bus.publish(subject, {"text": text, **(data or {})})
            except ValueError as erro:
                return ToolResult.error(str(erro), code=422)
            return ToolResult(text=f"publicada #{m.seq} em {m.subject}", metadata={"seq": m.seq})

        def bus_read(pattern: str = ">", after: int = 0, limit: int = 20) -> ToolResult:
            try:
                msgs = bus.read(pattern, after=after, limit=max(1, min(limit, 100)))
            except ValueError as erro:
                return ToolResult.error(str(erro), code=422)
            if not msgs:
                return ToolResult(text="(nenhuma mensagem)", metadata={"last_seq": after})
            linhas = [f"#{m.seq} {m.subject}: {json.dumps(m.data, ensure_ascii=False)[:300]}" for m in msgs]
            texto = "\n".join(linhas)
            if len(texto) > max_chars:
                texto = texto[:max_chars] + "\n…"
            return ToolResult(text=texto, metadata={"last_seq": msgs[-1].seq, "count": len(msgs)})

        super().__init__(
            [
                Tool(
                    name=f"{prefix}_publish",
                    description="Publica uma mensagem no barramento, num assunto hierárquico (ex.: equipe.revisor.pronto). Outros agentes e gatilhos leem por padrão de assunto.",
                    fn=bus_publish,
                    input_schema={
                        "type": "object",
                        "properties": {
                            "subject": {"type": "string", "description": "assunto: tokens separados por ponto, sem curingas"},
                            "text": {"type": "string", "description": "o conteúdo da mensagem"},
                            "data": {"type": "object", "description": "campos extras (opcional)"},
                        },
                        "required": ["subject", "text"],
                    },
                    parallel_safe=False,
                    risk="write",
                ),
                Tool(
                    name=f"{prefix}_read",
                    description="Lê mensagens do barramento que casam um padrão de assunto ('*' = um token, '>' = o resto), a partir de um seq. Devolve seq, assunto e conteúdo.",
                    fn=bus_read,
                    input_schema={
                        "type": "object",
                        "properties": {
                            "pattern": {"type": "string", "description": "padrão de assunto; padrão '>' (tudo)"},
                            "after": {"type": "integer", "description": "só mensagens com seq maior que este (padrão 0)"},
                            "limit": {"type": "integer", "description": "máximo de mensagens (padrão 20)"},
                        },
                    },
                    parallel_safe=True,
                    risk="read",
                ),
            ]
        )
