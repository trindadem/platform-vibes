"""Orçamento: execução agêntica sem teto é conta aberta.

Um agente preso num par de ações repete até o dinheiro acabar. O orçamento
fecha a conta por quatro eixos independentes — voltas, tokens, custo estimado e
tempo de parede — e o laço para **graciosamente**: devolve o último texto e um
`stop_reason` que diz qual eixo estourou, em vez de uma exceção que joga fora
o trabalho feito.

`Meter` é o acumulador; ele é o que o traço e o `Outcome` reportam.
"""

from __future__ import annotations

import time
from collections.abc import Callable
from dataclasses import dataclass, field
from typing import Any

from .models.provider import estimate_cost_usd

__all__ = ["MAX_TURNS", "Budget", "Meter"]

#: Teto de voltas padrão.
MAX_TURNS = 60


@dataclass(frozen=True, slots=True)
class Budget:
    max_turns: int = MAX_TURNS
    max_input_tokens: int | None = None
    max_output_tokens: int | None = None
    max_cost_usd: float | None = None
    max_wall_s: float | None = None
    max_tool_calls: int | None = None


@dataclass(slots=True)
class Meter:
    budget: Budget = field(default_factory=Budget)
    model: str = ""
    turns: int = 0
    tool_calls: int = 0
    usage: dict[str, int] = field(default_factory=dict)
    started_at: float = 0.0
    #: multiplicador do regime de cobrança (1.0 síncrono, 0.5 em lote).
    discount: float = 1.0
    _clock: Callable[[], float] = field(default=time.time, repr=False)

    def start(self) -> None:
        self.started_at = self._clock()

    def add_usage(self, parcel: dict[str, int]) -> None:
        for k, v in parcel.items():
            if isinstance(v, int):
                self.usage[k] = self.usage.get(k, 0) + v

    @property
    def input_tokens(self) -> int:
        return (
            self.usage.get("input_tokens", 0)
            + self.usage.get("cache_creation_input_tokens", 0)
            + self.usage.get("cache_read_input_tokens", 0)
        )

    @property
    def output_tokens(self) -> int:
        return self.usage.get("output_tokens", 0)

    @property
    def cost_usd(self) -> float:
        return estimate_cost_usd(self.model, self.usage, discount=self.discount)

    @property
    def elapsed_s(self) -> float:
        return (self._clock() - self.started_at) if self.started_at else 0.0

    def exhausted(self) -> str | None:
        """O eixo que estourou, ou None."""
        b = self.budget
        if self.turns >= b.max_turns:
            return f"max_turns={b.max_turns}"
        if b.max_input_tokens is not None and self.input_tokens >= b.max_input_tokens:
            return f"max_input_tokens={b.max_input_tokens}"
        if b.max_output_tokens is not None and self.output_tokens >= b.max_output_tokens:
            return f"max_output_tokens={b.max_output_tokens}"
        if b.max_cost_usd is not None and self.cost_usd >= b.max_cost_usd:
            return f"max_cost_usd={b.max_cost_usd}"
        if b.max_wall_s is not None and self.elapsed_s >= b.max_wall_s:
            return f"max_wall_s={b.max_wall_s}"
        if b.max_tool_calls is not None and self.tool_calls >= b.max_tool_calls:
            return f"max_tool_calls={b.max_tool_calls}"
        return None

    def to_dict(self) -> dict[str, Any]:
        return {
            "turns": self.turns,
            "tool_calls": self.tool_calls,
            "usage": dict(self.usage),
            "input_tokens": self.input_tokens,
            "output_tokens": self.output_tokens,
            "cost_usd": round(self.cost_usd, 6),
            "elapsed_s": round(self.elapsed_s, 3),
        }
