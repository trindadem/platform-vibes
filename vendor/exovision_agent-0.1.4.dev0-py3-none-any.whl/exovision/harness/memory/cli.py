"""`exovision-agent memory`: as 21 categorias de memória pela linha de comando.

    exovision-agent memory kinds                                   # as categorias, com regime e módulo
    exovision-agent memory write episodic "o deploy falhou às 3h" --db mem.db
    exovision-agent memory write entity "vortex.cidade = Lisboa" --db mem.db   # ou --payload '{"entity":..,"slot":..,"value":..}'
    exovision-agent memory write collective "..." --actor ana --db mem.db     # coletiva exige autoria
    exovision-agent memory read  episodic "deploy" --db mem.db -k 5 --json
    exovision-agent memory stats episodic --db mem.db
    exovision-agent memory consolidate semantic --db mem.db
    exovision-agent mem kinds                                      # `mem` é atalho de `memory`

Sem `--db` a memória vive só no processo (útil para `kinds` e para ver como
uma categoria reage a um texto). `--embedder` aceita os mesmos nomes de
`exovision-agent rag` (`hashing[:dim]`, `model2vec`, `fastembed`, ...); o
padrão é o hashing determinístico da memória.

Este módulo não tem `main`: ele registra o subcomando no parser de
`exovision.harness.cli` por `add_parser(sub)`, como `specialize` e `rag`.
"""

from __future__ import annotations

import argparse
import dataclasses
import json
from typing import Any

from .core.base import MemoryQuery, MemorySubsystem
from .core.record import MemoryRecord, Provenance
from .core.store import SQLiteStore
from .core.types import MemoryKind, ProvenanceKind
from .systems import SYSTEMS

__all__ = ["add_parser", "open_memory"]


def _kind(name: str) -> MemoryKind:
    try:
        return MemoryKind(name)
    except ValueError:
        opts = ", ".join(k.value for k in SYSTEMS)
        raise SystemExit(f"categoria desconhecida: {name!r}; opções: {opts}") from None


def open_memory(kind: str, *, db: str | None = None, embedder: str | None = None) -> MemorySubsystem:
    """Instancia a categoria `kind` sobre SQLite (`db`) ou em memória."""
    cls = SYSTEMS[_kind(kind)]
    kw: dict[str, Any] = {}
    if db:
        kw["store"] = SQLiteStore(db)
    if embedder:
        from ..rag.embed import load_embedder

        kw["embedder"] = load_embedder(embedder)
    return cls(**kw)


def _record_dict(r: MemoryRecord) -> dict[str, Any]:
    return {
        "id": r.id,
        "kind": r.kind.value,
        "content": r.content,
        "tags": list(r.tags),
        "importance": r.importance,
        "confidence": r.confidence,
        "created_at": r.created_at,
        "valid_to": r.valid_to,
    }


# --------------------------------------------------------------------------
# comandos
# --------------------------------------------------------------------------


def cmd_kinds(a: argparse.Namespace) -> int:
    rows: list[dict[str, Any]] = []
    for kind, cls in SYSTEMS.items():
        doc = (cls.__doc__ or "").strip().splitlines()
        rows.append({"kind": kind.value, "class": cls.__name__, "emergent": bool(cls.emergent), "module": cls.__module__.rsplit(".", 1)[-1], "summary": doc[0] if doc else ""})
    if a.json:
        print(json.dumps(rows, ensure_ascii=False, indent=2))
        return 0
    width = max(len(r["kind"]) for r in rows)
    for r in rows:
        regime = "emergente " if r["emergent"] else "tradicional"
        print(f"{r['kind']:{width}s}  {regime}  {r['class']:24s}  {r['summary'][:70]}")
    return 0


def cmd_write(a: argparse.Namespace) -> int:
    m = open_memory(a.kind, db=a.db, embedder=a.embedder)
    payload: dict[str, Any] = json.loads(a.payload) if a.payload else {}
    rec = MemoryRecord(content=a.text, kind=m.kind, tags=tuple(a.tag or ()), importance=a.importance, payload=payload)
    if a.actor:
        rec.provenance = Provenance(kind=ProvenanceKind.AGENT, agent_id=a.actor)
    try:
        res = m.write(rec)
    except ValueError as exc:  # a categoria exige um payload que não veio (ex.: procedural: skill)
        raise SystemExit(f"{a.kind}: {exc}") from None
    out = {"op": res.op.value if hasattr(res.op, "value") else str(res.op), "record_id": res.record_id, "accepted": res.accepted, "reason": res.reason, "superseded": list(res.superseded)}
    print(json.dumps(out, ensure_ascii=False, indent=2) if a.json else f"{out['op']} {out['record_id']}" + (f"  ({out['reason']})" if out["reason"] else ""))
    return 0 if res.accepted else 1


def cmd_read(a: argparse.Namespace) -> int:
    m = open_memory(a.kind, db=a.db, embedder=a.embedder)
    got = m.read(MemoryQuery(text=a.query, top_k=a.k, tags=tuple(a.tag or ())))
    if a.json:
        print(json.dumps([{"score": g.score, "subsystem": g.subsystem, "rationale": g.rationale, **_record_dict(g.record)} for g in got], ensure_ascii=False, indent=2))
        return 0
    for g in got:
        print(f"{g.score:.4f}  [{g.record.id[:8]}] {g.record.content[:160].replace(chr(10), ' ')}")
    return 0


def cmd_stats(a: argparse.Namespace) -> int:
    m = open_memory(a.kind, db=a.db, embedder=a.embedder)
    print(json.dumps(m.stats(), ensure_ascii=False, indent=2, default=str))
    return 0


def cmd_consolidate(a: argparse.Namespace) -> int:
    m = open_memory(a.kind, db=a.db, embedder=a.embedder)
    rep = m.consolidate()
    forget = m.forget() if a.forget else None
    out: dict[str, Any] = {"consolidate": dataclasses.asdict(rep)}
    if forget is not None:
        out["forget"] = dataclasses.asdict(forget)
    print(json.dumps(out, ensure_ascii=False, indent=2, default=str))
    return 0


def add_parser(sub: Any) -> None:
    sp = sub.add_parser(
        "memory",
        aliases=["mem"],
        help="memória: categorias, gravar, consultar, estatísticas, consolidar",
        description=__doc__,
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )
    ss = sp.add_subparsers(dest="mcmd", required=True)

    def common(sp: argparse.ArgumentParser) -> None:
        sp.add_argument("kind", help="categoria (ver `kinds`)")
        sp.add_argument("--db", default=None, help="arquivo SQLite; sem ele, memória só no processo")
        sp.add_argument("--embedder", default=None, help="hashing[:dim] | model2vec | fastembed | ... (padrão: hashing da memória)")
        sp.add_argument("--json", action="store_true")

    k = ss.add_parser("kinds", help="lista as categorias")
    k.add_argument("--json", action="store_true")
    k.set_defaults(fn=cmd_kinds)

    w = ss.add_parser("write", help="grava um registro")
    common(w)
    w.add_argument("text")
    w.add_argument("--tag", action="append")
    w.add_argument("--importance", type=float, default=0.5)
    w.add_argument("--payload", default=None, help="JSON; ex.: procedural exige {\"skill\": {...}}, entity {entity, slot, value}")
    w.add_argument("--actor", default=None, help="autoria (collective exige)")
    w.set_defaults(fn=cmd_write)

    r = ss.add_parser("read", help="consulta")
    common(r)
    r.add_argument("query")
    r.add_argument("-k", type=int, default=8)
    r.add_argument("--tag", action="append")
    r.set_defaults(fn=cmd_read)

    s = ss.add_parser("stats", help="estatísticas da categoria")
    common(s)
    s.set_defaults(fn=cmd_stats)

    c = ss.add_parser("consolidate", help="roda consolidate() e, com --forget, forget()")
    common(c)
    c.add_argument("--forget", action="store_true")
    c.set_defaults(fn=cmd_consolidate)
