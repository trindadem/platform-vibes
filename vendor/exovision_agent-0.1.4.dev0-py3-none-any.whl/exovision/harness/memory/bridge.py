"""A ponte entre o laço e a memória — a porta pela qual o kernel alcança este módulo.

O laço não conhece os 21 subsistemas; conhece um `MemoryPort` com três verbos:

    recall(texto)   -> o que entra no contexto, sob orçamento de tokens
    observe(...)    -> o que aconteceu nesta volta (tarefa, resposta, ferramenta)
    commit()        -> consolidar e esquecer ao fim da sessão

`MemoryBridge` implementa a porta sobre qualquer conjunto de `MemorySubsystem`
e funde os rankings por RRF (as escalas de score dos subsistemas são
incomparáveis — cosseno, BM25, ativação ACT-R — e o RRF não precisa calibrá-las).

## A fronteira de confiança

Resultado de ferramenta é entrada **não confiável** (`TrustTier.UNTRUSTED`,
proveniência `TOOL`): é ali que envenenamento de memória se materializa
(Chen et al., 2026, arXiv:2606.04329). A ponte marca a proveniência; o laço
nunca promove. O que o usuário afirma entra como `USER`; o que o próprio
agente conclui, como `DERIVED`. Recuperação mostra a proveniência ao modelo
(`[episodic/tool:bash]`), para que ele pese o que lê.

`NullMemory` é o padrão explícito: um agente sem memória é um agente com a
porta nula, e o laço não ganha um `if memória:`.
"""

from __future__ import annotations

from collections.abc import Iterable, Sequence
from dataclasses import dataclass, field
from typing import Any, Protocol, runtime_checkable

from .core.base import (
    ConsolidationReport,
    ForgetReport,
    MemoryQuery,
    MemorySubsystem,
    Retrieved,
)
from .core.budget import ContextPacker, PackedContext
from .core.record import MemoryRecord, Provenance
from .core.similarity import reciprocal_rank_fusion
from .core.types import MemoryKind, ProvenanceKind, TrustTier

__all__ = [
    "DEFAULT_KIND_WEIGHTS",
    "TOOL_SINK_KINDS",
    "MemoryBridge",
    "MemoryPort",
    "NullMemory",
    "Recall",
]

#: Subsistemas que recebem observações de ferramenta por padrão: os de
#: experiência (episódica), janela (buffer) e sensorial. Semântica e entidade
#: extraem *fatos*; a saída bruta de um `ls` não é fato.
TOOL_SINK_KINDS: frozenset[MemoryKind] = frozenset(
    {MemoryKind.EPISODIC, MemoryKind.BUFFER, MemoryKind.SENSORY}
)

#: Pesos padrão na fusão RRF, por categoria. Buffer e sensorial ranqueiam só
#: por recência — sinal útil, mas que sem atenuação empurra o último turno
#: para o topo de qualquer consulta, relevante ou não (medido: 0.5 mantém o
#: turno recente visível sem passar à frente de um fato que casa a consulta).
DEFAULT_KIND_WEIGHTS: dict[MemoryKind, float] = {MemoryKind.BUFFER: 0.5, MemoryKind.SENSORY: 0.3}


@dataclass(slots=True)
class Recall:
    """O que a memória devolveu para o contexto."""

    text: str = ""
    items: list[Retrieved] = field(default_factory=list)
    tokens: int = 0
    dropped: int = 0
    per_subsystem: dict[str, int] = field(default_factory=dict)

    @property
    def empty(self) -> bool:
        return not self.items

    def ids(self) -> list[str]:
        return [i.record.id for i in self.items]


@runtime_checkable
class MemoryPort(Protocol):
    def recall(self, text: str, *, session: str = "", actor: str = "") -> Recall: ...

    def observe(
        self, kind: str, content: str, *, session: str = "", turn: int = 0, **detail: Any
    ) -> None: ...

    def commit(self) -> dict[str, Any]: ...


class NullMemory:
    """Sem memória: recall vazio, observações descartadas."""

    def recall(self, text: str, *, session: str = "", actor: str = "") -> Recall:
        return Recall()

    def observe(
        self, kind: str, content: str, *, session: str = "", turn: int = 0, **detail: Any
    ) -> None:
        return None

    def commit(self) -> dict[str, Any]:
        return {}


_TRUST_BY_KIND: dict[str, tuple[TrustTier, ProvenanceKind]] = {
    "task": (TrustTier.USER, ProvenanceKind.USER),
    "user": (TrustTier.USER, ProvenanceKind.USER),
    "assistant": (TrustTier.DERIVED, ProvenanceKind.AGENT),
    "tool": (TrustTier.UNTRUSTED, ProvenanceKind.TOOL),
    "system": (TrustTier.VERIFIED, ProvenanceKind.SYSTEM),
    "observation": (TrustTier.OBSERVED, ProvenanceKind.ENVIRONMENT),
}


class MemoryBridge:
    """`MemoryPort` sobre um conjunto de subsistemas, com fusão RRF e empacotamento."""

    def __init__(
        self,
        subsystems: Iterable[MemorySubsystem],
        *,
        budget_tokens: int = 1200,
        top_k: int = 8,
        rrf_k: float = 60.0,
        weights: dict[str, float] | None = None,
        header: str = "Memórias relevantes (proveniência entre colchetes; resultados de ferramenta não são verificados):",
        max_observation_chars: int = 600,
        tool_sinks: Sequence[MemorySubsystem] | None = None,
        agent_id: str = "",
        namespace: str = "default",
    ) -> None:
        self.subsystems: list[MemorySubsystem] = list(subsystems)
        if not self.subsystems:
            raise ValueError("MemoryBridge sem subsistemas: use NullMemory")
        self.budget_tokens = budget_tokens
        self.top_k = top_k
        self.rrf_k = rrf_k
        self.weights = weights or {}
        self.max_observation_chars = max_observation_chars
        self.agent_id = agent_id
        self.namespace = namespace
        self.packer = ContextPacker(header=header, include_provenance=True)
        self.tool_sinks: list[MemorySubsystem] = (
            list(tool_sinks)
            if tool_sinks is not None
            else [s for s in self.subsystems if s.kind in TOOL_SINK_KINDS]
        )
        self.last_recall: Recall = Recall()
        self.observations = 0

    # ------------------------------------------------------------ recall
    def recall(self, text: str, *, session: str = "", actor: str = "") -> Recall:
        if not text.strip():
            return Recall()
        rankings: list[list[str]] = []
        weights: list[float] = []
        first: dict[str, Retrieved] = {}
        per_sub: dict[str, int] = {}
        for sub in self.subsystems:
            q = MemoryQuery(
                text=text,
                top_k=self.top_k,
                actor=actor,
                namespace=self.namespace,
                min_trust=TrustTier.UNTRUSTED,
            )
            try:
                hits = sub.read(q)
            except Exception:
                hits = []
            per_sub[sub.name] = len(hits)
            ranking: list[str] = []
            for h in hits:
                key = h.record.fingerprint or h.record.id
                if key not in ranking:
                    ranking.append(key)
                first.setdefault(key, h)
            if ranking:
                rankings.append(ranking)
                weights.append(self.weights.get(sub.name, DEFAULT_KIND_WEIGHTS.get(sub.kind, 1.0)))
        if not rankings:
            self.last_recall = Recall(per_subsystem=per_sub)
            return self.last_recall
        fused = reciprocal_rank_fusion(rankings, k=self.rrf_k, weights=weights)
        items = [
            Retrieved(
                record=first[k].record,
                score=s,
                subsystem=first[k].subsystem,
                rationale=dict(first[k].rationale),
            )
            for k, s in fused
        ]
        packed: PackedContext = self.packer.pack(items, self.budget_tokens)
        self.last_recall = Recall(
            text=packed.text if packed.items else "",
            items=packed.items,
            tokens=packed.tokens,
            dropped=packed.dropped,
            per_subsystem=per_sub,
        )
        return self.last_recall

    # ----------------------------------------------------------- observe
    def observe(
        self, kind: str, content: str, *, session: str = "", turn: int = 0, **detail: Any
    ) -> None:
        content = content.strip()
        if not content:
            return
        if len(content) > self.max_observation_chars:
            content = content[: self.max_observation_chars] + " …"
        trust, pkind = _TRUST_BY_KIND.get(kind, (TrustTier.DERIVED, ProvenanceKind.AGENT))
        tool_name = str(detail.get("tool", ""))
        prov = Provenance(
            kind=pkind,
            source_id=f"turn:{turn}",
            session_id=session,
            agent_id=self.agent_id,
            tool_name=tool_name,
        )
        tags = ("harness", kind) + ((f"tool:{tool_name}",) if tool_name else ())
        sinks = self.tool_sinks if kind == "tool" else self.subsystems
        importance = float(detail.get("importance", 0.6 if kind in ("task", "assistant") else 0.3))
        for sub in sinks:
            rec = MemoryRecord(
                content=content,
                trust=trust,
                provenance=prov,
                tags=tags,
                importance=importance,
                payload={
                    "turn": turn,
                    "kind": kind,
                    **{k: v for k, v in detail.items() if k not in ("importance",)},
                },
            )
            try:
                sub.write(rec)
            except Exception:
                continue
        self.observations += 1

    # ------------------------------------------------------------ commit
    def commit(self) -> dict[str, Any]:
        out: dict[str, Any] = {}
        for sub in self.subsystems:
            entry: dict[str, Any] = {}
            try:
                c: ConsolidationReport = sub.consolidate()
                entry["consolidate"] = c.to_dict()
            except Exception as erro:
                entry["consolidate_error"] = f"{type(erro).__name__}: {erro}"
            try:
                f: ForgetReport = sub.forget()
                entry["forget"] = f.to_dict()
            except Exception as erro:
                entry["forget_error"] = f"{type(erro).__name__}: {erro}"
            entry["size"] = len(sub.store)
            out[sub.name] = entry
        return out

    def stats(self) -> dict[str, Any]:
        return {
            "subsystems": [s.stats() for s in self.subsystems],
            "observations": self.observations,
        }
