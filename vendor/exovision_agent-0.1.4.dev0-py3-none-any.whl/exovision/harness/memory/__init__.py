"""exovision.harness.memory — memória de agente de nível laboratorial.

Módulo do kernel. A face pública é a ponte (`bridge.py`): o laço conhece um
`MemoryPort` com três verbos (`recall`, `observe`, `commit`); `MemoryBridge`
implementa a porta sobre qualquer conjunto de `MemorySubsystem`, funde por
RRF e empacota sob orçamento com proveniência visível; `NullMemory` é o
padrão explícito. O RAG e a especialização reutilizam `core/` (embeddings,
similaridade, texto, orçamento, grafo).

    bridge.py   MemoryPort, MemoryBridge, NullMemory, Recall — a porta do laço
    core/       registro bi-temporal, relógio, embeddings, scoring, store (SQLite),
                grafo, detecção simbólica de conflito, empacotamento sob orçamento
    systems/    as 21 categorias, uma classe por categoria, todas com a mesma
                interface (write/read/consolidate/forget/stats); `SYSTEMS` mapeia
                `MemoryKind -> classe`
    governance/ auditoria e quarentena (em construção)
    eval/       harness de avaliação e suítes (em construção)
    cli.py      `exovision-agent memory` (alias `mem`)

    from exovision.harness.memory import MemoryBridge
    from exovision.harness.memory.systems import EpisodicMemory, SemanticMemory
    porta = MemoryBridge([EpisodicMemory(), SemanticMemory()])

As referências bibliográficas de cada categoria estão na docstring do seu
módulo em `systems/`.
"""

from __future__ import annotations

from .bridge import (
    DEFAULT_KIND_WEIGHTS,
    TOOL_SINK_KINDS,
    MemoryBridge,
    MemoryPort,
    NullMemory,
    Recall,
)

__all__ = [
    "DEFAULT_KIND_WEIGHTS",
    "TOOL_SINK_KINDS",
    "MemoryBridge",
    "MemoryPort",
    "NullMemory",
    "Recall",
]
