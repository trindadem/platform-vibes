"""Grafo dirigido com pesos + algoritmos de propagação.

Núcleo compartilhado por três subsistemas de memória (grafo de conhecimento,
grafo temporal e índice hipocampal). Implementa:

* **Personalized PageRank** (Haveliwala, 2002) — o mecanismo de recuperação do
  HippoRAG (Gutiérrez et al., 2024, arXiv:2405.14831), onde a massa de
  probabilidade parte apenas dos nós-semente da consulta e se espalha pela
  vizinhança, realizando *pattern completion* no sentido da teoria de indexação
  hipocampal (Teyler & DiScenna, 1986).
* **Propagação de rótulos** (Raghavan et al., 2007) — detecção de comunidades
  quase linear, usada pelo Graphiti/Zep para construir o subgrafo de comunidade.
* **Busca em largura com caminhos** — respostas multi-hop explicáveis.
"""

from __future__ import annotations

from collections import defaultdict, deque
from collections.abc import Iterable, Iterator, Sequence
from dataclasses import dataclass, field

__all__ = ["Edge", "Graph"]


@dataclass(slots=True)
class Edge:
    source: str
    target: str
    relation: str = ""
    weight: float = 1.0
    record_id: str = ""
    metadata: dict = field(default_factory=dict)

    def key(self) -> tuple[str, str, str]:
        return (self.source, self.relation, self.target)


class Graph:
    """Multigrafo dirigido e rotulado, com travessia não-dirigida opcional."""

    def __init__(self) -> None:
        self._out: dict[str, list[Edge]] = defaultdict(list)
        self._in: dict[str, list[Edge]] = defaultdict(list)
        self._nodes: set[str] = set()
        self._edges: dict[tuple[str, str, str], Edge] = {}

    # --------------------------------------------------------------- build
    def add_node(self, node: str) -> None:
        self._nodes.add(node)

    def add_edge(self, edge: Edge) -> Edge:
        k = edge.key()
        existing = self._edges.get(k)
        if existing is not None:
            existing.weight += edge.weight
            existing.metadata.update(edge.metadata)
            return existing
        self._edges[k] = edge
        self._out[edge.source].append(edge)
        self._in[edge.target].append(edge)
        self._nodes.add(edge.source)
        self._nodes.add(edge.target)
        return edge

    def remove_edge(self, source: str, relation: str, target: str) -> bool:
        k = (source, relation, target)
        edge = self._edges.pop(k, None)
        if edge is None:
            return False
        self._out[source] = [e for e in self._out[source] if e.key() != k]
        self._in[target] = [e for e in self._in[target] if e.key() != k]
        return True

    # ---------------------------------------------------------------- read
    @property
    def nodes(self) -> frozenset[str]:
        return frozenset(self._nodes)

    def edges(self) -> Iterator[Edge]:
        return iter(self._edges.values())

    def out_edges(self, node: str) -> list[Edge]:
        return list(self._out.get(node, ()))

    def in_edges(self, node: str) -> list[Edge]:
        return list(self._in.get(node, ()))

    def neighbors(self, node: str, *, directed: bool = False) -> set[str]:
        out = {e.target for e in self._out.get(node, ())}
        if not directed:
            out |= {e.source for e in self._in.get(node, ())}
        return out

    def degree(self, node: str) -> int:
        return len(self._out.get(node, ())) + len(self._in.get(node, ()))

    def __len__(self) -> int:
        return len(self._nodes)

    # --------------------------------------------------- Personalized PageRank
    def personalized_pagerank(
        self,
        seeds: dict[str, float] | Sequence[str],
        *,
        damping: float = 0.5,
        iterations: int = 30,
        tolerance: float = 1e-6,
        directed: bool = False,
    ) -> dict[str, float]:
        """PPR com reinício nos nós-semente.

        `damping` 0.5 é o valor que o HippoRAG usa: mais baixo que o PageRank
        clássico (0.85) porque memória quer sinal *local* à consulta, não a
        importância global do grafo.
        """
        if not self._nodes:
            return {}
        if not isinstance(seeds, dict):
            seeds = {s: 1.0 for s in seeds}
        seeds = {s: w for s, w in seeds.items() if s in self._nodes and w > 0}
        if not seeds:
            return {}
        total = sum(seeds.values())
        restart = {n: seeds.get(n, 0.0) / total for n in self._nodes}

        # pesos de saída (simétricos quando `directed=False`)
        adj: dict[str, list[tuple[str, float]]] = {}
        for n in self._nodes:
            pairs: list[tuple[str, float]] = [(e.target, e.weight) for e in self._out.get(n, ())]
            if not directed:
                pairs += [(e.source, e.weight) for e in self._in.get(n, ())]
            adj[n] = pairs

        rank = dict(restart)
        for _ in range(iterations):
            nxt = {n: (1.0 - damping) * restart[n] for n in self._nodes}
            dangling = 0.0
            for n, r in rank.items():
                pairs = adj[n]
                if not pairs:
                    dangling += r
                    continue
                w_sum = sum(w for _, w in pairs)
                if w_sum <= 0:
                    dangling += r
                    continue
                share = damping * r / w_sum
                for tgt, w in pairs:
                    nxt[tgt] = nxt.get(tgt, 0.0) + share * w
            if dangling:
                # massa de nós sem saída volta para a distribuição de reinício
                for n in self._nodes:
                    nxt[n] += damping * dangling * restart[n]
            delta = sum(abs(nxt[n] - rank[n]) for n in self._nodes)
            rank = nxt
            if delta < tolerance:
                break
        return rank

    # ----------------------------------------------------------- caminhos
    def shortest_path(
        self, source: str, target: str, *, max_hops: int = 5, directed: bool = False
    ) -> list[Edge]:
        """BFS com reconstrução do caminho — resposta multi-hop explicável."""
        if source not in self._nodes or target not in self._nodes:
            return []
        if source == target:
            return []
        prev: dict[str, tuple[str, Edge]] = {}
        seen = {source}
        frontier: deque[tuple[str, int]] = deque([(source, 0)])
        while frontier:
            node, depth = frontier.popleft()
            if depth >= max_hops:
                continue
            steps: list[tuple[str, Edge]] = [(e.target, e) for e in self._out.get(node, ())]
            if not directed:
                steps += [(e.source, e) for e in self._in.get(node, ())]
            for nxt, edge in steps:
                if nxt in seen:
                    continue
                seen.add(nxt)
                prev[nxt] = (node, edge)
                if nxt == target:
                    path: list[Edge] = []
                    cur = target
                    while cur in prev:
                        parent, e = prev[cur]
                        path.append(e)
                        cur = parent
                    return list(reversed(path))
                frontier.append((nxt, depth + 1))
        return []

    def k_hop(self, source: str, k: int = 2, *, directed: bool = False) -> dict[str, int]:
        """Nós alcançáveis em até k saltos, com a distância."""
        if source not in self._nodes:
            return {}
        dist = {source: 0}
        frontier = deque([source])
        while frontier:
            node = frontier.popleft()
            d = dist[node]
            if d >= k:
                continue
            for nb in self.neighbors(node, directed=directed):
                if nb not in dist:
                    dist[nb] = d + 1
                    frontier.append(nb)
        return dist

    # -------------------------------------------------------- comunidades
    def label_propagation(self, *, iterations: int = 20, seed: int = 0) -> dict[str, str]:
        """Detecção de comunidades por propagação de rótulos (Raghavan et al., 2007).

        Quase linear no número de arestas; é o algoritmo que o Graphiti usa para
        montar o subgrafo de comunidade sobre o grafo semântico.
        """
        import random

        rng = random.Random(seed)
        labels = {n: n for n in self._nodes}
        order = list(self._nodes)
        for _ in range(iterations):
            rng.shuffle(order)
            changed = 0
            for node in order:
                counts: dict[str, float] = defaultdict(float)
                for e in self._out.get(node, ()):
                    counts[labels[e.target]] += e.weight
                for e in self._in.get(node, ()):
                    counts[labels[e.source]] += e.weight
                if not counts:
                    continue
                best = max(counts.items(), key=lambda kv: (kv[1], kv[0]))[0]
                if labels[node] != best:
                    labels[node] = best
                    changed += 1
            if changed == 0:
                break
        return labels

    def communities(self, **kw) -> dict[str, list[str]]:
        labels = self.label_propagation(**kw)
        out: dict[str, list[str]] = defaultdict(list)
        for node, label in labels.items():
            out[label].append(node)
        return {k: sorted(v) for k, v in out.items()}

    def subgraph(self, nodes: Iterable[str]) -> Graph:
        keep = set(nodes)
        g = Graph()
        for n in keep:
            g.add_node(n)
        for e in self._edges.values():
            if e.source in keep and e.target in keep:
                g.add_edge(Edge(e.source, e.target, e.relation, e.weight, e.record_id, dict(e.metadata)))
        return g

    def stats(self) -> dict[str, float | int]:
        deg = [self.degree(n) for n in self._nodes] or [0]
        return {
            "nodes": len(self._nodes),
            "edges": len(self._edges),
            "mean_degree": sum(deg) / len(deg),
            "max_degree": max(deg),
            "density": len(self._edges) / max(len(self._nodes) * (len(self._nodes) - 1), 1),
        }
