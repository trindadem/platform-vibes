"""Medidas de similaridade e o índice esparso BM25."""

from __future__ import annotations

import math
from collections import defaultdict
from collections.abc import Iterable, Sequence

from .text import tokenize

__all__ = ["BM25Index", "cosine", "dot", "euclidean", "jaccard", "mmr", "reciprocal_rank_fusion"]


def dot(a: Sequence[float], b: Sequence[float]) -> float:
    return sum(x * y for x, y in zip(a, b, strict=False))


def cosine(a: Sequence[float] | None, b: Sequence[float] | None) -> float:
    """Cosseno. Vetores do `HashingEmbedder` já vêm L2-normalizados -> vira o dot."""
    if not a or not b:
        return 0.0
    num = 0.0
    na = 0.0
    nb = 0.0
    for x, y in zip(a, b, strict=False):
        num += x * y
        na += x * x
        nb += y * y
    if na < 1e-12 or nb < 1e-12:
        return 0.0
    return num / math.sqrt(na * nb)


def euclidean(a: Sequence[float], b: Sequence[float]) -> float:
    return math.sqrt(sum((x - y) ** 2 for x, y in zip(a, b, strict=False)))


def jaccard(a: Iterable[str], b: Iterable[str]) -> float:
    sa, sb = set(a), set(b)
    if not sa and not sb:
        return 0.0
    return len(sa & sb) / len(sa | sb)


class BM25Index:
    """BM25 Okapi (Robertson & Zaragoza, 2009).

    score(D,Q) = sum_t IDF(t) * f(t,D)*(k1+1) / (f(t,D) + k1*(1-b+b*|D|/avgdl))
    IDF(t)     = ln(1 + (N - n_t + 0.5)/(n_t + 0.5))

    Índice incremental: `add` e `remove` mantêm df/avgdl corretos sem reindexar.
    """

    __slots__ = ("_df", "_len", "_postings", "_tf", "_total_len", "b", "k1")

    def __init__(self, k1: float = 1.5, b: float = 0.75) -> None:
        self.k1 = k1
        self.b = b
        self._tf: dict[str, dict[str, int]] = {}
        self._df: dict[str, int] = defaultdict(int)
        self._len: dict[str, int] = {}
        self._total_len = 0
        self._postings: dict[str, set[str]] = defaultdict(set)

    def __len__(self) -> int:
        return len(self._tf)

    @property
    def avgdl(self) -> float:
        return self._total_len / len(self._tf) if self._tf else 0.0

    def add(self, doc_id: str, text: str) -> None:
        if doc_id in self._tf:
            self.remove(doc_id)
        toks = tokenize(text)
        if not toks:
            self._tf[doc_id] = {}
            self._len[doc_id] = 0
            return
        tf: dict[str, int] = defaultdict(int)
        for t in toks:
            tf[t] += 1
        self._tf[doc_id] = dict(tf)
        self._len[doc_id] = len(toks)
        self._total_len += len(toks)
        for t in tf:
            self._df[t] += 1
            self._postings[t].add(doc_id)

    def remove(self, doc_id: str) -> None:
        tf = self._tf.pop(doc_id, None)
        if tf is None:
            return
        self._total_len -= self._len.pop(doc_id, 0)
        for t in tf:
            self._df[t] -= 1
            self._postings[t].discard(doc_id)
            if self._df[t] <= 0:
                self._df.pop(t, None)
                self._postings.pop(t, None)

    def idf(self, term: str) -> float:
        n = len(self._tf)
        df = self._df.get(term, 0)
        return math.log(1.0 + (n - df + 0.5) / (df + 0.5))

    def search(self, query: str, top_k: int = 10) -> list[tuple[str, float]]:
        toks = tokenize(query)
        if not toks or not self._tf:
            return []
        avgdl = self.avgdl or 1.0
        scores: dict[str, float] = defaultdict(float)
        for term in set(toks):
            postings = self._postings.get(term)
            if not postings:
                continue
            idf = self.idf(term)
            for doc_id in postings:
                f = self._tf[doc_id].get(term, 0)
                dl = self._len.get(doc_id, 0)
                denom = f + self.k1 * (1.0 - self.b + self.b * dl / avgdl)
                if denom > 0:
                    scores[doc_id] += idf * f * (self.k1 + 1.0) / denom
        ranked = sorted(scores.items(), key=lambda kv: (-kv[1], kv[0]))
        return ranked[:top_k]


def reciprocal_rank_fusion(
    rankings: Sequence[Sequence[str]], *, k: float = 60.0, weights: Sequence[float] | None = None
) -> list[tuple[str, float]]:
    """Reciprocal Rank Fusion (Cormack, Clarke & Buettcher, 2009).

    RRF(d) = sum_r w_r / (k + rank_r(d))

    Funde rankings de subsistemas cujas escalas de score são incomparáveis
    (cosseno, BM25, PageRank, ativação ACT-R) sem precisar calibrar escalas.
    """
    if weights is None:
        weights = [1.0] * len(rankings)
    if len(weights) != len(rankings):
        raise ValueError("weights e rankings com tamanhos diferentes")
    fused: dict[str, float] = defaultdict(float)
    for ranking, w in zip(rankings, weights, strict=True):
        for rank, doc_id in enumerate(ranking, start=1):
            fused[doc_id] += w / (k + rank)
    return sorted(fused.items(), key=lambda kv: (-kv[1], kv[0]))


def mmr(
    query_vec: Sequence[float],
    candidates: Sequence[tuple[str, Sequence[float], float]],
    *,
    lambda_: float = 0.7,
    top_k: int = 10,
) -> list[str]:
    """Maximal Marginal Relevance (Carbonell & Goldstein, 1998).

    MMR = argmax_{d in R\\S} [ lambda*sim(d,q) - (1-lambda)*max_{s in S} sim(d,s) ]

    Evita que o contexto se encha de k paráfrases do mesmo fato — o modo de
    falha dominante de recuperação top-k ingênua em memória conversacional.
    """
    selected: list[str] = []
    selected_vecs: list[Sequence[float]] = []
    pool = list(candidates)
    while pool and len(selected) < top_k:
        best_id: str | None = None
        best_score = -math.inf
        best_idx = -1
        for i, (doc_id, vec, rel) in enumerate(pool):
            redundancy = max((cosine(vec, s) for s in selected_vecs), default=0.0)
            score = lambda_ * rel - (1.0 - lambda_) * redundancy
            if score > best_score:
                best_score, best_id, best_idx = score, doc_id, i
        if best_id is None:
            break
        _, vec, _ = pool.pop(best_idx)
        selected.append(best_id)
        selected_vecs.append(vec)
    return selected
