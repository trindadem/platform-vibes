"""Funções de ativação e ranqueamento.

Este módulo concentra *toda* a matemática de "quão forte está este traço e quão
bem ele responde a esta consulta". Os subsistemas não reimplementam ranking;
eles chamam daqui. Isso torna a calibração (`exovision.harness.memory.eval.calibrate`)
um problema de otimização sobre um único objeto: `RetrievalWeights`.

Fórmulas implementadas
----------------------
Recência (Generative Agents; Park et al., 2023, arXiv:2304.03442)
    recency = gamma ^ (horas desde o último acesso),  gamma = 0.995 no paper

Score composto (mesmo paper)
    score = a_rec * recency + a_imp * importance + a_rel * relevance
    (o paper usa a_* = 1 e normaliza cada termo para [0,1])

Ativação de nível base — ACT-R (Anderson & Schooler, 1991; Anderson et al., 2004)
    B_i = ln( sum_{k=1..n} t_k^(-d) ),  d em [0.3, 0.7], tipicamente 0.5

Retenção de Ebbinghaus (Ebbinghaus, 1885; MemoryBank, Zhong et al., 2023)
    R(t) = exp(-t / S),  S incrementado a cada recuperação bem-sucedida

Modulação afetiva (Kensinger & Corkin, 2004; Mather & Sutherland, 2011 — ABC)
    força_codificacao *= (1 + beta * arousal)

Surpresa bayesiana (Itti & Baldi, 2009; EM-LLM, Fountas et al., 2025)
    usada como sinal de saliência e de fronteira de evento
"""

from __future__ import annotations

import math
from collections.abc import Sequence
from dataclasses import asdict, dataclass, field

from .record import MemoryRecord
from .similarity import cosine
from .types import TrustTier

__all__ = [
    "RetrievalWeights",
    "actr_activation",
    "affective_gain",
    "composite_score",
    "normalize",
    "novelty_score",
    "recency_score",
    "softmax",
    "trust_multiplier",
]

# gamma do paper Generative Agents, por hora.
DEFAULT_RECENCY_GAMMA = 0.995
# d do ACT-R. Anderson et al. (2004) usam 0.5 no modelo declarativo padrão.
DEFAULT_ACTR_DECAY = 0.5


@dataclass(slots=True)
class RetrievalWeights:
    """Pesos calibráveis do ranqueamento composto.

    Os defaults **não** são os do Generative Agents. O paper usa três sinais
    (relevância, recência, importância) com peso 1 cada; medimos que essa
    configuração serve fatos desatualizados e de fonte fraca acima dos
    autoritativos, porque a recência de uma afirmação não confiável vence a
    autoridade de uma verificada. Os defaults daqui incluem `trust` e
    `confidence` por isso.

    Use `RetrievalWeights.generative_agents()` para reproduzir a linha de base
    da literatura em ablações — o harness de avaliação compara as duas.
    """

    relevance: float = 1.0
    recency: float = 0.6
    importance: float = 0.6
    retention: float = 0.0
    activation: float = 0.0
    confidence: float = 0.5
    trust: float = 0.5
    affect: float = 0.0

    recency_gamma: float = DEFAULT_RECENCY_GAMMA
    actr_decay: float = DEFAULT_ACTR_DECAY
    arousal_beta: float = 0.5
    mmr_lambda: float = 0.7
    rrf_k: float = 60.0

    @classmethod
    def generative_agents(cls) -> RetrievalWeights:
        """Linha de base de Park et al. (2023): alpha_rec = alpha_imp = alpha_rel = 1."""
        return cls(relevance=1.0, recency=1.0, importance=1.0)

    @classmethod
    def actr(cls) -> RetrievalWeights:
        """Linha de base cognitiva: ativação de nível base + relevância."""
        return cls(relevance=1.0, recency=0.0, importance=0.0, activation=1.0)

    def as_dict(self) -> dict[str, float]:
        return asdict(self)

    @classmethod
    def from_dict(cls, d: dict[str, float]) -> RetrievalWeights:
        known = {f for f in cls.__dataclass_fields__}
        return cls(**{k: float(v) for k, v in d.items() if k in known})

    def normalized(self) -> RetrievalWeights:
        """Reescala os pesos de sinal (não os hiperparâmetros) para somarem 1."""
        signal_fields = (
            "relevance",
            "recency",
            "importance",
            "retention",
            "activation",
            "confidence",
            "trust",
            "affect",
        )
        total = sum(getattr(self, f) for f in signal_fields)
        if total <= 0:
            return self
        out = RetrievalWeights(**self.as_dict())
        for f in signal_fields:
            setattr(out, f, getattr(self, f) / total)
        return out


def recency_score(record: MemoryRecord, now: float, gamma: float = DEFAULT_RECENCY_GAMMA) -> float:
    """gamma^(horas desde o último acesso). Em [0,1], 1 = acabou de ser acessado."""
    hours = record.hours_since_access(now)
    if hours <= 0:
        return 1.0
    return gamma**hours


def actr_activation(
    record: MemoryRecord, now: float, d: float = DEFAULT_ACTR_DECAY, *, min_lag: float = 0.05
) -> float:
    """Ativação de nível base do ACT-R: B_i = ln(sum_k t_k^-d).

    `min_lag` (em horas) evita a singularidade em t -> 0. Retorna -inf teórico
    para itens nunca acessados; devolvemos um piso finito para o ranking.
    """
    times = record.decay.access_times or ([record.created_at] if record.created_at else [])
    if not times:
        return -10.0
    total = 0.0
    for t_k in times:
        lag_hours = max((now - t_k) / 3600.0, min_lag)
        total += lag_hours ** (-d)
    if total <= 0:
        return -10.0
    return math.log(total)


def novelty_score(
    vec: Sequence[float] | None, neighbors: Sequence[Sequence[float] | None], *, floor: float = 0.0
) -> float:
    """1 - max similaridade com os vizinhos já armazenados. Em [0,1].

    Usado (a) como sinal de admissão — A-MAC (arXiv:2603.04549) lista novidade
    entre os cinco fatores interpretáveis de pré-armazenamento — e (b) como
    proxy de surpresa para segmentação episódica.
    """
    if vec is None or not neighbors:
        return 1.0
    best = max((cosine(vec, n) for n in neighbors if n is not None), default=0.0)
    return max(floor, 1.0 - best)


def affective_gain(record: MemoryRecord, beta: float = 0.5) -> float:
    """Ganho multiplicativo de codificação por excitação emocional.

    Arousal amplifica a consolidação de traços prioritários (Mather &
    Sutherland, 2011, "Arousal-Biased Competition"). Valência entra apenas via
    congruência de humor, tratada na recuperação (`AffectiveMemory`).
    """
    return 1.0 + beta * max(0.0, min(1.0, record.affect.arousal))


def trust_multiplier(trust: TrustTier) -> float:
    """Mapeia o nível de confiança para [0,1]. QUARANTINED zera o item."""
    if trust == TrustTier.QUARANTINED:
        return 0.0
    return int(trust) / int(TrustTier.VERIFIED)


def normalize(values: Sequence[float]) -> list[float]:
    """Min-max para [0,1]. Constante -> todos 0.5 (evita dominância espúria)."""
    if not values:
        return []
    lo, hi = min(values), max(values)
    if hi - lo < 1e-12:
        return [0.5] * len(values)
    span = hi - lo
    return [(v - lo) / span for v in values]


def softmax(values: Sequence[float], temperature: float = 1.0) -> list[float]:
    if not values:
        return []
    t = max(temperature, 1e-6)
    m = max(values)
    exps = [math.exp((v - m) / t) for v in values]
    s = sum(exps)
    return [e / s for e in exps] if s > 0 else [1.0 / len(values)] * len(values)


@dataclass(slots=True)
class _Signals:
    relevance: list[float] = field(default_factory=list)
    recency: list[float] = field(default_factory=list)
    importance: list[float] = field(default_factory=list)
    retention: list[float] = field(default_factory=list)
    activation: list[float] = field(default_factory=list)
    confidence: list[float] = field(default_factory=list)
    trust: list[float] = field(default_factory=list)
    affect: list[float] = field(default_factory=list)


def composite_score(
    records: Sequence[MemoryRecord],
    query_vec: Sequence[float] | None,
    now: float,
    weights: RetrievalWeights,
) -> list[float]:
    """Score composto multi-sinal, com cada sinal normalizado dentro do lote.

    Normalizar *dentro do lote de candidatos* (e não globalmente) é o que o
    Generative Agents faz e o que mantém o score estável conforme o acervo
    cresce — sem isso, `activation` (log, ilimitado) engoliria os demais sinais.
    """
    if not records:
        return []
    sig = _Signals()
    for r in records:
        sig.relevance.append(cosine(query_vec, r.embedding) if query_vec is not None else 0.0)
        sig.recency.append(recency_score(r, now, weights.recency_gamma))
        sig.importance.append(r.importance)
        sig.retention.append(r.retention(now))
        sig.activation.append(actr_activation(r, now, weights.actr_decay))
        sig.confidence.append(r.confidence)
        sig.trust.append(trust_multiplier(r.trust))
        sig.affect.append(affective_gain(r, weights.arousal_beta) - 1.0)

    norm = {
        "relevance": normalize(sig.relevance),
        "recency": normalize(sig.recency),
        "importance": normalize(sig.importance),
        "retention": normalize(sig.retention),
        "activation": normalize(sig.activation),
        "confidence": normalize(sig.confidence),
        "trust": normalize(sig.trust),
        "affect": normalize(sig.affect),
    }
    out: list[float] = []
    for i, r in enumerate(records):
        s = 0.0
        for name, series in norm.items():
            w = getattr(weights, name)
            if w:
                s += w * series[i]
        # Quarentena nunca é recuperável, independentemente dos pesos.
        if r.trust == TrustTier.QUARANTINED:
            s = -math.inf
        out.append(s)
    return out
