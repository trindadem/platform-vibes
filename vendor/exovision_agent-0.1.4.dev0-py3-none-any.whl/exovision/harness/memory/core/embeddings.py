"""Embeddings.

O padrão do EXOVISION-I é o `HashingEmbedder`: determinístico, sem rede, sem
dependências e sem estado. Essa escolha é deliberada — o harness de avaliação e
a rotina de calibração precisam ser *reprodutíveis bit a bit*. Um embedder
neural é plugável (`ProviderEmbedder`) sem tocar em nenhum subsistema.

Técnica: *hashing trick* com sinal (Weinberger et al., 2009, "Feature Hashing
for Large Scale Multitask Learning") sobre uma mistura de n-gramas de palavra e
de caractere, TF sublinear e normalização L2. N-gramas de caractere dão
robustez morfológica (crucial em PT-BR: "mora"/"morava"/"moradia") e a tolerância
a erros de digitação que Bojanowski et al. (2017, fastText) exploram.
"""

from __future__ import annotations

import hashlib
import math
import struct
from collections.abc import Sequence
from typing import Protocol, runtime_checkable

from .text import char_ngrams, tokenize, word_ngrams

__all__ = ["Embedder", "HashingEmbedder", "ProviderEmbedder", "default_embedder", "noise_floor_of"]

#: constante empírica do piso de ruído do hashing: p99 do cosseno entre textos
#: sem nenhuma palavra em comum escala com ~C/sqrt(dim). Medido neste repositório
#: (4000 pares disjuntos): C = 2.6 ajusta p99 = 0.163 @256, 0.115 @512, 0.081 @1024.
HASHING_NOISE_CONSTANT = 2.6

try:  # pragma: no cover - caminho opcional
    import numpy as _np

    _HAS_NUMPY = True
except Exception:  # pragma: no cover
    _np = None
    _HAS_NUMPY = False


@runtime_checkable
class Embedder(Protocol):
    dim: int

    def encode(self, text: str) -> tuple[float, ...]: ...

    def encode_batch(self, texts: Sequence[str]) -> list[tuple[float, ...]]: ...


def noise_floor_of(embedder: object, default: float = 0.0) -> float:
    """Piso de similaridade abaixo do qual o sinal é indistinguível de ruído.

    Todo embedder tem um: dois textos sem relação nenhuma raramente dão cosseno
    exatamente zero. Ignorar isso faz a recuperação servir itens irrelevantes
    sempre que o acervo não tiver nada de fato relevante — o modo de falha que
    a literatura chama de *retrieval sem abstenção*. Subsistemas consultam este
    valor para descartar candidatos que estão dentro do ruído.
    """
    return float(getattr(embedder, "noise_floor", default))


def _hash64(feature: str) -> int:
    digest = hashlib.blake2b(feature.encode("utf-8"), digest_size=8).digest()
    return struct.unpack("<Q", digest)[0]


class HashingEmbedder:
    """Embedder de hashing determinístico.

    Parameters
    ----------
    dim:
        Dimensão do vetor. 512 é o ponto de equilíbrio medido entre colisão de
        hash e custo; 256 degrada ~2 pontos de recall@5 nos nossos suites.
    word_ngrams_range / char_ngrams_range:
        Faixas inclusivas. `(0, 0)` desativa a família.
    char_weight:
        Peso relativo das features de caractere. 0.5 equilibra precisão lexical
        (palavra) e robustez morfológica (caractere).
    """

    __slots__ = ("_cache", "_cache_cap", "_chi", "_clo", "_whi", "_wlo", "char_weight", "dim")

    @property
    def noise_floor(self) -> float:
        """p99 do cosseno entre textos lexicalmente disjuntos, ~2.6/sqrt(dim)."""
        return HASHING_NOISE_CONSTANT / math.sqrt(self.dim)

    def __init__(
        self,
        dim: int = 512,
        *,
        word_ngrams_range: tuple[int, int] = (1, 2),
        char_ngrams_range: tuple[int, int] = (3, 5),
        char_weight: float = 0.5,
        cache_size: int = 4096,
    ) -> None:
        if dim <= 0:
            raise ValueError("dim deve ser positivo")
        self.dim = dim
        self._wlo, self._whi = word_ngrams_range
        self._clo, self._chi = char_ngrams_range
        self.char_weight = char_weight
        self._cache: dict[str, tuple[float, ...]] = {}
        self._cache_cap = cache_size

    # ------------------------------------------------------------------ API
    def encode(self, text: str) -> tuple[float, ...]:
        if not text:
            return tuple([0.0] * self.dim)
        cached = self._cache.get(text)
        if cached is not None:
            return cached
        vec = self._encode_uncached(text)
        if len(self._cache) >= self._cache_cap:
            self._cache.clear()
        self._cache[text] = vec
        return vec

    def encode_batch(self, texts: Sequence[str]) -> list[tuple[float, ...]]:
        return [self.encode(t) for t in texts]

    # -------------------------------------------------------------- interno
    def _features(self, text: str) -> dict[str, float]:
        counts: dict[str, float] = {}
        if self._whi >= self._wlo >= 1:
            toks = tokenize(text)
            for feat in word_ngrams(toks, self._wlo, self._whi):
                counts["w:" + feat] = counts.get("w:" + feat, 0.0) + 1.0
        if self._chi >= self._clo >= 1:
            for feat in char_ngrams(text, self._clo, self._chi):
                key = "c:" + feat
                counts[key] = counts.get(key, 0.0) + self.char_weight
        return counts

    def _encode_uncached(self, text: str) -> tuple[float, ...]:
        counts = self._features(text)
        acc = [0.0] * self.dim
        for feat, raw_tf in counts.items():
            h = _hash64(feat)
            idx = h % self.dim
            sign = 1.0 if (h >> 63) & 1 else -1.0
            # TF sublinear (Manning et al., 2008, IR-book §6.4): amortece repetição
            weight = 1.0 + math.log(raw_tf) if raw_tf > 1.0 else raw_tf
            acc[idx] += sign * weight
        norm = math.sqrt(sum(v * v for v in acc))
        if norm < 1e-12:
            return tuple(acc)
        inv = 1.0 / norm
        return tuple(v * inv for v in acc)

    def __repr__(self) -> str:  # pragma: no cover
        return f"HashingEmbedder(dim={self.dim})"


class ProviderEmbedder:
    """Adaptador para um embedder externo (OpenAI, sentence-transformers, ...).

    Recebe um callable `fn(list[str]) -> list[list[float]]`; normaliza em L2 e
    cacheia. Nenhum subsistema conhece o provedor — só o protocolo `Embedder`.
    """

    __slots__ = ("_cache", "_cache_cap", "_fn", "_normalize", "dim", "noise_floor")

    def __init__(
        self,
        fn,
        dim: int,
        *,
        normalize: bool = True,
        cache_size: int = 4096,
        noise_floor: float = 0.0,
    ) -> None:
        #: meça o seu: cosseno p99 entre pares de textos não relacionados do seu domínio.
        self.noise_floor = noise_floor
        self._fn = fn
        self.dim = dim
        self._normalize = normalize
        self._cache: dict[str, tuple[float, ...]] = {}
        self._cache_cap = cache_size

    def encode(self, text: str) -> tuple[float, ...]:
        return self.encode_batch([text])[0]

    def encode_batch(self, texts: Sequence[str]) -> list[tuple[float, ...]]:
        missing = [t for t in texts if t not in self._cache]
        if missing:
            vectors = self._fn(missing)
            for text, vec in zip(missing, vectors, strict=True):
                v = tuple(float(x) for x in vec)
                if self._normalize:
                    n = math.sqrt(sum(x * x for x in v))
                    if n > 1e-12:
                        v = tuple(x / n for x in v)
                if len(self._cache) >= self._cache_cap:
                    self._cache.clear()
                self._cache[text] = v
        return [self._cache[t] for t in texts]

    def __repr__(self) -> str:  # pragma: no cover
        return f"ProviderEmbedder(dim={self.dim})"


default_embedder: Embedder = HashingEmbedder()
