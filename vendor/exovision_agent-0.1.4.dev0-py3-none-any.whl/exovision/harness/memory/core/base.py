"""Contrato comum a todos os 21 subsistemas de memória.

O ponto central do design: um subsistema expõe exatamente cinco verbos —
`write`, `read`, `consolidate`, `forget`, `stats` — sobre o mesmo
`MemoryRecord`. Qualquer subsistema pode, portanto, ser (a) ranqueado junto com
os outros via RRF, (b) auditado pelo mesmo caminho de governança e (c) avaliado
pelo mesmo harness. Subsistemas divergem no *mecanismo*, nunca na interface.

Os cinco verbos mapeiam o eixo *Dynamics* de Liu et al. (2026): formação
(`write`), recuperação (`read`), consolidação/evolução (`consolidate`) e
esquecimento (`forget`).
"""

from __future__ import annotations

import time
from abc import ABC, abstractmethod
from collections.abc import Iterator, Sequence
from dataclasses import dataclass, field
from typing import Any

from .clock import Clock, default_clock
from .embeddings import Embedder, default_embedder
from .events import EventBus, MemoryEvent
from .record import MemoryRecord
from .scoring import RetrievalWeights
from .store import InMemoryStore, MemoryStore
from .types import MemoryKind, RetrievalStrategy, TrustTier, WriteOp

__all__ = [
    "ConsolidationReport",
    "ForgetReport",
    "MemoryQuery",
    "MemorySubsystem",
    "Retrieved",
    "WriteResult",
]


@dataclass(slots=True)
class MemoryQuery:
    """Consulta de recuperação.

    `as_of` liga a semântica bi-temporal: "o que eu acreditava em T?" é uma
    consulta diferente de "o que eu acredito agora". A maioria das
    implementações só suporta a segunda.
    """

    text: str = ""
    vector: tuple[float, ...] | None = None
    top_k: int = 8
    kinds: tuple[MemoryKind, ...] = ()
    tags: tuple[str, ...] = ()
    namespace: str = ""
    actor: str = ""
    as_of: float | None = None
    strategy: RetrievalStrategy = RetrievalStrategy.COMPOSITE
    min_trust: TrustTier = TrustTier.UNTRUSTED
    include_invalid: bool = False
    diversify: bool = True
    filters: dict[str, Any] = field(default_factory=dict)

    def with_vector(self, embedder: Embedder) -> MemoryQuery:
        if self.vector is None and self.text:
            self.vector = embedder.encode(self.text)
        return self


@dataclass(slots=True)
class Retrieved:
    """Um resultado com a justificativa de por que foi recuperado.

    `rationale` carrega a decomposição por sinal. Sem isso não é possível
    responder à pergunta de auditoria "por que este item entrou no contexto?",
    que é a Camada 4 do stack de métricas de arXiv:2603.07670.
    """

    record: MemoryRecord
    score: float
    subsystem: str
    rationale: dict[str, float | str] = field(default_factory=dict)  # sinais numéricos; rótulos (estratégia, episódio) são str

    @property
    def id(self) -> str:
        return self.record.id

    @property
    def content(self) -> str:
        return self.record.content

    def __repr__(self) -> str:  # pragma: no cover
        return f"<Retrieved {self.subsystem} {self.score:.3f} {self.record.content[:40]!r}>"


@dataclass(slots=True)
class WriteResult:
    op: WriteOp
    record_id: str = ""
    superseded: tuple[str, ...] = ()
    reason: str = ""
    accepted: bool = True

    @classmethod
    def noop(cls, reason: str) -> WriteResult:
        return cls(op=WriteOp.NOOP, reason=reason, accepted=False)


@dataclass(slots=True)
class ConsolidationReport:
    subsystem: str = ""
    promoted: int = 0
    merged: int = 0
    abstracted: int = 0
    invalidated: int = 0
    links_created: int = 0
    notes: list[str] = field(default_factory=list)

    def __add__(self, other: ConsolidationReport) -> ConsolidationReport:
        return ConsolidationReport(
            subsystem=f"{self.subsystem}+{other.subsystem}".strip("+"),
            promoted=self.promoted + other.promoted,
            merged=self.merged + other.merged,
            abstracted=self.abstracted + other.abstracted,
            invalidated=self.invalidated + other.invalidated,
            links_created=self.links_created + other.links_created,
            notes=self.notes + other.notes,
        )

    def to_dict(self) -> dict[str, Any]:
        return {
            "subsystem": self.subsystem,
            "promoted": self.promoted,
            "merged": self.merged,
            "abstracted": self.abstracted,
            "invalidated": self.invalidated,
            "links_created": self.links_created,
            "notes": self.notes,
        }


@dataclass(slots=True)
class ForgetReport:
    subsystem: str = ""
    evicted: int = 0
    invalidated: int = 0
    demoted: int = 0
    retained: int = 0
    freed_chars: int = 0

    def to_dict(self) -> dict[str, Any]:
        return {
            "subsystem": self.subsystem,
            "evicted": self.evicted,
            "invalidated": self.invalidated,
            "demoted": self.demoted,
            "retained": self.retained,
            "freed_chars": self.freed_chars,
        }


class MemorySubsystem(ABC):
    """Base de todos os subsistemas."""

    kind: MemoryKind = MemoryKind.EPISODIC
    #: subsistemas emergentes marcam True — usado por relatórios e pela CLI
    emergent: bool = False

    def __init__(
        self,
        *,
        store: MemoryStore | None = None,
        embedder: Embedder | None = None,
        clock: Clock | None = None,
        bus: EventBus | None = None,
        weights: RetrievalWeights | None = None,
        name: str | None = None,
        namespace: str = "default",
    ) -> None:
        self.store: MemoryStore = store if store is not None else InMemoryStore()
        self.embedder: Embedder = embedder or default_embedder
        self.clock: Clock = clock or default_clock
        self.bus: EventBus = bus or EventBus()
        self.weights: RetrievalWeights = weights or RetrievalWeights()
        self.name = name or self.__class__.__name__
        self.namespace = namespace

    # ------------------------------------------------------------- verbos
    @abstractmethod
    def write(self, record: MemoryRecord) -> WriteResult: ...

    @abstractmethod
    def read(self, query: MemoryQuery) -> list[Retrieved]: ...

    def consolidate(self, now: float | None = None) -> ConsolidationReport:
        """Padrão: nada a consolidar."""
        return ConsolidationReport(subsystem=self.name)

    def forget(self, now: float | None = None) -> ForgetReport:
        """Padrão: nada a esquecer."""
        return ForgetReport(subsystem=self.name, retained=self.size())

    def stats(self) -> dict[str, Any]:
        return {
            "name": self.name,
            "kind": self.kind.value,
            "emergent": self.emergent,
            "size": self.size(),
        }

    # ------------------------------------------------------------ helpers
    def now(self, override: float | None = None) -> float:
        return self.clock.now() if override is None else override

    def ensure_embedding(self, record: MemoryRecord) -> MemoryRecord:
        if record.embedding is None:
            record.embedding = self.embedder.encode(record.content)
        return record

    def emit(self, op: str, record_id: str = "", /, **detail: Any) -> None:
        """Emite um evento de telemetria.

        `op`/`record_id` são posicionais-apenas para que `detail` possa conter
        chaves com esses mesmos nomes (um subsistema frequentemente quer
        registrar `op=` como detalhe da decisão de escrita).
        """
        self.bus.emit(
            MemoryEvent(op=op, subsystem=self.name, record_id=record_id, detail=detail)
        )

    def visible(self, record: MemoryRecord, query: MemoryQuery, now: float) -> bool:
        """Filtro comum de visibilidade: tempo, confiança, tags e ACL."""
        at = query.as_of if query.as_of is not None else now
        if not query.include_invalid and not record.is_live(at):
            return False
        if int(record.trust) < int(query.min_trust):
            return False
        if query.tags and not set(query.tags) & set(record.tags):
            return False
        if record.acl and query.actor and query.actor not in record.acl:  # noqa: SIM103 - guardas legíveis
            return False
        return True

    def own(self) -> Iterator[MemoryRecord]:
        """Só os registros desta categoria.

        Várias categorias podem dividir um arquivo (o `memory.db` de um perfil
        tem episódica, semântica e buffer), e o `SQLiteStore` espelha o arquivo
        inteiro ao abrir: sem o filtro, cada categoria lia — e apresentava como
        seu — o que as outras gravaram.
        """
        return self.store.scan(kind=self.kind)

    def size(self) -> int:
        return sum(1 for _ in self.own())

    def candidates(self, query: MemoryQuery, now: float) -> list[MemoryRecord]:
        return [r for r in self.own() if self.visible(r, query, now)]

    def touch_all(self, records: Sequence[MemoryRecord], now: float) -> None:
        """Marca acesso: reforça o traço (Ebbinghaus/ACT-R) e persiste."""
        for r in records:
            r.decay.touch(now)
            self.store.put(r)

    def _timed(self) -> float:
        return time.perf_counter()

    def __repr__(self) -> str:  # pragma: no cover
        return f"<{self.name} kind={self.kind.value} n={len(self.store)}>"
