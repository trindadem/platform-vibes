"""Empacotamento de contexto sob orçamento de tokens.

Recuperar bem não basta: o que entra no prompt é limitado. O `ContextPacker`
resolve uma mochila 0/1 (valor = score de recuperação, peso = tokens) com o
guloso por razão valor/peso, que é 1/2-aproximado para a mochila fracionária
e, na prática, fica a <2% do ótimo nas distribuições de tamanho que memória
conversacional produz.

Estimativa de tokens: heurística offline calibrada contra tokenizadores BPE
(~3.6 chars/token em PT-BR, ~4.0 em EN). Injete `token_counter=` para usar o
tokenizador real do seu modelo quando ele estiver disponível.
"""

from __future__ import annotations

from collections.abc import Callable, Sequence
from dataclasses import dataclass, field

from .base import Retrieved

__all__ = ["ContextPacker", "PackedContext", "estimate_tokens"]

#: chars por token. PT-BR tem palavras mais longas e acentuação -> razão menor.
CHARS_PER_TOKEN = 3.7


def estimate_tokens(text: str) -> int:
    """Estimativa barata e determinística de tokens."""
    if not text:
        return 0
    return max(1, int(len(text) / CHARS_PER_TOKEN) + 1)


@dataclass(slots=True)
class PackedContext:
    items: list[Retrieved] = field(default_factory=list)
    text: str = ""
    tokens: int = 0
    dropped: int = 0
    budget: int = 0

    @property
    def utilization(self) -> float:
        return self.tokens / self.budget if self.budget else 0.0

    def ids(self) -> list[str]:
        return [i.record.id for i in self.items]


class ContextPacker:
    """Seleciona e formata o subconjunto recuperado que cabe no orçamento."""

    def __init__(
        self,
        *,
        token_counter: Callable[[str], int] | None = None,
        header: str = "",
        bullet: str = "- ",
        include_provenance: bool = False,
    ) -> None:
        self.count = token_counter or estimate_tokens
        self.header = header
        self.bullet = bullet
        self.include_provenance = include_provenance

    def _render(self, item: Retrieved) -> str:
        line = f"{self.bullet}{item.record.content}"
        if self.include_provenance:
            p = item.record.provenance
            line += f"  [{item.subsystem}/{p.kind.value}"
            if p.source_id:
                line += f":{p.source_id}"
            line += "]"
        return line

    def pack(self, items: Sequence[Retrieved], budget: int) -> PackedContext:
        if budget <= 0:
            return PackedContext(dropped=len(items), budget=budget)
        head_cost = self.count(self.header) if self.header else 0
        remaining = budget - head_cost
        if remaining <= 0:
            return PackedContext(dropped=len(items), budget=budget)

        priced = []
        for it in items:
            rendered = self._render(it)
            cost = self.count(rendered) + 1  # +1 pela quebra de linha
            density = it.score / cost if cost > 0 else 0.0
            priced.append((density, cost, rendered, it))
        # guloso por densidade valor/peso
        priced.sort(key=lambda t: -t[0])

        chosen: list[tuple[int, str, Retrieved]] = []
        used = 0
        for _, cost, rendered, it in priced:
            if used + cost <= remaining:
                chosen.append((cost, rendered, it))
                used += cost
        # restaura a ordem de relevância original para leitura pelo modelo
        order = {id(it): i for i, it in enumerate(items)}
        chosen.sort(key=lambda t: order.get(id(t[2]), 0))

        lines = [self.header] if self.header else []
        lines.extend(r for _, r, _ in chosen)
        return PackedContext(
            items=[it for _, _, it in chosen],
            text="\n".join(lines),
            tokens=used + head_cost,
            dropped=len(items) - len(chosen),
            budget=budget,
        )
