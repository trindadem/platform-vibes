"""Extração de triplas (sujeito, relação, objeto).

O HippoRAG e o Graphiti usam um LLM para OpenIE. O EXOVISION-I aceita um
extrator de LLM via o protocolo `TripleExtractor`, mas o **default é
determinístico e offline** — um extrator por padrões — para que todo o SDK,
inclusive os subsistemas de grafo, rode e seja avaliável sem rede.

Limitação declarada: o extrator por padrões acerta asserções simples
sujeito-verbo-objeto e erra sentenças com subordinação, elipse ou voz passiva.
Ele é a linha de base honesta, não o estado da arte. Em produção, injete
`CallableTripleExtractor(lambda text: ...)` apoiado num LLM — nenhuma outra
parte do SDK muda.
"""

from __future__ import annotations

import re
from collections.abc import Callable, Sequence
from dataclasses import dataclass
from typing import Protocol, runtime_checkable

from .text import STOPWORDS, fold

__all__ = ["CallableTripleExtractor", "PatternTripleExtractor", "Triple", "TripleExtractor"]


@dataclass(frozen=True, slots=True)
class Triple:
    subject: str
    relation: str
    object: str
    confidence: float = 1.0

    def as_text(self) -> str:
        return f"{self.subject} -[{self.relation}]-> {self.object}"


@runtime_checkable
class TripleExtractor(Protocol):
    def extract(self, text: str) -> list[Triple]: ...


#: verbos/locuções relacionais frequentes em asserções de agente (PT + EN)
RELATION_LEXICON: frozenset[str] = frozenset(
    ["mora", "reside", "vive", "trabalha", "usa", "utiliza", "tem", "possui", "contem", "roda", "executa", "gerencia", "administra", "depende", "precisa", "requer", "pertence", "faz", "cria", "gera", "envia", "recebe", "chama", "conhece", "gosta", "prefere", "odeia", "estuda", "ensina", "lidera", "integra", "conecta", "hospeda", "publica", "implementa", "monitora", "protege", "substitui", "suporta", "fornece", "consome", "fica", "situa", "localiza", "nasceu", "estuda", "leciona", "dirige", "coordena", "atende", "serve", "virou", "tornou", "herda", "estende", "implementa", "aciona", "dispara", "agenda", "lives", "works", "uses", "has", "have", "contains", "runs", "executes", "manages", "owns", "belongs", "needs", "requires", "creates", "sends", "receives", "knows", "likes", "prefers", "hosts", "publishes", "monitors", "supports", "provides", "replaces", "connects", "integrates"]
)

_COPULA = frozenset({"e", "eh", "sao", "era", "eram", "foi", "foram", "is", "are", "was", "were"})
_PREPS = frozenset({"em", "no", "na", "nos", "nas", "de", "do", "da", "com", "para", "por", "in", "on", "at", "of", "to", "with", "for"})
#: artigos e conjunções que separam a relação do seu argumento sem serem parte dele
_SKIPPABLE = frozenset({"a", "o", "as", "os", "um", "uma", "uns", "umas", "the", "an", "e", "ou", "and", "or"})
#: conjunções que indicam coordenação -> o sujeito é elíptico e herda o anterior
_COORDINATORS = frozenset({"e", "ou", "and", "or", ","})

_TOKEN_RE = re.compile(r"\b[\w\-]+\b", re.UNICODE)


class PatternTripleExtractor:
    """Extrator SVO por padrões, sem dependências.

    Heurística: percorre os tokens; ao encontrar um marcador de relação (verbo do
    léxico ou cópula), toma como sujeito o grupo nominal imediatamente à esquerda
    e como objeto o grupo imediatamente à direita, absorvendo preposições na
    relação ("mora em" -> relação `mora_em`).
    """

    def __init__(
        self,
        *,
        lexicon: frozenset[str] = RELATION_LEXICON,
        min_token_len: int = 2,
        confidence: float = 0.6,
    ) -> None:
        self.lexicon = lexicon
        self.min_token_len = min_token_len
        self.confidence = confidence

    @staticmethod
    def _capitalized_copula(tok: str, pos: int | None) -> bool:
        """"São" em "São Paulo" é topônimo, não o verbo "são".

        Cópula grafada com maiúscula no meio da frase é nome próprio (São
        José, São Luís); só no início da frase a maiúscula é ambígua, e aí
        mantemos a leitura de verbo.
        """
        return pos is not None and pos > 0 and tok[:1].isupper() and fold(tok) in _COPULA

    def _is_entity_token(self, tok: str, pos: int | None = None) -> bool:
        f = fold(tok)
        if self._capitalized_copula(tok, pos):
            return len(f) >= self.min_token_len
        return (
            len(f) >= self.min_token_len
            and f not in STOPWORDS
            and f not in self.lexicon
            and f not in _COPULA
            and f not in _PREPS
        )

    def _span(self, tokens: list[str], start: int, step: int, *, max_skip: int = 2) -> str:
        return self._span_with_end(tokens, start, step, max_skip=max_skip)[0]

    def _span_with_end(
        self, tokens: list[str], start: int, step: int, *, max_skip: int = 2
    ) -> tuple[str, int]:
        """Agrupa tokens de entidade contíguos a partir de `start`, na direção `step`.

        Pula até `max_skip` tokens ignoráveis (artigos, conjunções) antes de
        começar a coletar — sem isso, "é **a** capital de X" não produz objeto.
        Devolve também o índice do primeiro token *após* o grupo, que é o que
        permite inspecionar o que segue (ex.: a preposição de "capital **de** X").
        """
        i = start
        skipped = 0
        while 0 <= i < len(tokens) and not self._is_entity_token(tokens[i], i):
            if fold(tokens[i]) not in _SKIPPABLE or skipped >= max_skip:
                return "", i
            skipped += 1
            i += step
        parts: list[str] = []
        while 0 <= i < len(tokens) and self._is_entity_token(tokens[i], i):
            parts.append(tokens[i])
            i += step
            if len(parts) >= 4:
                break
        if step < 0:
            parts.reverse()
        return "_".join(fold(p) for p in parts), i

    def extract(self, text: str) -> list[Triple]:
        tokens = _TOKEN_RE.findall(text)
        out: list[Triple] = []
        last_subject = ""
        for i, tok in enumerate(tokens):
            f = fold(tok)
            if f not in self.lexicon and f not in _COPULA:
                continue
            if self._capitalized_copula(tok, i):
                continue  # "São Paulo": nome próprio, não marcador de relação
            rel_parts = [f]
            j = i + 1
            while j < len(tokens) and fold(tokens[j]) in _PREPS:
                rel_parts.append(fold(tokens[j]))
                j += 1
            subject = self._span(tokens, i - 1, -1, max_skip=0)
            if not subject and i > 0 and fold(tokens[i - 1]) in _COORDINATORS:
                # Sujeito elíptico por coordenação: "Ana trabalha na X e gosta de Y".
                subject = last_subject
            obj, obj_end = self._span_with_end(tokens, j, +1)
            if not (subject and obj and subject != obj):
                continue
            last_subject = subject

            # Padrão "X é a <nominal> de Y": o nominal pertence à relação, não é
            # o objeto. Frequentíssimo em PT ("é a capital de", "é o dono de").
            # Só se aplica à cópula: com verbo pleno, o objeto já é o argumento.
            if f in _COPULA:
                k = obj_end
                if k < len(tokens) and fold(tokens[k]) in _PREPS:
                    deeper = self._span(tokens, k + 1, +1)
                    if deeper and deeper != subject:
                        out.append(
                            Triple(
                                subject=subject,
                                relation="_".join([*rel_parts, obj, fold(tokens[k])]),
                                object=deeper,
                                confidence=self.confidence,
                            )
                        )
                        continue
            out.append(
                Triple(
                    subject=subject,
                    relation="_".join(rel_parts),
                    object=obj,
                    confidence=self.confidence,
                )
            )
        return out


class CallableTripleExtractor:
    """Adapta uma função (tipicamente um LLM fazendo OpenIE) ao protocolo."""

    def __init__(self, fn: Callable[[str], Sequence[tuple[str, str, str]]], *, confidence: float = 0.9) -> None:
        self._fn = fn
        self.confidence = confidence

    def extract(self, text: str) -> list[Triple]:
        return [
            Triple(fold(s), fold(r), fold(o), self.confidence) for s, r, o in self._fn(text)
        ]
