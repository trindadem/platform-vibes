"""Normalização e tokenização de texto, neutra de idioma (com cuidado para PT-BR)."""

from __future__ import annotations

import re
import unicodedata
from functools import lru_cache

__all__ = ["STOPWORDS", "char_ngrams", "content_words", "fold", "tokenize", "word_ngrams"]

_WORD_RE = re.compile(r"[0-9]+(?:[.,][0-9]+)*|[^\W_]+", re.UNICODE)

# Stopwords PT + EN. Curta de propósito: listas agressivas destroem consultas
# factuais curtas ("quem é o chefe dele?").
STOPWORDS: frozenset[str] = frozenset(
    ["a", "o", "e", "de", "da", "do", "das", "dos", "em", "no", "na", "nos", "nas", "um", "uma", "uns", "umas", "para", "por", "com", "que", "se", "ao", "aos", "as", "os", "pelo", "pela", "como", "mais", "mas", "ou", "ja", "nao", "sim", "eu", "tu", "ele", "ela", "nos", "vos", "eles", "elas", "meu", "minha", "seu", "sua", "isso", "isto", "aquilo", "the", "of", "and", "to", "in", "on", "at", "for", "with", "is", "are", "was", "were", "be", "been", "being", "an", "it", "this", "that", "these", "those", "from", "as", "by", "or", "if", "then", "than", "so", "such"]
)


@lru_cache(maxsize=8192)
def fold(text: str) -> str:
    """Minúsculas + remoção de diacríticos. 'Endereço' -> 'endereco'."""
    decomposed = unicodedata.normalize("NFKD", text.lower())
    return "".join(c for c in decomposed if not unicodedata.combining(c))


def tokenize(text: str, *, keep_stopwords: bool = True) -> list[str]:
    toks = _WORD_RE.findall(fold(text))
    if keep_stopwords:
        return toks
    return [t for t in toks if t not in STOPWORDS]


def content_words(text: str) -> list[str]:
    """Tokens de conteúdo (sem stopwords, >=2 chars). Base de extração de entidades."""
    return [t for t in tokenize(text, keep_stopwords=False) if len(t) >= 2]


def word_ngrams(tokens: list[str], lo: int, hi: int) -> list[str]:
    out: list[str] = []
    n_tok = len(tokens)
    for n in range(lo, hi + 1):
        if n == 1:
            out.extend(tokens)
            continue
        for i in range(n_tok - n + 1):
            out.append("_".join(tokens[i : i + n]))
    return out


def char_ngrams(text: str, lo: int, hi: int) -> list[str]:
    """N-gramas de caractere com fronteira de palavra (robustez a morfologia/typos)."""
    out: list[str] = []
    for tok in _WORD_RE.findall(fold(text)):
        padded = f"<{tok}>"
        length = len(padded)
        for n in range(lo, hi + 1):
            if length < n:
                continue
            for i in range(length - n + 1):
                out.append(padded[i : i + n])
    return out
