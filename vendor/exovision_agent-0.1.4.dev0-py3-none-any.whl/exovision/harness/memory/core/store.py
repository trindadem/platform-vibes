"""Backends de armazenamento.

Dois backends implementam o mesmo protocolo `MemoryStore`:

* `InMemoryStore` — dicionário + índice vetorial plano + BM25. Padrão em testes
  e em agentes efêmeros.
* `SQLiteStore` — persistente (WAL), com os vetores em BLOB e o texto em FTS5
  quando disponível. Escolhido para produção single-node: um agente com memória
  de longo prazo precisa sobreviver a reinício de processo, e SQLite entrega
  durabilidade sem operar um serviço externo.

Ambos mantêm os índices *incrementalmente* — `put`/`delete` atualizam BM25 e o
índice vetorial na mesma chamada, de modo que não existe reindexação global.
"""

from __future__ import annotations

import json
import sqlite3
import threading
from abc import ABC, abstractmethod
from collections.abc import Callable, Iterator, Sequence
from typing import Any

from .record import MemoryRecord
from .similarity import BM25Index, cosine
from .types import MemoryKind

__all__ = ["InMemoryStore", "MemoryStore", "SQLiteStore", "open_store"]

try:  # pragma: no cover
    import numpy as _np

    _HAS_NUMPY = True
except Exception:  # pragma: no cover
    _np = None
    _HAS_NUMPY = False

Predicate = Callable[[MemoryRecord], bool]


class MemoryStore(ABC):
    """Contrato de armazenamento. Subsistemas dependem só desta interface."""

    # ------------------------------------------------------------ escrita
    @abstractmethod
    def put(self, record: MemoryRecord) -> None: ...

    @abstractmethod
    def delete(self, record_id: str) -> bool: ...

    # ------------------------------------------------------------ leitura
    @abstractmethod
    def get(self, record_id: str) -> MemoryRecord | None: ...

    @abstractmethod
    def scan(self, *, kind: MemoryKind | None = None) -> Iterator[MemoryRecord]: ...

    @abstractmethod
    def __len__(self) -> int: ...

    # ------------------------------------------------------------- índices
    @abstractmethod
    def search_dense(
        self, vec: Sequence[float], top_k: int, *, where: Predicate | None = None
    ) -> list[tuple[str, float]]: ...

    @abstractmethod
    def search_sparse(
        self, query: str, top_k: int, *, where: Predicate | None = None
    ) -> list[tuple[str, float]]: ...

    @abstractmethod
    def by_fingerprint(self, fingerprint: str) -> list[MemoryRecord]: ...

    # ---------------------------------------------------------- utilidades
    def put_many(self, records: Sequence[MemoryRecord]) -> None:
        for r in records:
            self.put(r)

    def get_many(self, ids: Sequence[str]) -> list[MemoryRecord]:
        out = []
        for i in ids:
            r = self.get(i)
            if r is not None:
                out.append(r)
        return out

    def all(self) -> list[MemoryRecord]:
        return list(self.scan())

    def close(self) -> None:  # pragma: no cover - default no-op
        return None

    def __enter__(self):  # pragma: no cover
        return self

    def __exit__(self, *exc):  # pragma: no cover
        self.close()


class InMemoryStore(MemoryStore):
    """Backend em memória. Thread-safe por um lock reentrante único."""

    def __init__(self) -> None:
        self._records: dict[str, MemoryRecord] = {}
        self._bm25 = BM25Index()
        self._by_kind: dict[MemoryKind, set[str]] = {}
        self._by_fp: dict[str, set[str]] = {}
        self._lock = threading.RLock()
        self._matrix: Any = None  # cache numpy (id_order, array)
        self._matrix_ids: list[str] = []
        self._matrix_dirty = True

    def put(self, record: MemoryRecord) -> None:
        with self._lock:
            old = self._records.get(record.id)
            if old is not None:
                self._by_kind.get(old.kind, set()).discard(old.id)
                self._by_fp.get(old.fingerprint, set()).discard(old.id)
            self._records[record.id] = record
            self._bm25.add(record.id, record.content)
            self._by_kind.setdefault(record.kind, set()).add(record.id)
            self._by_fp.setdefault(record.fingerprint, set()).add(record.id)
            self._matrix_dirty = True

    def delete(self, record_id: str) -> bool:
        with self._lock:
            rec = self._records.pop(record_id, None)
            if rec is None:
                return False
            self._bm25.remove(record_id)
            self._by_kind.get(rec.kind, set()).discard(record_id)
            self._by_fp.get(rec.fingerprint, set()).discard(record_id)
            self._matrix_dirty = True
            return True

    def get(self, record_id: str) -> MemoryRecord | None:
        return self._records.get(record_id)

    def scan(self, *, kind: MemoryKind | None = None) -> Iterator[MemoryRecord]:
        with self._lock:
            if kind is None:
                snapshot = list(self._records.values())
            else:
                ids = list(self._by_kind.get(kind, ()))
                snapshot = [self._records[i] for i in ids if i in self._records]
        yield from snapshot

    def __len__(self) -> int:
        return len(self._records)

    def by_fingerprint(self, fingerprint: str) -> list[MemoryRecord]:
        ids = self._by_fp.get(fingerprint, set())
        return [self._records[i] for i in ids if i in self._records]

    # --------------------------------------------------------------- busca
    def _rebuild_matrix(self) -> None:
        if not _HAS_NUMPY:
            return
        ids = [r.id for r in self._records.values() if r.embedding is not None]
        if not ids:
            self._matrix, self._matrix_ids, self._matrix_dirty = None, [], False
            return
        dim = len(next(r.embedding for r in self._records.values() if r.embedding is not None))
        mat = _np.zeros((len(ids), dim), dtype=_np.float32)
        for row, rid in enumerate(ids):
            emb = self._records[rid].embedding
            if emb is not None and len(emb) == dim:
                mat[row] = emb
        norms = _np.linalg.norm(mat, axis=1, keepdims=True)
        norms[norms < 1e-12] = 1.0
        self._matrix = mat / norms
        self._matrix_ids = ids
        self._matrix_dirty = False

    def search_dense(
        self, vec: Sequence[float], top_k: int, *, where: Predicate | None = None
    ) -> list[tuple[str, float]]:
        if not self._records or top_k <= 0:
            return []
        if _HAS_NUMPY and where is None:
            with self._lock:
                if self._matrix_dirty:
                    self._rebuild_matrix()
                mat, ids = self._matrix, self._matrix_ids
            if mat is not None and ids:
                q = _np.asarray(vec, dtype=_np.float32)
                qn = float(_np.linalg.norm(q))
                if qn > 1e-12:
                    q = q / qn
                if q.shape[0] == mat.shape[1]:
                    sims = mat @ q
                    k = min(top_k, len(ids))
                    idx = _np.argpartition(-sims, k - 1)[:k]
                    idx = idx[_np.argsort(-sims[idx])]
                    return [(ids[int(i)], float(sims[int(i)])) for i in idx]
        scored: list[tuple[str, float]] = []
        for rec in list(self._records.values()):
            if rec.embedding is None:
                continue
            if where is not None and not where(rec):
                continue
            scored.append((rec.id, cosine(vec, rec.embedding)))
        scored.sort(key=lambda kv: (-kv[1], kv[0]))
        return scored[:top_k]

    def search_sparse(
        self, query: str, top_k: int, *, where: Predicate | None = None
    ) -> list[tuple[str, float]]:
        hits = self._bm25.search(query, top_k if where is None else top_k * 5)
        if where is None:
            return hits[:top_k]
        out = []
        for rid, score in hits:
            rec = self._records.get(rid)
            if rec is not None and where(rec):
                out.append((rid, score))
                if len(out) >= top_k:
                    break
        return out


_SCHEMA = """
CREATE TABLE IF NOT EXISTS records (
    id           TEXT PRIMARY KEY,
    kind         TEXT NOT NULL,
    content      TEXT NOT NULL,
    fingerprint  TEXT NOT NULL,
    created_at   REAL NOT NULL,
    updated_at   REAL NOT NULL,
    valid_to     REAL,
    expired_at   REAL,
    doc          TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_records_kind ON records(kind);
CREATE INDEX IF NOT EXISTS idx_records_fp   ON records(fingerprint);
CREATE INDEX IF NOT EXISTS idx_records_time ON records(created_at);
"""


class SQLiteStore(MemoryStore):
    """Backend persistente em SQLite (WAL).

    O índice vetorial é mantido em memória e reconstruído na abertura — a escala
    alvo single-node (10^5..10^6 registros) cabe confortavelmente, e evita
    dependência de extensão de vetor. Para escalas maiores, injete um
    `MemoryStore` apoiado em pgvector/FAISS: o protocolo é o mesmo.
    """

    def __init__(self, path: str, *, synchronous: str = "NORMAL") -> None:
        self.path = path
        self._conn = sqlite3.connect(path, check_same_thread=False)
        self._conn.row_factory = sqlite3.Row
        self._conn.execute("PRAGMA journal_mode=WAL")
        self._conn.execute(f"PRAGMA synchronous={synchronous}")
        self._conn.executescript(_SCHEMA)
        self._conn.commit()
        self._lock = threading.RLock()
        self._mem = InMemoryStore()
        self._hydrate()

    def _hydrate(self) -> None:
        cur = self._conn.execute("SELECT doc FROM records")
        for row in cur:
            self._mem.put(MemoryRecord.from_dict(json.loads(row["doc"])))

    def put(self, record: MemoryRecord) -> None:
        with self._lock:
            self._mem.put(record)
            self._conn.execute(
                "INSERT OR REPLACE INTO records"
                " (id, kind, content, fingerprint, created_at, updated_at, valid_to, expired_at, doc)"
                " VALUES (?,?,?,?,?,?,?,?,?)",
                (
                    record.id,
                    record.kind.value,
                    record.content,
                    record.fingerprint,
                    record.created_at,
                    record.updated_at,
                    record.valid_to,
                    record.expired_at,
                    json.dumps(record.to_dict(), ensure_ascii=False),
                ),
            )
            self._conn.commit()

    def put_many(self, records: Sequence[MemoryRecord]) -> None:
        with self._lock:
            rows = []
            for r in records:
                self._mem.put(r)
                rows.append(
                    (
                        r.id,
                        r.kind.value,
                        r.content,
                        r.fingerprint,
                        r.created_at,
                        r.updated_at,
                        r.valid_to,
                        r.expired_at,
                        json.dumps(r.to_dict(), ensure_ascii=False),
                    )
                )
            self._conn.executemany(
                "INSERT OR REPLACE INTO records"
                " (id, kind, content, fingerprint, created_at, updated_at, valid_to, expired_at, doc)"
                " VALUES (?,?,?,?,?,?,?,?,?)",
                rows,
            )
            self._conn.commit()

    def delete(self, record_id: str) -> bool:
        with self._lock:
            ok = self._mem.delete(record_id)
            self._conn.execute("DELETE FROM records WHERE id = ?", (record_id,))
            self._conn.commit()
            return ok

    def get(self, record_id: str) -> MemoryRecord | None:
        return self._mem.get(record_id)

    def scan(self, *, kind: MemoryKind | None = None) -> Iterator[MemoryRecord]:
        return self._mem.scan(kind=kind)

    def __len__(self) -> int:
        return len(self._mem)

    def by_fingerprint(self, fingerprint: str) -> list[MemoryRecord]:
        return self._mem.by_fingerprint(fingerprint)

    def search_dense(self, vec, top_k, *, where=None):
        return self._mem.search_dense(vec, top_k, where=where)

    def search_sparse(self, query, top_k, *, where=None):
        return self._mem.search_sparse(query, top_k, where=where)

    def flush(self) -> None:
        with self._lock:
            self._conn.commit()

    def close(self) -> None:
        with self._lock:
            self._conn.commit()
            self._conn.close()


def open_store(path: str | None = None) -> MemoryStore:
    """`None` -> memória; caminho -> SQLite persistente."""
    return InMemoryStore() if path is None else SQLiteStore(path)
