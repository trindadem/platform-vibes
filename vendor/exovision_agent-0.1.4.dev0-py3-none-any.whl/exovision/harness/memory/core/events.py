"""Telemetria do subsistema de memória.

Toda operação (write/read/consolidate/forget/quarantine) emite um evento. Isso
sustenta três requisitos de produção que a literatura de 2026 trata como
obrigatórios e a maioria das implementações ignora:

1. Auditoria de governança — "por que este fato entrou no contexto?"
   (Camada 4 do stack de métricas em arXiv:2603.07670).
2. Atribuição causal para auditoria de envenenamento pós-hoc
   (MemAudit, arXiv:2605.23723).
3. Contabilidade de eficiência — operações de memória e tokens por consulta,
   as métricas de eficiência do MemBench (Tan et al., 2025).
"""

from __future__ import annotations

import contextlib
import time
from collections import Counter, deque
from collections.abc import Callable, Iterable
from dataclasses import dataclass, field
from typing import Any

__all__ = ["EventBus", "MemoryEvent", "NullBus"]


@dataclass(slots=True)
class MemoryEvent:
    op: str
    subsystem: str
    record_id: str = ""
    at: float = field(default_factory=time.time)
    duration_ms: float = 0.0
    detail: dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> dict[str, Any]:
        return {
            "op": self.op,
            "subsystem": self.subsystem,
            "record_id": self.record_id,
            "at": self.at,
            "duration_ms": self.duration_ms,
            "detail": self.detail,
        }


class EventBus:
    """Buffer circular + fan-out para assinantes. Sem I/O no caminho quente."""

    __slots__ = ("_buf", "_counts", "_subscribers", "enabled")

    def __init__(self, capacity: int = 10_000, *, enabled: bool = True) -> None:
        self._buf: deque[MemoryEvent] = deque(maxlen=capacity)
        self._subscribers: list[Callable[[MemoryEvent], None]] = []
        self._counts: Counter[str] = Counter()
        self.enabled = enabled

    def emit(self, event: MemoryEvent) -> None:
        if not self.enabled:
            return
        self._buf.append(event)
        self._counts[f"{event.subsystem}.{event.op}"] += 1
        for sub in self._subscribers:
            with contextlib.suppress(Exception):  # observar não é participar: um observador que quebra não derruba a escrita
                sub(event)

    def subscribe(self, fn: Callable[[MemoryEvent], None]) -> None:
        self._subscribers.append(fn)

    def history(self, *, op: str | None = None, subsystem: str | None = None) -> list[MemoryEvent]:
        return [
            e
            for e in self._buf
            if (op is None or e.op == op) and (subsystem is None or e.subsystem == subsystem)
        ]

    def counts(self) -> dict[str, int]:
        return dict(self._counts)

    def clear(self) -> None:
        self._buf.clear()
        self._counts.clear()

    def __iter__(self) -> Iterable[MemoryEvent]:  # pragma: no cover
        return iter(self._buf)

    def __len__(self) -> int:
        return len(self._buf)


class NullBus(EventBus):
    """Bus desligado, para benchmarks de latência pura."""

    def __init__(self) -> None:
        super().__init__(capacity=1, enabled=False)
