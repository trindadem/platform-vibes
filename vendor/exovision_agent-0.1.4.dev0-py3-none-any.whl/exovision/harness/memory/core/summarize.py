"""Sumarização abstrativa (plugável) e extrativa (default, offline).

O EXOVISION-I nunca *exige* um LLM. O sumarizador default é extrativo — seleção
de sentenças por centralidade no grafo de similaridade, a ideia do TextRank
(Mihalcea & Tarau, 2004) e do LexRank (Erkan & Radev, 2004). É determinístico,
não alucina e não inventa fatos que não estavam no texto — propriedade
importante, já que a *deriva de sumarização* (perda de detalhes raros a cada
passe recursivo) é o modo de falha conhecido desta família de memória.

Injete um `Summarizer` baseado em LLM quando quiser sumários abstrativos.
"""

from __future__ import annotations

import re
from collections.abc import Callable, Sequence
from typing import Protocol, runtime_checkable

from .similarity import cosine

__all__ = ["CallableSummarizer", "ExtractiveSummarizer", "Summarizer", "split_sentences"]

_SENT_SPLIT = re.compile(r"(?<=[.!?;])\s+|\n+")


def split_sentences(text: str) -> list[str]:
    parts = [p.strip() for p in _SENT_SPLIT.split(text) if p and p.strip()]
    return parts or ([text.strip()] if text.strip() else [])


@runtime_checkable
class Summarizer(Protocol):
    def summarize(self, texts: Sequence[str], *, max_chars: int = 480) -> str: ...


class ExtractiveSummarizer:
    """Seleção de sentenças por centralidade + cobertura (MMR sobre sentenças).

    Preserva literalmente o texto de origem, então o sumário é sempre rastreável
    às sentenças que o geraram — requisito de auditoria que sumários abstrativos
    não atendem sem trabalho extra.
    """

    def __init__(self, embedder=None, *, diversity: float = 0.35) -> None:
        from .embeddings import default_embedder

        self.embedder = embedder or default_embedder
        self.diversity = diversity

    def summarize(self, texts: Sequence[str], *, max_chars: int = 480) -> str:
        sentences: list[str] = []
        for t in texts:
            sentences.extend(split_sentences(t))
        if not sentences:
            return ""
        if sum(len(s) for s in sentences) <= max_chars:
            return " ".join(sentences)

        vecs = [self.embedder.encode(s) for s in sentences]
        n = len(sentences)
        # centralidade = similaridade média com as demais sentenças
        centrality = [
            sum(cosine(vecs[i], vecs[j]) for j in range(n) if j != i) / max(n - 1, 1)
            for i in range(n)
        ]
        chosen: list[int] = []
        chosen_vecs: list[tuple[float, ...]] = []
        budget = 0
        order = sorted(range(n), key=lambda i: -centrality[i])
        while len(chosen) < n and budget < max_chars:
            best_i, best_score = -1, -1e9
            for i in order:
                if i in chosen:
                    continue
                redundancy = max((cosine(vecs[i], v) for v in chosen_vecs), default=0.0)
                score = (1 - self.diversity) * centrality[i] - self.diversity * redundancy
                if score > best_score:
                    best_score, best_i = score, i
            if best_i < 0:
                break
            cost = len(sentences[best_i]) + 1
            if budget + cost > max_chars and chosen:
                break
            chosen.append(best_i)
            chosen_vecs.append(vecs[best_i])
            budget += cost
        chosen.sort()  # restaura a ordem narrativa original
        return " ".join(sentences[i] for i in chosen)


class CallableSummarizer:
    """Adapta uma função (tipicamente uma chamada de LLM) ao protocolo."""

    def __init__(self, fn: Callable[[Sequence[str], int], str]) -> None:
        self._fn = fn

    def summarize(self, texts: Sequence[str], *, max_chars: int = 480) -> str:
        return self._fn(texts, max_chars)
