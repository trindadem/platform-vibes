"""`MemoryRecord`: a unidade atômica de memória do EXOVISION-I.

Um único tipo de registro atravessa todos os 21 subsistemas. Subsistemas
especializam-se pelos campos `kind`, `payload` e `links`, nunca por classes
de registro divergentes — isso é o que permite fusão de ranking entre
subsistemas heterogêneos e um único caminho de auditoria/governança.

Modelo bi-temporal (Snodgrass & Ahn, 1985; aplicado a memória de agentes por
Zep/Graphiti, Rasmussen et al. 2025):

    tempo de evento     : `valid_from` .. `valid_to`  (quando o fato foi/é verdade)
    tempo de transação  : `created_at` .. `expired_at` (quando o sistema soube/deixou de crer)

Fatos nunca são deletados por contradição: são *invalidados* (escreve-se
`valid_to`), de modo que o sistema consegue responder "o que eu acreditava, e
quando" e nunca serve um fato obsoleto como corrente.
"""

from __future__ import annotations

import hashlib
import math
import uuid
from dataclasses import dataclass, field, replace
from typing import Any

from .clock import SECONDS_PER_HOUR
from .types import MemoryForm, MemoryFunction, MemoryKind, Modality, ProvenanceKind, TrustTier

__all__ = ["Affect", "DecayState", "MemoryRecord", "Provenance", "content_fingerprint"]


def content_fingerprint(text: str) -> str:
    """Hash estável de conteúdo normalizado — base da deduplicação exata."""
    normalized = " ".join(text.lower().split())
    return hashlib.blake2b(normalized.encode("utf-8"), digest_size=16).hexdigest()


@dataclass(frozen=True, slots=True)
class Provenance:
    """De onde o registro veio. Obrigatório: sem proveniência não há governança."""

    kind: ProvenanceKind = ProvenanceKind.SYSTEM
    source_id: str = ""
    session_id: str = ""
    agent_id: str = ""
    tool_name: str = ""
    uri: str = ""
    derived_from: tuple[str, ...] = ()

    def to_dict(self) -> dict[str, Any]:
        return {
            "kind": self.kind.value,
            "source_id": self.source_id,
            "session_id": self.session_id,
            "agent_id": self.agent_id,
            "tool_name": self.tool_name,
            "uri": self.uri,
            "derived_from": list(self.derived_from),
        }

    @classmethod
    def from_dict(cls, d: dict[str, Any]) -> Provenance:
        return cls(
            kind=ProvenanceKind(d.get("kind", "system")),
            source_id=d.get("source_id", ""),
            session_id=d.get("session_id", ""),
            agent_id=d.get("agent_id", ""),
            tool_name=d.get("tool_name", ""),
            uri=d.get("uri", ""),
            derived_from=tuple(d.get("derived_from", ())),
        )


@dataclass(frozen=True, slots=True)
class Affect:
    """Anotação afetiva no modelo circumplexo (Russell, 1980).

    `arousal` modula a força de codificação; `valence` enviesa a recuperação
    congruente com o humor (Bower, 1981; Kensinger & Corkin, 2004).
    """

    valence: float = 0.0  # [-1, 1] — negativo .. positivo
    arousal: float = 0.0  # [ 0, 1] — calmo .. excitado
    dominance: float = 0.0  # [-1, 1] — submisso .. dominante

    @property
    def is_neutral(self) -> bool:
        return abs(self.valence) < 1e-9 and self.arousal < 1e-9

    def to_dict(self) -> dict[str, float]:
        return {"valence": self.valence, "arousal": self.arousal, "dominance": self.dominance}


@dataclass(slots=True)
class DecayState:
    """Estado mutável usado pelas políticas de esquecimento.

    - `strength` (S) é a estabilidade do traço na curva de Ebbinghaus
      R(t) = exp(-t/S); MemoryBank (Zhong et al., 2023) incrementa S a cada uso.
    - `access_times` alimenta a ativação de nível base do ACT-R
      B_i = ln(sum_k t_k^-d) (Anderson & Schooler, 1991).
    """

    strength: float = 1.0
    access_count: int = 0
    last_access: float = 0.0
    access_times: list[float] = field(default_factory=list)
    reinforcements: int = 0
    max_access_history: int = 64

    def touch(self, now: float, *, reinforce: float = 0.6) -> None:
        """Registra um acesso: reforça o traço e atualiza o histórico."""
        self.access_count += 1
        self.last_access = now
        self.access_times.append(now)
        if len(self.access_times) > self.max_access_history:
            # mantém os mais recentes: o termo t^-d dos antigos é desprezível
            del self.access_times[: len(self.access_times) - self.max_access_history]
        self.strength += reinforce
        self.reinforcements += 1

    def to_dict(self) -> dict[str, Any]:
        return {
            "strength": self.strength,
            "access_count": self.access_count,
            "last_access": self.last_access,
            "access_times": list(self.access_times),
            "reinforcements": self.reinforcements,
        }

    @classmethod
    def from_dict(cls, d: dict[str, Any]) -> DecayState:
        return cls(
            strength=float(d.get("strength", 1.0)),
            access_count=int(d.get("access_count", 0)),
            last_access=float(d.get("last_access", 0.0)),
            access_times=[float(x) for x in d.get("access_times", [])],
            reinforcements=int(d.get("reinforcements", 0)),
        )


def _new_id() -> str:
    return uuid.uuid4().hex


@dataclass(slots=True)
class MemoryRecord:
    """Unidade atômica de memória."""

    content: str
    kind: MemoryKind = MemoryKind.EPISODIC
    id: str = field(default_factory=_new_id)

    # --- classificação ---
    form: MemoryForm = MemoryForm.TOKEN
    function: MemoryFunction = MemoryFunction.FACTUAL
    modality: Modality = Modality.TEXT
    tags: tuple[str, ...] = ()

    # --- tempo de transação (quando o sistema soube) ---
    created_at: float = 0.0
    updated_at: float = 0.0
    expired_at: float | None = None  # quando o sistema deixou de acreditar

    # --- tempo de evento (quando foi verdade no mundo) ---
    valid_from: float | None = None
    valid_to: float | None = None

    # --- sinais de ranking ---
    importance: float = 0.5  # [0,1]; auto-avaliado (Generative Agents)
    confidence: float = 1.0  # [0,1]; incerteza epistêmica
    salience: float = 0.0  # surpresa/novidade no momento da codificação
    affect: Affect = field(default_factory=Affect)

    # --- governança ---
    trust: TrustTier = TrustTier.DERIVED
    provenance: Provenance = field(default_factory=Provenance)
    acl: tuple[str, ...] = ()  # namespaces/agentes autorizados; vazio = público no escopo

    # --- estrutura ---
    embedding: tuple[float, ...] | None = None
    links: dict[str, tuple[str, ...]] = field(default_factory=dict)  # relação -> ids
    payload: dict[str, Any] = field(default_factory=dict)  # campos específicos do subsistema

    # --- dinâmica ---
    decay: DecayState = field(default_factory=DecayState)
    fingerprint: str = ""

    def __post_init__(self) -> None:
        if not self.fingerprint:
            self.fingerprint = content_fingerprint(self.content)
        if self.updated_at == 0.0:
            self.updated_at = self.created_at
        if self.decay.last_access == 0.0:
            self.decay.last_access = self.created_at

    # ------------------------------------------------------------------ tempo
    def is_live(self, now: float) -> bool:
        """O registro é crível *e* aplicável agora?"""
        if self.expired_at is not None and now >= self.expired_at:
            return False
        if self.valid_from is not None and now < self.valid_from:
            return False
        if self.valid_to is not None and now >= self.valid_to:  # noqa: SIM103 - guardas legíveis
            return False
        return True

    def age_hours(self, now: float) -> float:
        return max(0.0, (now - self.created_at) / SECONDS_PER_HOUR)

    def hours_since_access(self, now: float) -> float:
        return max(0.0, (now - self.decay.last_access) / SECONDS_PER_HOUR)

    def invalidate(self, at: float) -> None:
        """Invalidação bi-temporal: o fato deixa de valer, mas o traço permanece."""
        self.valid_to = at
        self.updated_at = at

    def expire(self, at: float) -> None:
        """O sistema deixa de acreditar no registro (retratação, não fim de validade)."""
        self.expired_at = at
        self.updated_at = at

    # ------------------------------------------------------- força do traço
    def retention(self, now: float) -> float:
        """Curva de esquecimento de Ebbinghaus: R(t) = exp(-t / S).

        Ebbinghaus (1885); operacionalizada para agentes em MemoryBank
        (Zhong et al., 2023, arXiv:2305.10250).
        """
        t = self.hours_since_access(now)
        s = max(self.decay.strength, 1e-6)
        return math.exp(-t / s)

    def with_embedding(self, vec: tuple[float, ...]) -> MemoryRecord:
        self.embedding = vec
        return self

    def copy(self, **changes: Any) -> MemoryRecord:
        return replace(self, **changes)

    # ---------------------------------------------------------- serialização
    def to_dict(self) -> dict[str, Any]:
        return {
            "id": self.id,
            "content": self.content,
            "kind": self.kind.value,
            "form": self.form.value,
            "function": self.function.value,
            "modality": self.modality.value,
            "tags": list(self.tags),
            "created_at": self.created_at,
            "updated_at": self.updated_at,
            "expired_at": self.expired_at,
            "valid_from": self.valid_from,
            "valid_to": self.valid_to,
            "importance": self.importance,
            "confidence": self.confidence,
            "salience": self.salience,
            "affect": self.affect.to_dict(),
            "trust": int(self.trust),
            "provenance": self.provenance.to_dict(),
            "acl": list(self.acl),
            "embedding": list(self.embedding) if self.embedding is not None else None,
            "links": {k: list(v) for k, v in self.links.items()},
            "payload": self.payload,
            "decay": self.decay.to_dict(),
            "fingerprint": self.fingerprint,
        }

    @classmethod
    def from_dict(cls, d: dict[str, Any]) -> MemoryRecord:
        aff = d.get("affect") or {}
        rec = cls(
            content=d["content"],
            kind=MemoryKind(d.get("kind", "episodic")),
            id=d.get("id", _new_id()),
            form=MemoryForm(d.get("form", "token")),
            function=MemoryFunction(d.get("function", "factual")),
            modality=Modality(d.get("modality", "text")),
            tags=tuple(d.get("tags", ())),
            created_at=float(d.get("created_at", 0.0)),
            updated_at=float(d.get("updated_at", 0.0)),
            expired_at=d.get("expired_at"),
            valid_from=d.get("valid_from"),
            valid_to=d.get("valid_to"),
            importance=float(d.get("importance", 0.5)),
            confidence=float(d.get("confidence", 1.0)),
            salience=float(d.get("salience", 0.0)),
            affect=Affect(
                valence=float(aff.get("valence", 0.0)),
                arousal=float(aff.get("arousal", 0.0)),
                dominance=float(aff.get("dominance", 0.0)),
            ),
            trust=TrustTier(int(d.get("trust", TrustTier.DERIVED))),
            provenance=Provenance.from_dict(d.get("provenance", {})),
            acl=tuple(d.get("acl", ())),
            embedding=tuple(d["embedding"]) if d.get("embedding") else None,
            links={k: tuple(v) for k, v in (d.get("links") or {}).items()},
            payload=dict(d.get("payload") or {}),
            decay=DecayState.from_dict(d.get("decay", {})),
            fingerprint=d.get("fingerprint", ""),
        )
        return rec

    def __repr__(self) -> str:  # pragma: no cover - diagnóstico
        head = self.content[:48].replace("\n", " ")
        return f"<MemoryRecord {self.kind.value}:{self.id[:8]} imp={self.importance:.2f} {head!r}>"
