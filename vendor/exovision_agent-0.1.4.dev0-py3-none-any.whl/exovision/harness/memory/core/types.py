"""Vocabulário de tipos do subsistema de memória do EXOVISION-I.

As enumerações aqui são o contrato estável entre os subsistemas de memória,
o orquestrador, a camada de governança e o harness de avaliação.

Referências de taxonomia:
  - Tulving (1972, 1985) — distinção episódico / semântico / procedural.
  - Atkinson & Shiffrin (1968) — modelo multi-armazém (sensorial / curto / longo prazo).
  - Baddeley & Hitch (1974); Baddeley (2000) — memória de trabalho multicomponente.
  - Sumers et al. (2024), "CoALA: Cognitive Architectures for Language Agents" — mapeamento
    das memórias cognitivas para agentes de linguagem.
  - Liu et al. (2026), "Memory in the Age of AI Agents: A Survey" (arXiv:2512.13564) —
    eixos Form (token/latent/parametric) x Function (factual/experiential/working) x
    Dynamics (formation/consolidation/retrieval/forgetting).
"""

from __future__ import annotations

from enum import Enum

__all__ = [
    "EMERGENT_KINDS",
    "TRADITIONAL_KINDS",
    "ConsolidationStage",
    "MemoryForm",
    "MemoryFunction",
    "MemoryKind",
    "Modality",
    "ProvenanceKind",
    "RetrievalStrategy",
    "TrustTier",
    "WriteOp",
]


class MemoryKind(str, Enum):
    """As 21 categorias de memória implementadas pelo EXOVISION-I.

    Dez categorias tradicionais (consolidadas na literatura cognitiva e em
    frameworks de agentes desde 2020) e onze emergentes (2023-2026).
    """

    # ---------------- Tradicionais (10) ----------------
    SENSORY = "sensory"  # buffer icônico/ecoico; Sperling (1960), Neisser (1967)
    WORKING = "working"  # Baddeley & Hitch (1974)
    EPISODIC = "episodic"  # Tulving (1972)
    SEMANTIC = "semantic"  # Tulving (1972); Quillian (1968)
    PROCEDURAL = "procedural"  # Anderson (1982); Voyager (Wang et al., 2023)
    BUFFER = "buffer"  # janela deslizante de diálogo (LangChain, 2022)
    SUMMARY = "summary"  # sumarização recursiva/hierárquica; RAPTOR (Sarthi et al., 2024)
    VECTOR = "vector"  # RAG denso; Lewis et al. (2020)
    ENTITY = "entity"  # perfil/slots por entidade; MemoryBank (Zhong et al., 2023)
    GRAPH = "graph"  # grafo de conhecimento estático; GraphRAG (Edge et al., 2024)

    # ---------------- Emergentes (11) ----------------
    AGENTIC_OS = "agentic_os"  # MemGPT/Letta (Packer et al., 2023)
    ZETTELKASTEN = "zettelkasten"  # A-MEM (Xu et al., 2025, arXiv:2502.12110)
    TEMPORAL_GRAPH = "temporal_graph"  # Zep/Graphiti (Rasmussen et al., 2025, arXiv:2501.13956)
    REFLECTIVE = "reflective"  # Generative Agents (Park et al., 2023); Reflexion; ExpeL
    NEURAL = "neural"  # Titans (Behrouz et al., 2025, arXiv:2501.00663)
    HIPPOCAMPAL = "hippocampal"  # HippoRAG (Gutiérrez et al., 2024, arXiv:2405.14831)
    PROSPECTIVE = "prospective"  # PM-Bench (2026, arXiv:2607.12385); PIS (arXiv:2609.01272)
    AFFECTIVE = "affective"  # modulação valência/arousal; Kensinger & Corkin (2004)
    COLLECTIVE = "collective"  # memória compartilhada multiagente
    LATENT = "latent"  # memória comprimida latente; gist tokens (Mu et al., 2023)
    CONSOLIDATED = "consolidated"  # produto do sleep-time consolidation

    @property
    def is_emergent(self) -> bool:
        return self in EMERGENT_KINDS


TRADITIONAL_KINDS: frozenset[MemoryKind] = frozenset(
    {
        MemoryKind.SENSORY,
        MemoryKind.WORKING,
        MemoryKind.EPISODIC,
        MemoryKind.SEMANTIC,
        MemoryKind.PROCEDURAL,
        MemoryKind.BUFFER,
        MemoryKind.SUMMARY,
        MemoryKind.VECTOR,
        MemoryKind.ENTITY,
        MemoryKind.GRAPH,
    }
)

EMERGENT_KINDS: frozenset[MemoryKind] = frozenset(
    {
        MemoryKind.AGENTIC_OS,
        MemoryKind.ZETTELKASTEN,
        MemoryKind.TEMPORAL_GRAPH,
        MemoryKind.REFLECTIVE,
        MemoryKind.NEURAL,
        MemoryKind.HIPPOCAMPAL,
        MemoryKind.PROSPECTIVE,
        MemoryKind.AFFECTIVE,
        MemoryKind.COLLECTIVE,
        MemoryKind.LATENT,
        MemoryKind.CONSOLIDATED,
    }
)


class MemoryForm(str, Enum):
    """Eixo *Form* da taxonomia de Liu et al. (2026): onde a memória vive."""

    TOKEN = "token"  # texto/símbolos recuperáveis e auditáveis
    LATENT = "latent"  # vetores/estados ocultos comprimidos
    PARAMETRIC = "parametric"  # pesos atualizados em test-time


class MemoryFunction(str, Enum):
    """Eixo *Function*: para que a memória serve."""

    FACTUAL = "factual"
    EXPERIENTIAL = "experiential"
    WORKING = "working"


class Modality(str, Enum):
    TEXT = "text"
    CODE = "code"
    IMAGE = "image"
    AUDIO = "audio"
    TABULAR = "tabular"
    PROPRIOCEPTIVE = "proprioceptive"
    EVENT = "event"


class TrustTier(int, Enum):
    """Níveis de confiança. Ordenação importa: resolução de conflito prefere o maior.

    Motivado por Chen et al. (2026), "From Untrusted Input to Trusted Memory"
    (arXiv:2606.04329): a fronteira entrada-não-confiável -> memória-confiável é
    o ponto onde ataques de envenenamento (MINJA) se materializam.
    """

    QUARANTINED = 0  # detectado como suspeito; nunca entra no contexto
    UNTRUSTED = 1  # web aberta, ferramenta externa, outro agente
    DERIVED = 2  # inferido pelo próprio agente (reflexão, sumário)
    OBSERVED = 3  # observado diretamente no ambiente
    USER = 4  # afirmado pelo usuário
    VERIFIED = 5  # validado contra fonte autoritativa


class ProvenanceKind(str, Enum):
    USER = "user"
    AGENT = "agent"
    TOOL = "tool"
    ENVIRONMENT = "environment"
    PEER_AGENT = "peer_agent"
    WEB = "web"
    SYSTEM = "system"
    CONSOLIDATION = "consolidation"


class WriteOp(str, Enum):
    """Operações do pipeline de escrita.

    Espelha o conjunto de ações do Mem0 (Chhikara et al., 2025, arXiv:2504.19413):
    o extrator decide, por fato candidato, entre ADD / UPDATE / DELETE / NOOP.
    """

    ADD = "add"
    UPDATE = "update"
    DELETE = "delete"
    NOOP = "noop"
    INVALIDATE = "invalidate"  # extensão bi-temporal (Zep): não apaga, marca t_invalid
    MERGE = "merge"
    QUARANTINE = "quarantine"


class RetrievalStrategy(str, Enum):
    DENSE = "dense"
    SPARSE = "sparse"  # BM25
    HYBRID = "hybrid"  # fusão RRF de denso + esparso
    GRAPH_WALK = "graph_walk"  # Personalized PageRank
    TEMPORAL_CONTIGUITY = "temporal_contiguity"  # Howard & Kahana (2002)
    ACTIVATION = "activation"  # ACT-R base-level activation
    COMPOSITE = "composite"  # Generative Agents: recency+importance+relevance


class ConsolidationStage(str, Enum):
    """Estágios do pipeline de consolidação offline ("sleep-time compute").

    Analogia com consolidação sistêmica hipocampo -> neocórtex
    (McClelland, McNaughton & O'Reilly, 1995; Squire & Alvarez, 1995).
    """

    REPLAY = "replay"
    ABSTRACT = "abstract"
    RECONCILE = "reconcile"
    PRUNE = "prune"
    REINDEX = "reindex"
