"""Relógio injetável.

Todo o subsistema de memória lê o tempo por meio de um `Clock`. Isso torna
determinísticos os testes de decaimento, invalidação bi-temporal e disparo de
memória prospectiva — sem `sleep()` e sem flakiness.
"""

from __future__ import annotations

import time
from typing import Protocol, runtime_checkable

__all__ = ["Clock", "ManualClock", "SystemClock", "default_clock"]

SECONDS_PER_HOUR = 3600.0
SECONDS_PER_DAY = 86400.0


@runtime_checkable
class Clock(Protocol):
    def now(self) -> float:
        """Timestamp UNIX em segundos (float)."""
        ...


class SystemClock:
    """Relógio de parede. Padrão em produção."""

    __slots__ = ()

    def now(self) -> float:
        return time.time()

    def __repr__(self) -> str:  # pragma: no cover - trivial
        return "SystemClock()"


class ManualClock:
    """Relógio controlado por teste/simulação.

    >>> c = ManualClock(start=1000.0)
    >>> c.advance(hours=2)
    8200.0
    >>> c.now()
    8200.0
    """

    __slots__ = ("_t",)

    def __init__(self, start: float = 0.0) -> None:
        self._t = float(start)

    def now(self) -> float:
        return self._t

    def advance(
        self, seconds: float = 0.0, *, minutes: float = 0.0, hours: float = 0.0, days: float = 0.0
    ) -> float:
        self._t += seconds + minutes * 60.0 + hours * SECONDS_PER_HOUR + days * SECONDS_PER_DAY
        return self._t

    def set(self, t: float) -> float:
        self._t = float(t)
        return self._t

    def __repr__(self) -> str:  # pragma: no cover - trivial
        return f"ManualClock(t={self._t!r})"


default_clock: Clock = SystemClock()
