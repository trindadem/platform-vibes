"""Detecção de conflito: a diferença entre *duplicata* e *contradição*.

Motivação empírica (medida neste repositório com o `HashingEmbedder` padrão):

    "backup roda às 3h"      vs "backup roda às 5h"       -> cosseno 0.780
    "o cluster tem dois nós" vs "o cluster tem três nós"  -> cosseno 0.718
    "o deploy falhou"        vs "o deploy não funcionou"  -> cosseno 0.381

Ou seja: **similaridade de embedding é anticorrelacionada com a distinção que
importa**. Os dois pares mais similares são contradições; o menos similar é uma
paráfrase. Qualquer pipeline que decida "fundir/deduplicar se cos >= tau" vai,
com alta probabilidade, *apagar a atualização de um fato substituindo-a pela
versão antiga* — exatamente o modo de falha que os benchmarks de 2026 medem como
"knowledge update" (LongMemEval) e "staleness".

A correção é não delegar a decisão ao cosseno. Este módulo extrai sinais
simbólicos — numerais, horários, datas, negação, polaridade — e veta a fusão
quando eles divergem, roteando o par para o caminho de contradição
(UPDATE/INVALIDATE) em vez do caminho de deduplicação (MERGE).

O mesmo primitivo sustenta a invalidação bi-temporal ao estilo Zep/Graphiti
(Rasmussen et al., 2025) e a decisão ADD/UPDATE/DELETE/NOOP do Mem0
(Chhikara et al., 2025).
"""

from __future__ import annotations

import re
from collections.abc import Callable
from dataclasses import dataclass
from enum import Enum

from .text import fold

__all__ = [
    "Conflict",
    "ConflictKind",
    "detect_conflict",
    "negation_count",
    "numeric_signature",
    "proper_nouns",
    "safe_to_merge",
]

_NUM_RE = re.compile(r"\d+(?:[.,]\d+)?")
_TIME_RE = re.compile(r"\b(\d{1,2})\s*(?:h|:)\s*(\d{2})?\b")
_DATE_RE = re.compile(r"\b(\d{1,2})[/-](\d{1,2})(?:[/-](\d{2,4}))?\b")

#: numerais por extenso (PT/EN) — "dois nós" e "2 nós" devem colidir
_WORD_NUMBERS: dict[str, str] = {
    "zero": "0", "um": "1", "uma": "1", "dois": "2", "duas": "2", "tres": "3",
    "quatro": "4", "cinco": "5", "seis": "6", "sete": "7", "oito": "8",
    "nove": "9", "dez": "10", "onze": "11", "doze": "12", "vinte": "20",
    "trinta": "30", "cem": "100", "mil": "1000",
    "one": "1", "two": "2", "three": "3", "four": "4", "five": "5", "six": "6",
    "seven": "7", "eight": "8", "nine": "9", "ten": "10",
}

_NEGATIONS = frozenset(
    ["nao", "nunca", "jamais", "nenhum", "nenhuma", "nem", "sem", "tampouco", "not", "no", "never", "none", "neither", "nor", "without", "cannot", "cant", "dont", "doesnt", "isnt", "wasnt"]
)

#: pares antônimos ORDENADOS: (polo_positivo, polo_negativo).
#: A ordem importa — a polaridade efetiva é `polo XOR paridade_de_negação`,
#: de modo que "falhou" e "não funcionou" sejam reconhecidos como concordantes.
_ANTONYMS: tuple[tuple[str, str], ...] = (
    ("ativo", "inativo"),
    ("ligado", "desligado"),
    ("online", "offline"),
    ("sucesso", "falha"),
    ("funcionou", "falhou"),
    ("aprovado", "reprovado"),
    ("habilitado", "desabilitado"),
    ("enabled", "disabled"),
    ("success", "failure"),
    ("up", "down"),
    ("gosta", "odeia"),
    ("likes", "hates"),
)


class ConflictKind(str, Enum):
    NONE = "none"
    NUMERIC = "numeric"  # valores numéricos divergentes
    TEMPORAL = "temporal"  # horários/datas divergentes
    NEGATION = "negation"  # polaridade invertida
    ANTONYM = "antonym"  # par antônimo conhecido
    ENTITY = "entity"  # mesmo predicado, valor de entidade substituído


@dataclass(frozen=True, slots=True)
class Conflict:
    kind: ConflictKind
    detail: str = ""
    left: frozenset[str] = frozenset()
    right: frozenset[str] = frozenset()

    def __bool__(self) -> bool:
        return self.kind is not ConflictKind.NONE


NO_CONFLICT = Conflict(ConflictKind.NONE)


def numeric_signature(text: str) -> tuple[frozenset[str], frozenset[str]]:
    """Extrai (numerais, marcas temporais) normalizados.

    Numerais por extenso são mapeados para dígitos, então "dois nós" e "2 nós"
    produzem a mesma assinatura — e não disparam falso conflito.
    """
    folded = fold(text)
    nums: set[str] = set()
    temporal: set[str] = set()

    for m in _TIME_RE.finditer(folded):
        hh = m.group(1).lstrip("0") or "0"
        mm = m.group(2) or "00"
        temporal.add(f"t{hh}:{mm}")
    for m in _DATE_RE.finditer(folded):
        d, mo = m.group(1).lstrip("0"), m.group(2).lstrip("0")
        y = m.group(3) or ""
        temporal.add(f"d{d}/{mo}/{y}")

    consumed = {m.group(0) for m in _TIME_RE.finditer(folded)}
    consumed |= {m.group(0) for m in _DATE_RE.finditer(folded)}
    leftover = folded
    for c in consumed:
        leftover = leftover.replace(c, " ")
    for m in _NUM_RE.finditer(leftover):
        nums.add(m.group(0).replace(",", "."))
    for tok in re.findall(r"[a-z]+", leftover):
        if tok in _WORD_NUMBERS:
            nums.add(_WORD_NUMBERS[tok])
    return frozenset(nums), frozenset(temporal)


def negation_count(text: str) -> int:
    return sum(1 for tok in re.findall(r"[a-z]+", fold(text)) if tok in _NEGATIONS)


def _polarity(tokens: set[str], pair: tuple[str, str]) -> int | None:
    """0 se o texto usa o polo positivo, 1 se usa o negativo, None se nenhum."""
    if pair[0] in tokens:
        return 0
    if pair[1] in tokens:
        return 1
    return None


def _antonym_clash(a: str, b: str) -> tuple[str, str] | None:
    """Conflito de antônimo *após* compor com a paridade de negação.

    "o deploy falhou" (polo=1, neg=0 -> efetivo 1) e
    "o deploy não funcionou" (polo=0, neg=1 -> efetivo 1) concordam.
    """
    ta = set(re.findall(r"[a-z]+", fold(a)))
    tb = set(re.findall(r"[a-z]+", fold(b)))
    neg_a, neg_b = negation_count(a) % 2, negation_count(b) % 2
    for pair in _ANTONYMS:
        pa, pb = _polarity(ta, pair), _polarity(tb, pair)
        if pa is None or pb is None:
            continue
        if (pa ^ neg_a) != (pb ^ neg_b):
            return pair[pa], pair[pb]
    return None


def _content_overlap(a: str, b: str) -> float:
    """Jaccard das palavras de conteúdo, ignorando marcas de negação."""
    ta = {t for t in re.findall(r"[a-z]+", fold(a)) if t not in _NEGATIONS and len(t) > 2}
    tb = {t for t in re.findall(r"[a-z]+", fold(b)) if t not in _NEGATIONS and len(t) > 2}
    if not ta or not tb:
        return 0.0
    return len(ta & tb) / len(ta | tb)


#: tokens iniciais de sentença que herdam maiúscula da pontuação, não de nome próprio
_SENTENCE_START = re.compile(r"(?:^|[.!?]\s+)(\w)")


def proper_nouns(text: str) -> frozenset[str]:
    """Tokens capitalizados que não são início de sentença — proxy de nome próprio.

    Sinal ortográfico, não sintático: funciona bem para PT/EN escritos
    convencionalmente e **degrada para conjunto vazio em texto todo minúsculo**.
    Essa limitação é deliberada e explícita — quando um extrator de entidades
    (NER ou LLM) estiver disponível, injete-o em `detect_conflict(...,
    entity_extractor=)` e a mesma regra passa a valer com cobertura total.
    """
    starts = {m.start(1) for m in _SENTENCE_START.finditer(text)}
    out: set[str] = set()
    for m in re.finditer(r"\b\w+\b", text, flags=re.UNICODE):
        tok = m.group(0)
        if len(tok) < 2 or m.start() in starts:
            continue
        if tok[0].isupper():
            out.add(fold(tok))
    return frozenset(out)


def _frame(text: str, entities: frozenset[str]) -> set[str]:
    """Palavras de conteúdo que *não* são a entidade — o predicado da asserção."""
    toks = {t for t in re.findall(r"[a-z]+", fold(text)) if t not in _NEGATIONS and len(t) > 2}
    return toks - set(entities)


def _prefix_context(text: str, entities: frozenset[str]) -> set[str]:
    """Palavras de conteúdo que *antecedem* a primeira entidade do texto.

    É o slot sintático em que a entidade aparece. Comparar esse contexto é o que
    separa "mesma pergunta, resposta diferente" (contradição) de "perguntas
    diferentes" (coexistência).
    """
    toks = [(m.group(0), m.start()) for m in re.finditer(r"\b\w+\b", text, flags=re.UNICODE)]
    first_entity_pos = None
    for tok, pos in toks:
        if fold(tok) in entities:
            first_entity_pos = pos
            break
    if first_entity_pos is None:
        return set()
    return {
        fold(t)
        for t, pos in toks
        if pos < first_entity_pos and fold(t) not in _NEGATIONS and len(t) > 2
    }


def _entity_substitution(
    a: str, b: str, extractor: Callable[[str], frozenset[str]] | None = None
) -> tuple[str, str] | None:
    """Mesmo slot, entidade trocada: "mora em BH" -> "mora em SP".

    Três condições, todas necessárias:

    1. os dois lados têm entidades e elas são **disjuntas** (se compartilham
       alguma, um é provavelmente refinamento do outro, não substituição);
    2. o **contexto que antecede** a entidade é essencialmente o mesmo — é o que
       rejeita "Ana trabalha na Contabo" vs "Bruno trabalha na Hetzner", onde o
       sujeito mudou junto e portanto são fatos independentes;
    3. os predicados se sobrepõem.
    """
    get = extractor or proper_nouns
    ea, eb = get(a), get(b)
    if not ea or not eb or (ea & eb):
        return None
    fa, fb = _frame(a, ea), _frame(b, eb)
    if not fa or not fb or len(fa & fb) / min(len(fa), len(fb)) < 0.5:
        return None
    pa, pb = _prefix_context(a, ea), _prefix_context(b, eb)
    if not pa or not pb:
        return None
    if len(pa & pb) / len(pa | pb) < 0.8:
        return None
    return ",".join(sorted(ea)), ",".join(sorted(eb))


def detect_conflict(
    a: str, b: str, *, entity_extractor: Callable[[str], frozenset[str]] | None = None
) -> Conflict:
    """Classifica o tipo de conflito entre duas asserções.

    Retorna `ConflictKind.NONE` quando as duas podem ser tratadas como a mesma
    informação. Duas assimetrias deliberadas:

    * um lado sem numerais e o outro com eles ("o backup roda de madrugada" vs
      "o backup roda às 3h") **não** é conflito — é especificação, e o caminho
      correto é UPDATE/merge, não invalidar;
    * negação e antonímia são compostas, não somadas: "falhou" e
      "não funcionou" concordam.
    """
    na, ta = numeric_signature(a)
    nb, tb = numeric_signature(b)

    if ta and tb and ta != tb:
        return Conflict(ConflictKind.TEMPORAL, f"{sorted(ta)} != {sorted(tb)}", ta, tb)
    if na and nb and na != nb:
        return Conflict(ConflictKind.NUMERIC, f"{sorted(na)} != {sorted(nb)}", na, nb)

    clash = _antonym_clash(a, b)
    if clash is not None:
        return Conflict(ConflictKind.ANTONYM, f"{clash[0]} != {clash[1]}")

    subst = _entity_substitution(a, b, entity_extractor)
    if subst is not None:
        return Conflict(ConflictKind.ENTITY, f"{subst[0]} != {subst[1]}")

    # Paridade de negação só é evidência de contradição quando os dois textos
    # dizem *a mesma coisa* fora a negação. Sem esse guarda, qualquer par que
    # lexicalize a negação de formas diferentes ("falhou" / "não funcionou")
    # vira falso positivo.
    if (negation_count(a) % 2) != (negation_count(b) % 2) and _content_overlap(a, b) >= 0.6:
        return Conflict(
            ConflictKind.NEGATION, f"neg({negation_count(a)}) != neg({negation_count(b)})"
        )

    return NO_CONFLICT


def safe_to_merge(
    a: str,
    b: str,
    similarity: float,
    threshold: float,
    *,
    entity_extractor: Callable[[str], frozenset[str]] | None = None,
) -> bool:
    """Fundir só se for similar o suficiente **e** livre de conflito simbólico.

    Este é o guarda que impede o modo de falha documentado no topo do módulo.
    """
    if similarity < threshold:
        return False
    return not detect_conflict(a, b, entity_extractor=entity_extractor)
