"""[TRADICIONAL 1/10] Memória sensorial — buffer icônico/ecoico.

O primeiro armazém do modelo multi-armazém de Atkinson & Shiffrin (1968):
alta capacidade, altíssima taxa de decaimento, pré-atencional. Sperling (1960)
mediu o traço icônico em ~250 ms; o traço ecoico (Darwin, Turvey & Crowder,
1972) dura ~2-4 s.

Por que um agente precisa disso? Porque nem todo dado observado merece virar
memória. O buffer sensorial é o ponto onde um agente embarcado/multimodal
absorve uma torrente de observações (frames, chunks de áudio, eventos de
telemetria) e só o que ultrapassa o limiar de atenção é promovido adiante. Sem
esse estágio, o caminho de escrita da memória de longo prazo vira o gargalo — e,
pior, a superfície de envenenamento passa a ser *toda* a entrada bruta.
"""

from __future__ import annotations

from collections import deque
from collections.abc import Iterable
from typing import Any

from ..core.base import ForgetReport, MemoryQuery, MemorySubsystem, Retrieved, WriteResult
from ..core.record import MemoryRecord
from ..core.similarity import cosine
from ..core.types import MemoryForm, MemoryFunction, MemoryKind, Modality, WriteOp

__all__ = ["SensoryMemory"]

#: janelas de persistência por modalidade, em segundos (literatura psicofísica)
DEFAULT_WINDOWS: dict[Modality, float] = {
    Modality.IMAGE: 0.25,  # icônico — Sperling (1960)
    Modality.AUDIO: 3.0,  # ecoico — Darwin et al. (1972)
    Modality.TEXT: 2.0,
    Modality.CODE: 2.0,
    Modality.EVENT: 1.0,
    Modality.TABULAR: 1.0,
    Modality.PROPRIOCEPTIVE: 0.5,
}


class SensoryMemory(MemorySubsystem):
    """Registro sensorial com decaimento sub-segundo e porta de atenção.

    Parameters
    ----------
    capacity:
        Tamanho do anel por modalidade. O buffer é pré-atencional: descartar o
        mais antigo é o comportamento correto, não uma perda.
    attention_threshold:
        Saliência mínima [0,1] para que o item seja marcado promovível.
    novelty_gate:
        Se True, a saliência é aumentada pela dissimilaridade em relação ao item
        anterior da mesma modalidade — detecção de mudança, o disparador
        clássico de atenção (Sokolov, 1963, resposta de orientação).
    """

    kind = MemoryKind.SENSORY

    def __init__(
        self,
        *,
        capacity: int = 128,
        windows: dict[Modality, float] | None = None,
        attention_threshold: float = 0.35,
        novelty_gate: bool = True,
        **kw: Any,
    ) -> None:
        super().__init__(**kw)
        self.capacity = capacity
        self.windows = dict(DEFAULT_WINDOWS if windows is None else windows)
        self.attention_threshold = attention_threshold
        self.novelty_gate = novelty_gate
        self._rings: dict[Modality, deque[MemoryRecord]] = {}
        self._promoted: list[MemoryRecord] = []
        self._seen = 0
        self._dropped = 0

    # ------------------------------------------------------------- escrita
    def write(self, record: MemoryRecord) -> WriteResult:
        now = self.now()
        self._seen += 1
        record.kind = MemoryKind.SENSORY
        record.form = MemoryForm.LATENT
        record.function = MemoryFunction.WORKING
        if record.created_at == 0.0:
            record.created_at = now
            record.updated_at = now
            record.decay.last_access = now
        self.ensure_embedding(record)

        ring = self._rings.setdefault(record.modality, deque(maxlen=self.capacity))
        if self.novelty_gate and ring:
            prev = ring[-1]
            change = 1.0 - cosine(record.embedding, prev.embedding)
            # a saliência é o máximo entre a declarada e a mudança detectada
            record.salience = max(record.salience, change)

        if len(ring) == ring.maxlen:
            self._dropped += 1
        ring.append(record)

        if record.salience >= self.attention_threshold:
            self._promoted.append(record)
            self.emit("attend", record.id, salience=record.salience)
            return WriteResult(op=WriteOp.ADD, record_id=record.id, reason="attended")
        self.emit("sense", record.id, salience=record.salience)
        return WriteResult(op=WriteOp.ADD, record_id=record.id, reason="below_threshold")

    # ------------------------------------------------------------- leitura
    def read(self, query: MemoryQuery) -> list[Retrieved]:
        """Devolve apenas o que ainda está dentro da janela sensorial."""
        now = self.now(query.as_of)
        query.with_vector(self.embedder)
        out: list[Retrieved] = []
        for modality, ring in self._rings.items():
            window = self.windows.get(modality, 1.0)
            for rec in ring:
                age = now - rec.created_at
                if age > window:
                    continue
                decay = max(0.0, 1.0 - age / window) if window > 0 else 0.0
                rel = cosine(query.vector, rec.embedding) if query.vector else 1.0
                out.append(
                    Retrieved(
                        record=rec,
                        score=decay * (0.5 + 0.5 * rel),
                        subsystem=self.name,
                        rationale={"decay": decay, "relevance": rel, "salience": rec.salience},
                    )
                )
        out.sort(key=lambda r: -r.score)
        return out[: query.top_k]

    # --------------------------------------------------------- promoção/GC
    def drain_promoted(self) -> list[MemoryRecord]:
        """Itens que passaram a porta de atenção, para a memória de trabalho."""
        out, self._promoted = self._promoted, []
        return out

    def peek(self, modality: Modality | None = None) -> Iterable[MemoryRecord]:
        if modality is not None:
            return tuple(self._rings.get(modality, ()))
        return tuple(r for ring in self._rings.values() for r in ring)

    def forget(self, now: float | None = None) -> ForgetReport:
        """Expurga tudo que saiu da janela. O buffer sensorial não persiste."""
        t = self.now(now)
        evicted = 0
        for modality, ring in self._rings.items():
            window = self.windows.get(modality, 1.0)
            keep = deque((r for r in ring if (t - r.created_at) <= window), maxlen=self.capacity)
            evicted += len(ring) - len(keep)
            self._rings[modality] = keep
        retained = sum(len(r) for r in self._rings.values())
        self.emit("decay", evicted=evicted, retained=retained)
        return ForgetReport(subsystem=self.name, evicted=evicted, retained=retained)

    def stats(self) -> dict[str, Any]:
        s = super().stats()
        s.update(
            {
                "size": sum(len(r) for r in self._rings.values()),
                "seen": self._seen,
                "overflow_dropped": self._dropped,
                "pending_promotion": len(self._promoted),
                "attention_rate": (
                    (self._seen - self._dropped) and len(self._promoted) / max(self._seen, 1)
                ),
            }
        )
        return s
