"""[EMERGENTE 9/11] Memória coletiva — o que vários agentes sabem juntos.

Memória compartilhada multiagente. O problema não é armazenar — é decidir o
que fazer quando dois agentes afirmam coisas diferentes, e como um agente
sabe o quanto confiar no que outro escreveu. Três regras:

* **Toda escrita tem autor.** Registro sem `provenance.agent_id` é recusado:
  sem autoria não há como atribuir, disputar nem auditar.
* **Consenso independente sobe a confiança.** O mesmo fato afirmado por
  `quorum` agentes distintos vira endosso (um registro, vários endossantes)
  e é promovido a `OBSERVED` — vários observadores independentes valem mais
  que um, mas ainda não valem uma fonte autoritativa (`VERIFIED`).
* **Contradição não é resolvida por quem chegou por último.** Os dois lados
  ficam, marcados como *contestados*; o de menor confiança perde
  `confidence`; a resolução vem de um árbitro (`resolve()`), nunca do
  relógio. É a diferença entre uma memória coletiva e um quadro branco.

Sincronização entre instâncias (`merge_from`) é por união com
last-writer-wins por `updated_at` e união de endossantes — o suficiente para
réplicas que convergem sem coordenação (CRDT de estado, no espírito de
Shapiro et al., 2011).
"""

from __future__ import annotations

from typing import Any

from ..core.base import (
    ConsolidationReport,
    ForgetReport,
    MemoryQuery,
    MemorySubsystem,
    Retrieved,
    WriteResult,
)
from ..core.conflict import detect_conflict
from ..core.embeddings import noise_floor_of
from ..core.record import MemoryRecord
from ..core.scoring import composite_score
from ..core.types import MemoryForm, MemoryFunction, MemoryKind, TrustTier, WriteOp

__all__ = ["CollectiveMemory"]


class CollectiveMemory(MemorySubsystem):
    """Armazém compartilhado com autoria, endosso, disputa e sincronização.

    Parameters
    ----------
    quorum:
        Número de agentes distintos que precisam afirmar um fato para ele
        contar como consenso.
    conflict_threshold:
        Cosseno mínimo para sequer comparar duas afirmações por conflito.
        `None` ancora em 3x o piso de ruído.
    """

    kind = MemoryKind.COLLECTIVE
    emergent = True

    def __init__(
        self,
        *,
        quorum: int = 2,
        conflict_threshold: float | None = None,
        consensus_boost: float = 0.2,
        **kw: Any,
    ) -> None:
        super().__init__(**kw)
        floor = noise_floor_of(self.embedder, 0.1)
        self.quorum = max(1, quorum)
        self.conflict_threshold = floor * 3.0 if conflict_threshold is None else conflict_threshold
        self.consensus_boost = consensus_boost
        self._agents: set[str] = set()
        self.disputes = 0

    # ------------------------------------------------------------- escrita
    def write(self, record: MemoryRecord) -> WriteResult:
        agent = record.provenance.agent_id
        if not agent:
            return WriteResult.noop(
                "registro sem provenance.agent_id: memória coletiva exige autoria"
            )
        now = self.now()
        record.kind = MemoryKind.COLLECTIVE
        record.form = MemoryForm.TOKEN
        record.function = MemoryFunction.FACTUAL
        if record.created_at == 0.0:
            record.created_at = now
            record.updated_at = now
            record.decay.last_access = now
        self._agents.add(agent)
        self.ensure_embedding(record)

        # Mesmo conteúdo, outro agente: endosso, não duplicata.
        for existing in self.store.by_fingerprint(record.fingerprint):
            if existing.is_live(now):
                return self.endorse(existing.id, agent)

        record.payload.setdefault("endorsers", [agent])
        record.payload.setdefault("contested_with", [])
        contested = self._check_conflicts(record, now)
        self.store.put(record)
        self.emit("assert", record.id, agent=agent, contested=len(contested))
        return WriteResult(
            op=WriteOp.ADD,
            record_id=record.id,
            reason=f"contested={len(contested)}" if contested else "",
        )

    def endorse(self, record_id: str, agent_id: str) -> WriteResult:
        """Outro agente afirma o mesmo: soma endosso; quórum promove a OBSERVED."""
        rec = self.store.get(record_id)
        if rec is None:
            return WriteResult.noop(f"registro {record_id} não existe")
        now = self.now()
        self._agents.add(agent_id)
        endorsers: list[str] = list(rec.payload.get("endorsers", []))
        if agent_id in endorsers:
            return WriteResult(
                op=WriteOp.NOOP, record_id=rec.id, reason="já endossado por este agente"
            )
        endorsers.append(agent_id)
        rec.payload["endorsers"] = endorsers
        rec.decay.touch(now)
        rec.updated_at = now
        promoted = False
        if len(endorsers) >= self.quorum and int(rec.trust) < int(TrustTier.OBSERVED):
            rec.trust = TrustTier.OBSERVED
            rec.payload["consensus"] = True
            promoted = True
        self.store.put(rec)
        self.emit("endorse", rec.id, agent=agent_id, endorsers=len(endorsers), promoted=promoted)
        return WriteResult(
            op=WriteOp.UPDATE,
            record_id=rec.id,
            reason="consenso" if promoted else f"endossos={len(endorsers)}",
        )

    def _check_conflicts(self, record: MemoryRecord, now: float) -> list[str]:
        contested: list[str] = []
        for rid, sim in self.store.search_dense(record.embedding or (), 8):
            if sim < self.conflict_threshold:
                continue
            other = self.store.get(rid)
            if other is None or not other.is_live(now) or rid == record.id:
                continue
            if not detect_conflict(other.content, record.content):
                continue
            contested.append(rid)
            other.payload.setdefault("contested_with", []).append(record.id)
            # o lado de menor confiança perde confidence; em empate, os dois perdem um pouco
            if int(other.trust) < int(record.trust):
                other.confidence = max(0.05, other.confidence - 0.3)
            elif int(other.trust) > int(record.trust):
                record.confidence = max(0.05, record.confidence - 0.3)
            else:
                other.confidence = max(0.05, other.confidence - 0.15)
                record.confidence = max(0.05, record.confidence - 0.15)
            other.updated_at = now
            self.store.put(other)
            self.disputes += 1
            self.emit("dispute", record.id, with_=rid)
        record.payload["contested_with"] = contested
        return contested

    def resolve(self, winner_id: str, loser_id: str, *, arbiter: str) -> bool:
        """Um árbitro decide: o perdedor é invalidado (bi-temporal), o vencedor limpo."""
        w, l_ = self.store.get(winner_id), self.store.get(loser_id)
        if w is None or l_ is None:
            return False
        now = self.now()
        l_.invalidate(now)
        l_.payload["resolved_by"] = arbiter
        w.payload["contested_with"] = [
            c for c in w.payload.get("contested_with", []) if c != loser_id
        ]
        w.payload["resolved_by"] = arbiter
        w.confidence = min(1.0, w.confidence + 0.3)
        w.updated_at = now
        self.store.put(l_)
        self.store.put(w)
        self.emit("resolve", winner_id, loser=loser_id, arbiter=arbiter)
        return True

    # ------------------------------------------------------------- leitura
    def read(self, query: MemoryQuery) -> list[Retrieved]:
        """Composto (trust e confidence pesam) + bônus de consenso; ACL via `query.actor`."""
        now = self.now(query.as_of)
        query.with_vector(self.embedder)
        cands = self.candidates(query, now)
        if not cands:
            return []
        base = composite_score(cands, query.vector, now, self.weights)
        out: list[Retrieved] = []
        for rec, s in zip(cands, base, strict=True):
            n = len(rec.payload.get("endorsers", []))
            consensus = min(1.0, n / self.quorum)
            contested = float(bool(rec.payload.get("contested_with")))
            score = s + self.consensus_boost * consensus - 0.1 * contested
            out.append(
                Retrieved(
                    record=rec,
                    score=score,
                    subsystem=self.name,
                    rationale={
                        "composite": s,
                        "endorsers": float(n),
                        "consensus": consensus,
                        "contested": contested,
                    },
                )
            )
        out.sort(key=lambda r: -r.score)
        top = out[: query.top_k]
        self.touch_all([r.record for r in top], now)
        return top

    # ------------------------------------------------------- sincronização
    def merge_from(self, other: CollectiveMemory) -> int:
        """União de estado: novo entra; igual id -> mais recente vence; endossantes se unem."""
        merged = 0
        for rec in other.store.scan(kind=MemoryKind.COLLECTIVE):
            mine = self.store.get(rec.id)
            if mine is None:
                dup = [d for d in self.store.by_fingerprint(rec.fingerprint) if d.id != rec.id]
                if dup:
                    for agent in rec.payload.get("endorsers", []):
                        self.endorse(dup[0].id, agent)
                    continue
                self.store.put(rec.copy(payload=dict(rec.payload), links=dict(rec.links)))
                merged += 1
                continue
            union = list(
                dict.fromkeys(
                    [*mine.payload.get("endorsers", []), *rec.payload.get("endorsers", [])]
                )
            )
            newer = rec if rec.updated_at > mine.updated_at else mine
            keep = newer.copy(
                payload={**newer.payload, "endorsers": union}, links=dict(newer.links)
            )
            if len(union) >= self.quorum and int(keep.trust) < int(TrustTier.OBSERVED):
                keep.trust = TrustTier.OBSERVED
                keep.payload["consensus"] = True
            self.store.put(keep)
            merged += 1
        self._agents |= other._agents
        self.emit("merge", "", records=merged, from_=other.name)
        return merged

    # -------------------------------------------------------------- extras
    def consensus(self) -> list[MemoryRecord]:
        now = self.now()
        return [
            r
            for r in self.store.scan(kind=MemoryKind.COLLECTIVE)
            if r.payload.get("consensus") and r.is_live(now)
        ]

    def contested(self) -> list[MemoryRecord]:
        now = self.now()
        return [
            r
            for r in self.store.scan(kind=MemoryKind.COLLECTIVE)
            if r.payload.get("contested_with") and r.is_live(now)
        ]

    def consolidate(self, now: float | None = None) -> ConsolidationReport:
        """Reavalia quórum (endossos podem ter chegado por merge)."""
        report = ConsolidationReport(subsystem=self.name)
        for rec in self.store.scan(kind=MemoryKind.COLLECTIVE):
            n = len(rec.payload.get("endorsers", []))
            if n >= self.quorum and not rec.payload.get("consensus"):
                rec.payload["consensus"] = True
                if int(rec.trust) < int(TrustTier.OBSERVED):
                    rec.trust = TrustTier.OBSERVED
                self.store.put(rec)
                report.promoted += 1
        return report

    def forget(self, now: float | None = None) -> ForgetReport:
        """Afirmação solitária, de baixa retenção e sem disputa sai; consenso fica."""
        t = self.now(now)
        evicted = 0
        for rec in list(self.store.scan(kind=MemoryKind.COLLECTIVE)):
            if rec.payload.get("consensus") or rec.payload.get("contested_with"):
                continue
            if rec.retention(t) < 0.02 and rec.importance < 0.5:
                self.store.delete(rec.id)
                evicted += 1
        return ForgetReport(subsystem=self.name, evicted=evicted, retained=self.size())

    def stats(self) -> dict[str, Any]:
        s = super().stats()
        s.update(
            {
                "agents": len(self._agents),
                "consensus": len(self.consensus()),
                "contested": len(self.contested()),
                "disputes": self.disputes,
            }
        )
        return s
