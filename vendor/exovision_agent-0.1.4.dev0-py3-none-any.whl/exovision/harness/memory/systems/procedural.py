"""[TRADICIONAL 6/10] Memória procedural — biblioteca de habilidades.

Memória procedural é o "como fazer": não recuperada como texto para ler, mas
como procedimento para *executar*. Em humanos, Anderson (1982) descreve a
transição declarativo -> procedural pela compilação de conhecimento; em agentes,
o marco é a biblioteca de skills do Voyager (Wang et al., 2023,
arXiv:2305.16291), onde habilidades são código executável e reutilizável, com
ganho medido de 15,3x em velocidade de progresso.

Duas decisões de projeto aqui:

* **Confiabilidade é uma posterior Beta, não uma média.** Uma habilidade 1/1
  não é "100% confiável". Modelamos sucesso/falha como Beta(alpha, beta) com prior
  Jeffreys (0.5, 0.5) e ranqueamos pelo limite inferior do intervalo de
  credibilidade — ou por amostragem de Thompson quando se quer exploração. É
  o que evita o agente fixar-se numa skill com uma única execução sortuda.

* **Pré-condições são verificáveis.** Uma skill recuperada cujas pré-condições
  não valem no estado atual é pior que nenhuma. `applicable_in()` filtra antes
  de ranquear.
"""

from __future__ import annotations

import math
import random
from collections.abc import Sequence
from dataclasses import dataclass, field
from typing import Any

from ..core.base import (
    ConsolidationReport,
    ForgetReport,
    MemoryQuery,
    MemorySubsystem,
    Retrieved,
    WriteResult,
)
from ..core.record import MemoryRecord
from ..core.similarity import cosine
from ..core.types import MemoryForm, MemoryFunction, MemoryKind, WriteOp

__all__ = ["ProceduralMemory", "Skill", "beta_lower_bound"]


def beta_lower_bound(successes: float, failures: float, *, z: float = 1.96) -> float:
    """Limite inferior de Wilson para a taxa de sucesso.

    Wilson (1927). Comparado ao intervalo normal, comporta-se bem com n pequeno
    — que é o regime de toda skill recém-aprendida.
    """
    n = successes + failures
    if n <= 0:
        return 0.0
    p = successes / n
    denom = 1.0 + z * z / n
    centre = p + z * z / (2 * n)
    margin = z * math.sqrt((p * (1 - p) + z * z / (4 * n)) / n)
    return max(0.0, (centre - margin) / denom)


@dataclass(slots=True)
class Skill:
    """Uma habilidade reutilizável."""

    name: str
    description: str
    body: str = ""  # código ou plano em passos
    signature: str = ""
    preconditions: tuple[str, ...] = ()
    postconditions: tuple[str, ...] = ()
    successes: float = 0.0
    failures: float = 0.0
    alpha0: float = 0.5  # prior de Jeffreys
    beta0: float = 0.5
    version: int = 1
    parent: str = ""
    last_used: float = 0.0
    mean_latency_ms: float = 0.0
    tags: tuple[str, ...] = ()
    metadata: dict[str, Any] = field(default_factory=dict)

    @property
    def uses(self) -> int:
        return int(self.successes + self.failures)

    @property
    def reliability(self) -> float:
        """Média posterior Beta(alpha0+s, beta0+f)."""
        a = self.alpha0 + self.successes
        b = self.beta0 + self.failures
        return a / (a + b)

    @property
    def reliability_lcb(self) -> float:
        """Limite inferior — o critério conservador de seleção."""
        return beta_lower_bound(self.successes, self.failures)

    def sample_reliability(self, rng: random.Random) -> float:
        """Amostragem de Thompson: explora skills pouco testadas."""
        return rng.betavariate(self.alpha0 + self.successes, self.beta0 + self.failures)

    def to_dict(self) -> dict[str, Any]:
        return {
            "name": self.name,
            "description": self.description,
            "body": self.body,
            "signature": self.signature,
            "preconditions": list(self.preconditions),
            "postconditions": list(self.postconditions),
            "successes": self.successes,
            "failures": self.failures,
            "version": self.version,
            "parent": self.parent,
            "last_used": self.last_used,
            "mean_latency_ms": self.mean_latency_ms,
            "tags": list(self.tags),
            "metadata": self.metadata,
        }

    @classmethod
    def from_dict(cls, d: dict[str, Any]) -> Skill:
        return cls(
            name=d["name"],
            description=d.get("description", ""),
            body=d.get("body", ""),
            signature=d.get("signature", ""),
            preconditions=tuple(d.get("preconditions", ())),
            postconditions=tuple(d.get("postconditions", ())),
            successes=float(d.get("successes", 0.0)),
            failures=float(d.get("failures", 0.0)),
            version=int(d.get("version", 1)),
            parent=d.get("parent", ""),
            last_used=float(d.get("last_used", 0.0)),
            mean_latency_ms=float(d.get("mean_latency_ms", 0.0)),
            tags=tuple(d.get("tags", ())),
            metadata=dict(d.get("metadata") or {}),
        )


class ProceduralMemory(MemorySubsystem):
    """Biblioteca de habilidades com seleção sensível a incerteza.

    Parameters
    ----------
    selection:
        ``"lcb"`` (conservador, produção) ou ``"thompson"`` (exploratório,
        aprendizado). O default é ``lcb``: em produção, a regressão causada por
        escolher uma skill não testada custa mais do que o ganho de explorar.
    """

    kind = MemoryKind.PROCEDURAL

    def __init__(
        self, *, selection: str = "lcb", seed: int = 7, min_reliability: float = 0.0, **kw: Any
    ) -> None:
        super().__init__(**kw)
        self.selection = selection
        self.min_reliability = min_reliability
        self._rng = random.Random(seed)
        self._skills: dict[str, Skill] = {}
        self._record_of: dict[str, str] = {}  # nome da skill -> id do registro

    # ------------------------------------------------------------- escrita
    def add_skill(self, skill: Skill) -> WriteResult:
        """Registra (ou versiona) uma habilidade."""
        now = self.now()
        existing = self._skills.get(skill.name)
        if existing is not None:
            if existing.body == skill.body and existing.description == skill.description:
                return WriteResult(
                    op=WriteOp.NOOP, record_id=self._record_of[skill.name], reason="identica"
                )
            # Nova versão herda a estatística da anterior, com desconto:
            # o comportamento mudou, então a evidência antiga vale menos.
            skill.version = existing.version + 1
            skill.parent = existing.name
            skill.successes = existing.successes * 0.5
            skill.failures = existing.failures * 0.5
        self._skills[skill.name] = skill
        rec = MemoryRecord(
            content=f"{skill.name}: {skill.description}",
            kind=MemoryKind.PROCEDURAL,
            created_at=now,
            updated_at=now,
            form=MemoryForm.TOKEN,
            function=MemoryFunction.EXPERIENTIAL,
            tags=skill.tags,
            importance=0.7,
            payload={"skill": skill.to_dict()},
        )
        if existing is not None:
            rec.id = self._record_of[skill.name]
        self.ensure_embedding(rec)
        self.store.put(rec)
        self._record_of[skill.name] = rec.id
        self.emit("skill_add", rec.id, skill=skill.name, version=skill.version)
        return WriteResult(op=WriteOp.ADD if existing is None else WriteOp.UPDATE, record_id=rec.id)

    def write(self, record: MemoryRecord) -> WriteResult:
        """Aceita um `MemoryRecord` cujo payload contém uma skill serializada."""
        data = record.payload.get("skill")
        if not data:
            raise ValueError("ProceduralMemory.write exige payload['skill']")
        return self.add_skill(Skill.from_dict(data))

    # ---------------------------------------------------------- feedback
    def record_outcome(
        self, name: str, *, success: bool, latency_ms: float = 0.0, note: str = ""
    ) -> None:
        """Atualiza a posterior da skill com o resultado de uma execução."""
        skill = self._skills.get(name)
        if skill is None:
            return
        now = self.now()
        if success:
            skill.successes += 1.0
        else:
            skill.failures += 1.0
        skill.last_used = now
        if latency_ms > 0:
            n = skill.uses
            skill.mean_latency_ms = (skill.mean_latency_ms * (n - 1) + latency_ms) / max(n, 1)
        rid = self._record_of.get(name)
        if rid:
            rec = self.store.get(rid)
            if rec is not None:
                rec.payload["skill"] = skill.to_dict()
                rec.decay.touch(now)
                self.store.put(rec)
        self.emit(
            "skill_outcome", rid or "", skill=name, success=success, reliability=skill.reliability
        )

    # ------------------------------------------------------------- leitura
    def applicable_in(self, state: Sequence[str]) -> list[Skill]:
        """Skills cujas pré-condições estão todas satisfeitas no estado dado."""
        have = {s.lower() for s in state}
        return [
            sk
            for sk in self._skills.values()
            if all(p.lower() in have for p in sk.preconditions)
        ]

    def read(self, query: MemoryQuery) -> list[Retrieved]:
        now = self.now(query.as_of)
        query.with_vector(self.embedder)
        state = tuple(query.filters.get("state", ()))
        pool = self.applicable_in(state) if state else list(self._skills.values())
        out: list[Retrieved] = []
        for skill in pool:
            rid = self._record_of.get(skill.name)
            rec = self.store.get(rid) if rid else None
            if rec is None or not self.visible(rec, query, now):
                continue
            rel = cosine(query.vector, rec.embedding) if query.vector else 0.0
            if self.selection == "thompson":
                reliability = skill.sample_reliability(self._rng)
            else:
                reliability = skill.reliability_lcb
            if skill.uses > 0 and skill.reliability < self.min_reliability:
                continue
            out.append(
                Retrieved(
                    record=rec,
                    score=0.6 * rel + 0.4 * reliability,
                    subsystem=self.name,
                    rationale={
                        "relevance": rel,
                        "reliability": skill.reliability,
                        "reliability_lcb": skill.reliability_lcb,
                        "uses": float(skill.uses),
                        "version": float(skill.version),
                    },
                )
            )
        out.sort(key=lambda r: -r.score)
        return out[: query.top_k]

    def select(self, task: str, *, state: Sequence[str] = ()) -> Skill | None:
        """Atalho: melhor skill para uma tarefa, respeitando pré-condições."""
        hits = self.read(MemoryQuery(text=task, top_k=1, filters={"state": tuple(state)}))
        if not hits:
            return None
        return self._skills.get(hits[0].record.payload["skill"]["name"])

    def get(self, name: str) -> Skill | None:
        return self._skills.get(name)

    def consolidate(self, now: float | None = None) -> ConsolidationReport:
        """Poda skills dominadas: mesma descrição, confiabilidade estritamente pior."""
        report = ConsolidationReport(subsystem=self.name)
        names = list(self._skills)
        for i, a_name in enumerate(names):
            a = self._skills.get(a_name)
            if a is None or a.uses < 3:
                continue
            for b_name in names[i + 1 :]:
                b = self._skills.get(b_name)
                if b is None or b.uses < 3:
                    continue
                ra, rb = self.store.get(self._record_of[a_name]), self.store.get(
                    self._record_of[b_name]
                )
                if ra is None or rb is None:
                    continue
                if cosine(ra.embedding, rb.embedding) < 0.9:
                    continue
                loser = a if a.reliability_lcb < b.reliability_lcb else b
                winner = b if loser is a else a
                if winner.reliability_lcb - loser.reliability_lcb < 0.2:
                    continue
                self._skills.pop(loser.name, None)
                rid = self._record_of.pop(loser.name, None)
                if rid:
                    self.store.delete(rid)
                report.merged += 1
                report.notes.append(f"{loser.name} dominada por {winner.name}")
                break
        return report

    def forget(self, now: float | None = None) -> ForgetReport:
        """Aposenta skills com evidência suficiente de que não funcionam."""
        evicted = 0
        for name, skill in list(self._skills.items()):
            if skill.uses >= 5 and skill.reliability < 0.2:
                self._skills.pop(name, None)
                rid = self._record_of.pop(name, None)
                if rid:
                    self.store.delete(rid)
                evicted += 1
                self.emit("skill_retire", rid or "", skill=name)
        return ForgetReport(subsystem=self.name, evicted=evicted, retained=len(self._skills))

    def stats(self) -> dict[str, Any]:
        s = super().stats()
        rel = [sk.reliability for sk in self._skills.values() if sk.uses]
        s.update(
            {
                "skills": len(self._skills),
                "selection": self.selection,
                "mean_reliability": sum(rel) / len(rel) if rel else 0.0,
                "total_executions": sum(sk.uses for sk in self._skills.values()),
            }
        )
        return s
