"""[EMERGENTE 3/11] Grafo de conhecimento temporal — modelo bi-temporal.

Zep / Graphiti (Rasmussen et al., 2025, arXiv:2501.13956). A contribuição que
importa: **fatos não são apagados quando mudam, são invalidados**. Cada aresta
carrega dois eixos de tempo:

    tempo de evento     t_valid .. t_invalid   (quando o fato valeu no mundo)
    tempo de transação  t_created .. t_expired (quando o sistema soube/retratou)

Com isso o grafo responde três perguntas que um KG comum confunde numa só:

    "o que é verdade agora?"            -> arestas com t_invalid vazio
    "o que era verdade em março?"       -> arestas válidas naquele instante
    "o que eu acreditava em março?"     -> arestas conhecidas naquele instante

A terceira é a que permite auditar uma decisão passada do agente: ele agiu mal
ou agiu bem com a informação que tinha?

Três subgrafos, como no paper:
  * **episódico**  — eventos brutos, com o timestamp original;
  * **semântico**  — entidades e relações extraídas, bi-temporais;
  * **comunidade** — agrupamentos por propagação de rótulos, para visão macro.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any

from ..core.base import (
    ConsolidationReport,
    ForgetReport,
    MemoryQuery,
    MemorySubsystem,
    Retrieved,
    WriteResult,
)
from ..core.conflict import detect_conflict
from ..core.extract import PatternTripleExtractor, Triple, TripleExtractor
from ..core.graph import Edge, Graph
from ..core.record import MemoryRecord
from ..core.similarity import cosine
from ..core.text import content_words
from ..core.types import MemoryForm, MemoryFunction, MemoryKind, WriteOp

__all__ = ["TemporalEdge", "TemporalKnowledgeGraph"]


@dataclass(slots=True)
class TemporalEdge:
    """Aresta com as quatro marcas temporais."""

    subject: str
    relation: str
    object: str
    record_id: str
    t_valid: float
    t_invalid: float | None = None
    t_created: float = 0.0
    t_expired: float | None = None
    episode_ids: list[str] = field(default_factory=list)
    confidence: float = 1.0

    def valid_at(self, t: float) -> bool:
        """O fato valia no mundo em t?"""
        if t < self.t_valid:
            return False
        return self.t_invalid is None or t < self.t_invalid

    def known_at(self, t: float) -> bool:
        """O sistema conhecia o fato em t?"""
        if t < self.t_created:
            return False
        return self.t_expired is None or t < self.t_expired

    def as_text(self) -> str:
        return f"{self.subject} -[{self.relation}]-> {self.object}"

    def key(self) -> tuple[str, str, str]:
        return (self.subject, self.relation, self.object)


class TemporalKnowledgeGraph(MemorySubsystem):
    """Grafo bi-temporal com invalidação de arestas por contradição."""

    kind = MemoryKind.TEMPORAL_GRAPH
    emergent = True

    def __init__(
        self,
        *,
        extractor: TripleExtractor | None = None,
        damping: float = 0.5,
        invalidate_on_conflict: bool = True,
        **kw: Any,
    ) -> None:
        super().__init__(**kw)
        self.extractor = extractor or PatternTripleExtractor()
        self.damping = damping
        self.invalidate_on_conflict = invalidate_on_conflict
        self.graph = Graph()  # subgrafo semântico (arestas correntes)
        self._edges: list[TemporalEdge] = []
        self._by_key: dict[tuple[str, str, str], list[TemporalEdge]] = {}
        self._episodes: list[str] = []
        self._communities: dict[str, str] = {}

    # ------------------------------------------------------------- escrita
    def write(self, record: MemoryRecord) -> WriteResult:
        """Ingere um episódio: grava o evento bruto e materializa as arestas."""
        now = self.now()
        occurred_at = record.valid_from if record.valid_from is not None else (record.created_at or now)
        record.kind = MemoryKind.TEMPORAL_GRAPH
        record.form = MemoryForm.TOKEN
        record.function = MemoryFunction.EXPERIENTIAL
        if record.created_at == 0.0:
            record.created_at = now
            record.updated_at = now
            record.decay.last_access = now
        record.valid_from = occurred_at
        record.payload.setdefault("subgraph", "episodic")
        self.ensure_embedding(record)
        self.store.put(record)
        self._episodes.append(record.id)

        triples = self.extractor.extract(record.content)
        invalidated: list[str] = []
        added: list[str] = []
        for t in triples:
            res = self.add_fact(
                t, occurred_at=occurred_at, known_at=now, episode_id=record.id
            )
            added.append(res.record_id)
            invalidated.extend(res.superseded)
        self.emit("episode", record.id, triples=len(triples), invalidated=len(invalidated))
        return WriteResult(
            op=WriteOp.ADD,
            record_id=record.id,
            superseded=tuple(invalidated),
            reason=f"triplas={len(added)}",
        )

    def add_fact(
        self,
        triple: Triple,
        *,
        occurred_at: float,
        known_at: float | None = None,
        episode_id: str = "",
    ) -> WriteResult:
        """Insere um fato, invalidando os que ele contradiz."""
        known = self.now(known_at)
        key = triple.key() if hasattr(triple, "key") else (triple.subject, triple.relation, triple.object)

        # Mesmo fato, reafirmado: reforça em vez de duplicar.
        for e in self._by_key.get(key, ()):
            if e.valid_at(occurred_at) and e.t_expired is None:
                rec = self.store.get(e.record_id)
                if rec is not None:
                    rec.decay.touch(known)
                    rec.payload["support"] = int(rec.payload.get("support", 1)) + 1
                    self.store.put(rec)
                if episode_id:
                    e.episode_ids.append(episode_id)
                return WriteResult(op=WriteOp.NOOP, record_id=e.record_id, reason="reafirmado")

        superseded = self._invalidate_conflicts(triple, occurred_at, known) if self.invalidate_on_conflict else []

        rec = MemoryRecord(
            content=triple.as_text(),
            kind=MemoryKind.TEMPORAL_GRAPH,
            created_at=known,
            updated_at=known,
            valid_from=occurred_at,
            form=MemoryForm.TOKEN,
            function=MemoryFunction.FACTUAL,
            confidence=triple.confidence,
            importance=0.6,
            payload={
                "subgraph": "semantic",
                "subject": triple.subject,
                "relation": triple.relation,
                "object": triple.object,
                "support": 1,
                "episode_id": episode_id,
            },
        )
        self.ensure_embedding(rec)
        self.store.put(rec)
        edge = TemporalEdge(
            subject=triple.subject,
            relation=triple.relation,
            object=triple.object,
            record_id=rec.id,
            t_valid=occurred_at,
            t_created=known,
            episode_ids=[episode_id] if episode_id else [],
            confidence=triple.confidence,
        )
        self._edges.append(edge)
        self._by_key.setdefault(key, []).append(edge)
        self.graph.add_edge(Edge(triple.subject, triple.object, triple.relation, 1.0, rec.id))
        return WriteResult(op=WriteOp.ADD, record_id=rec.id, superseded=tuple(superseded))

    def _invalidate_conflicts(self, triple: Triple, occurred_at: float, known: float) -> list[str]:
        """Invalida arestas correntes que o novo fato contradiz.

        Regra do Graphiti: `t_invalid` da aresta antiga recebe o `t_valid` da
        aresta que a invalida — não o instante da ingestão. O grafo passa a
        conhecer a fronteira temporal correta entre as duas versões.
        """
        out: list[str] = []
        for edge in self._edges:
            if edge.t_invalid is not None or edge.t_expired is not None:
                continue
            if edge.subject != triple.subject or edge.relation != triple.relation:
                continue
            if edge.object == triple.object:
                continue
            # mesmo sujeito + mesma relação + objeto diferente = substituição de valor
            conflict = detect_conflict(edge.as_text(), triple.as_text())
            if conflict or edge.relation == triple.relation:
                edge.t_invalid = occurred_at
                rec = self.store.get(edge.record_id)
                if rec is not None:
                    rec.invalidate(occurred_at)
                    rec.payload["invalidated_by"] = triple.as_text()
                    self.store.put(rec)
                self.graph.remove_edge(edge.subject, edge.relation, edge.object)
                out.append(edge.record_id)
                self.emit("edge_invalidate", edge.record_id, by=triple.as_text(), at=occurred_at)
        return out

    def retract(self, record_id: str, *, at: float | None = None) -> bool:
        """Retratação: o sistema deixa de acreditar (t_expired), sem mudar t_valid.

        Diferente de invalidar. Invalidar diz "deixou de ser verdade"; retratar
        diz "nunca foi verdade, eu me enganei". Um agente auditável precisa dos
        dois.
        """
        t = self.now(at)
        for edge in self._edges:
            if edge.record_id == record_id:
                edge.t_expired = t
                rec = self.store.get(record_id)
                if rec is not None:
                    rec.expire(t)
                    self.store.put(rec)
                self.graph.remove_edge(edge.subject, edge.relation, edge.object)
                self.emit("retract", record_id, at=t)
                return True
        return False

    # ------------------------------------------------------------- leitura
    def facts_valid_at(self, t: float, *, known_at: float | None = None) -> list[TemporalEdge]:
        """Arestas verdadeiras em `t`, opcionalmente limitadas ao que era conhecido em `known_at`."""
        out = [e for e in self._edges if e.valid_at(t)]
        if known_at is not None:
            out = [e for e in out if e.known_at(known_at)]
        return out

    def beliefs_at(self, t: float) -> list[TemporalEdge]:
        """O que o sistema *acreditava* em t — a consulta de auditoria."""
        return [e for e in self._edges if e.known_at(t) and e.valid_at(t)]

    def history_of(self, subject: str, relation: str) -> list[TemporalEdge]:
        """Todas as versões de um par (sujeito, relação), em ordem cronológica."""
        out = [e for e in self._edges if e.subject == subject and e.relation == relation]
        out.sort(key=lambda e: e.t_valid)
        return out

    def read(self, query: MemoryQuery) -> list[Retrieved]:
        now = self.now(query.as_of)
        query.with_vector(self.embedder)
        terms = set(content_words(query.text))
        seeds: dict[str, float] = {}
        for node in self.graph.nodes:
            hit = terms & set(node.split("_"))
            if hit:
                seeds[node] = len(hit) / max(len(node.split("_")), 1)
        ranks = self.graph.personalized_pagerank(seeds, damping=self.damping) if seeds else {}

        out: list[Retrieved] = []
        for edge in self._edges:
            if not query.include_invalid and not (edge.valid_at(now) and edge.known_at(now)):
                continue
            rec = self.store.get(edge.record_id)
            if rec is None:
                continue
            if query.tags and not set(query.tags) & set(rec.tags):
                continue
            activation = ranks.get(edge.subject, 0.0) + ranks.get(edge.object, 0.0)
            rel = cosine(query.vector, rec.embedding) if query.vector else 0.0
            score = 0.6 * activation * 10.0 + 0.4 * rel
            if score <= 0:
                continue
            out.append(
                Retrieved(
                    record=rec,
                    score=score,
                    subsystem=self.name,
                    rationale={
                        "ppr_activation": activation,
                        "relevance": rel,
                        "t_valid": edge.t_valid,
                        "t_invalid": edge.t_invalid if edge.t_invalid is not None else -1.0,
                        "community": float(hash(self._communities.get(edge.subject, "")) % 1000),
                    },
                )
            )
        out.sort(key=lambda r: -r.score)
        top = out[: query.top_k]
        self.touch_all([t.record for t in top], now)
        return top

    def consolidate(self, now: float | None = None) -> ConsolidationReport:
        """Constrói o subgrafo de comunidade por propagação de rótulos."""
        report = ConsolidationReport(subsystem=self.name)
        self._communities = self.graph.label_propagation()
        groups: dict[str, list[str]] = {}
        for node, label in self._communities.items():
            groups.setdefault(label, []).append(node)
        report.abstracted = len(groups)
        report.notes.append(f"{len(groups)} comunidades sobre {len(self.graph)} nós")
        self.emit("communities", count=len(groups))
        return report

    def forget(self, now: float | None = None) -> ForgetReport:
        """Nunca apaga aresta invalidada: o histórico *é* o produto."""
        invalid = sum(1 for e in self._edges if e.t_invalid is not None)
        expired = sum(1 for e in self._edges if e.t_expired is not None)
        return ForgetReport(
            subsystem=self.name,
            invalidated=invalid,
            demoted=expired,
            retained=len(self._edges) - invalid - expired,
        )

    def stats(self) -> dict[str, Any]:
        now = self.now()
        s = super().stats()
        s.update(
            {
                "edges_total": len(self._edges),
                "edges_current": sum(1 for e in self._edges if e.valid_at(now) and e.known_at(now)),
                "edges_invalidated": sum(1 for e in self._edges if e.t_invalid is not None),
                "edges_retracted": sum(1 for e in self._edges if e.t_expired is not None),
                "episodes": len(self._episodes),
                "graph": self.graph.stats(),
            }
        )
        return s
