"""[EMERGENTE 4/11] Memória reflexiva — observações que viram insights.

Três linhagens, um mecanismo:

* **Generative Agents** (Park et al., 2023, arXiv:2304.03442): quando a soma
  das importâncias das observações recentes cruza um limiar, o agente
  *reflete* — sintetiza observações em afirmações de nível mais alto, que
  entram na memória como registros próprios apontando para as evidências.
  Reflexões sobre reflexões formam uma árvore.
* **Reflexion** (Shinn et al., 2023, arXiv:2303.11366): após cada tentativa,
  uma *lição verbal* ("falhei porque X; da próxima vez Y") persiste e entra no
  contexto da tentativa seguinte.
* **ExpeL** (Zhao et al., 2024, arXiv:2308.10144): insights extraídos de
  sucessos e falhas recebem votos — sobem, descem, são editados ou removidos.

Sem LLM disponível, a síntese é *extrativa* (o insight é composto de sentenças
literais das observações que o geraram), o que garante rastreabilidade: todo
insight aponta para suas evidências em `links["evidence"]`. Injete um
`reflector=` (chamada de LLM) para síntese abstrativa; a interface é a mesma.
"""

from __future__ import annotations

from collections.abc import Callable, Sequence
from typing import Any

from ..core.base import (
    ConsolidationReport,
    ForgetReport,
    MemoryQuery,
    MemorySubsystem,
    Retrieved,
    WriteResult,
)
from ..core.embeddings import noise_floor_of
from ..core.record import MemoryRecord, Provenance
from ..core.scoring import composite_score
from ..core.similarity import cosine
from ..core.summarize import ExtractiveSummarizer, Summarizer
from ..core.types import MemoryForm, MemoryFunction, MemoryKind, ProvenanceKind, TrustTier, WriteOp

__all__ = ["ReflectiveMemory", "Reflector"]

#: Uma função que recebe evidências e devolve uma afirmação de nível mais alto.
Reflector = Callable[[Sequence[str]], str]


class ReflectiveMemory(MemorySubsystem):
    """Observações + insights em árvore, lições de tentativa e votos.

    Parameters
    ----------
    reflection_threshold:
        Soma de importâncias (em [0,1] cada) acumulada desde a última reflexão
        que dispara uma nova. Park et al. usam 150 numa escala 1-10 com ~100
        observações/dia; 6.0 em [0,1] reproduz a mesma cadência relativa.
    window:
        Quantas observações recentes entram numa reflexão.
    cluster_threshold:
        Cosseno mínimo para agrupar observações no mesmo insight. `None`
        ancora em 2x o piso de ruído do embedder.
    insight_boost:
        Acréscimo de importância por nível de abstração: insights são o que o
        agente aprendeu, e devem vencer observações cruas de mesma relevância.
    """

    kind = MemoryKind.REFLECTIVE
    emergent = True

    def __init__(
        self,
        *,
        reflection_threshold: float = 6.0,
        window: int = 24,
        cluster_threshold: float | None = None,
        min_cluster: int = 2,
        max_insights: int = 3,
        max_level: int = 3,
        insight_boost: float = 0.15,
        reflector: Reflector | None = None,
        summarizer: Summarizer | None = None,
        **kw: Any,
    ) -> None:
        super().__init__(**kw)
        floor = noise_floor_of(self.embedder, 0.1)
        self.reflection_threshold = reflection_threshold
        self.window = window
        self.cluster_threshold = floor * 2.0 if cluster_threshold is None else cluster_threshold
        self.min_cluster = min_cluster
        self.max_insights = max_insights
        self.max_level = max_level
        self.insight_boost = insight_boost
        self.reflector = reflector
        self.summarizer = summarizer or ExtractiveSummarizer(self.embedder)
        self._since_reflection = 0.0
        self._order: list[str] = []
        self.reflections = 0

    # ------------------------------------------------------------- escrita
    def write(self, record: MemoryRecord) -> WriteResult:
        """Observação. Cruza o limiar de importância acumulada -> reflete."""
        now = self.now()
        record.kind = MemoryKind.REFLECTIVE
        record.form = MemoryForm.TOKEN
        record.function = MemoryFunction.EXPERIENTIAL
        if record.created_at == 0.0:
            record.created_at = now
            record.updated_at = now
            record.decay.last_access = now
        record.payload.setdefault("level", 0)
        self.ensure_embedding(record)
        self.store.put(record)
        self._order.append(record.id)
        self._since_reflection += max(0.0, min(1.0, record.importance))
        self.emit("observe", record.id, level=record.payload["level"])
        abstracted = 0
        if self._since_reflection >= self.reflection_threshold:
            abstracted = len(self.reflect(now))
        return WriteResult(op=WriteOp.ADD, record_id=record.id, reason=f"insights={abstracted}")

    def record_outcome(
        self, task: str, *, success: bool, lesson: str, importance: float = 0.8
    ) -> WriteResult:
        """Reflexion: uma lição verbal ligada à tarefa e ao desfecho."""
        rec = MemoryRecord(
            content=lesson,
            importance=importance,
            tags=("lesson", "success" if success else "failure"),
            trust=TrustTier.DERIVED,
            provenance=Provenance(kind=ProvenanceKind.AGENT, source_id=f"task:{task[:64]}"),
            payload={"task": task, "success": success, "level": 0, "votes": 0},
        )
        return self.write(rec)

    def lessons(
        self, task: str = "", *, top_k: int = 5, failures_only: bool = False
    ) -> list[MemoryRecord]:
        """Lições mais relevantes para a tarefa (ou as mais recentes, sem tarefa)."""
        now = self.now()
        pool = [
            r
            for r in self.store.scan(kind=MemoryKind.REFLECTIVE)
            if "lesson" in r.tags and r.is_live(now)
        ]
        if failures_only:
            pool = [r for r in pool if "failure" in r.tags]
        if not pool:
            return []
        if not task:
            pool.sort(key=lambda r: -r.created_at)
            return pool[:top_k]
        qv = self.embedder.encode(task)
        pool.sort(key=lambda r: -(cosine(qv, r.embedding) + 0.05 * r.payload.get("votes", 0)))
        return pool[:top_k]

    # -------------------------------------------------------- votos (ExpeL)
    def upvote(self, record_id: str) -> bool:
        return self._vote(record_id, +1)

    def downvote(self, record_id: str, *, remove_below: int = -2) -> bool:
        ok = self._vote(record_id, -1)
        rec = self.store.get(record_id)
        if ok and rec is not None and rec.payload.get("votes", 0) <= remove_below:
            rec.expire(self.now())
            self.store.put(rec)
            self.emit("retire", record_id, votes=rec.payload["votes"])
        return ok

    def _vote(self, record_id: str, delta: int) -> bool:
        rec = self.store.get(record_id)
        if rec is None:
            return False
        rec.payload["votes"] = int(rec.payload.get("votes", 0)) + delta
        rec.confidence = max(0.05, min(1.0, rec.confidence + 0.1 * delta))
        rec.updated_at = self.now()
        self.store.put(rec)
        return True

    # ------------------------------------------------------------ reflexão
    def reflect(self, now: float | None = None) -> list[MemoryRecord]:
        """Sintetiza as observações recentes em insights de nível superior."""
        t = self.now(now)
        pool: list[MemoryRecord] = []
        for rid in reversed(self._order):
            rec = self.store.get(rid)
            if rec is None or not rec.is_live(t):
                continue
            if int(rec.payload.get("level", 0)) >= self.max_level:
                continue
            pool.append(rec)
            if len(pool) >= self.window:
                break
        self._since_reflection = 0.0
        if len(pool) < self.min_cluster:
            return []

        clusters = self._cluster(pool)
        insights: list[MemoryRecord] = []
        for members in clusters[: self.max_insights]:
            if len(members) < self.min_cluster:
                continue
            # Observações raramente terminam com ponto; sem a fronteira, o
            # sumarizador extrativo emenda duas sentenças numa só.
            texts = [
                m.content.rstrip()
                if m.content.rstrip().endswith((".", "!", "?"))
                else m.content.rstrip() + "."
                for m in members
            ]
            if self.reflector is not None:
                content = self.reflector(texts).strip()
            else:
                content = self.summarizer.summarize(texts, max_chars=280)
            if not content:
                continue
            level = max(int(m.payload.get("level", 0)) for m in members) + 1
            importance = min(
                1.0, sum(m.importance for m in members) / len(members) + self.insight_boost * level
            )
            insight = MemoryRecord(
                content=content,
                kind=MemoryKind.REFLECTIVE,
                form=MemoryForm.TOKEN,
                function=MemoryFunction.EXPERIENTIAL,
                importance=importance,
                confidence=min(m.confidence for m in members),
                trust=TrustTier.DERIVED,
                provenance=Provenance(
                    kind=ProvenanceKind.AGENT,
                    source_id="reflection",
                    derived_from=tuple(m.id for m in members),
                ),
                links={"evidence": tuple(m.id for m in members)},
                payload={"level": level, "votes": 0, "evidence_count": len(members)},
                created_at=t,
                updated_at=t,
                tags=("insight",),
            )
            self.ensure_embedding(insight)
            self.store.put(insight)
            self._order.append(insight.id)
            for m in members:
                m.links["abstracted_by"] = (*m.links.get("abstracted_by", ()), insight.id)
                self.store.put(m)
            insights.append(insight)
        self.reflections += 1
        self.emit("reflect", "", insights=len(insights), pool=len(pool))
        return insights

    def _cluster(self, pool: list[MemoryRecord]) -> list[list[MemoryRecord]]:
        """Agrupamento guloso por similaridade, semeado pela importância."""
        remaining = sorted(pool, key=lambda r: -r.importance)
        clusters: list[list[MemoryRecord]] = []
        while remaining:
            seed = remaining.pop(0)
            members = [seed]
            rest: list[MemoryRecord] = []
            for r in remaining:
                if cosine(seed.embedding, r.embedding) >= self.cluster_threshold:
                    members.append(r)
                else:
                    rest.append(r)
            remaining = rest
            clusters.append(members)
        clusters.sort(key=lambda c: (-len(c), -sum(m.importance for m in c)))
        return clusters

    # ------------------------------------------------------------- leitura
    def read(self, query: MemoryQuery) -> list[Retrieved]:
        """Composto (relevância + recência + importância) com insights promovidos."""
        now = self.now(query.as_of)
        query.with_vector(self.embedder)
        cands = self.candidates(query, now)
        if not cands:
            return []
        scores = composite_score(cands, query.vector, now, self.weights)
        out: list[Retrieved] = []
        for rec, s in zip(cands, scores, strict=True):
            level = int(rec.payload.get("level", 0))
            votes = int(rec.payload.get("votes", 0))
            score = s + self.insight_boost * level + 0.05 * votes
            out.append(
                Retrieved(
                    record=rec,
                    score=score,
                    subsystem=self.name,
                    rationale={"composite": s, "level": float(level), "votes": float(votes)},
                )
            )
        out.sort(key=lambda r: -r.score)
        top = out[: query.top_k]
        self.touch_all([r.record for r in top], now)
        return top

    # -------------------------------------------------------------- extras
    def insights(self, *, min_level: int = 1) -> list[MemoryRecord]:
        now = self.now()
        out = [
            r
            for r in self.store.scan(kind=MemoryKind.REFLECTIVE)
            if int(r.payload.get("level", 0)) >= min_level and r.is_live(now)
        ]
        out.sort(key=lambda r: (-int(r.payload.get("level", 0)), -r.importance))
        return out

    def evidence(self, insight_id: str) -> list[MemoryRecord]:
        rec = self.store.get(insight_id)
        if rec is None:
            return []
        return [
            r for r in (self.store.get(i) for i in rec.links.get("evidence", ())) if r is not None
        ]

    def consolidate(self, now: float | None = None) -> ConsolidationReport:
        """Reflexão forçada (sleep-time): sintetiza o que ainda não foi abstraído."""
        made = self.reflect(now)
        return ConsolidationReport(
            subsystem=self.name,
            abstracted=len(made),
            links_created=sum(len(i.links.get("evidence", ())) for i in made),
        )

    def forget(self, now: float | None = None) -> ForgetReport:
        """Observação já abstraída e de baixa retenção sai; o insight fica."""
        t = self.now(now)
        invalidated = 0
        for rec in list(self.store.scan(kind=MemoryKind.REFLECTIVE)):
            if not rec.is_live(t):
                continue
            covered = bool(rec.links.get("abstracted_by"))
            if (
                covered
                and int(rec.payload.get("level", 0)) == 0
                and rec.retention(t) < 0.05
                and "lesson" not in rec.tags
            ):
                rec.expire(t)
                self.store.put(rec)
                invalidated += 1
        return ForgetReport(
            subsystem=self.name, invalidated=invalidated, retained=self.size() - invalidated
        )

    def stats(self) -> dict[str, Any]:
        s = super().stats()
        levels: dict[int, int] = {}
        for r in self.store.scan(kind=MemoryKind.REFLECTIVE):
            lv = int(r.payload.get("level", 0))
            levels[lv] = levels.get(lv, 0) + 1
        s.update(
            {
                "reflections": self.reflections,
                "levels": levels,
                "pending_importance": round(self._since_reflection, 3),
            }
        )
        return s
