"""[TRADICIONAL 2/10] Memória de trabalho — modelo multicomponente de Baddeley.

Implementa os quatro componentes de Baddeley & Hitch (1974) com o buffer
episódico acrescentado em Baddeley (2000):

  * alça fonológica       -> conteúdo verbal/textual
  * bloco de esboço visuoespacial -> conteúdo visual/espacial
  * buffer episódico      -> ligações multimodais integradas
  * executivo central     -> alocação de atenção, ensaio e deslocamento

Capacidade: Miller (1956) propôs 7±2 chunks; Cowan (2001) revisou para 4±1 sob
controle de ensaio. O default aqui é 7 slots, configurável — em agentes, o
limite real é o orçamento de tokens, e o valor certo sai da calibração.

O executivo central é *o* diferencial em relação a "só uma lista dos N últimos
turnos": slots competem por ativação, o ensaio (`rehearse`) refresca o que é
relevante à meta corrente, e o deslocamento remove o slot menos ativo — não o
mais antigo. É a diferença entre uma fila e uma memória de trabalho.
"""

from __future__ import annotations

import math
from dataclasses import dataclass
from typing import Any

from ..core.base import (
    ConsolidationReport,
    ForgetReport,
    MemoryQuery,
    MemorySubsystem,
    Retrieved,
    WriteResult,
)
from ..core.conflict import safe_to_merge
from ..core.record import MemoryRecord
from ..core.similarity import cosine
from ..core.types import MemoryForm, MemoryFunction, MemoryKind, Modality, WriteOp

__all__ = ["Component", "Slot", "WorkingMemory"]


class Component(str):
    PHONOLOGICAL = "phonological_loop"
    VISUOSPATIAL = "visuospatial_sketchpad"
    EPISODIC_BUFFER = "episodic_buffer"


_MODALITY_TO_COMPONENT = {
    Modality.TEXT: Component.PHONOLOGICAL,
    Modality.CODE: Component.PHONOLOGICAL,
    Modality.AUDIO: Component.PHONOLOGICAL,
    Modality.IMAGE: Component.VISUOSPATIAL,
    Modality.PROPRIOCEPTIVE: Component.VISUOSPATIAL,
    Modality.TABULAR: Component.EPISODIC_BUFFER,
    Modality.EVENT: Component.EPISODIC_BUFFER,
}


@dataclass(slots=True)
class Slot:
    record: MemoryRecord
    component: str
    activation: float = 1.0
    rehearsals: int = 0
    entered_at: float = 0.0
    goal_relevance: float = 0.0

    def decay(self, elapsed_s: float, tau: float) -> None:
        """Decaimento exponencial da ativação, com constante de tempo `tau` (s)."""
        if elapsed_s > 0 and tau > 0:
            self.activation *= math.exp(-elapsed_s / tau)


class WorkingMemory(MemorySubsystem):
    """Memória de trabalho com capacidade limitada e controle executivo.

    Parameters
    ----------
    capacity:
        Slots por componente. 7 = Miller (1956). Use 4 para modelar Cowan (2001).
    tau_seconds:
        Constante de decaimento da ativação. ~18 s reproduz a curva de
        Peterson & Peterson (1959) sem ensaio.
    goal:
        Texto da meta corrente. O executivo central usa isso para enviesar o
        ensaio e a decisão de deslocamento.
    """

    kind = MemoryKind.WORKING

    def __init__(
        self,
        *,
        capacity: int = 7,
        tau_seconds: float = 18.0,
        goal: str = "",
        rehearsal_gain: float = 0.6,
        goal_bias: float = 0.5,
        chunk_threshold: float = 0.6,
        **kw: Any,
    ) -> None:
        super().__init__(**kw)
        self.capacity = capacity
        self.tau = tau_seconds
        self.rehearsal_gain = rehearsal_gain
        self.goal_bias = goal_bias
        self.chunk_threshold = chunk_threshold
        self._slots: dict[str, list[Slot]] = {
            Component.PHONOLOGICAL: [],
            Component.VISUOSPATIAL: [],
            Component.EPISODIC_BUFFER: [],
        }
        self._goal = ""
        self._goal_vec: tuple[float, ...] | None = None
        self._displaced: list[MemoryRecord] = []
        self._last_tick = 0.0
        self.set_goal(goal)

    # ---------------------------------------------------- executivo central
    def set_goal(self, goal: str) -> None:
        """Define a meta corrente; reavalia a relevância de todos os slots."""
        self._goal = goal
        self._goal_vec = self.embedder.encode(goal) if goal else None
        if self._goal_vec is not None:
            for slot in self._all_slots():
                slot.goal_relevance = cosine(self._goal_vec, slot.record.embedding)

    @property
    def goal(self) -> str:
        return self._goal

    def _all_slots(self) -> list[Slot]:
        return [s for slots in self._slots.values() for s in slots]

    def _tick(self, now: float) -> None:
        """Aplica decaimento desde o último acesso ao componente."""
        if self._last_tick == 0.0:
            self._last_tick = now
            return
        elapsed = now - self._last_tick
        if elapsed <= 0:
            return
        for slot in self._all_slots():
            slot.decay(elapsed, self.tau)
        self._last_tick = now

    # ------------------------------------------------------------- escrita
    def write(self, record: MemoryRecord) -> WriteResult:
        now = self.now()
        self._tick(now)
        record.kind = MemoryKind.WORKING
        record.form = MemoryForm.TOKEN
        record.function = MemoryFunction.WORKING
        if record.created_at == 0.0:
            record.created_at = now
            record.updated_at = now
            record.decay.last_access = now
        self.ensure_embedding(record)

        component = _MODALITY_TO_COMPONENT.get(record.modality, Component.EPISODIC_BUFFER)
        slots = self._slots[component]
        relevance = cosine(self._goal_vec, record.embedding) if self._goal_vec else 0.0
        slot = Slot(
            record=record,
            component=component,
            activation=1.0 + record.salience,
            entered_at=now,
            goal_relevance=relevance,
        )

        displaced: tuple[str, ...] = ()
        if len(slots) >= self.capacity:
            # Deslocamento: sai o slot de menor ativação efetiva, não o mais antigo.
            victim_idx = min(
                range(len(slots)), key=lambda i: self._effective_activation(slots[i])
            )
            victim = slots.pop(victim_idx)
            self._displaced.append(victim.record)
            displaced = (victim.record.id,)
            self.emit("displace", victim.record.id, component=component)
        slots.append(slot)
        self.store.put(record)
        self.emit("encode", record.id, component=component, activation=slot.activation)
        return WriteResult(op=WriteOp.ADD, record_id=record.id, superseded=displaced)

    def _effective_activation(self, slot: Slot) -> float:
        """Ativação enviesada pela meta — o viés atencional do executivo central.

        A modulação é *multiplicativa e limitada*: relevância à meta reponderá
        traços de força comparável, mas não ressuscita um traço já decaído. Essa
        é a previsão de Baddeley — o executivo central aloca atenção, não
        substitui o decaimento. Consequência prática: com `goal_bias` baixo, a
        recência domina; ele é um parâmetro de calibração, não uma constante.
        """
        return slot.activation * (1.0 + self.goal_bias * max(0.0, slot.goal_relevance))

    # ------------------------------------------------------------- leitura
    def read(self, query: MemoryQuery) -> list[Retrieved]:
        now = self.now(query.as_of)
        self._tick(now)
        query.with_vector(self.embedder)
        out: list[Retrieved] = []
        for slot in self._all_slots():
            if not self.visible(slot.record, query, now):
                continue
            rel = cosine(query.vector, slot.record.embedding) if query.vector else 0.0
            act = self._effective_activation(slot)
            out.append(
                Retrieved(
                    record=slot.record,
                    score=0.6 * act + 0.4 * rel,
                    subsystem=self.name,
                    rationale={
                        "activation": act,
                        "relevance": rel,
                        "goal_relevance": slot.goal_relevance,
                        "component": slot.component,
                    },
                )
            )
        out.sort(key=lambda r: -r.score)
        return out[: query.top_k]

    # ------------------------------------------------------------- ensaio
    def rehearse(self, query: str | None = None, *, top_k: int = 3) -> int:
        """Ensaio articulatório: refresca a ativação dos slots mais relevantes.

        Sem ensaio, o traço decai por `tau` e é deslocado. Com ensaio, o agente
        mantém deliberadamente ativo o que importa para a meta.
        """
        now = self.now()
        self._tick(now)
        vec = self.embedder.encode(query) if query else self._goal_vec
        slots = self._all_slots()
        if not slots:
            return 0
        if vec is None:
            targets = sorted(slots, key=lambda s: -s.activation)[:top_k]
        else:
            targets = sorted(slots, key=lambda s: -cosine(vec, s.record.embedding))[:top_k]
        for slot in targets:
            slot.activation += self.rehearsal_gain
            slot.rehearsals += 1
            slot.record.decay.touch(now)
        self.emit("rehearse", count=len(targets))
        return len(targets)

    def drain_displaced(self) -> list[MemoryRecord]:
        """Itens deslocados — candidatos à codificação episódica de longo prazo."""
        out, self._displaced = self._displaced, []
        return out

    def consolidate(self, now: float | None = None) -> ConsolidationReport:
        """Chunking: funde slots redundantes do mesmo componente em um só.

        É o mecanismo pelo qual Miller (1956) explica capacidade aparente maior:
        agrupar itens em chunks de ordem superior. A fusão passa por
        `core.conflict.safe_to_merge`, então versões contraditórias de um mesmo
        fato nunca são colapsadas — elas permanecem separadas e seguem para a
        resolução de contradição na memória semântica.
        """
        t = self.now(now)
        self._tick(t)
        report = ConsolidationReport(subsystem=self.name)
        for component, slots in self._slots.items():
            if len(slots) < 2:
                continue
            merged: list[Slot] = []
            consumed: set[int] = set()
            for i, a in enumerate(slots):
                if i in consumed:
                    continue
                group = [a]
                for j in range(i + 1, len(slots)):
                    if j in consumed:
                        continue
                    sim = cosine(a.record.embedding, slots[j].record.embedding)
                    # O guarda de conflito é obrigatório: dois slots podem ser
                    # lexicalmente quase idênticos e ainda assim contraditórios
                    # ("3 nós" vs "2 nós"). Fundi-los apagaria a atualização.
                    if safe_to_merge(
                        a.record.content, slots[j].record.content, sim, self.chunk_threshold
                    ):
                        group.append(slots[j])
                        consumed.add(j)
                if len(group) > 1:
                    chunk = MemoryRecord(
                        content=" | ".join(g.record.content for g in group),
                        kind=MemoryKind.WORKING,
                        created_at=t,
                        modality=a.record.modality,
                        salience=max(g.record.salience for g in group),
                        importance=max(g.record.importance for g in group),
                    )
                    self.ensure_embedding(chunk)
                    chunk.links["chunk_of"] = tuple(g.record.id for g in group)
                    self.store.put(chunk)
                    merged.append(
                        Slot(
                            record=chunk,
                            component=component,
                            activation=max(g.activation for g in group),
                            entered_at=t,
                            goal_relevance=max(g.goal_relevance for g in group),
                        )
                    )
                    report.merged += len(group) - 1
                else:
                    merged.append(a)
            self._slots[component] = merged
        if report.merged:
            self.emit("chunk", merged=report.merged)
        return report

    def forget(self, now: float | None = None) -> ForgetReport:
        """Remove slots cuja ativação caiu abaixo do limiar de recuperação."""
        t = self.now(now)
        self._tick(t)
        threshold = 0.1
        evicted = 0
        for component, slots in self._slots.items():
            keep = []
            for s in slots:
                if s.activation < threshold:
                    self._displaced.append(s.record)
                    evicted += 1
                else:
                    keep.append(s)
            self._slots[component] = keep
        retained = len(self._all_slots())
        return ForgetReport(subsystem=self.name, evicted=evicted, retained=retained)

    def stats(self) -> dict[str, Any]:
        s = super().stats()
        s.update(
            {
                "size": len(self._all_slots()),
                "capacity_per_component": self.capacity,
                "load": {k: len(v) for k, v in self._slots.items()},
                "goal": self._goal,
                "goal_bias": self.goal_bias,
                "pending_displaced": len(self._displaced),
                "mean_activation": (
                    sum(x.activation for x in self._all_slots()) / len(self._all_slots())
                    if self._all_slots()
                    else 0.0
                ),
            }
        )
        return s
