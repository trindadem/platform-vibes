"""[EMERGENTE 1/11] Memória agêntica tipo SO — hierarquia com auto-edição.

MemGPT (Packer et al., 2023, arXiv:2310.08560), hoje Letta. A ideia: tratar a
janela de contexto como RAM e o armazenamento externo como disco, dando ao
*próprio agente* as chamadas de sistema para paginar informação entre os níveis.
A memória deixa de ser um índice que alguém consulta e passa a ser um recurso
que o agente administra.

Três níveis:

  * **core** — blocos sempre presentes no prompt (persona, usuário, tarefa).
    Capacidade rígida em caracteres. É a RAM.
  * **recall** — histórico recente de mensagens, pesquisável. É o swap.
  * **archival** — armazenamento frio ilimitado, pesquisável. É o disco.

As "chamadas de sistema" (`core_memory_append`, `core_memory_replace`,
`archival_memory_insert`, `archival_memory_search`, `conversation_search`) são
expostas como esquema de ferramentas em `tool_schema()`, prontas para registrar
no loop de function-calling do seu agente.

Pressão de memória: quando um bloco core estoura, o conteúdo mais antigo é
*despejado para archival com um sumário deixado no lugar* — nunca descartado.
O agente perde detalhe no prompt, não a informação.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Any

from ..core.base import (
    ConsolidationReport,
    ForgetReport,
    MemoryQuery,
    MemorySubsystem,
    Retrieved,
    WriteResult,
)
from ..core.record import MemoryRecord
from ..core.similarity import cosine, reciprocal_rank_fusion
from ..core.summarize import ExtractiveSummarizer, Summarizer
from ..core.types import MemoryForm, MemoryFunction, MemoryKind, WriteOp

__all__ = ["AgenticOSMemory", "CoreBlock", "Tier"]


class Tier(str):
    CORE = "core"
    RECALL = "recall"
    ARCHIVAL = "archival"


@dataclass(slots=True)
class CoreBlock:
    """Um bloco de memória central, sempre presente no prompt."""

    label: str
    value: str = ""
    limit: int = 800
    description: str = ""
    read_only: bool = False
    edits: int = 0

    @property
    def used(self) -> float:
        return len(self.value) / self.limit if self.limit else 0.0

    def render(self) -> str:
        return f'<{self.label}>\n{self.value}\n</{self.label}>'


class AgenticOSMemory(MemorySubsystem):
    """Hierarquia core/recall/archival com paginação dirigida pelo agente.

    Parameters
    ----------
    pressure_threshold:
        Fração de ocupação de um bloco core a partir da qual `memory_pressure()`
        avisa o agente. 0.75 dá folga para ele decidir o que compactar antes de
        a escrita falhar.
    """

    kind = MemoryKind.AGENTIC_OS
    emergent = True

    def __init__(
        self,
        *,
        blocks: dict[str, int] | None = None,
        recall_limit: int = 200,
        pressure_threshold: float = 0.75,
        summarizer: Summarizer | None = None,
        auto_evict: bool = True,
        **kw: Any,
    ) -> None:
        super().__init__(**kw)
        spec = blocks or {"persona": 800, "human": 800, "task": 600}
        self.blocks: dict[str, CoreBlock] = {
            label: CoreBlock(label=label, limit=limit) for label, limit in spec.items()
        }
        self.recall_limit = recall_limit
        self.pressure_threshold = pressure_threshold
        self.auto_evict = auto_evict
        self.summarizer = summarizer or ExtractiveSummarizer(self.embedder)
        self._recall: list[str] = []
        self._syscalls: list[dict[str, Any]] = []

    # ------------------------------------------------- chamadas de sistema
    def core_memory_append(self, label: str, content: str) -> WriteResult:
        """Anexa ao bloco core. Sob pressão, despeja o começo para archival."""
        block = self.blocks.get(label)
        if block is None:
            return WriteResult.noop(f"bloco_inexistente:{label}")
        if block.read_only:
            return WriteResult.noop(f"bloco_somente_leitura:{label}")
        self._log("core_memory_append", label=label, chars=len(content))
        candidate = (block.value + "\n" + content).strip() if block.value else content
        if len(candidate) > block.limit:
            if not self.auto_evict:
                return WriteResult.noop("estouro_de_bloco")
            candidate = self._relieve_pressure(block, candidate)
        block.value = candidate
        block.edits += 1
        self.emit("core_append", label=label, used=block.used)
        return WriteResult(op=WriteOp.ADD, record_id=f"core:{label}")

    def core_memory_replace(self, label: str, old: str, new: str) -> WriteResult:
        """Substitui um trecho exato do bloco — a operação de correção do MemGPT."""
        block = self.blocks.get(label)
        if block is None:
            return WriteResult.noop(f"bloco_inexistente:{label}")
        if block.read_only:
            return WriteResult.noop(f"bloco_somente_leitura:{label}")
        if old not in block.value:
            return WriteResult.noop("trecho_nao_encontrado")
        self._log("core_memory_replace", label=label)
        updated = block.value.replace(old, new, 1)
        if len(updated) > block.limit:
            updated = self._relieve_pressure(block, updated)
        block.value = updated
        block.edits += 1
        self.emit("core_replace", label=label, used=block.used)
        return WriteResult(op=WriteOp.UPDATE, record_id=f"core:{label}")

    def archival_memory_insert(self, content: str, **meta: Any) -> WriteResult:
        """Grava no armazenamento frio."""
        self._log("archival_memory_insert", chars=len(content))
        rec = self._store_record(content, Tier.ARCHIVAL, **meta)
        return WriteResult(op=WriteOp.ADD, record_id=rec.id)

    def archival_memory_search(self, query: str, *, top_k: int = 5) -> list[MemoryRecord]:
        self._log("archival_memory_search", query=query)
        return self._search(query, Tier.ARCHIVAL, top_k)

    def conversation_search(self, query: str, *, top_k: int = 5) -> list[MemoryRecord]:
        self._log("conversation_search", query=query)
        return self._search(query, Tier.RECALL, top_k)

    def tool_schema(self) -> list[dict[str, Any]]:
        """Esquema das chamadas de sistema, pronto para function-calling."""
        labels = sorted(self.blocks)
        return [
            {
                "name": "core_memory_append",
                "description": "Anexa conteúdo a um bloco de memória central sempre visível.",
                "parameters": {
                    "type": "object",
                    "properties": {
                        "label": {"type": "string", "enum": labels},
                        "content": {"type": "string"},
                    },
                    "required": ["label", "content"],
                },
            },
            {
                "name": "core_memory_replace",
                "description": "Substitui um trecho exato de um bloco central (para corrigir fatos).",
                "parameters": {
                    "type": "object",
                    "properties": {
                        "label": {"type": "string", "enum": labels},
                        "old": {"type": "string"},
                        "new": {"type": "string"},
                    },
                    "required": ["label", "old", "new"],
                },
            },
            {
                "name": "archival_memory_insert",
                "description": "Guarda informação no armazenamento de longo prazo.",
                "parameters": {
                    "type": "object",
                    "properties": {"content": {"type": "string"}},
                    "required": ["content"],
                },
            },
            {
                "name": "archival_memory_search",
                "description": "Busca semântica no armazenamento de longo prazo.",
                "parameters": {
                    "type": "object",
                    "properties": {
                        "query": {"type": "string"},
                        "top_k": {"type": "integer", "default": 5},
                    },
                    "required": ["query"],
                },
            },
            {
                "name": "conversation_search",
                "description": "Busca no histórico recente de conversa.",
                "parameters": {
                    "type": "object",
                    "properties": {
                        "query": {"type": "string"},
                        "top_k": {"type": "integer", "default": 5},
                    },
                    "required": ["query"],
                },
            },
        ]

    # --------------------------------------------------------- interno
    def _log(self, name: str, **kw: Any) -> None:
        self._syscalls.append({"call": name, "at": self.now(), **kw})

    def _store_record(self, content: str, tier: str, **meta: Any) -> MemoryRecord:
        now = self.now()
        rec = MemoryRecord(
            content=content,
            kind=MemoryKind.AGENTIC_OS,
            created_at=now,
            updated_at=now,
            form=MemoryForm.TOKEN,
            function=MemoryFunction.FACTUAL,
            payload={"tier": tier, **meta},
        )
        self.ensure_embedding(rec)
        self.store.put(rec)
        if tier == Tier.RECALL:
            self._recall.append(rec.id)
            if len(self._recall) > self.recall_limit:
                overflow = self._recall[: len(self._recall) - self.recall_limit]
                del self._recall[: len(overflow)]
                for rid in overflow:
                    old = self.store.get(rid)
                    if old is not None:
                        old.payload["tier"] = Tier.ARCHIVAL
                        self.store.put(old)
                self.emit("page_out", count=len(overflow), to=Tier.ARCHIVAL)
        return rec

    def _search(self, query: str, tier: str, top_k: int) -> list[MemoryRecord]:
        vec = self.embedder.encode(query)
        in_tier = lambda r: r.payload.get("tier") == tier  # noqa: E731
        dense = [rid for rid, _ in self.store.search_dense(vec, top_k * 4, where=in_tier)]
        sparse = [rid for rid, _ in self.store.search_sparse(query, top_k * 4, where=in_tier)]
        fused = reciprocal_rank_fusion([dense, sparse], k=self.weights.rrf_k)
        out = [r for r in self.store.get_many([rid for rid, _ in fused]) if r is not None]
        now = self.now()
        for r in out[:top_k]:
            r.decay.touch(now)
            self.store.put(r)
        return out[:top_k]

    def _relieve_pressure(self, block: CoreBlock, candidate: str) -> str:
        """Despeja o início do bloco para archival, deixando um sumário no lugar.

        A informação não é perdida: o texto integral vai para o disco frio e o
        bloco central fica com um ponteiro sumarizado. É a diferença entre
        paginação e vazamento.
        """
        marker = "[resumo do histórico paginado:"
        # Remove marcadores anteriores ANTES de resumir. Sem isso, cada despejo
        # resume o resumo do despejo anterior e o bloco vira uma pilha de
        # "[resumo de [resumo de [resumo ..." — a deriva de sumarização em ação.
        lines = [ln for ln in candidate.split("\n") if not ln.startswith(marker)]
        previous = [ln for ln in candidate.split("\n") if ln.startswith(marker)]
        keep: list[str] = []
        size = 0
        for line in reversed(lines):
            if size + len(line) + 1 > block.limit * 0.6:
                break
            keep.append(line)
            size += len(line) + 1
        keep.reverse()
        evicted = lines[: len(lines) - len(keep)]
        if evicted or previous:
            body = "\n".join(evicted)
            if body:
                self.archival_memory_insert(body, evicted_from=block.label)
            # O sumário é sempre recomputado a partir do TEXTO ORIGINAL de tudo
            # que já foi paginado deste bloco — nunca a partir do sumário antigo.
            full = [
                r.content
                for r in self.own()
                if r.payload.get("evicted_from") == block.label
            ]
            digest = self.summarizer.summarize(full, max_chars=int(block.limit * 0.25))
            keep.insert(0, f"{marker} {digest}]")
            self.emit(
                "memory_pressure", label=block.label, evicted_chars=len(body), sources=len(full)
            )
        return "\n".join(keep)[: block.limit]

    # ------------------------------------------------------ API padrão
    def write(self, record: MemoryRecord) -> WriteResult:
        """Escreve no tier indicado por `payload['tier']` (default: recall)."""
        tier = record.payload.get("tier", Tier.RECALL)
        if tier == Tier.CORE:
            return self.core_memory_append(record.payload.get("label", "task"), record.content)
        rec = self._store_record(record.content, tier)
        return WriteResult(op=WriteOp.ADD, record_id=rec.id)

    def read(self, query: MemoryQuery) -> list[Retrieved]:
        """Core é sempre devolvido (está no prompt); recall e archival, por busca."""
        now = self.now(query.as_of)
        query.with_vector(self.embedder)
        out: list[Retrieved] = []
        for label, block in self.blocks.items():
            if not block.value:
                continue
            rec = MemoryRecord(
                content=block.render(),
                kind=MemoryKind.AGENTIC_OS,
                created_at=now,
                importance=1.0,
                payload={"tier": Tier.CORE, "label": label},
            )
            out.append(
                Retrieved(record=rec, score=10.0, subsystem=self.name,
                          rationale={"tier": 0.0, "always_in_context": 1.0, "used": block.used})
            )
        for tier, weight in ((Tier.RECALL, 1.0), (Tier.ARCHIVAL, 0.8)):
            for rec in self._search(query.text, tier, query.top_k):
                if not self.visible(rec, query, now):
                    continue
                rel = cosine(query.vector, rec.embedding) if query.vector else 0.0
                out.append(
                    Retrieved(record=rec, score=weight * rel, subsystem=self.name,
                              rationale={"relevance": rel, "tier_weight": weight})
                )
        out.sort(key=lambda r: -r.score)
        return out[: query.top_k + len(self.blocks)]

    def render_core(self) -> str:
        return "\n".join(b.render() for b in self.blocks.values() if b.value)

    def memory_pressure(self) -> dict[str, float]:
        """Ocupação por bloco — o sinal que o agente usa para decidir compactar."""
        return {
            label: b.used for label, b in self.blocks.items() if b.used >= self.pressure_threshold
        }

    def syscalls(self) -> list[dict[str, Any]]:
        return list(self._syscalls)

    def consolidate(self, now: float | None = None) -> ConsolidationReport:
        """Move recall antigo para archival, deixando o swap enxuto."""
        report = ConsolidationReport(subsystem=self.name)
        keep = self._recall[-self.recall_limit // 2 :]
        moved = [r for r in self._recall if r not in set(keep)]
        for rid in moved:
            rec = self.store.get(rid)
            if rec is not None:
                rec.payload["tier"] = Tier.ARCHIVAL
                self.store.put(rec)
                report.promoted += 1
        self._recall = keep
        return report

    def forget(self, now: float | None = None) -> ForgetReport:
        return ForgetReport(subsystem=self.name, retained=self.size())

    def stats(self) -> dict[str, Any]:
        s = super().stats()
        tiers: dict[str, int] = {}
        for r in self.own():
            t = r.payload.get("tier", "?")
            tiers[t] = tiers.get(t, 0) + 1
        s.update(
            {
                "core_blocks": {k: round(b.used, 3) for k, b in self.blocks.items()},
                "tiers": tiers,
                "syscalls": len(self._syscalls),
                "pressure": self.memory_pressure(),
            }
        )
        return s
