"""[TRADICIONAL 3/10] Buffer de conversa — janela deslizante.

A linha de base de toda memória de agente e ainda a única com recall perfeito
dentro da sua janela. Duas políticas de corte:

  * por turnos (`max_turns`)  — a `ConversationBufferWindowMemory` do LangChain
  * por tokens (`max_tokens`) — o que realmente importa quando o prompt é caro

Nada aqui é sofisticado, e é esse o ponto: os benchmarks de 2025-2026
(LongMemEval, MemoryAgentBench) mostram repetidamente que sistemas elaborados
perdem para a janela simples em horizontes curtos. O buffer é a referência que
os subsistemas sofisticados precisam superar — e o `MemoryOrchestrator` o
mantém no fan-out por isso, não por legado.
"""

from __future__ import annotations

from collections import deque
from typing import Any

from ..core.base import ForgetReport, MemoryQuery, MemorySubsystem, Retrieved, WriteResult
from ..core.budget import estimate_tokens
from ..core.record import MemoryRecord
from ..core.types import MemoryForm, MemoryFunction, MemoryKind, WriteOp

__all__ = ["ConversationBuffer"]


class ConversationBuffer(MemorySubsystem):
    """Janela deslizante sobre os turnos recentes.

    Itens que saem da janela ficam disponíveis em `drain_evicted()` — é o gancho
    que alimenta a sumarização e a codificação episódica sem perder nada.
    """

    kind = MemoryKind.BUFFER

    def __init__(
        self, *, max_turns: int = 20, max_tokens: int | None = 4000, **kw: Any
    ) -> None:
        super().__init__(**kw)
        self.max_turns = max_turns
        self.max_tokens = max_tokens
        self._window: deque[MemoryRecord] = deque()
        self._tokens = 0
        self._evicted: list[MemoryRecord] = []
        self._rebuild_window()

    def _rebuild_window(self) -> None:
        """Num arquivo persistente (o `memory.db` de um perfil), a janela são os
        últimos turnos gravados — senão cada execução começa amnésica e o que a
        anterior gravou fica no arquivo sem que ninguém o leia."""
        recs = sorted(self.own(), key=lambda r: (r.created_at, r.payload.get("turn", 0)))
        keep: deque[MemoryRecord] = deque()
        tokens = 0
        for rec in reversed(recs):
            cost = self._cost(rec)
            if len(keep) >= self.max_turns or (self.max_tokens is not None and tokens + cost > self.max_tokens and keep):
                break
            keep.appendleft(rec)
            tokens += cost
        # o que ficou fora da janela já foi evicto por alguma execução anterior: não volta
        for rec in recs[: len(recs) - len(keep)]:
            self.store.delete(rec.id)
        self._window, self._tokens = keep, tokens

    def _cost(self, record: MemoryRecord) -> int:
        return int(record.payload.get("tokens") or estimate_tokens(record.content))

    def write(self, record: MemoryRecord) -> WriteResult:
        now = self.now()
        record.kind = MemoryKind.BUFFER
        record.form = MemoryForm.TOKEN
        record.function = MemoryFunction.WORKING
        if record.created_at == 0.0:
            record.created_at = now
            record.updated_at = now
            record.decay.last_access = now
        record.payload.setdefault("tokens", estimate_tokens(record.content))
        record.payload.setdefault("turn", len(self._window))
        self.ensure_embedding(record)
        self._window.append(record)
        self._tokens += self._cost(record)
        self.store.put(record)

        evicted: list[str] = []
        while self._window and (
            len(self._window) > self.max_turns
            or (self.max_tokens is not None and self._tokens > self.max_tokens)
        ):
            old = self._window.popleft()
            self._tokens -= self._cost(old)
            self._evicted.append(old)
            evicted.append(old.id)
            self.emit("evict", old.id, reason="window_slide")
        return WriteResult(op=WriteOp.ADD, record_id=record.id, superseded=tuple(evicted))

    def read(self, query: MemoryQuery) -> list[Retrieved]:
        """Retorna os turnos mais recentes. Recência é o único sinal — por design."""
        now = self.now(query.as_of)
        items = [r for r in self._window if self.visible(r, query, now)]
        out: list[Retrieved] = []
        n = len(items)
        for i, rec in enumerate(items):
            recency = (i + 1) / n if n else 0.0
            out.append(
                Retrieved(
                    record=rec,
                    score=recency,
                    subsystem=self.name,
                    rationale={"recency": recency, "turn": float(rec.payload.get("turn", i))},
                )
            )
        out.sort(key=lambda r: -r.score)
        return out[: query.top_k]

    def transcript(self, *, separator: str = "\n") -> str:
        return separator.join(r.content for r in self._window)

    def drain_evicted(self) -> list[MemoryRecord]:
        out, self._evicted = self._evicted, []
        return out

    def forget(self, now: float | None = None) -> ForgetReport:
        """O que saiu da janela e ninguém drenou sai também do arquivo."""
        n = len(self._evicted)
        freed = sum(len(r.content) for r in self._evicted)
        for rec in self._evicted:
            self.store.delete(rec.id)
        self._evicted.clear()
        return ForgetReport(
            subsystem=self.name, evicted=n, retained=len(self._window), freed_chars=freed
        )

    def stats(self) -> dict[str, Any]:
        s = super().stats()
        s.update(
            {
                "size": len(self._window),
                "tokens": self._tokens,
                "max_turns": self.max_turns,
                "max_tokens": self.max_tokens,
                "pending_evicted": len(self._evicted),
            }
        )
        return s
