"""[TRADICIONAL 7/10] Memória de sumário — compressão recursiva e hierárquica.

Duas estratégias, ambas clássicas e ambas com o mesmo risco:

* **Sumário rolante** — condensa periodicamente a conversa
  (`ConversationSummaryMemory`, LangChain 2022). Barato, mas cada passe
  recomprime o sumário anterior: detalhes de baixa frequência desaparecem por
  *deriva de sumarização*.
* **Árvore hierárquica** — RAPTOR (Sarthi et al., 2024, arXiv:2401.18059):
  agrupa e sumariza recursivamente, produzindo uma árvore consultável em
  múltiplas granularidades. A recuperação pode ir a uma folha (detalhe) ou a um
  nó interno (visão geral).

Mitigação de deriva implementada aqui: o sumário nunca substitui as folhas.
Cada nó guarda `source_ids`, então qualquer sumário é expansível de volta ao
texto que o originou — o agente pode "dar zoom" quando a resposta exige detalhe.
"""

from __future__ import annotations

from collections.abc import Sequence
from dataclasses import dataclass, field
from typing import Any

from ..core.base import (
    ConsolidationReport,
    ForgetReport,
    MemoryQuery,
    MemorySubsystem,
    Retrieved,
    WriteResult,
)
from ..core.record import MemoryRecord
from ..core.similarity import cosine
from ..core.summarize import ExtractiveSummarizer, Summarizer
from ..core.types import MemoryForm, MemoryFunction, MemoryKind, WriteOp

__all__ = ["SummaryMemory", "SummaryNode"]


@dataclass(slots=True)
class SummaryNode:
    id: str
    level: int
    source_ids: tuple[str, ...] = ()
    children: tuple[str, ...] = ()
    covered_leaves: int = 0
    span: tuple[float, float] = (0.0, 0.0)
    metadata: dict[str, Any] = field(default_factory=dict)


class SummaryMemory(MemorySubsystem):
    """Árvore de sumários sobre um fluxo de folhas.

    Parameters
    ----------
    group_size:
        Folhas por nó de nível 1. Ramificação da árvore nos níveis acima.
    max_chars:
        Orçamento de caracteres por sumário.
    keep_leaves:
        Se True (default), as folhas continuam armazenadas e recuperáveis. É a
        defesa contra a deriva: o sumário é um atalho, não uma substituição.
    """

    kind = MemoryKind.SUMMARY

    def __init__(
        self,
        *,
        group_size: int = 5,
        max_chars: int = 480,
        max_levels: int = 4,
        keep_leaves: bool = True,
        summarizer: Summarizer | None = None,
        **kw: Any,
    ) -> None:
        super().__init__(**kw)
        self.group_size = group_size
        self.max_chars = max_chars
        self.max_levels = max_levels
        self.keep_leaves = keep_leaves
        self.summarizer = summarizer or ExtractiveSummarizer(self.embedder)
        self._leaves: list[str] = []
        self._nodes: dict[str, SummaryNode] = {}
        self._pending: list[str] = []
        self._rolling_id: str = ""

    # ------------------------------------------------------------- escrita
    def write(self, record: MemoryRecord) -> WriteResult:
        """Adiciona uma folha; fecha um nó de nível 1 a cada `group_size`."""
        now = self.now()
        if record.created_at == 0.0:
            record.created_at = now
            record.updated_at = now
            record.decay.last_access = now
        record.payload.setdefault("summary_level", 0)
        self.ensure_embedding(record)
        self.store.put(record)
        self._leaves.append(record.id)
        self._pending.append(record.id)
        if len(self._pending) >= self.group_size:
            self._build_node(self._pending, level=1)
            self._pending = []
        return WriteResult(op=WriteOp.ADD, record_id=record.id)

    def _build_node(self, source_ids: Sequence[str], *, level: int) -> MemoryRecord | None:
        recs = [r for r in self.store.get_many(list(source_ids)) if r is not None]
        if not recs:
            return None
        text = self.summarizer.summarize([r.content for r in recs], max_chars=self.max_chars)
        if not text:
            return None
        node_rec = MemoryRecord(
            content=text,
            kind=MemoryKind.SUMMARY,
            created_at=self.now(),
            form=MemoryForm.TOKEN,
            function=MemoryFunction.FACTUAL,
            importance=min(1.0, 0.4 + 0.1 * level),
            confidence=max(0.3, 1.0 - 0.15 * level),  # confiança cai a cada passe
            payload={"summary_level": level, "covered": len(recs)},
        )
        node_rec.links["summarizes"] = tuple(r.id for r in recs)
        self.ensure_embedding(node_rec)
        self.store.put(node_rec)
        covered = sum(
            self._nodes[r.id].covered_leaves if r.id in self._nodes else 1 for r in recs
        )
        self._nodes[node_rec.id] = SummaryNode(
            id=node_rec.id,
            level=level,
            source_ids=tuple(r.id for r in recs),
            children=tuple(r.id for r in recs if r.id in self._nodes),
            covered_leaves=covered,
            span=(min(r.created_at for r in recs), max(r.created_at for r in recs)),
        )
        self.emit("summarize", node_rec.id, level=level, covered=covered)
        return node_rec

    # ------------------------------------------------------------- leitura
    def read(self, query: MemoryQuery) -> list[Retrieved]:
        now = self.now(query.as_of)
        query.with_vector(self.embedder)
        wanted_level = query.filters.get("level")
        out: list[Retrieved] = []
        for rec in self.candidates(query, now):
            level = int(rec.payload.get("summary_level", 0))
            if level == 0 and not self.keep_leaves:
                continue
            if wanted_level is not None and level != wanted_level:
                continue
            rel = cosine(query.vector, rec.embedding) if query.vector else 0.0
            # Nós mais altos cobrem mais, mas valem menos por unidade de detalhe.
            breadth = self._nodes[rec.id].covered_leaves if rec.id in self._nodes else 1
            score = rel * (1.0 + 0.08 * level) * rec.confidence
            out.append(
                Retrieved(
                    record=rec,
                    score=score,
                    subsystem=self.name,
                    rationale={
                        "relevance": rel,
                        "level": float(level),
                        "covers_leaves": float(breadth),
                        "confidence": rec.confidence,
                    },
                )
            )
        out.sort(key=lambda r: -r.score)
        return out[: query.top_k]

    def expand(self, node_id: str, *, depth: int = 1) -> list[MemoryRecord]:
        """Desce do sumário para as fontes — a defesa contra deriva.

        `depth=-1` desce até as folhas.
        """
        node = self._nodes.get(node_id)
        if node is None:
            return []
        out: list[MemoryRecord] = []
        for sid in node.source_ids:
            rec = self.store.get(sid)
            if rec is None:
                continue
            if sid in self._nodes and depth != 0:
                out.extend(self.expand(sid, depth=depth - 1 if depth > 0 else -1))
            else:
                out.append(rec)
        return out

    def rolling(self) -> str:
        """Sumário rolante único de tudo que foi escrito."""
        rec = self.store.get(self._rolling_id) if self._rolling_id else None
        return rec.content if rec is not None else ""

    # -------------------------------------------------------- consolidação
    def consolidate(self, now: float | None = None) -> ConsolidationReport:
        """Fecha o grupo pendente e sobe a árvore um nível por chamada."""
        report = ConsolidationReport(subsystem=self.name)
        if self._pending:
            if self._build_node(self._pending, level=1) is not None:
                report.abstracted += 1
            self._pending = []

        for level in range(1, self.max_levels):
            nodes = sorted(
                (n for n in self._nodes.values() if n.level == level), key=lambda n: n.span[0]
            )
            parents = {c for n in self._nodes.values() for c in n.children}
            orphans = [n for n in nodes if n.id not in parents]
            if len(orphans) < 2:
                continue
            for i in range(0, len(orphans), self.group_size):
                group = orphans[i : i + self.group_size]
                if len(group) < 2:
                    continue
                if self._build_node([n.id for n in group], level=level + 1) is not None:
                    report.abstracted += 1

        # sumário rolante de nível máximo
        tops = [n for n in self._nodes.values() if n.level == max((x.level for x in self._nodes.values()), default=0)]
        if tops:
            rec = self._build_node([n.id for n in tops], level=self.max_levels)
            if rec is not None:
                self._rolling_id = rec.id
        return report

    def forget(self, now: float | None = None) -> ForgetReport:
        """Descarta folhas já cobertas por sumário, se `keep_leaves` for False."""
        if self.keep_leaves:
            return ForgetReport(subsystem=self.name, retained=self.size())
        covered = {sid for n in self._nodes.values() for sid in n.source_ids}
        evicted = freed = 0
        for lid in list(self._leaves):
            if lid in covered:
                rec = self.store.get(lid)
                if rec is not None:
                    freed += len(rec.content)
                    self.store.delete(lid)
                    evicted += 1
                self._leaves.remove(lid)
        return ForgetReport(
            subsystem=self.name, evicted=evicted, retained=self.size(), freed_chars=freed
        )

    def stats(self) -> dict[str, Any]:
        s = super().stats()
        levels: dict[int, int] = {}
        for n in self._nodes.values():
            levels[n.level] = levels.get(n.level, 0) + 1
        s.update(
            {
                "leaves": len(self._leaves),
                "nodes": len(self._nodes),
                "levels": levels,
                "pending": len(self._pending),
                "compression_ratio": (
                    sum(len(leaf.content) for leaf in (self.store.get(i) for i in self._leaves) if leaf is not None)
                    / max(sum(len(n_.content) for n_ in (self.store.get(k) for k in self._nodes) if n_ is not None), 1)
                    if self._nodes
                    else 0.0
                ),
            }
        )
        return s
