"""[TRADICIONAL 8/10] Memória vetorial — RAG denso sobre o acervo.

A linha de base de toda memória externa desde Lewis et al. (2020, RAG). O que
esta implementação acrescenta ao "top-k por cosseno":

* **Chunking com sobreposição** consciente de fronteira de sentença — cortar no
  meio de uma frase destrói a recuperação do fato que atravessa o corte.
* **Recuperação híbrida** densa + BM25 fundida por RRF (Cormack et al., 2009).
  Denso pega paráfrase; esparso pega identificadores exatos (nomes de serviço,
  SKUs, hashes) que o embedding dilui. Nenhum dos dois sozinho basta.
* **MMR** para diversidade, evitando encher o contexto de k paráfrases do mesmo
  trecho.
* **Reranker plugável** (two-stage retrieval): recuperação barata e ampla,
  reordenação cara e estreita — o padrão de produção descrito no survey
  arXiv:2603.07670, §"Read path".
"""

from __future__ import annotations

from collections.abc import Callable, Sequence
from typing import Any

from ..core.base import ForgetReport, MemoryQuery, MemorySubsystem, Retrieved, WriteResult
from ..core.record import MemoryRecord
from ..core.similarity import cosine, mmr, reciprocal_rank_fusion
from ..core.summarize import split_sentences
from ..core.types import MemoryForm, MemoryFunction, MemoryKind, RetrievalStrategy, WriteOp

__all__ = ["VectorMemory", "chunk_text"]

Reranker = Callable[[str, Sequence[MemoryRecord]], Sequence[float]]


def chunk_text(text: str, *, max_chars: int = 600, overlap_sentences: int = 1) -> list[str]:
    """Divide em janelas que respeitam fronteiras de sentença, com sobreposição."""
    sentences = split_sentences(text)
    if not sentences:
        return []
    chunks: list[str] = []
    cur: list[str] = []
    size = 0
    for sent in sentences:
        if cur and size + len(sent) > max_chars:
            chunks.append(" ".join(cur))
            cur = cur[-overlap_sentences:] if overlap_sentences > 0 else []
            size = sum(len(s) for s in cur)
        cur.append(sent)
        size += len(sent) + 1
    if cur:
        chunks.append(" ".join(cur))
    return chunks


class VectorMemory(MemorySubsystem):
    """Armazém vetorial com recuperação híbrida, MMR e reranker opcional."""

    kind = MemoryKind.VECTOR

    def __init__(
        self,
        *,
        chunk_chars: int = 600,
        overlap_sentences: int = 1,
        auto_chunk: bool = True,
        strategy: RetrievalStrategy = RetrievalStrategy.HYBRID,
        reranker: Reranker | None = None,
        rerank_pool: int = 30,
        **kw: Any,
    ) -> None:
        super().__init__(**kw)
        self.chunk_chars = chunk_chars
        self.overlap_sentences = overlap_sentences
        self.auto_chunk = auto_chunk
        self.strategy = strategy
        self.reranker = reranker
        self.rerank_pool = rerank_pool

    def write(self, record: MemoryRecord) -> WriteResult:
        now = self.now()
        record.kind = MemoryKind.VECTOR
        record.form = MemoryForm.LATENT
        record.function = MemoryFunction.FACTUAL
        if record.created_at == 0.0:
            record.created_at = now
            record.updated_at = now
            record.decay.last_access = now

        if not self.auto_chunk or len(record.content) <= self.chunk_chars:
            self.ensure_embedding(record)
            self.store.put(record)
            return WriteResult(op=WriteOp.ADD, record_id=record.id)

        pieces = chunk_text(
            record.content, max_chars=self.chunk_chars, overlap_sentences=self.overlap_sentences
        )
        ids: list[str] = []
        for i, piece in enumerate(pieces):
            child = record.copy(
                content=piece,
                id=f"{record.id}-c{i:03d}",
                embedding=None,
                fingerprint="",
                links={**record.links, "chunk_of": (record.id,)},
                payload={**record.payload, "chunk_index": i, "chunk_total": len(pieces)},
            )
            child.__post_init__()
            self.ensure_embedding(child)
            self.store.put(child)
            ids.append(child.id)
        self.emit("chunk", record.id, pieces=len(ids))
        return WriteResult(op=WriteOp.ADD, record_id=record.id, superseded=tuple(ids))

    def read(self, query: MemoryQuery) -> list[Retrieved]:
        now = self.now(query.as_of)
        query.with_vector(self.embedder)
        pool_size = max(query.top_k * 4, self.rerank_pool)
        visible = {r.id for r in self.candidates(query, now)}
        if not visible:
            return []

        dense = [rid for rid, _ in self.store.search_dense(query.vector or (), pool_size) if rid in visible]
        sparse = (
            [rid for rid, _ in self.store.search_sparse(query.text, pool_size) if rid in visible]
            if query.text
            else []
        )
        if self.strategy is RetrievalStrategy.DENSE or not sparse:
            order = dense
        elif self.strategy is RetrievalStrategy.SPARSE:
            order = sparse
        else:
            order = [rid for rid, _ in reciprocal_rank_fusion([dense, sparse], k=self.weights.rrf_k)]

        recs = [r for r in self.store.get_many(order) if r is not None]
        if not recs:
            return []

        if self.reranker is not None:
            scores = list(self.reranker(query.text, recs[: self.rerank_pool]))
            paired = sorted(zip(recs[: self.rerank_pool], scores, strict=True), key=lambda t: -t[1])
            recs = [r for r, _ in paired] + recs[self.rerank_pool :]

        rel = {r.id: cosine(query.vector, r.embedding) if query.vector else 0.0 for r in recs}
        if query.diversify and query.vector is not None:
            keep = set(
                mmr(
                    query.vector,
                    [(r.id, r.embedding or (), rel[r.id]) for r in recs],
                    lambda_=self.weights.mmr_lambda,
                    top_k=query.top_k,
                )
            )
            recs = [r for r in recs if r.id in keep]

        out = [
            Retrieved(
                record=r,
                score=rel[r.id],
                subsystem=self.name,
                rationale={"relevance": rel[r.id], "strategy": self.strategy.value},
            )
            for r in recs
        ]
        out.sort(key=lambda x: -x.score)
        top = out[: query.top_k]
        self.touch_all([t.record for t in top], now)
        return top

    def forget(self, now: float | None = None) -> ForgetReport:
        t = self.now(now)
        evicted = freed = 0
        for rec in list(self.store.scan(kind=MemoryKind.VECTOR)):
            if rec.retention(t) < 0.01 and rec.decay.access_count == 0 and rec.importance < 0.4:
                freed += len(rec.content)
                self.store.delete(rec.id)
                evicted += 1
        return ForgetReport(
            subsystem=self.name, evicted=evicted, retained=self.size(), freed_chars=freed
        )

    def stats(self) -> dict[str, Any]:
        s = super().stats()
        chunks = sum(1 for r in self.own() if "chunk_of" in r.links)
        s.update({"chunks": chunks, "strategy": self.strategy.value, "reranked": self.reranker is not None})
        return s
