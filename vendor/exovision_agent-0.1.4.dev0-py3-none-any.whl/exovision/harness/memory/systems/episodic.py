"""[TRADICIONAL 4/10] Memória episódica — traços de eventos com contexto.

Memória episódica é o "o quê / onde / quando" de Tulving (1972, 1985): o
registro de experiências específicas, indexadas por contexto temporal e
recuperáveis por viagem mental no tempo.

Duas mecânicas fazem esta implementação ir além de "carimbar data em chunks":

1. **Segmentação por surpresa.** Fluxos de experiência não vêm pré-cortados em
   eventos. Seguimos o EM-LLM (Fountas et al., 2025, arXiv:2407.09450): a
   surpresa bayesiana marca fronteiras candidatas e um refinamento
   grafo-teórico ajusta o corte para maximizar a modularidade (ou minimizar a
   condutância) da matriz de similaridade intra-janela. Isso reproduz a
   segmentação humana de eventos (Zacks et al., 2007, *event segmentation
   theory*) melhor do que cortes de tamanho fixo.

2. **Recuperação por contiguidade temporal.** Recuperar um evento torna seus
   vizinhos temporais mais acessíveis — o efeito de contiguidade do modelo TCM
   de Howard & Kahana (2002), assimétrico para frente. É o que permite
   responder "o que aconteceu logo depois daquilo?", pergunta que a recuperação
   puramente por similaridade erra sistematicamente.
"""

from __future__ import annotations

import math
from collections.abc import Sequence
from dataclasses import dataclass, field
from typing import Any

from ..core.base import (
    ConsolidationReport,
    ForgetReport,
    MemoryQuery,
    MemorySubsystem,
    Retrieved,
    WriteResult,
)
from ..core.record import MemoryRecord
from ..core.scoring import composite_score
from ..core.similarity import cosine
from ..core.types import MemoryForm, MemoryFunction, MemoryKind, WriteOp

__all__ = ["Episode", "EpisodicMemory"]


@dataclass(slots=True)
class Episode:
    """Um evento coerente: uma sequência contígua de traços."""

    id: str
    member_ids: list[str] = field(default_factory=list)
    start: float = 0.0
    end: float = 0.0
    centroid: tuple[float, ...] | None = None
    boundary_surprise: float = 0.0
    summary: str = ""

    def __len__(self) -> int:
        return len(self.member_ids)


def _modularity(sim: list[list[float]], cut: int) -> float:
    """Modularidade de dois blocos (Newman, 2006) sobre a matriz de similaridade.

    Q = sum_c [ (w_in_c / W) - (w_tot_c / (2W))^2 ]
    """
    n = len(sim)
    if cut <= 0 or cut >= n:
        return -1.0
    total = sum(sim[i][j] for i in range(n) for j in range(n) if i != j)
    if total <= 0:
        return -1.0
    q = 0.0
    for lo, hi in ((0, cut), (cut, n)):
        w_in = sum(sim[i][j] for i in range(lo, hi) for j in range(lo, hi) if i != j)
        w_tot = sum(sim[i][j] for i in range(lo, hi) for j in range(n) if i != j)
        q += (w_in / total) - (w_tot / total) ** 2
    return q


def _conductance(sim: list[list[float]], cut: int) -> float:
    """Condutância do corte: peso que atravessa a fronteira / min(vol). Menor é melhor."""
    n = len(sim)
    if cut <= 0 or cut >= n:
        return math.inf
    cross = sum(sim[i][j] for i in range(cut) for j in range(cut, n))
    vol_a = sum(sim[i][j] for i in range(cut) for j in range(n) if i != j)
    vol_b = sum(sim[i][j] for i in range(cut, n) for j in range(n) if i != j)
    denom = min(vol_a, vol_b)
    return cross / denom if denom > 0 else math.inf


class EpisodicMemory(MemorySubsystem):
    """Traços episódicos agrupados em eventos, recuperáveis por contiguidade.

    Parameters
    ----------
    surprise_threshold:
        Em desvios-padrão acima da média móvel de surpresa. gamma=1.0 segue o
        limiar adaptativo mu + gamma*sigma do EM-LLM.
    refinement:
        ``"modularity"`` | ``"conductance"`` | ``"none"``.
    contiguity_weight:
        Peso do termo de contiguidade temporal na recuperação. 0 desliga.
    forward_asymmetry:
        Contiguidade para frente é ~2x mais forte que para trás em humanos
        (Kahana, 1996). 2.0 reproduz essa assimetria.
    """

    kind = MemoryKind.EPISODIC

    def __init__(
        self,
        *,
        surprise_threshold: float = 1.0,
        min_event_size: int = 2,
        max_event_size: int = 24,
        refinement: str = "modularity",
        contiguity_weight: float = 0.25,
        forward_asymmetry: float = 2.0,
        **kw: Any,
    ) -> None:
        super().__init__(**kw)
        self.surprise_threshold = surprise_threshold
        self.min_event_size = min_event_size
        self.max_event_size = max_event_size
        self.refinement = refinement
        self.contiguity_weight = contiguity_weight
        self.forward_asymmetry = forward_asymmetry

        self._sequence: list[str] = []  # ordem temporal de ingestão
        self._position: dict[str, int] = {}
        self._episodes: list[Episode] = []
        self._episode_of: dict[str, str] = {}
        self._pending: list[str] = []  # traços ainda não fechados em evento
        self._surprises: list[float] = []
        self._mu = 0.0
        self._m2 = 0.0  # Welford, para desvio-padrão online
        self._n = 0

    # --------------------------------------------------------- surpresa
    def _update_surprise_stats(self, s: float) -> tuple[float, float]:
        """Média/desvio online (Welford, 1962) — sem guardar o histórico todo."""
        self._n += 1
        delta = s - self._mu
        self._mu += delta / self._n
        self._m2 += delta * (s - self._mu)
        var = self._m2 / self._n if self._n > 1 else 0.0
        return self._mu, math.sqrt(max(var, 0.0))

    def _surprise(self, record: MemoryRecord) -> float:
        """Proxy de surpresa bayesiana: dissimilaridade com o traço anterior.

        Com um LLM disponível, troque por -log p(x_t | x_<t) (a definição do
        EM-LLM); a interface de fronteira é a mesma.
        """
        if not self._sequence:
            return 1.0
        prev = self.store.get(self._sequence[-1])
        if prev is None or prev.embedding is None or record.embedding is None:
            return 1.0
        return 1.0 - cosine(record.embedding, prev.embedding)

    # ------------------------------------------------------------ escrita
    def write(self, record: MemoryRecord) -> WriteResult:
        now = self.now()
        record.kind = MemoryKind.EPISODIC
        record.form = MemoryForm.TOKEN
        record.function = MemoryFunction.EXPERIENTIAL
        if record.created_at == 0.0:
            record.created_at = now
            record.updated_at = now
            record.decay.last_access = now
        if record.valid_from is None:
            record.valid_from = record.created_at
        self.ensure_embedding(record)

        surprise = self._surprise(record)
        record.salience = max(record.salience, surprise)
        mu, sigma = self._update_surprise_stats(surprise)
        self._surprises.append(surprise)

        self.store.put(record)
        self._position[record.id] = len(self._sequence)
        self._sequence.append(record.id)
        self._pending.append(record.id)

        # Fronteira de evento: surpresa acima do limiar adaptativo mu + gamma*sigma
        is_boundary = surprise > (mu + self.surprise_threshold * sigma) and sigma > 1e-9
        if (is_boundary and len(self._pending) >= self.min_event_size) or len(
            self._pending
        ) >= self.max_event_size:
            self._close_event(surprise)

        self.emit("encode", record.id, surprise=surprise, boundary=is_boundary)
        return WriteResult(op=WriteOp.ADD, record_id=record.id)

    def _close_event(self, boundary_surprise: float) -> Episode | None:
        if len(self._pending) < self.min_event_size:
            return None
        members = self._pending
        if self.refinement != "none" and len(members) >= 4:
            members, leftover = self._refine_boundary(members)
            self._pending = leftover
        else:
            self._pending = []

        recs = [r for r in self.store.get_many(members) if r is not None]
        if not recs:
            return None
        ep = Episode(
            id=f"ep-{len(self._episodes):06d}",
            member_ids=[r.id for r in recs],
            start=min(r.created_at for r in recs),
            end=max(r.created_at for r in recs),
            centroid=self._centroid([r.embedding for r in recs]),
            boundary_surprise=boundary_surprise,
            summary=" ".join(r.content for r in recs)[:280],
        )
        self._episodes.append(ep)
        for rid in ep.member_ids:
            self._episode_of[rid] = ep.id
        self.emit("segment", ep.id, size=len(ep), surprise=boundary_surprise)
        return ep

    def _refine_boundary(self, members: list[str]) -> tuple[list[str], list[str]]:
        """Refinamento grafo-teórico do corte (EM-LLM, §3.2).

        Trata a matriz de similaridade dos traços da janela como adjacência e
        escolhe o corte que maximiza a modularidade (ou minimiza a condutância).
        """
        recs = [r for r in self.store.get_many(members) if r is not None]
        n = len(recs)
        if n < 4:
            return members, []
        sim = [[0.0] * n for _ in range(n)]
        for i in range(n):
            for j in range(i + 1, n):
                s = max(0.0, cosine(recs[i].embedding, recs[j].embedding))
                sim[i][j] = sim[j][i] = s

        lo, hi = max(self.min_event_size, 1), n - 1
        if lo >= hi:
            return members, []
        if self.refinement == "conductance":
            best_cut = min(range(lo, hi + 1), key=lambda c: _conductance(sim, c))
        else:
            best_cut = max(range(lo, hi + 1), key=lambda c: _modularity(sim, c))
        return [r.id for r in recs[:best_cut]], [r.id for r in recs[best_cut:]]

    @staticmethod
    def _centroid(vectors: Sequence[tuple[float, ...] | None]) -> tuple[float, ...] | None:
        vs = [v for v in vectors if v]
        if not vs:
            return None
        dim = len(vs[0])
        acc = [0.0] * dim
        for v in vs:
            for i in range(min(dim, len(v))):
                acc[i] += v[i]
        norm = math.sqrt(sum(x * x for x in acc))
        return tuple(x / norm for x in acc) if norm > 1e-12 else tuple(acc)

    # ------------------------------------------------------------ leitura
    def read(self, query: MemoryQuery) -> list[Retrieved]:
        now = self.now(query.as_of)
        query.with_vector(self.embedder)
        cands = self.candidates(query, now)
        if not cands:
            return []
        scores = composite_score(cands, query.vector, now, self.weights)
        ranked = sorted(zip(cands, scores, strict=True), key=lambda t: -t[1])

        # Estágio 2: contiguidade temporal (Howard & Kahana, 2002).
        # Os vizinhos dos melhores itens ganham ativação, com viés para frente.
        boost: dict[str, float] = {}
        if self.contiguity_weight > 0:
            for rec, _ in ranked[: max(1, query.top_k // 2)]:
                pos = self._position.get(rec.id)
                if pos is None:
                    continue
                for offset in (-2, -1, 1, 2):
                    nb = pos + offset
                    if 0 <= nb < len(self._sequence):
                        nid = self._sequence[nb]
                        lag = abs(offset)
                        direction = self.forward_asymmetry if offset > 0 else 1.0
                        boost[nid] = boost.get(nid, 0.0) + direction / (lag + 1.0)

        out: list[Retrieved] = []
        max_boost = max(boost.values()) if boost else 1.0
        for rec, score in ranked:
            contig = boost.get(rec.id, 0.0) / max_boost if max_boost > 0 else 0.0
            out.append(
                Retrieved(
                    record=rec,
                    score=score + self.contiguity_weight * contig,
                    subsystem=self.name,
                    rationale={
                        "composite": score,
                        "contiguity": contig,
                        "episode": self._episode_of.get(rec.id, ""),
                    },
                )
            )
        out.sort(key=lambda r: -r.score)
        top = out[: query.top_k]
        self.touch_all([r.record for r in top], now)
        return top

    # --------------------------------------------------------- navegação
    def episodes(self) -> list[Episode]:
        return list(self._episodes)

    def episode_of(self, record_id: str) -> Episode | None:
        eid = self._episode_of.get(record_id)
        return next((e for e in self._episodes if e.id == eid), None) if eid else None

    def replay(self, episode_id: str) -> list[MemoryRecord]:
        """Reexecuta um evento na ordem original — o insumo do replay offline."""
        ep = next((e for e in self._episodes if e.id == episode_id), None)
        if ep is None:
            return []
        return [r for r in self.store.get_many(ep.member_ids) if r is not None]

    def window(self, record_id: str, *, before: int = 2, after: int = 2) -> list[MemoryRecord]:
        """Vizinhança temporal de um traço — "o que aconteceu em volta disto?"."""
        pos = self._position.get(record_id)
        if pos is None:
            return []
        lo, hi = max(0, pos - before), min(len(self._sequence), pos + after + 1)
        return [r for r in self.store.get_many(self._sequence[lo:hi]) if r is not None]

    def consolidate(self, now: float | None = None) -> ConsolidationReport:
        """Fecha o evento pendente e recomputa os centróides."""
        report = ConsolidationReport(subsystem=self.name)
        if len(self._pending) >= self.min_event_size:
            ep = self._close_event(self._surprises[-1] if self._surprises else 0.0)
            if ep is not None:
                report.abstracted += 1
        for ep in self._episodes:
            recs = [r for r in self.store.get_many(ep.member_ids) if r is not None]
            if recs:
                ep.centroid = self._centroid([r.embedding for r in recs])
        return report

    def forget(self, now: float | None = None) -> ForgetReport:
        """Esquecimento por retenção: descarta traços de baixa retenção e baixa importância.

        Traços importantes ou recentemente reforçados sobrevivem — é a assimetria
        que a curva de Ebbinghaus com reforço (MemoryBank) prevê.
        """
        t = self.now(now)
        evicted = freed = 0
        for rec in list(self.store.scan(kind=MemoryKind.EPISODIC)):
            if rec.retention(t) < 0.02 and rec.importance < 0.5 and rec.decay.access_count == 0:
                freed += len(rec.content)
                self.store.delete(rec.id)
                evicted += 1
        if evicted:
            self.emit("forget", evicted=evicted)
        return ForgetReport(
            subsystem=self.name, evicted=evicted, retained=self.size(), freed_chars=freed
        )

    def stats(self) -> dict[str, Any]:
        s = super().stats()
        sizes = [len(e) for e in self._episodes]
        s.update(
            {
                "episodes": len(self._episodes),
                "pending": len(self._pending),
                "mean_event_size": sum(sizes) / len(sizes) if sizes else 0.0,
                "surprise_mu": self._mu,
                "surprise_sigma": math.sqrt(self._m2 / self._n) if self._n > 1 else 0.0,
            }
        )
        return s
