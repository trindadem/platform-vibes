"""[EMERGENTE 10/11] Memória latente — o que fica é o vetor e o *gist*.

Gist tokens (Mu, Li & Goodman, 2023, arXiv:2304.08467) e a família de
memórias comprimidas (Memorizing Transformers, Wu et al. 2022; AutoCompressor,
Chevalier et al. 2023): em vez de guardar o texto, guarda-se uma representação
comprimida da qual só se recupera o *essencial*. É `MemoryForm.LATENT`.

O que este subsistema faz de honesto, e diz que faz:

* **O conteúdo original é descartado** após a compressão (a menos que
  `keep_content=True`). `reconstruct()` devolve o gist — uma seleção
  extrativa curta — e não o texto. Compressão com perda é o ponto, não um
  defeito escondido.
* **O vetor é quantizado para int8** (`array('b')`): 1 byte por dimensão em
  vez de um `float` Python (24 bytes + ponteiro numa tupla). A fidelidade
  é medida, não presumida: `stats()["quantization_fidelity"]` é o cosseno
  médio entre vetor original e dequantizado; o teste exige ≥ 0.98.
* **A busca é feita sobre o índice quantizado**, não sobre `record.embedding`
  — que fica `None` de propósito, para o custo de memória ser o declarado.

A razão de compressão reportada é em caracteres de texto (`original/gist`),
que é o que um orçamento de contexto sente.
"""

from __future__ import annotations

import math
from array import array
from collections.abc import Sequence
from typing import Any

from ..core.base import (
    ConsolidationReport,
    ForgetReport,
    MemoryQuery,
    MemorySubsystem,
    Retrieved,
    WriteResult,
)
from ..core.conflict import safe_to_merge
from ..core.record import MemoryRecord, content_fingerprint
from ..core.summarize import ExtractiveSummarizer, Summarizer
from ..core.types import MemoryForm, MemoryFunction, MemoryKind, WriteOp

__all__ = ["LatentMemory", "dequantize", "quantize"]


def quantize(vec: Sequence[float]) -> tuple[array, float]:
    """int8 simétrico: q = round(v / scale), scale = max|v| / 127."""
    peak = max((abs(x) for x in vec), default=0.0)
    scale = peak / 127.0 if peak > 0 else 1.0
    q = array("b", (max(-127, min(127, round(x / scale))) for x in vec))
    return q, scale


def dequantize(q: array, scale: float) -> list[float]:
    return [x * scale for x in q]


def _cos_q(query: Sequence[float], q: array, scale: float) -> float:
    """Cosseno consulta-float x item-int8 sem materializar o vetor float."""
    dot = 0.0
    nq = 0.0
    for a, b in zip(query, q, strict=False):
        dot += a * b
        nq += b * b
    na = math.sqrt(sum(a * a for a in query))
    if na == 0 or nq == 0:
        return 0.0
    return dot / (na * math.sqrt(nq))


class LatentMemory(MemorySubsystem):
    """Vetores int8 + gists; sem texto original.

    Parameters
    ----------
    gist_chars:
        Tamanho alvo do gist extrativo.
    keep_content:
        Se True, guarda o original em `payload["source"]` (desliga a economia).
    merge_threshold:
        Cosseno a partir do qual dois gists são candidatos a fusão na
        consolidação (a fusão ainda passa pelo detector de conflito).
    """

    kind = MemoryKind.LATENT
    emergent = True

    def __init__(
        self,
        *,
        gist_chars: int = 120,
        keep_content: bool = False,
        summarizer: Summarizer | None = None,
        merge_threshold: float = 0.95,
        **kw: Any,
    ) -> None:
        super().__init__(**kw)
        self.gist_chars = gist_chars
        self.keep_content = keep_content
        self.summarizer = summarizer or ExtractiveSummarizer(self.embedder)
        self.merge_threshold = merge_threshold
        self._q: dict[str, tuple[array, float]] = {}
        self._fidelity_sum = 0.0
        self._fidelity_n = 0
        self._source_chars = 0
        self._gist_chars_total = 0

    # ------------------------------------------------------------- escrita
    def write(self, record: MemoryRecord) -> WriteResult:
        now = self.now()
        original = record.content
        record.kind = MemoryKind.LATENT
        record.form = MemoryForm.LATENT
        record.function = MemoryFunction.FACTUAL
        if record.created_at == 0.0:
            record.created_at = now
            record.updated_at = now
            record.decay.last_access = now
        vec = record.embedding or self.embedder.encode(original)
        q, scale = quantize(vec)
        # fidelidade medida por item, não presumida
        deq = dequantize(q, scale)
        dot = sum(a * b for a, b in zip(vec, deq, strict=True))
        na = math.sqrt(sum(a * a for a in vec)) or 1.0
        nb = math.sqrt(sum(b * b for b in deq)) or 1.0
        self._fidelity_sum += dot / (na * nb)
        self._fidelity_n += 1

        gist = (
            self.summarizer.summarize([original], max_chars=self.gist_chars)
            or original[: self.gist_chars]
        )
        if len(gist) > self.gist_chars * 1.5:
            gist = gist[: self.gist_chars].rstrip() + "…"
        record.fingerprint = record.fingerprint or content_fingerprint(original)
        record.content = gist
        record.embedding = None  # o índice é o quantizado; o float não fica
        record.payload["source_chars"] = len(original)
        record.payload["gist_chars"] = len(gist)
        record.payload["compression"] = round(len(original) / max(len(gist), 1), 2)
        if self.keep_content:
            record.payload["source"] = original
        self._q[record.id] = (q, scale)
        self._source_chars += len(original)
        self._gist_chars_total += len(gist)
        self.store.put(record)
        self.emit("compress", record.id, compression=record.payload["compression"])
        return WriteResult(
            op=WriteOp.ADD, record_id=record.id, reason=f"x{record.payload['compression']}"
        )

    # ------------------------------------------------------------- leitura
    def read(self, query: MemoryQuery) -> list[Retrieved]:
        now = self.now(query.as_of)
        query.with_vector(self.embedder)
        if query.vector is None:
            return []
        cands = self.candidates(query, now)
        out: list[Retrieved] = []
        for rec in cands:
            qs = self._q.get(rec.id)
            if qs is None:
                continue
            sim = _cos_q(query.vector, qs[0], qs[1])
            score = sim * (0.7 + 0.3 * rec.importance)
            out.append(
                Retrieved(
                    record=rec,
                    score=score,
                    subsystem=self.name,
                    rationale={
                        "similarity": sim,
                        "compression": rec.payload.get("compression", 1.0),
                    },
                )
            )
        out.sort(key=lambda r: -r.score)
        top = out[: query.top_k]
        self.touch_all([r.record for r in top], now)
        return top

    def reconstruct(self, record_id: str) -> str:
        """O que se consegue recuperar: o gist (ou o original, se foi mantido)."""
        rec = self.store.get(record_id)
        if rec is None:
            return ""
        return str(rec.payload.get("source") or rec.content)

    def vector_of(self, record_id: str) -> list[float]:
        qs = self._q.get(record_id)
        return dequantize(*qs) if qs else []

    # ------------------------------------------------------- consolidação
    def consolidate(self, now: float | None = None) -> ConsolidationReport:
        """Funde quase-duplicatas latentes — só se o detector de conflito deixar."""
        t = self.now(now)
        report = ConsolidationReport(subsystem=self.name)
        ids = [r.id for r in self.store.scan(kind=MemoryKind.LATENT) if r.is_live(t)]
        removed: set[str] = set()
        for i, a in enumerate(ids):
            if a in removed:
                continue
            ra = self.store.get(a)
            if ra is None:
                continue
            va = self.vector_of(a)
            for b in ids[i + 1 :]:
                if b in removed:
                    continue
                rb = self.store.get(b)
                qs = self._q.get(b)
                if rb is None or qs is None:
                    continue
                sim = _cos_q(va, qs[0], qs[1])
                if safe_to_merge(ra.content, rb.content, sim, self.merge_threshold):
                    keep, drop = (ra, rb) if ra.importance >= rb.importance else (rb, ra)
                    keep.decay.touch(t)
                    keep.links["merged"] = (*keep.links.get("merged", ()), drop.id)
                    self.store.put(keep)
                    self.store.delete(drop.id)
                    self._q.pop(drop.id, None)
                    removed.add(drop.id)
                    report.merged += 1
                    if drop is ra:
                        break
        return report

    def forget(self, now: float | None = None) -> ForgetReport:
        t = self.now(now)
        evicted = 0
        for rec in list(self.store.scan(kind=MemoryKind.LATENT)):
            if rec.retention(t) < 0.02 and rec.importance < 0.5:
                self.store.delete(rec.id)
                self._q.pop(rec.id, None)
                evicted += 1
        return ForgetReport(subsystem=self.name, evicted=evicted, retained=self.size())

    def stats(self) -> dict[str, Any]:
        s = super().stats()
        index_bytes = sum(len(q) for q, _ in self._q.values())
        s.update(
            {
                "quantization_fidelity": round(self._fidelity_sum / self._fidelity_n, 4)
                if self._fidelity_n
                else 1.0,
                "index_bytes": index_bytes,
                "float_equivalent_bytes": index_bytes * 8,
                "text_compression": round(self._source_chars / max(self._gist_chars_total, 1), 2),
            }
        )
        return s
