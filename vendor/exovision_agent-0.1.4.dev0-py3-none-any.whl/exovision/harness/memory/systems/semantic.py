"""[TRADICIONAL 5/10] Memória semântica — fatos descontextualizados.

Memória semântica guarda o *que é verdade*, desacoplado de quando/onde foi
aprendido (Tulving, 1972; rede de conceitos de Quillian, 1968). Para um agente,
é onde vivem "o usuário mora em BH", "o cluster tem 2 managers", "a API expira
tokens em 1h".

O que distingue esta implementação de "um índice vetorial de frases":

1. **Pipeline de escrita com decisão explícita.** Todo fato candidato é
   comparado com o acervo e roteado para ADD / UPDATE / INVALIDATE / NOOP — o
   conjunto de operações do Mem0 (Chhikara et al., 2025, arXiv:2504.19413),
   acrescido de INVALIDATE para preservar a história bi-temporal.

2. **Contradição não é duplicata.** A decisão usa `core.conflict`, não o
   cosseno: um fato novo que contradiz um antigo *invalida* o antigo em vez de
   coexistir com ele. Servir um fato obsoleto como corrente é a falha de
   "knowledge update"/staleness que os benchmarks de 2026 medem.

3. **Precedência por confiança.** Quando duas fontes discordam, vence o nível de
   confiança maior (usuário > observação > inferência), não a mais recente.
"""

from __future__ import annotations

from collections import defaultdict
from typing import Any

from ..core.base import (
    ConsolidationReport,
    ForgetReport,
    MemoryQuery,
    MemorySubsystem,
    Retrieved,
    WriteResult,
)
from ..core.conflict import ConflictKind, detect_conflict
from ..core.record import MemoryRecord
from ..core.scoring import composite_score
from ..core.similarity import cosine, reciprocal_rank_fusion
from ..core.text import content_words
from ..core.types import MemoryForm, MemoryFunction, MemoryKind, WriteOp

__all__ = ["SemanticMemory"]


class SemanticMemory(MemorySubsystem):
    """Armazém de fatos com resolução de contradição e recuperação híbrida.

    Parameters
    ----------
    dedup_threshold:
        Cosseno acima do qual dois fatos são considerados a mesma asserção
        (sujeito ao veto de conflito).
    supersede_threshold:
        Cosseno acima do qual um conflito detectado é tratado como *atualização
        do mesmo fato* e não como um fato novo e independente. Abaixo dele, os
        dois coexistem (falam de coisas diferentes que por acaso conflitam).
    contested_penalty:
        Demoção aplicada, na leitura, a um fato contestado por outro de confiança
        maior que ainda está vivo. Grande o suficiente para tirá-lo do topo sem
        torná-lo irrecuperável.
    """

    kind = MemoryKind.SEMANTIC

    def __init__(
        self,
        *,
        dedup_threshold: float = 0.82,
        supersede_threshold: float = 0.55,
        contested_penalty: float = 1.0,
        hybrid: bool = True,
        **kw: Any,
    ) -> None:
        super().__init__(**kw)
        self.dedup_threshold = dedup_threshold
        self.supersede_threshold = supersede_threshold
        self.contested_penalty = contested_penalty
        self.hybrid = hybrid
        self._entity_index: dict[str, set[str]] = defaultdict(set)
        self._superseded: dict[str, str] = {}  # antigo -> novo
        #: id -> id do registro de MAIOR confiança que o contesta.
        #: Um fato contestado continua recuperável (o agente precisa saber que a
        #: discordância existe), mas é demovido para trás do autoritativo.
        self._contested: dict[str, str] = {}

    # ------------------------------------------------------------- escrita
    def write(self, record: MemoryRecord) -> WriteResult:
        now = self.now()
        record.kind = MemoryKind.SEMANTIC
        record.form = MemoryForm.TOKEN
        record.function = MemoryFunction.FACTUAL
        if record.created_at == 0.0:
            record.created_at = now
            record.updated_at = now
            record.decay.last_access = now
        if record.valid_from is None:
            record.valid_from = record.created_at
        self.ensure_embedding(record)

        decision = self._decide(record, now)
        if decision.op is WriteOp.NOOP:
            self.emit("noop", decision.record_id, reason=decision.reason)
            return decision

        if decision.op is WriteOp.INVALIDATE:
            for old_id in decision.superseded:
                old = self.store.get(old_id)
                if old is None:
                    continue
                old.invalidate(now)
                self.store.put(old)
                self._superseded[old_id] = record.id
                self.emit("invalidate", old_id, superseded_by=record.id, reason=decision.reason)

        self.store.put(record)
        for token in set(content_words(record.content)):
            self._entity_index[token].add(record.id)
        self.emit("write", record.id, op=decision.op.value)
        return WriteResult(
            op=decision.op,
            record_id=record.id,
            superseded=decision.superseded,
            reason=decision.reason,
        )

    def _decide(self, incoming: MemoryRecord, now: float) -> WriteResult:
        """ADD / UPDATE / INVALIDATE / NOOP contra o acervo vivo."""
        # Duplicata exata (fingerprint) -> reforça o traço existente, não duplica.
        for twin in self.store.by_fingerprint(incoming.fingerprint):
            if twin.is_live(now):
                twin.decay.touch(now)
                twin.confidence = max(twin.confidence, incoming.confidence)
                twin.trust = max(twin.trust, incoming.trust, key=int)
                self.store.put(twin)
                return WriteResult(
                    op=WriteOp.NOOP,
                    record_id=twin.id,
                    reason="duplicata_exata_reforcada",
                    accepted=False,
                )

        neighbours = self.store.search_dense(incoming.embedding or (), 12)
        conflicts: list[str] = []
        detail = ""
        for rid, sim in neighbours:
            existing = self.store.get(rid)
            if existing is None or not existing.is_live(now) or existing.id == incoming.id:
                continue
            conflict = detect_conflict(existing.content, incoming.content)
            if not conflict:
                if sim >= self.dedup_threshold:
                    existing.decay.touch(now)
                    self.store.put(existing)
                    return WriteResult(
                        op=WriteOp.NOOP,
                        record_id=existing.id,
                        reason=f"quase_duplicata(cos={sim:.2f})",
                        accepted=False,
                    )
                continue
            if sim < self.supersede_threshold:
                # Conflita, mas fala de outro assunto — coexistem.
                continue
            # Precedência por confiança: uma fonte mais fraca não derruba
            # uma afirmação mais forte; entra com confiança reduzida.
            if int(incoming.trust) < int(existing.trust):
                # A fonte mais fraca não derruba a mais forte. O fato entra
                # marcado como contestado: continua auditável e recuperável sob
                # demanda, mas nunca é servido como a resposta corrente.
                incoming.confidence *= 0.5
                incoming.links["contested_by"] = (
                    *incoming.links.get("contested_by", ()),
                    existing.id,
                )
                self._contested[incoming.id] = existing.id
                return WriteResult(
                    op=WriteOp.ADD,
                    record_id=incoming.id,
                    reason=f"contestado_por_fonte_mais_forte({conflict.kind.value})",
                )
            conflicts.append(existing.id)
            detail = conflict.kind.value

        if conflicts:
            return WriteResult(
                op=WriteOp.INVALIDATE,
                record_id=incoming.id,
                superseded=tuple(conflicts),
                reason=f"contradicao_{detail}",
            )
        return WriteResult(op=WriteOp.ADD, record_id=incoming.id, reason="novo")

    # ------------------------------------------------------------- leitura
    def read(self, query: MemoryQuery) -> list[Retrieved]:
        now = self.now(query.as_of)
        query.with_vector(self.embedder)
        cands = self.candidates(query, now)
        if not cands:
            return []
        by_id = {r.id: r for r in cands}

        if self.hybrid and query.text:
            dense = [
                rid
                for rid, _ in self.store.search_dense(query.vector or (), query.top_k * 4)
                if rid in by_id
            ]
            sparse = [
                rid
                for rid, _ in self.store.search_sparse(query.text, query.top_k * 4)
                if rid in by_id
            ]
            fused = reciprocal_rank_fusion([dense, sparse], k=self.weights.rrf_k)
            pool = [by_id[rid] for rid, _ in fused][: query.top_k * 3]
            if not pool:
                pool = cands
        else:
            pool = cands

        scores = composite_score(pool, query.vector, now, self.weights)
        out: list[Retrieved] = []
        for rec, score in zip(pool, scores, strict=True):
            contested_by = self._contested.get(rec.id, "")
            penalty = 0.0
            if contested_by:
                challenger = self.store.get(contested_by)
                if challenger is not None and challenger.is_live(now):
                    penalty = self.contested_penalty
            out.append(
                Retrieved(
                    record=rec,
                    score=score - penalty,
                    subsystem=self.name,
                    rationale={
                        "composite": score,
                        "relevance": cosine(query.vector, rec.embedding) if query.vector else 0.0,
                        "confidence": rec.confidence,
                        "trust": float(int(rec.trust)),
                        "contested_penalty": penalty,
                    },
                )
            )
        out.sort(key=lambda r: -r.score)
        top = out[: query.top_k]
        self.touch_all([r.record for r in top], now)
        return top

    # --------------------------------------------------------------- extras
    def history(self, record_id: str) -> list[MemoryRecord]:
        """Cadeia de versões de um fato, da mais antiga à corrente."""
        chain: list[MemoryRecord] = []
        cur: str | None = record_id
        seen: set[str] = set()
        while cur and cur not in seen:
            seen.add(cur)
            rec = self.store.get(cur)
            if rec is None:
                break
            chain.append(rec)
            cur = self._superseded.get(cur)
        return chain

    def contested(self) -> dict[str, str]:
        """Mapa fato_contestado -> fato_autoritativo. Insumo de auditoria."""
        return dict(self._contested)

    def about(self, entity: str, *, top_k: int = 10) -> list[MemoryRecord]:
        """Fatos que mencionam uma entidade (índice invertido de palavras de conteúdo)."""
        now = self.now()
        ids = self._entity_index.get(entity.lower(), set())
        recs = [r for r in self.store.get_many(list(ids)) if r and r.is_live(now)]
        recs.sort(key=lambda r: -r.updated_at)
        return recs[:top_k]

    def consolidate(self, now: float | None = None) -> ConsolidationReport:
        """Varre o acervo em busca de contradições que escaparam na escrita.

        Necessário porque a decisão de escrita só olha os 12 vizinhos mais
        próximos: fatos que se tornaram contraditórios depois, por conta de
        outras atualizações, só aparecem nesta varredura periódica.
        """
        t = self.now(now)
        report = ConsolidationReport(subsystem=self.name)
        live = [r for r in self.store.scan(kind=MemoryKind.SEMANTIC) if r.is_live(t)]
        live.sort(key=lambda r: r.created_at)
        for i, older in enumerate(live):
            if not older.is_live(t):
                continue
            for newer in live[i + 1 :]:
                if not newer.is_live(t):
                    continue
                sim = cosine(older.embedding, newer.embedding)
                if sim < self.supersede_threshold:
                    continue
                conflict = detect_conflict(older.content, newer.content)
                if conflict.kind is ConflictKind.NONE:
                    continue
                if int(newer.trust) >= int(older.trust):
                    older.invalidate(t)
                    self.store.put(older)
                    self._superseded[older.id] = newer.id
                    report.invalidated += 1
                    report.notes.append(f"{older.id[:8]}<-{newer.id[:8]} ({conflict.kind.value})")
                    break
        if report.invalidated:
            self.emit("consolidate", invalidated=report.invalidated)
        return report

    def forget(self, now: float | None = None) -> ForgetReport:
        """Poda fatos invalidados há muito tempo (tombstone com TTL)."""
        t = self.now(now)
        ttl = 90 * 86400.0
        evicted = freed = invalid = 0
        for rec in list(self.store.scan(kind=MemoryKind.SEMANTIC)):
            if rec.valid_to is not None:
                invalid += 1
                if (t - rec.valid_to) > ttl:
                    freed += len(rec.content)
                    self.store.delete(rec.id)
                    evicted += 1
        return ForgetReport(
            subsystem=self.name,
            evicted=evicted,
            invalidated=invalid,
            retained=self.size(),
            freed_chars=freed,
        )

    def stats(self) -> dict[str, Any]:
        now = self.now()
        live = sum(1 for r in self.store.scan(kind=MemoryKind.SEMANTIC) if r.is_live(now))
        s = super().stats()
        s.update(
            {
                "live_facts": live,
                "invalidated": len(self.store) - live,
                "entities_indexed": len(self._entity_index),
                "supersession_edges": len(self._superseded),
                "contested": len(self._contested),
            }
        )
        return s
