"""[EMERGENTE 11/11] Memória consolidada — o produto do "sono".

Consolidação sistêmica (McClelland, McNaughton & O'Reilly, 1995; Squire &
Alvarez, 1995): o hipocampo grava rápido e específico; durante o sono, os
episódios são *reapresentados* ao neocórtex, que aprende devagar o que é
regular entre eles. O que sobra é esquema, não episódio. A versão para
agentes é "sleep-time compute" (Letta, 2025; arXiv:2504.13171): trabalho de
memória feito fora do caminho quente da conversa.

O ciclo aqui segue os cinco estágios de `ConsolidationStage`:

    REPLAY     amostra episódios das *fontes* (intercalando recentes e importantes —
               replay intercalado é o que evita o esquecimento catastrófico
               do que é antigo)
    ABSTRACT   agrupa por similaridade e sintetiza um esquema por grupo
    RECONCILE  esquema novo x esquemas existentes: funde se for o mesmo,
               invalida o antigo se contradizer (bi-temporal)
    PRUNE      marca as fontes como consolidadas e, opcionalmente, expira as
               de baixa retenção — o traço agora vive no esquema
    REINDEX    garante embeddings e emite o relatório

Todo esquema aponta para os episódios que o geraram
(`links["derived_from"]`, `provenance.kind = CONSOLIDATION`): a
consolidação é auditável de ponta a ponta.
"""

from __future__ import annotations

from collections.abc import Sequence
from typing import Any

from ..core.base import (
    ConsolidationReport,
    ForgetReport,
    MemoryQuery,
    MemorySubsystem,
    Retrieved,
    WriteResult,
)
from ..core.conflict import detect_conflict
from ..core.embeddings import noise_floor_of
from ..core.record import MemoryRecord, Provenance
from ..core.scoring import composite_score, recency_score
from ..core.similarity import cosine
from ..core.summarize import ExtractiveSummarizer, Summarizer
from ..core.types import (
    ConsolidationStage,
    MemoryForm,
    MemoryFunction,
    MemoryKind,
    ProvenanceKind,
    TrustTier,
    WriteOp,
)

__all__ = ["ConsolidatedMemory"]


class ConsolidatedMemory(MemorySubsystem):
    """Esquemas produzidos por ciclos de consolidação sobre subsistemas-fonte.

    Parameters
    ----------
    sources:
        Subsistemas de onde os episódios são reapresentados (tipicamente a
        episódica e o buffer).
    replay_size:
        Quantos episódios entram por ciclo — metade os mais recentes, metade
        os mais importantes ainda não consolidados.
    cluster_threshold:
        Cosseno mínimo para dois episódios irem ao mesmo esquema. `None`
        ancora em 2.5x o piso de ruído.
    prune:
        Se True, fontes consolidadas de baixa retenção são expiradas.
    """

    kind = MemoryKind.CONSOLIDATED
    emergent = True

    def __init__(
        self,
        *,
        sources: Sequence[MemorySubsystem] = (),
        replay_size: int = 32,
        cluster_threshold: float | None = None,
        min_cluster: int = 2,
        prune: bool = True,
        prune_retention: float = 0.05,
        merge_threshold: float | None = None,
        summarizer: Summarizer | None = None,
        **kw: Any,
    ) -> None:
        super().__init__(**kw)
        floor = noise_floor_of(self.embedder, 0.1)
        self.sources: list[MemorySubsystem] = list(sources)
        self.replay_size = replay_size
        self.cluster_threshold = floor * 2.5 if cluster_threshold is None else cluster_threshold
        self.min_cluster = min_cluster
        self.prune = prune
        self.prune_retention = prune_retention
        self.merge_threshold = floor * 4.0 if merge_threshold is None else merge_threshold
        self.summarizer = summarizer or ExtractiveSummarizer(self.embedder)
        self.cycles = 0
        self.last_stages: dict[str, int] = {}

    def add_source(self, sub: MemorySubsystem) -> None:
        self.sources.append(sub)

    # ------------------------------------------------------------- escrita
    def write(self, record: MemoryRecord) -> WriteResult:
        """Escrita direta de um esquema já abstraído (ou vindo de outra instância)."""
        now = self.now()
        record.kind = MemoryKind.CONSOLIDATED
        record.form = MemoryForm.TOKEN
        record.function = MemoryFunction.FACTUAL
        if record.created_at == 0.0:
            record.created_at = now
            record.updated_at = now
            record.decay.last_access = now
        if record.provenance.kind is not ProvenanceKind.CONSOLIDATION:
            record.provenance = Provenance(
                kind=ProvenanceKind.CONSOLIDATION,
                source_id=record.provenance.source_id,
                derived_from=record.provenance.derived_from,
            )
        record.payload.setdefault("evidence_count", len(record.links.get("derived_from", ())))
        self.ensure_embedding(record)
        self.store.put(record)
        return WriteResult(op=WriteOp.ADD, record_id=record.id)

    # --------------------------------------------------------------- ciclo
    def sleep(self, now: float | None = None) -> ConsolidationReport:
        """Um ciclo completo: replay -> abstract -> reconcile -> prune -> reindex."""
        t = self.now(now)
        report = ConsolidationReport(subsystem=self.name)
        stages: dict[str, int] = {}

        episodes = self._replay(t)
        stages[ConsolidationStage.REPLAY.value] = len(episodes)
        self.emit("stage", "", stage=ConsolidationStage.REPLAY.value, n=len(episodes))
        if len(episodes) < self.min_cluster:
            self.cycles += 1
            self.last_stages = stages
            report.notes.append("nada a consolidar")
            return report

        schemas = self._abstract(episodes, t)
        stages[ConsolidationStage.ABSTRACT.value] = len(schemas)
        self.emit("stage", "", stage=ConsolidationStage.ABSTRACT.value, n=len(schemas))

        new, absorbed_into, merged, invalidated = self._reconcile(schemas, t)
        stages[ConsolidationStage.RECONCILE.value] = merged + invalidated
        report.merged += merged
        report.invalidated += invalidated
        self.emit(
            "stage",
            "",
            stage=ConsolidationStage.RECONCILE.value,
            merged=merged,
            invalidated=invalidated,
        )

        marked, pruned = self._prune(new + absorbed_into, t)
        stages[ConsolidationStage.PRUNE.value] = pruned
        report.promoted += marked
        self.emit("stage", "", stage=ConsolidationStage.PRUNE.value, marked=marked, pruned=pruned)

        for s in new:
            self.ensure_embedding(s)
            self.store.put(s)
        stages[ConsolidationStage.REINDEX.value] = len(new)
        report.abstracted += len(new)
        report.links_created += sum(len(s.links.get("derived_from", ())) for s in new)
        self.cycles += 1
        self.last_stages = stages
        report.notes.append(f"ciclo {self.cycles}: {stages}")
        self.emit("stage", "", stage=ConsolidationStage.REINDEX.value, n=len(schemas))
        return report

    def _replay(self, t: float) -> list[MemoryRecord]:
        pool: list[MemoryRecord] = []
        for src in self.sources:
            for rec in src.store.scan(kind=src.kind):
                if (
                    rec.kind is MemoryKind.CONSOLIDATED
                    or rec.payload.get("consolidated_by")
                    or not rec.is_live(t)
                ):
                    continue
                if int(rec.trust) <= int(TrustTier.QUARANTINED):
                    continue
                pool.append(rec)
        if not pool:
            return []
        half = max(1, self.replay_size // 2)
        recent = sorted(pool, key=lambda r: -r.created_at)[:half]
        important = sorted(pool, key=lambda r: -(r.importance + 0.2 * r.salience))[:half]
        seen: set[str] = set()
        out: list[MemoryRecord] = []
        # intercalado: recente, importante, recente, importante...
        for a, b in zip(recent + [None] * half, important + [None] * half, strict=False):
            for r in (a, b):
                if r is not None and r.id not in seen:
                    seen.add(r.id)
                    out.append(r)
        return out[: self.replay_size]

    def _abstract(self, episodes: list[MemoryRecord], t: float) -> list[MemoryRecord]:
        for e in episodes:
            if e.embedding is None:
                e.embedding = self.embedder.encode(e.content)
        remaining = sorted(episodes, key=lambda r: -r.importance)
        schemas: list[MemoryRecord] = []
        while remaining:
            seed = remaining.pop(0)
            members = [seed]
            rest: list[MemoryRecord] = []
            for r in remaining:
                if cosine(seed.embedding, r.embedding) >= self.cluster_threshold:
                    members.append(r)
                else:
                    rest.append(r)
            remaining = rest
            if len(members) < self.min_cluster:
                continue
            texts = [
                m.content.rstrip()
                if m.content.rstrip().endswith((".", "!", "?"))
                else m.content.rstrip() + "."
                for m in members
            ]
            content = self.summarizer.summarize(texts, max_chars=320)
            if not content:
                continue
            tags = tuple(sorted({tg for m in members for tg in m.tags}))
            schema = MemoryRecord(
                content=content,
                kind=MemoryKind.CONSOLIDATED,
                form=MemoryForm.TOKEN,
                function=MemoryFunction.FACTUAL,
                importance=min(1.0, sum(m.importance for m in members) / len(members) + 0.1),
                confidence=sum(m.confidence for m in members) / len(members),
                trust=TrustTier.DERIVED,
                provenance=Provenance(
                    kind=ProvenanceKind.CONSOLIDATION,
                    source_id=f"cycle:{self.cycles + 1}",
                    derived_from=tuple(m.id for m in members),
                ),
                links={"derived_from": tuple(m.id for m in members)},
                payload={
                    "evidence_count": len(members),
                    "min_source_trust": min(int(m.trust) for m in members),
                    "sources": sorted({m.kind.value for m in members}),
                },
                tags=tags,
                created_at=t,
                updated_at=t,
                valid_from=min((m.valid_from or m.created_at) for m in members),
            )
            self.ensure_embedding(schema)
            schemas.append(schema)
        return schemas

    def _reconcile(
        self, schemas: list[MemoryRecord], t: float
    ) -> tuple[list[MemoryRecord], list[MemoryRecord], int, int]:
        """-> (esquemas novos, esquemas existentes que absorveram novos, fundidos, invalidados)."""
        merged = invalidated = 0
        existing = [r for r in self.store.scan(kind=MemoryKind.CONSOLIDATED) if r.is_live(t)]
        kept: list[MemoryRecord] = []
        absorbed_into: list[MemoryRecord] = []
        for s in schemas:
            absorbed = False
            for old in existing:
                sim = cosine(s.embedding, old.embedding)
                if sim < self.merge_threshold:
                    continue
                if detect_conflict(old.content, s.content):
                    # o esquema novo vem de episódios mais recentes: o antigo deixa de valer
                    old.invalidate(t)
                    old.payload["invalidated_by"] = s.id
                    self.store.put(old)
                    invalidated += 1
                    self.emit("invalidate", old.id, by=s.id)
                    continue
                old.links["derived_from"] = tuple(
                    dict.fromkeys(
                        (*old.links.get("derived_from", ()), *s.links.get("derived_from", ()))
                    )
                )
                old.payload["evidence_count"] = len(old.links["derived_from"])
                old.decay.touch(t)
                old.updated_at = t
                old.importance = max(old.importance, s.importance)
                self.store.put(old)
                merged += 1
                absorbed = True
                # as fontes do esquema absorvido passam a apontar para o existente
                absorbed_into.append(old)
                break
            if not absorbed:
                kept.append(s)
        return kept, absorbed_into, merged, invalidated

    def _prune(self, schemas: list[MemoryRecord], t: float) -> tuple[int, int]:
        marked = pruned = 0
        by_src: dict[str, MemoryRecord] = {}
        for src in self.sources:
            for rec in src.store.scan(kind=src.kind):
                by_src[rec.id] = rec
        for s in schemas:
            found = self.store.get(s.id)
            target = found if found is not None else s
            for eid in target.links.get("derived_from", ()):
                source = by_src.get(eid)
                if source is None or source.payload.get("consolidated_by"):
                    continue
                source.payload["consolidated_by"] = target.id
                source.links["consolidated_by"] = (target.id,)
                marked += 1
                if self.prune and source.retention(t) < self.prune_retention and source.importance < 0.8:
                    source.expire(t)
                    pruned += 1
                for src in self.sources:
                    if src.store.get(eid) is not None:
                        src.store.put(source)
        return marked, pruned

    # ------------------------------------------------------------- leitura
    def read(self, query: MemoryQuery) -> list[Retrieved]:
        now = self.now(query.as_of)
        query.with_vector(self.embedder)
        cands = self.candidates(query, now)
        if not cands:
            return []
        base = composite_score(cands, query.vector, now, self.weights)
        out: list[Retrieved] = []
        for rec, s in zip(cands, base, strict=True):
            ev = int(rec.payload.get("evidence_count", 1))
            score = s + 0.05 * min(ev, 6)
            out.append(
                Retrieved(
                    record=rec,
                    score=score,
                    subsystem=self.name,
                    rationale={
                        "composite": s,
                        "evidence": float(ev),
                        "recency": recency_score(rec, now),
                    },
                )
            )
        out.sort(key=lambda r: -r.score)
        top = out[: query.top_k]
        self.touch_all([r.record for r in top], now)
        return top

    def evidence(self, schema_id: str) -> list[MemoryRecord]:
        rec = self.store.get(schema_id)
        if rec is None:
            return []
        out: list[MemoryRecord] = []
        for eid in rec.links.get("derived_from", ()):
            for src in self.sources:
                e = src.store.get(eid)
                if e is not None:
                    out.append(e)
                    break
        return out

    def consolidate(self, now: float | None = None) -> ConsolidationReport:
        return self.sleep(now)

    def forget(self, now: float | None = None) -> ForgetReport:
        """Esquema invalidado há muito, ou sem evidência e de baixa retenção, sai."""
        t = self.now(now)
        evicted = 0
        for rec in list(self.store.scan(kind=MemoryKind.CONSOLIDATED)):
            if (
                not rec.is_live(t) and (t - (rec.valid_to or rec.expired_at or t)) > 30 * 86400
            ) or (rec.is_live(t) and not rec.links.get("derived_from") and rec.retention(t) < 0.02):
                self.store.delete(rec.id)
                evicted += 1
        return ForgetReport(subsystem=self.name, evicted=evicted, retained=self.size())

    def stats(self) -> dict[str, Any]:
        s = super().stats()
        s.update(
            {
                "cycles": self.cycles,
                "sources": [src.name for src in self.sources],
                "last_stages": dict(self.last_stages),
            }
        )
        return s
