"""[EMERGENTE 8/11] Memória afetiva — emoção modula codificação e recuperação.

Dois efeitos bem estabelecidos na psicologia da memória, ambos implementados:

* **Excitação fortalece a codificação.** Eventos com arousal alto são
  lembrados melhor e por mais tempo (Kensinger & Corkin, 2004; Mather &
  Sutherland, 2011, "arousal-biased competition"). Aqui: a estabilidade do
  traço (`decay.strength`) e a importância sobem com o arousal.
* **Recuperação congruente com o humor.** O que se lembra depende do estado
  afetivo de quem lembra (Bower, 1981): humor negativo facilita memórias
  negativas. Aqui: `set_mood()` fixa o estado corrente e a leitura ganha um
  termo de congruência de valência.

A anotação afetiva vem de um `appraiser` (LLM, classificador) quando
disponível; sem ele, um léxico PT/EN curto estima valência e arousal — o
suficiente para o mecanismo ser testável, e explícito o bastante para
ninguém confundir com análise de sentimento séria. O modelo dimensional é
o circumplexo de Russell (1980): valência em [-1, 1], arousal em [0, 1].
"""

from __future__ import annotations

import re
from collections.abc import Callable
from typing import Any

from ..core.base import (
    ConsolidationReport,
    ForgetReport,
    MemoryQuery,
    MemorySubsystem,
    Retrieved,
    WriteResult,
)
from ..core.record import Affect, MemoryRecord
from ..core.scoring import RetrievalWeights, affective_gain, composite_score
from ..core.text import fold, tokenize
from ..core.types import MemoryForm, MemoryFunction, MemoryKind, WriteOp

__all__ = ["AffectiveMemory", "Appraiser", "LexiconAppraiser"]

Appraiser = Callable[[str], Affect]

_POSITIVE = frozenset(
    [
        "bom",
        "boa",
        "otimo",
        "otima",
        "excelente",
        "sucesso",
        "feliz",
        "alegria",
        "alegre",
        "ganhou",
        "venceu",
        "resolvido",
        "resolvida",
        "funcionou",
        "funciona",
        "perfeito",
        "perfeita",
        "obrigado",
        "obrigada",
        "parabens",
        "amor",
        "adorei",
        "gostei",
        "calmo",
        "tranquilo",
        "good",
        "great",
        "excellent",
        "success",
        "happy",
        "joy",
        "won",
        "solved",
        "works",
        "perfect",
        "thanks",
        "love",
        "loved",
        "like",
        "calm",
    ]
)
_NEGATIVE = frozenset(
    [
        "ruim",
        "pessimo",
        "pessima",
        "erro",
        "erros",
        "falha",
        "falhou",
        "falhando",
        "quebrou",
        "quebrado",
        "perdeu",
        "perda",
        "medo",
        "raiva",
        "odio",
        "triste",
        "tristeza",
        "urgente",
        "urgencia",
        "critico",
        "critica",
        "grave",
        "perigo",
        "incidente",
        "caiu",
        "fora",
        "ataque",
        "bad",
        "terrible",
        "error",
        "errors",
        "failure",
        "failed",
        "broke",
        "broken",
        "lost",
        "loss",
        "fear",
        "anger",
        "hate",
        "sad",
        "urgent",
        "critical",
        "danger",
        "incident",
        "down",
        "outage",
        "attack",
    ]
)
_AROUSING = frozenset(
    [
        "urgente",
        "urgencia",
        "critico",
        "critica",
        "grave",
        "perigo",
        "incidente",
        "ataque",
        "agora",
        "imediatamente",
        "emergencia",
        "panico",
        "caiu",
        "fora",
        "explodiu",
        "incrivel",
        "fantastico",
        "ganhou",
        "venceu",
        "urgent",
        "critical",
        "danger",
        "incident",
        "attack",
        "now",
        "immediately",
        "emergency",
        "panic",
        "outage",
        "amazing",
        "won",
    ]
)


class LexiconAppraiser:
    """Avaliação afetiva por léxico: proxy barato, determinístico e declarado como tal."""

    def __call__(self, text: str) -> Affect:
        toks = [fold(t) for t in tokenize(text)]
        if not toks:
            return Affect()
        pos = sum(1 for t in toks if t in _POSITIVE)
        neg = sum(1 for t in toks if t in _NEGATIVE)
        arousing = sum(1 for t in toks if t in _AROUSING)
        valence = (pos - neg) / (pos + neg + 1.0)
        exclam = text.count("!")
        caps = len(re.findall(r"\b[A-ZÀ-Ú]{3,}\b", text))
        arousal = min(1.0, 0.25 * arousing + 0.15 * exclam + 0.1 * caps + 0.1 * (pos + neg > 0))
        return Affect(valence=max(-1.0, min(1.0, valence)), arousal=arousal)


class AffectiveMemory(MemorySubsystem):
    """Memória cuja força e cujo acesso dependem do afeto.

    Parameters
    ----------
    arousal_beta:
        Ganho de codificação por unidade de arousal (0.5 -> traço até 1.5x mais estável).
    congruence:
        Peso do termo de congruência de humor na recuperação.
    """

    kind = MemoryKind.AFFECTIVE
    emergent = True

    def __init__(
        self,
        *,
        appraiser: Appraiser | None = None,
        arousal_beta: float = 0.5,
        congruence: float = 0.3,
        **kw: Any,
    ) -> None:
        super().__init__(**kw)
        self.appraiser: Appraiser = appraiser or LexiconAppraiser()
        self.arousal_beta = arousal_beta
        self.congruence = congruence
        self.mood = Affect()
        if self.weights.affect == 0.0:
            self.weights = RetrievalWeights(
                **{**self.weights.as_dict(), "affect": 0.4, "arousal_beta": arousal_beta}
            )

    def set_mood(self, valence: float, arousal: float = 0.0) -> Affect:
        self.mood = Affect(
            valence=max(-1.0, min(1.0, valence)), arousal=max(0.0, min(1.0, arousal))
        )
        self.emit("mood", "", valence=self.mood.valence, arousal=self.mood.arousal)
        return self.mood

    # ------------------------------------------------------------- escrita
    def write(self, record: MemoryRecord) -> WriteResult:
        now = self.now()
        record.kind = MemoryKind.AFFECTIVE
        record.form = MemoryForm.TOKEN
        record.function = MemoryFunction.EXPERIENTIAL
        if record.created_at == 0.0:
            record.created_at = now
            record.updated_at = now
            record.decay.last_access = now
        if record.affect.is_neutral:
            record.affect = self.appraiser(record.content)
        gain = affective_gain(record, self.arousal_beta)
        # Excitação fortalece o traço: mais estabilidade (Ebbinghaus S) e mais importância.
        record.decay.strength *= gain
        record.importance = min(1.0, record.importance * gain)
        record.payload["valence"] = record.affect.valence
        record.payload["arousal"] = record.affect.arousal
        record.payload["encoding_gain"] = gain
        self.ensure_embedding(record)
        self.store.put(record)
        self.emit(
            "encode",
            record.id,
            valence=round(record.affect.valence, 2),
            arousal=round(record.affect.arousal, 2),
            gain=round(gain, 3),
        )
        return WriteResult(op=WriteOp.ADD, record_id=record.id, reason=f"gain={gain:.2f}")

    # ------------------------------------------------------------- leitura
    def read(self, query: MemoryQuery) -> list[Retrieved]:
        """Composto + congruência de humor (Bower, 1981)."""
        now = self.now(query.as_of)
        query.with_vector(self.embedder)
        cands = self.candidates(query, now)
        if not cands:
            return []
        base = composite_score(cands, query.vector, now, self.weights)
        out: list[Retrieved] = []
        for rec, s in zip(cands, base, strict=True):
            congr = 1.0 - abs(rec.affect.valence - self.mood.valence) / 2.0
            # humor neutro não enviesa: o termo só pesa quando há humor declarado
            weight = self.congruence * abs(self.mood.valence)
            score = s + weight * congr
            out.append(
                Retrieved(
                    record=rec,
                    score=score,
                    subsystem=self.name,
                    rationale={
                        "composite": s,
                        "congruence": congr,
                        "valence": rec.affect.valence,
                        "arousal": rec.affect.arousal,
                    },
                )
            )
        out.sort(key=lambda r: -r.score)
        top = out[: query.top_k]
        self.touch_all([r.record for r in top], now)
        return top

    # -------------------------------------------------------------- extras
    def by_valence(self, *, positive: bool, top_k: int = 5) -> list[MemoryRecord]:
        recs = [
            r
            for r in self.store.scan(kind=MemoryKind.AFFECTIVE)
            if (r.affect.valence > 0) == positive and r.affect.valence != 0
        ]
        recs.sort(key=lambda r: -abs(r.affect.valence))
        return recs[:top_k]

    def consolidate(self, now: float | None = None) -> ConsolidationReport:
        """Reforço preferencial: traços de alto arousal ganham um toque de consolidação."""
        t = self.now(now)
        report = ConsolidationReport(subsystem=self.name)
        for rec in self.store.scan(kind=MemoryKind.AFFECTIVE):
            if rec.affect.arousal >= 0.5 and rec.is_live(t):
                rec.decay.touch(t, reinforce=0.3 * rec.affect.arousal)
                self.store.put(rec)
                report.promoted += 1
        return report

    def forget(self, now: float | None = None) -> ForgetReport:
        """Neutro e frio esquece mais rápido; emocional resiste."""
        t = self.now(now)
        evicted = 0
        for rec in list(self.store.scan(kind=MemoryKind.AFFECTIVE)):
            floor = 0.05 * (1.0 - 0.8 * rec.affect.arousal)
            if rec.retention(t) < floor and rec.importance < 0.6:
                self.store.delete(rec.id)
                evicted += 1
        return ForgetReport(subsystem=self.name, evicted=evicted, retained=self.size())

    def stats(self) -> dict[str, Any]:
        s = super().stats()
        recs = list(self.store.scan(kind=MemoryKind.AFFECTIVE))
        n = len(recs) or 1
        s.update(
            {
                "mood": self.mood.to_dict(),
                "mean_valence": round(sum(r.affect.valence for r in recs) / n, 3),
                "mean_arousal": round(sum(r.affect.arousal for r in recs) / n, 3),
                "high_arousal": sum(1 for r in recs if r.affect.arousal >= 0.5),
            }
        )
        return s
