"""[EMERGENTE 6/11] Índice hipocampal — passagens ligadas por entidades, recuperadas por PPR.

HippoRAG (Gutiérrez et al., 2024, arXiv:2405.14831), sobre a teoria da
indexação hipocampal (Teyler & DiScenna, 1986): o neocórtex guarda as
passagens; o hipocampo guarda um **índice esparso** de entidades e relações
que aponta para elas; recuperar é *completar um padrão* — ativar as entidades
da consulta e deixar a ativação se espalhar pelo índice até as passagens.

Mecanismo, aqui:

1. **Indexação.** De cada passagem saem triplas (extrator por padrões) e nomes
   próprios; cada entidade vira um nó; a passagem vira um nó ligado às suas
   entidades; triplas viram arestas entidade-entidade. Entidades com nomes
   diferentes e embeddings próximos ganham arestas de *sinonímia*.
2. **Recuperação.** As entidades da consulta são as sementes de um
   Personalized PageRank com `damping=0.5` (o valor do paper: mais baixo que
   o PageRank clássico, porque memória quer sinal local à consulta). A massa
   que chega aos nós de passagem é o score.

O que isso compra é **multi-hop num único passo**: "que moeda usa o país da
empresa da Ana?" ativa `ana`, a massa flui para a passagem que a liga à
empresa, dali à entidade empresa, à passagem que liga a empresa ao país, e
assim por diante — sem uma cadeia de consultas.
"""

from __future__ import annotations

from typing import Any

from ..core.base import (
    ConsolidationReport,
    ForgetReport,
    MemoryQuery,
    MemorySubsystem,
    Retrieved,
    WriteResult,
)
from ..core.conflict import proper_nouns
from ..core.embeddings import noise_floor_of
from ..core.extract import PatternTripleExtractor, TripleExtractor
from ..core.graph import Edge, Graph
from ..core.record import MemoryRecord
from ..core.similarity import cosine
from ..core.text import content_words, fold
from ..core.types import MemoryForm, MemoryFunction, MemoryKind, WriteOp

__all__ = ["HippocampalMemory"]

PSG = "psg:"
ENT = "ent:"


class HippocampalMemory(MemorySubsystem):
    """Passagens + índice de entidades; recuperação por Personalized PageRank.

    Parameters
    ----------
    damping:
        Fator de amortecimento do PPR (0.5 no HippoRAG).
    synonym_threshold:
        Cosseno mínimo entre nomes de entidade para uma aresta de sinonímia.
        `None` ancora em 3x o piso de ruído do embedder — bem acima do ruído,
        porque sinonímia falsa funde entidades distintas para sempre.
    dense_weight:
        Peso da similaridade densa consulta-passagem somada ao PPR. Serve
        para desempatar e para consultas sem entidade reconhecível.
    """

    kind = MemoryKind.HIPPOCAMPAL
    emergent = True

    def __init__(
        self,
        *,
        extractor: TripleExtractor | None = None,
        damping: float = 0.5,
        synonym_threshold: float | None = None,
        dense_weight: float = 0.3,
        max_seeds: int = 8,
        **kw: Any,
    ) -> None:
        super().__init__(**kw)
        floor = noise_floor_of(self.embedder, 0.1)
        self.extractor = extractor or PatternTripleExtractor()
        self.damping = damping
        self.synonym_threshold = floor * 3.0 if synonym_threshold is None else synonym_threshold
        self.dense_weight = dense_weight
        self.max_seeds = max_seeds
        self.graph = Graph()
        self._entity_vec: dict[str, tuple[float, ...]] = {}
        self._entities_of: dict[str, list[str]] = {}
        self._synonyms = 0

    # ------------------------------------------------------------ índice
    def _entities(self, text: str) -> list[str]:
        names: list[str] = []
        for t in self.extractor.extract(text):
            for e in (t.subject, t.object):
                if e and e not in names:
                    names.append(e)
        for pn in sorted(proper_nouns(text)):
            if pn not in names:
                names.append(pn)
        return names

    def _add_entity(self, name: str) -> str:
        node = ENT + name
        if node in self.graph.nodes:
            return node
        self.graph.add_node(node)
        vec = self.embedder.encode(name.replace("_", " "))
        # sinonímia: liga ao(s) nome(s) mais próximo(s) acima do limiar
        for other, ovec in self._entity_vec.items():
            sim = cosine(vec, ovec)
            if sim >= self.synonym_threshold:
                self.graph.add_edge(Edge(node, other, "synonym", sim))
                self._synonyms += 1
        self._entity_vec[node] = vec
        return node

    # ------------------------------------------------------------- escrita
    def write(self, record: MemoryRecord) -> WriteResult:
        now = self.now()
        record.kind = MemoryKind.HIPPOCAMPAL
        record.form = MemoryForm.TOKEN
        record.function = MemoryFunction.FACTUAL
        if record.created_at == 0.0:
            record.created_at = now
            record.updated_at = now
            record.decay.last_access = now
        self.ensure_embedding(record)
        self.store.put(record)

        pnode = PSG + record.id
        self.graph.add_node(pnode)
        names = self._entities(record.content)
        enodes: list[str] = []
        for n in names:
            en = self._add_entity(n)
            enodes.append(en)
            self.graph.add_edge(Edge(pnode, en, "mentions", 1.0, record.id))
        for t in self.extractor.extract(record.content):
            self.graph.add_edge(Edge(ENT + t.subject, ENT + t.object, t.relation, 1.0, record.id))
        self._entities_of[record.id] = enodes
        record.payload["entities"] = names
        self.store.put(record)
        self.emit("index", record.id, entities=len(names))
        return WriteResult(op=WriteOp.ADD, record_id=record.id, reason=f"entities={len(names)}")

    # ------------------------------------------------------------- leitura
    def seeds_for(self, text: str) -> dict[str, float]:
        """Nós-semente: entidades da consulta que existem no índice."""
        seeds: dict[str, float] = {}
        known = self.graph.nodes
        for n in self._entities(text):
            node = ENT + n
            if node in known:
                seeds[node] = 1.0
        # palavras de conteúdo que casam exatamente um nome de entidade: semente fraca
        for w in content_words(text):
            node = ENT + fold(w)
            if node in known:
                seeds[node] = max(seeds.get(node, 0.0), 0.5)
        if len(seeds) > self.max_seeds:
            seeds = dict(sorted(seeds.items(), key=lambda kv: -kv[1])[: self.max_seeds])
        return seeds

    def read(self, query: MemoryQuery) -> list[Retrieved]:
        now = self.now(query.as_of)
        query.with_vector(self.embedder)
        cands = {r.id: r for r in self.candidates(query, now)}
        if not cands:
            return []
        seeds = self.seeds_for(query.text) if query.text else {}
        rank = self.graph.personalized_pagerank(seeds, damping=self.damping) if seeds else {}
        ppr = {rid: rank.get(PSG + rid, 0.0) for rid in cands}
        max_ppr = max(ppr.values()) if ppr else 0.0
        out: list[Retrieved] = []
        for rid, rec in cands.items():
            p = ppr[rid] / max_ppr if max_ppr > 0 else 0.0
            d = cosine(query.vector, rec.embedding)
            score = p + self.dense_weight * d
            out.append(
                Retrieved(
                    record=rec,
                    score=score,
                    subsystem=self.name,
                    rationale={"ppr": p, "dense": d, "seeds": float(len(seeds))},
                )
            )
        out.sort(key=lambda r: -r.score)
        top = [r for r in out if r.score > 0][: query.top_k]
        self.touch_all([r.record for r in top], now)
        return top

    # -------------------------------------------------------------- extras
    def entities(self) -> list[str]:
        return sorted(n[len(ENT) :] for n in self.graph.nodes if n.startswith(ENT))

    def passages_about(self, entity: str) -> list[MemoryRecord]:
        node = ENT + fold(entity).replace(" ", "_")
        out: list[MemoryRecord] = []
        for e in self.graph.in_edges(node):
            if e.relation == "mentions" and e.source.startswith(PSG):
                rec = self.store.get(e.source[len(PSG) :])
                if rec is not None:
                    out.append(rec)
        return out

    def consolidate(self, now: float | None = None) -> ConsolidationReport:
        """Comunidades por propagação de rótulos -> `payload["community"]` de cada passagem."""
        report = ConsolidationReport(subsystem=self.name)
        if not len(self.graph):
            return report
        labels = self.graph.label_propagation()
        n = 0
        for rid in list(self._entities_of):
            rec = self.store.get(rid)
            if rec is None:
                continue
            label = labels.get(PSG + rid, "")
            if rec.payload.get("community") != label:
                rec.payload["community"] = label
                self.store.put(rec)
                n += 1
        report.promoted = n
        report.notes.append(f"{len(set(labels.values()))} comunidades")
        return report

    def forget(self, now: float | None = None) -> ForgetReport:
        """Passagem de baixa retenção cujas entidades continuam cobertas por outras sai."""
        t = self.now(now)
        evicted = 0
        for rid in list(self._entities_of):
            rec = self.store.get(rid)
            if rec is None:
                continue
            if rec.retention(t) >= 0.05 or rec.importance >= 0.5:
                continue
            covered = all(
                any(
                    e.source != PSG + rid
                    for e in self.graph.in_edges(en)
                    if e.relation == "mentions"
                )
                for en in self._entities_of[rid]
            )
            if not covered:
                continue
            for en in self._entities_of[rid]:
                self.graph.remove_edge(PSG + rid, "mentions", en)
            self.store.delete(rid)
            self._entities_of.pop(rid, None)
            evicted += 1
        return ForgetReport(subsystem=self.name, evicted=evicted, retained=self.size())

    def stats(self) -> dict[str, Any]:
        s = super().stats()
        g = self.graph.stats()
        s.update(
            {
                "entities": len(self._entity_vec),
                "passages": len(self._entities_of),
                "edges": g["edges"],
                "synonym_edges": self._synonyms,
            }
        )
        return s
