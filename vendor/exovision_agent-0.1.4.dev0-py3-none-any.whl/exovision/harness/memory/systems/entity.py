"""[TRADICIONAL 9/10] Memória de entidade — perfis e slots com proveniência.

Não é "mais um índice de texto": é um armazém *estruturado* chave-valor por
entidade, onde cada slot carrega sua própria história, confiança e proveniência.
É o formato que sustenta personalização (MemoryBank, Zhong et al., 2023;
`ConversationEntityMemory` do LangChain) e é o que um agente realmente injeta no
prompt como "o que eu sei sobre você".

A resolução de escrita usa a mesma ordem de precedência do resto do SDK:
(1) confiança da fonte, depois (2) recência. Última-escrita-vence puro é o que
faz um agente adotar o palpite de uma ferramenta por cima de uma afirmação
explícita do usuário.
"""

from __future__ import annotations

import re
from collections.abc import Iterable
from dataclasses import dataclass, field
from typing import Any

from ..core.base import (
    ConsolidationReport,
    ForgetReport,
    MemoryQuery,
    MemorySubsystem,
    Retrieved,
    WriteResult,
)
from ..core.conflict import detect_conflict
from ..core.record import MemoryRecord, Provenance
from ..core.similarity import cosine
from ..core.text import fold
from ..core.types import MemoryForm, MemoryFunction, MemoryKind, TrustTier, WriteOp

__all__ = ["EntityMemory", "Slot", "SlotValue"]


@dataclass(slots=True)
class SlotValue:
    value: str
    at: float
    trust: TrustTier = TrustTier.DERIVED
    confidence: float = 1.0
    provenance: Provenance = field(default_factory=Provenance)
    record_id: str = ""


@dataclass(slots=True)
class Slot:
    """Um atributo de uma entidade, com histórico completo de versões."""

    key: str
    current: SlotValue
    history: list[SlotValue] = field(default_factory=list)

    def versions(self) -> list[SlotValue]:
        return [*self.history, self.current]

    def as_of(self, t: float) -> SlotValue | None:
        best: SlotValue | None = None
        for v in self.versions():
            if v.at <= t and (best is None or v.at >= best.at):
                best = v
        return best


class EntityMemory(MemorySubsystem):
    """Perfis por entidade com slots versionados."""

    kind = MemoryKind.ENTITY

    def __init__(self, *, max_history: int = 32, **kw: Any) -> None:
        super().__init__(**kw)
        self.max_history = max_history
        self._profiles: dict[str, dict[str, Slot]] = {}
        self._aliases: dict[str, str] = {}

    # ------------------------------------------------------- normalização
    def canonical(self, entity: str) -> str:
        key = fold(entity).strip()
        return self._aliases.get(key, key)

    def alias(self, alias: str, canonical: str) -> None:
        """Resolução de identidade: 'o usuário' == 'matheus' == 'mt'."""
        self._aliases[fold(alias).strip()] = fold(canonical).strip()

    # ------------------------------------------------------------- escrita
    def set(
        self,
        entity: str,
        key: str,
        value: str,
        *,
        trust: TrustTier = TrustTier.DERIVED,
        confidence: float = 1.0,
        provenance: Provenance | None = None,
        at: float | None = None,
    ) -> WriteResult:
        now = self.now(at)
        ent = self.canonical(entity)
        slot_key = fold(key).strip()
        profile = self._profiles.setdefault(ent, {})
        prov = provenance or Provenance()

        rec = MemoryRecord(
            content=f"{entity}.{key} = {value}",
            kind=MemoryKind.ENTITY,
            created_at=now,
            updated_at=now,
            valid_from=now,
            form=MemoryForm.TOKEN,
            function=MemoryFunction.FACTUAL,
            trust=trust,
            confidence=confidence,
            provenance=prov,
            importance=0.7,
            payload={"entity": ent, "slot": slot_key, "value": value},
        )
        self.ensure_embedding(rec)

        new_value = SlotValue(
            value=value, at=now, trust=trust, confidence=confidence, provenance=prov, record_id=rec.id
        )
        existing = profile.get(slot_key)
        if existing is None:
            profile[slot_key] = Slot(key=slot_key, current=new_value)
            self.store.put(rec)
            self.emit("slot_set", rec.id, entity=ent, slot=slot_key)
            return WriteResult(op=WriteOp.ADD, record_id=rec.id)

        cur = existing.current
        if fold(cur.value) == fold(value):
            cur.confidence = max(cur.confidence, confidence)
            cur.trust = max(cur.trust, trust, key=int)
            return WriteResult(op=WriteOp.NOOP, record_id=cur.record_id, reason="valor_igual", accepted=False)

        # Precedência: confiança da fonte primeiro, recência só como desempate.
        if int(trust) < int(cur.trust):
            self.emit("slot_reject", rec.id, entity=ent, slot=slot_key, reason="fonte_mais_fraca")
            return WriteResult(
                op=WriteOp.NOOP,
                record_id=cur.record_id,
                reason=f"mantido_valor_de_fonte_superior({cur.trust.name})",
                accepted=False,
            )

        old_rec = self.store.get(cur.record_id)
        if old_rec is not None:
            old_rec.invalidate(now)
            self.store.put(old_rec)
        existing.history.append(cur)
        if len(existing.history) > self.max_history:
            del existing.history[: len(existing.history) - self.max_history]
        existing.current = new_value
        self.store.put(rec)
        conflict = detect_conflict(cur.value, value)
        self.emit("slot_update", rec.id, entity=ent, slot=slot_key, conflict=conflict.kind.value)
        return WriteResult(
            op=WriteOp.UPDATE, record_id=rec.id, superseded=(cur.record_id,), reason=conflict.kind.value
        )

    def write(self, record: MemoryRecord) -> WriteResult:
        """Aceita `payload={'entity','slot','value'}` ou infere de 'X.y = z'."""
        entity = record.payload.get("entity")
        slot = record.payload.get("slot")
        value = record.payload.get("value")
        if not (entity and slot and value is not None):
            m = re.match(r"\s*([^.=]+)\.([^=]+?)\s*=\s*(.+)", record.content)
            if not m:
                raise ValueError(
                    "EntityMemory.write exige payload {entity, slot, value} "
                    "ou conteúdo no formato 'entidade.slot = valor'"
                )
            entity, slot, value = m.group(1).strip(), m.group(2).strip(), m.group(3).strip()
        return self.set(
            entity,
            slot,
            str(value),
            trust=record.trust,
            confidence=record.confidence,
            provenance=record.provenance,
            at=record.created_at or None,
        )

    # ------------------------------------------------------------- leitura
    def get(self, entity: str, key: str, *, at: float | None = None) -> SlotValue | None:
        slot = self._profiles.get(self.canonical(entity), {}).get(fold(key).strip())
        if slot is None:
            return None
        return slot.as_of(at) if at is not None else slot.current

    def profile(self, entity: str, *, at: float | None = None) -> dict[str, str]:
        out: dict[str, str] = {}
        for key, slot in self._profiles.get(self.canonical(entity), {}).items():
            v = slot.as_of(at) if at is not None else slot.current
            if v is not None:
                out[key] = v.value
        return out

    def render(self, entity: str, *, at: float | None = None) -> str:
        """Bloco de perfil pronto para injetar no prompt."""
        prof = self.profile(entity, at=at)
        if not prof:
            return ""
        lines = [f"# Perfil: {entity}"]
        lines.extend(f"- {k}: {v}" for k, v in sorted(prof.items()))
        return "\n".join(lines)

    def entities(self) -> Iterable[str]:
        return tuple(self._profiles)

    def read(self, query: MemoryQuery) -> list[Retrieved]:
        now = self.now(query.as_of)
        query.with_vector(self.embedder)
        wanted = query.filters.get("entity")
        out: list[Retrieved] = []
        for rec in self.candidates(query, now):
            if wanted and rec.payload.get("entity") != self.canonical(str(wanted)):
                continue
            rel = cosine(query.vector, rec.embedding) if query.vector else 0.0
            trust_w = int(rec.trust) / int(TrustTier.VERIFIED)
            out.append(
                Retrieved(
                    record=rec,
                    score=0.7 * rel + 0.3 * trust_w,
                    subsystem=self.name,
                    rationale={"relevance": rel, "trust": trust_w, "entity": rec.payload.get("entity", "")},
                )
            )
        out.sort(key=lambda r: -r.score)
        return out[: query.top_k]

    def consolidate(self, now: float | None = None) -> ConsolidationReport:
        """Funde entidades cujos perfis são consistentes e cujos nomes colidem."""
        report = ConsolidationReport(subsystem=self.name)
        names = list(self._profiles)
        for i, a in enumerate(names):
            for b in names[i + 1 :]:
                if a not in self._profiles or b not in self._profiles:
                    continue
                if not (a in b or b in a):  # colisão de nome por substring
                    continue
                pa, pb = self._profiles[a], self._profiles[b]
                shared = set(pa) & set(pb)
                if any(
                    detect_conflict(pa[k].current.value, pb[k].current.value) for k in shared
                ):
                    continue  # perfis discordam: não são a mesma entidade
                target, source = (a, b) if len(pa) >= len(pb) else (b, a)
                for k, slot in self._profiles[source].items():
                    self._profiles[target].setdefault(k, slot)
                self._profiles.pop(source, None)
                self._aliases[source] = target
                report.merged += 1
                report.notes.append(f"{source} -> {target}")
        return report

    def forget(self, now: float | None = None) -> ForgetReport:
        """Poda histórico antigo dos slots, mantendo sempre o valor corrente."""
        demoted = 0
        for profile in self._profiles.values():
            for slot in profile.values():
                if len(slot.history) > self.max_history // 2:
                    cut = len(slot.history) - self.max_history // 2
                    for v in slot.history[:cut]:
                        self.store.delete(v.record_id)
                    del slot.history[:cut]
                    demoted += cut
        return ForgetReport(subsystem=self.name, demoted=demoted, retained=self.size())

    def stats(self) -> dict[str, Any]:
        s = super().stats()
        slots = sum(len(p) for p in self._profiles.values())
        s.update(
            {
                "entities": len(self._profiles),
                "slots": slots,
                "aliases": len(self._aliases),
                "versions": sum(len(sl.versions()) for p in self._profiles.values() for sl in p.values()),
            }
        )
        return s
