"""[EMERGENTE 7/11] Memória prospectiva — lembrar de *fazer* no futuro.

Memória prospectiva (Einstein & McDaniel, 1990) é a que sustenta intenções
adiadas: "quando X acontecer, faça Y". Três tipos canônicos, os três aqui:

* **baseada em tempo** — dispara num instante ("às 15h, rodar o backup");
* **baseada em evento** — dispara quando um *cue* aparece no contexto
  ("quando o usuário mencionar o deploy, lembrar do certificado");
* **baseada em atividade** — dispara ao fim de outra tarefa ("depois dos
  testes, atualizar o changelog").

PM-Bench (2026, arXiv:2607.12385) mostra que agentes de linguagem falham
sistematicamente nas três — a intenção é registrada e nunca resgatada porque
nada a *verifica* a cada passo. Este subsistema existe para ser verificado:
`check(now, context)` é chamado pelo harness a cada volta e devolve o que
disparou; `pending()` mostra o que ainda espera. PIS (arXiv:2609.01272)
motiva a urgência crescente: uma intenção vencida e não cumprida sobe de
importância em vez de sumir.
"""

from __future__ import annotations

from collections.abc import Iterable
from typing import Any

from ..core.base import (
    ConsolidationReport,
    ForgetReport,
    MemoryQuery,
    MemorySubsystem,
    Retrieved,
    WriteResult,
)
from ..core.clock import SECONDS_PER_HOUR
from ..core.embeddings import noise_floor_of
from ..core.record import MemoryRecord
from ..core.similarity import cosine
from ..core.text import content_words
from ..core.types import MemoryForm, MemoryFunction, MemoryKind, WriteOp

__all__ = ["ProspectiveMemory"]


class ProspectiveMemory(MemorySubsystem):
    """Intenções com gatilho de tempo, de evento ou de atividade.

    Parameters
    ----------
    cue_threshold:
        Cosseno mínimo entre o contexto corrente e o cue para disparar uma
        intenção baseada em evento. `None` ancora em 3x o piso de ruído.
    grace_s:
        Tolerância após o instante alvo antes de contar como *perdida*.
    escalation:
        Quanto a importância sobe por hora de atraso (PIS).
    """

    kind = MemoryKind.PROSPECTIVE
    emergent = True

    def __init__(
        self,
        *,
        cue_threshold: float | None = None,
        grace_s: float = 6 * SECONDS_PER_HOUR,
        escalation: float = 0.05,
        retention_s: float = 7 * 24 * SECONDS_PER_HOUR,
        **kw: Any,
    ) -> None:
        super().__init__(**kw)
        floor = noise_floor_of(self.embedder, 0.1)
        self.cue_threshold = floor * 3.0 if cue_threshold is None else cue_threshold
        self.grace_s = grace_s
        self.escalation = escalation
        self.retention_s = retention_s
        self.fired = 0
        self.missed = 0

    # ------------------------------------------------------------- escrita
    def intend(
        self,
        content: str,
        *,
        at: float | None = None,
        cue: str | None = None,
        after: str | None = None,
        importance: float = 0.7,
        **meta: Any,
    ) -> WriteResult:
        """Registra uma intenção. Pelo menos um gatilho: `at`, `cue` ou `after`."""
        if at is None and cue is None and after is None:
            return WriteResult.noop("intenção sem gatilho: informe at=, cue= ou after=")
        rec = MemoryRecord(
            content=content,
            importance=importance,
            payload={"trigger": {"at": at, "cue": cue, "after": after}, **meta},
        )
        return self.write(rec)

    def write(self, record: MemoryRecord) -> WriteResult:
        """Escrita genérica: sem gatilho explícito, o próprio conteúdo é o cue."""
        now = self.now()
        record.kind = MemoryKind.PROSPECTIVE
        record.form = MemoryForm.TOKEN
        record.function = MemoryFunction.WORKING
        if record.created_at == 0.0:
            record.created_at = now
            record.updated_at = now
            record.decay.last_access = now
        trig = dict(record.payload.get("trigger") or {})
        if not any(trig.get(k) is not None for k in ("at", "cue", "after")):
            trig = {"at": None, "cue": record.content, "after": None}
        record.payload["trigger"] = trig
        record.payload.setdefault("status", "pending")
        if trig.get("cue"):
            record.payload["cue_vec"] = list(self.embedder.encode(str(trig["cue"])))
        if trig.get("at") is not None:
            record.valid_from = None  # a intenção é visível antes do alvo (é o que se planeja)
        self.ensure_embedding(record)
        self.store.put(record)
        self.emit("intend", record.id, trigger={k: v for k, v in trig.items() if v is not None})
        return WriteResult(op=WriteOp.ADD, record_id=record.id)

    # ------------------------------------------------------------ gatilhos
    def check(
        self, now: float | None = None, context: str = "", completed: Iterable[str] = ()
    ) -> list[MemoryRecord]:
        """Verifica todas as intenções pendentes; devolve as que dispararam.

        Chamado a cada passo do agente. Uma intenção dispara uma vez; depois
        fica `fired` até `complete()` ou até o esquecimento.
        """
        t = self.now(now)
        done = {c.strip().lower() for c in completed if c}
        ctx_vec = self.embedder.encode(context) if context else None
        ctx_words = set(content_words(context)) if context else set()
        fired: list[MemoryRecord] = []
        for rec in self._pending(t):
            trig = rec.payload["trigger"]
            why = ""
            if trig.get("at") is not None and t >= float(trig["at"]):
                why = "time"
            elif trig.get("cue") and ctx_vec is not None:
                sim = cosine(ctx_vec, tuple(rec.payload.get("cue_vec") or ()))
                cue_words = set(content_words(str(trig["cue"])))
                overlap = len(cue_words & ctx_words) / len(cue_words) if cue_words else 0.0
                if sim >= self.cue_threshold or overlap >= 0.6:
                    why = "cue"
            elif trig.get("after") and str(trig["after"]).strip().lower() in done:
                why = "activity"
            if why:
                rec.payload["status"] = "fired"
                rec.payload["fired_at"] = t
                rec.payload["fired_by"] = why
                rec.updated_at = t
                rec.decay.touch(t)
                self.store.put(rec)
                self.fired += 1
                self.emit("fire", rec.id, by=why)
                fired.append(rec)
        return fired

    def complete(self, record_id: str, now: float | None = None) -> bool:
        rec = self.store.get(record_id)
        if rec is None:
            return False
        t = self.now(now)
        rec.payload["status"] = "done"
        rec.invalidate(t)
        self.store.put(rec)
        self.emit("complete", record_id)
        return True

    def _pending(self, t: float) -> list[MemoryRecord]:
        return [
            r
            for r in self.store.scan(kind=MemoryKind.PROSPECTIVE)
            if r.payload.get("status") == "pending" and r.is_live(t)
        ]

    def pending(self, now: float | None = None) -> list[MemoryRecord]:
        t = self.now(now)
        out = self._pending(t)
        out.sort(
            key=lambda r: (
                self._hours_until(r, t) if self._hours_until(r, t) is not None else 1e9,
                -r.importance,
            )
        )
        return out

    def overdue(self, now: float | None = None) -> list[MemoryRecord]:
        t = self.now(now)
        return [
            r
            for r in self.store.scan(kind=MemoryKind.PROSPECTIVE)
            if r.payload.get("status") == "fired" and r.is_live(t)
        ]

    @staticmethod
    def _hours_until(rec: MemoryRecord, t: float) -> float | None:
        at = rec.payload.get("trigger", {}).get("at")
        return (float(at) - t) / SECONDS_PER_HOUR if at is not None else None

    # ------------------------------------------------------------- leitura
    def read(self, query: MemoryQuery) -> list[Retrieved]:
        """Pendentes e disparadas, por relevância + urgência + importância."""
        t = self.now(query.as_of)
        query.with_vector(self.embedder)
        out: list[Retrieved] = []
        for rec in self.candidates(query, t):
            status = rec.payload.get("status", "pending")
            if status == "done":
                continue
            rel = cosine(query.vector, rec.embedding) if query.vector is not None else 0.0
            h = self._hours_until(rec, t)
            if status == "fired":
                urgency = 1.0
            elif h is None:
                urgency = 0.3
            else:
                urgency = 1.0 / (1.0 + max(h, 0.0))
            score = 0.5 * rel + 0.3 * urgency + 0.2 * rec.importance
            out.append(
                Retrieved(
                    record=rec,
                    score=score,
                    subsystem=self.name,
                    rationale={
                        "relevance": rel,
                        "urgency": urgency,
                        "importance": rec.importance,
                        "fired": float(status == "fired"),
                    },
                )
            )
        out.sort(key=lambda r: -r.score)
        return out[: query.top_k]

    # ------------------------------------------------------- consolidação
    def consolidate(self, now: float | None = None) -> ConsolidationReport:
        """Escalada (PIS): intenção disparada e não cumprida sobe de importância."""
        t = self.now(now)
        report = ConsolidationReport(subsystem=self.name)
        for rec in self.overdue(t):
            hours = (t - float(rec.payload.get("fired_at", t))) / SECONDS_PER_HOUR
            new_imp = min(1.0, rec.importance + self.escalation * hours)
            if new_imp > rec.importance:
                rec.importance = new_imp
                self.store.put(rec)
                report.promoted += 1
        return report

    def forget(self, now: float | None = None) -> ForgetReport:
        """Concluídas antigas saem; alvos de tempo vencidos sem disparo viram *perdidas*."""
        t = self.now(now)
        evicted = invalidated = 0
        for rec in list(self.store.scan(kind=MemoryKind.PROSPECTIVE)):
            status = rec.payload.get("status")
            at = rec.payload.get("trigger", {}).get("at")
            if status == "pending" and at is not None and t > float(at) + self.grace_s:
                rec.payload["status"] = "missed"
                rec.expire(t)
                self.store.put(rec)
                self.missed += 1
                invalidated += 1
                self.emit("miss", rec.id)
            elif (
                status in ("done", "missed")
                and (rec.valid_to or rec.expired_at or t) + self.retention_s < t
            ):
                self.store.delete(rec.id)
                evicted += 1
        return ForgetReport(
            subsystem=self.name, evicted=evicted, invalidated=invalidated, retained=self.size()
        )

    def stats(self) -> dict[str, Any]:
        s = super().stats()
        t = self.now()
        s.update(
            {
                "pending": len(self._pending(t)),
                "overdue": len(self.overdue(t)),
                "fired": self.fired,
                "missed": self.missed,
            }
        )
        return s
