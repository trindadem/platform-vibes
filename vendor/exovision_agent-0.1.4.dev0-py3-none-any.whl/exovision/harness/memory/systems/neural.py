"""[EMERGENTE 5/11] Memória neural — pesos atualizados em tempo de teste.

Titans (Behrouz, Zhong & Mirrokni, 2025, arXiv:2501.00663): a memória de longo
prazo é um módulo cujos **parâmetros** são atualizados durante a inferência,
por descida de gradiente sobre uma perda associativa. Três ideias que o paper
introduz e que este módulo reproduz numa memória associativa linear:

* **Surpresa como sinal de escrita.** A "surpresa momentânea" é o gradiente
  da perda ||M.k - v||^2 — quanto pior a memória prevê o valor a partir da chave,
  mais ela muda. Eventos esperados quase não alteram os pesos.
* **Surpresa passada (momento).** O gradiente entra por um acumulador com
  momento eta, de modo que uma sequência de eventos surpreendentes segue
  escrevendo mesmo quando o evento corrente é banal.
* **Portão de esquecimento.** Um decaimento alpha por passo (weight decay)
  impede a memória de saturar; é o análogo paramétrico da curva de Ebbinghaus.

A representação é `MemoryForm.PARAMETRIC`: o que fica são pesos, não texto.
Os registros continuam no `store` para auditoria e para o `read` devolver
algo legível — a memória neural *ranqueia* registros pela concordância entre o
valor recuperado M·q e o valor de cada um. Reconstruir texto a partir dos
pesos não é possível, e isso é dito aqui em vez de escondido.

Implementação em stdlib pura: uma projeção aleatória (Johnson-Lindenstrauss,
semente fixa) leva o embedding a `dim` dimensões, e a memória é uma matriz
`dim x dim`. Com `dim=64` cada escrita custa ~8k multiplicações.
"""

from __future__ import annotations

import math
import random
from collections.abc import Sequence
from typing import Any

from ..core.base import (
    ConsolidationReport,
    ForgetReport,
    MemoryQuery,
    MemorySubsystem,
    Retrieved,
    WriteResult,
)
from ..core.record import MemoryRecord
from ..core.similarity import cosine
from ..core.types import MemoryForm, MemoryFunction, MemoryKind, WriteOp

__all__ = ["NeuralMemory"]

Vec = list[float]
Mat = list[list[float]]


def _matvec(m: Mat, v: Sequence[float]) -> Vec:
    return [sum(row[i] * v[i] for i in range(len(v))) for row in m]


def _norm(v: Sequence[float]) -> float:
    return math.sqrt(sum(x * x for x in v)) or 1.0


class NeuralMemory(MemorySubsystem):
    """Memória associativa com atualização por surpresa, momento e esquecimento.

    Parameters
    ----------
    dim:
        Dimensão interna após a projeção aleatória.
    lr:
        theta — taxa de aprendizado (quanto a surpresa momentânea escreve).
    momentum:
        eta — peso da surpresa passada; 0 desliga o momento.
    forget:
        alpha — decaimento dos pesos por passo, em [0,1). 0 desliga o esquecimento.
    seed:
        Semente das projeções (determinismo para calibração e testes).
    """

    kind = MemoryKind.NEURAL
    emergent = True

    def __init__(
        self,
        *,
        dim: int = 64,
        lr: float = 0.5,
        momentum: float = 0.6,
        forget: float = 0.01,
        seed: int = 0,
        **kw: Any,
    ) -> None:
        super().__init__(**kw)
        if not 0.0 <= forget < 1.0:
            raise ValueError("forget (alpha) precisa estar em [0, 1)")
        self.dim = dim
        self.lr = lr
        self.momentum = momentum
        self.alpha = forget  # `forget` é o verbo da interface; o parâmetro vira alpha
        self.seed = seed
        self._proj_k: Mat | None = None
        self._proj_v: Mat | None = None
        self.M: Mat = [[0.0] * dim for _ in range(dim)]
        self.S: Mat = [[0.0] * dim for _ in range(dim)]
        self._values: dict[str, Vec] = {}
        self._keys: dict[str, Vec] = {}
        self.steps = 0
        self._surprise_history: list[float] = []

    # ---------------------------------------------------------- projeções
    def _projections(self, in_dim: int) -> tuple[Mat, Mat]:
        if self._proj_k is None or len(self._proj_k[0]) != in_dim:
            rng = random.Random(self.seed)
            scale = 1.0 / math.sqrt(self.dim)
            self._proj_k = [[rng.gauss(0.0, scale) for _ in range(in_dim)] for _ in range(self.dim)]
            self._proj_v = [[rng.gauss(0.0, scale) for _ in range(in_dim)] for _ in range(self.dim)]
        assert self._proj_v is not None
        return self._proj_k, self._proj_v

    def _kv(self, embedding: Sequence[float]) -> tuple[Vec, Vec]:
        pk, pv = self._projections(len(embedding))
        k = _matvec(pk, embedding)
        v = _matvec(pv, embedding)
        nk, nv = _norm(k), _norm(v)
        return [x / nk for x in k], [x / nv for x in v]

    # ---------------------------------------------------------- dinâmica
    def surprise(self, k: Sequence[float], v: Sequence[float]) -> float:
        """||M.k - v|| — a surpresa momentânea (norma do erro de predição)."""
        pred = _matvec(self.M, k)
        return math.sqrt(sum((pred[i] - v[i]) ** 2 for i in range(self.dim)))

    def _step(self, k: Vec, v: Vec) -> float:
        """Uma atualizacao: S <- eta*S - theta*grad(loss) ; M <- (1-alpha)*M + S."""
        pred = _matvec(self.M, k)
        err = [pred[i] - v[i] for i in range(self.dim)]
        s = math.sqrt(sum(e * e for e in err))
        for i in range(self.dim):
            row_s = self.S[i]
            row_m = self.M[i]
            gi = err[i]
            for j in range(self.dim):
                row_s[j] = self.momentum * row_s[j] - self.lr * gi * k[j]
                row_m[j] = (1.0 - self.alpha) * row_m[j] + row_s[j]
        self.steps += 1
        return s

    # ------------------------------------------------------------- escrita
    def write(self, record: MemoryRecord) -> WriteResult:
        now = self.now()
        record.kind = MemoryKind.NEURAL
        record.form = MemoryForm.PARAMETRIC
        record.function = MemoryFunction.EXPERIENTIAL
        if record.created_at == 0.0:
            record.created_at = now
            record.updated_at = now
            record.decay.last_access = now
        self.ensure_embedding(record)
        k, v = self._kv(record.embedding or ())
        s = self._step(k, v)
        self._keys[record.id] = k
        self._values[record.id] = v
        self._surprise_history.append(s)
        record.salience = s
        record.payload["surprise"] = s
        record.payload["step"] = self.steps
        self.store.put(record)
        self.emit("update", record.id, surprise=round(s, 4), step=self.steps)
        return WriteResult(op=WriteOp.ADD, record_id=record.id, reason=f"surprise={s:.3f}")

    # ------------------------------------------------------------- leitura
    def recall_vector(self, text: str) -> Vec:
        """M·q — o valor associado à consulta, direto dos pesos."""
        k, _ = self._kv(self.embedder.encode(text))
        return _matvec(self.M, k)

    def read(self, query: MemoryQuery) -> list[Retrieved]:
        """Ranqueia registros pela concordância entre M·q e o valor de cada um."""
        now = self.now(query.as_of)
        query.with_vector(self.embedder)
        cands = self.candidates(query, now)
        if not cands or query.vector is None:
            return []
        k, _ = self._kv(query.vector)
        recalled = _matvec(self.M, k)
        out: list[Retrieved] = []
        for rec in cands:
            v = self._values.get(rec.id)
            if v is None:
                continue
            assoc = cosine(recalled, v)
            direct = cosine(query.vector, rec.embedding)
            score = 0.7 * assoc + 0.3 * direct
            out.append(
                Retrieved(
                    record=rec,
                    score=score,
                    subsystem=self.name,
                    rationale={
                        "associative": assoc,
                        "direct": direct,
                        "surprise": rec.payload.get("surprise", 0.0),
                    },
                )
            )
        out.sort(key=lambda r: -r.score)
        top = out[: query.top_k]
        self.touch_all([r.record for r in top], now)
        return top

    # ------------------------------------------------------- consolidação
    def consolidate(self, now: float | None = None, *, epochs: int = 1) -> ConsolidationReport:
        """Replay: reapresenta os registros mais surpreendentes (test-time training)."""
        report = ConsolidationReport(subsystem=self.name)
        def _neg_surprise(i: str) -> float:
            rec = self.store.get(i)
            return -float(rec.payload.get("surprise", 0.0)) if rec is not None else 0.0

        ids = sorted(self._keys, key=_neg_surprise)
        before = [self.surprise(self._keys[i], self._values[i]) for i in ids]
        for _ in range(epochs):
            for i in ids:
                self._step(self._keys[i], self._values[i])
        after = [self.surprise(self._keys[i], self._values[i]) for i in ids]
        report.promoted = len(ids)
        if ids:
            report.notes.append(
                f"loss média {sum(before) / len(before):.3f} -> {sum(after) / len(after):.3f}"
            )
        return report

    def forget(self, now: float | None = None) -> ForgetReport:
        """Registros cujo traço nos pesos já se apagou saem do índice legível."""
        t = self.now(now)
        evicted = 0
        for rid in list(self._keys):
            rec = self.store.get(rid)
            if rec is None:
                self._keys.pop(rid, None)
                self._values.pop(rid, None)
                continue
            assoc = cosine(_matvec(self.M, self._keys[rid]), self._values[rid])
            if assoc < 0.05 and rec.retention(t) < 0.1:
                self.store.delete(rid)
                self._keys.pop(rid, None)
                self._values.pop(rid, None)
                evicted += 1
        return ForgetReport(subsystem=self.name, evicted=evicted, retained=self.size())

    def stats(self) -> dict[str, Any]:
        s = super().stats()
        hist = self._surprise_history[-50:]
        s.update(
            {
                "dim": self.dim,
                "steps": self.steps,
                "mean_recent_surprise": round(sum(hist) / len(hist), 4) if hist else 0.0,
                "weight_norm": round(math.sqrt(sum(x * x for row in self.M for x in row)), 4),
            }
        )
        return s
