"""[EMERGENTE 2/11] Memória Zettelkasten — notas atômicas que evoluem.

A-MEM (Xu et al., 2025, arXiv:2502.12110). Inspirado no método de fichas de
Niklas Luhmann: cada memória é uma *nota atômica* com palavras-chave, tags e
contexto; ao ser criada, a nota é ligada automaticamente às notas relacionadas;
e — o ponto que dá nome ao mecanismo — **as notas antigas são reescritas** à luz
da nova. A rede não só cresce: ela se reorganiza.

Duas propriedades que isso compra:

* **Raciocínio multi-hop sem grafo explícito.** A recuperação parte das notas
  mais similares e espalha ativação pelos links (spreading activation, Collins
  & Loftus 1975), alcançando notas que a similaridade direta nunca traria.
* **Contexto que amadurece.** Uma nota escrita cedo, quando o agente não
  entendia o domínio, ganha tags e contexto melhores depois. Em memória estática,
  ela continuaria pobre para sempre.

O risco correspondente é deriva: reescrever notas pode corromper o registro
original. Mitigação implementada: a *evolução só altera metadados* (tags,
contexto, links). O `content` é imutável — o que o agente observou, observou.
"""

from __future__ import annotations

from collections import defaultdict
from typing import Any

from ..core.base import (
    ConsolidationReport,
    ForgetReport,
    MemoryQuery,
    MemorySubsystem,
    Retrieved,
    WriteResult,
)
from ..core.embeddings import noise_floor_of
from ..core.record import MemoryRecord
from ..core.text import content_words
from ..core.types import MemoryForm, MemoryFunction, MemoryKind, WriteOp

__all__ = ["ZettelkastenMemory"]


class ZettelkastenMemory(MemorySubsystem):
    """Rede de notas atômicas auto-ligadas e auto-evolutivas.

    Parameters
    ----------
    link_threshold:
        Cosseno mínimo para criar um link entre notas. `None` (default) ancora
        no piso de ruído medido do embedder (x1.3) em vez de uma constante
        arbitrária — com o `HashingEmbedder` de 512 dims isso dá ~0.15.
    max_links:
        Grau máximo por nota. Sem teto, notas genéricas viram hubs e a
        ativação espalhada perde seletividade.
    evolution_threshold:
        Similaridade a partir da qual uma nota vizinha é *evoluída* (recebe as
        palavras-chave da nova nota). `None` ancora em 3x o piso de ruído —
        bem acima de `link_threshold` de propósito: ligar é barato, reescrever
        não.
    gate_multiplier:
        Multiplicador aplicado ao piso de ruído para formar o portão de
        recuperação. 1.25 leva o p99 medido ao p99.9 (0.115 -> 0.144 com o
        embedder default de 512 dims).
    spread_decay:
        Fator de atenuação por salto na ativação espalhada.
    """

    kind = MemoryKind.ZETTELKASTEN
    emergent = True

    def __init__(
        self,
        *,
        link_threshold: float | None = None,
        max_links: int = 8,
        evolution_threshold: float | None = None,
        gate_multiplier: float = 1.25,
        spread_decay: float = 0.5,
        spread_hops: int = 2,
        max_keywords: int = 8,
        **kw: Any,
    ) -> None:
        super().__init__(**kw)
        floor = noise_floor_of(self.embedder, 0.1)
        # Defaults ancorados no piso de ruído do embedder, não em constantes
        # mágicas: ligar acima do ruído, evoluir bem acima dele.
        self.noise_floor = floor
        self.link_threshold = floor * 1.3 if link_threshold is None else link_threshold
        self.max_links = max_links
        self.evolution_threshold = (
            floor * 3.0 if evolution_threshold is None else evolution_threshold
        )
        # `noise_floor` é o p99 do ruído; para o *portão de recuperação* usamos
        # p99.9 (~1.25x), porque o custo de injetar um fato irrelevante no prompt
        # é maior que o de perder um fraco — que a ativação espalhada ainda pode
        # recuperar por outro caminho.
        self.gate_multiplier = gate_multiplier
        self.retrieval_gate = floor * gate_multiplier
        self.spread_decay = spread_decay
        self.spread_hops = spread_hops
        self.max_keywords = max_keywords
        self._links: dict[str, dict[str, float]] = defaultdict(dict)
        self._evolutions = 0

    # ------------------------------------------------------------- escrita
    def write(self, record: MemoryRecord) -> WriteResult:
        now = self.now()
        record.kind = MemoryKind.ZETTELKASTEN
        record.form = MemoryForm.TOKEN
        record.function = MemoryFunction.FACTUAL
        if record.created_at == 0.0:
            record.created_at = now
            record.updated_at = now
            record.decay.last_access = now
        self.ensure_embedding(record)

        keywords = self._keywords(record.content)
        record.payload.setdefault("keywords", keywords)
        record.payload.setdefault("context", "")
        record.payload.setdefault("generation", 0)
        self.store.put(record)

        created = self._autolink(record, now)
        evolved = self._evolve_neighbours(record, now)
        self.emit("note_add", record.id, links=created, evolved=evolved)
        return WriteResult(op=WriteOp.ADD, record_id=record.id, reason=f"links={created},evolved={evolved}")

    def _keywords(self, text: str) -> list[str]:
        """Palavras-chave por frequência x raridade local (sem corpus externo)."""
        words = content_words(text)
        freq: dict[str, int] = defaultdict(int)
        for w in words:
            freq[w] += 1
        ranked = sorted(freq.items(), key=lambda kv: (-kv[1], -len(kv[0]), kv[0]))
        return [w for w, _ in ranked[: self.max_keywords]]

    def _autolink(self, note: MemoryRecord, now: float) -> int:
        """Liga a nota nova às mais próximas, respeitando o grau máximo."""
        neighbours = self.store.search_dense(note.embedding or (), self.max_links * 3)
        created = 0
        for rid, sim in neighbours:
            if rid == note.id or sim < self.link_threshold:
                continue
            other = self.store.get(rid)
            if other is None:
                continue
            if len(self._links[note.id]) >= self.max_links:
                break
            self._links[note.id][rid] = sim
            self._links[rid][note.id] = sim
            created += 1
        # poda hubs: mantém só os `max_links` vizinhos mais fortes
        for nid in (note.id, *self._links[note.id]):
            links = self._links[nid]
            if len(links) > self.max_links:
                keep = dict(sorted(links.items(), key=lambda kv: -kv[1])[: self.max_links])
                dropped = set(links) - set(keep)
                self._links[nid] = keep
                for d in dropped:
                    self._links[d].pop(nid, None)
        for nid, links in ((note.id, self._links[note.id]),):
            rec = self.store.get(nid)
            if rec is not None:
                rec.links["related"] = tuple(links)
                self.store.put(rec)
        return created

    def _evolve_neighbours(self, note: MemoryRecord, now: float) -> int:
        """Evolução de memória: vizinhos fortes herdam palavras-chave e contexto.

        `content` nunca muda — só metadados. É a salvaguarda contra corromper o
        registro do que foi de fato observado.
        """
        evolved = 0
        new_kw = set(note.payload.get("keywords", ()))
        for rid, sim in sorted(self._links[note.id].items(), key=lambda kv: -kv[1]):
            if sim < self.evolution_threshold:
                break
            other = self.store.get(rid)
            if other is None:
                continue
            before = set(other.payload.get("keywords", ()))
            merged = list(before | new_kw)[: self.max_keywords * 2]
            if set(merged) == before:
                continue
            other.payload["keywords"] = merged
            other.payload["generation"] = int(other.payload.get("generation", 0)) + 1
            ctx = other.payload.get("context", "")
            snippet = note.content[:80]
            other.payload["context"] = (ctx + " | " + snippet).strip(" |")[:400]
            other.updated_at = now
            self.store.put(other)
            evolved += 1
            self._evolutions += 1
        if evolved:
            self.emit("evolve", note.id, evolved=evolved)
        return evolved

    # ------------------------------------------------------------- leitura
    def read(self, query: MemoryQuery) -> list[Retrieved]:
        """Similaridade direta + ativação espalhada pelos links."""
        now = self.now(query.as_of)
        query.with_vector(self.embedder)
        visible = {r.id: r for r in self.candidates(query, now)}
        if not visible:
            return []

        direct: dict[str, float] = {}
        for rid, sim in self.store.search_dense(query.vector or (), query.top_k * 3):
            # Abaixo do piso de ruído o "sinal" é colisão de hash, não semântica.
            if rid in visible and sim > self.retrieval_gate:
                direct[rid] = sim

        # spreading activation (Collins & Loftus, 1975)
        activation: dict[str, float] = dict(direct)
        frontier = dict(direct)
        for hop in range(1, self.spread_hops + 1):
            nxt: dict[str, float] = {}
            decay = self.spread_decay**hop
            for src, act in frontier.items():
                for nb, w in self._links.get(src, {}).items():
                    if nb not in visible:
                        continue
                    contribution = act * w * decay
                    if contribution > nxt.get(nb, 0.0):
                        nxt[nb] = contribution
            for nid, val in nxt.items():
                activation[nid] = activation.get(nid, 0.0) + val
            frontier = nxt
            if not frontier:
                break

        out = [
            Retrieved(
                record=visible[rid],
                score=score,
                subsystem=self.name,
                rationale={
                    "direct": direct.get(rid, 0.0),
                    "spread": score - direct.get(rid, 0.0),
                    "degree": float(len(self._links.get(rid, {}))),
                    "generation": float(visible[rid].payload.get("generation", 0)),
                },
            )
            for rid, score in activation.items()
        ]
        out.sort(key=lambda r: -r.score)
        out = [r for r in out if r.score > self.retrieval_gate * 0.4]
        top = out[: query.top_k]
        self.touch_all([t.record for t in top], now)
        return top

    # -------------------------------------------------------------- extras
    def links_of(self, note_id: str) -> dict[str, float]:
        return dict(self._links.get(note_id, {}))

    def trail(self, note_id: str, *, hops: int = 2) -> list[MemoryRecord]:
        """Percorre a rede a partir de uma nota — a 'trilha' do Zettelkasten."""
        seen = {note_id}
        frontier = [note_id]
        out: list[MemoryRecord] = []
        for _ in range(hops):
            nxt: list[str] = []
            for nid in frontier:
                for nb, _w in sorted(self._links.get(nid, {}).items(), key=lambda kv: -kv[1]):
                    if nb in seen:
                        continue
                    seen.add(nb)
                    rec = self.store.get(nb)
                    if rec is not None:
                        out.append(rec)
                        nxt.append(nb)
            frontier = nxt
        return out

    def consolidate(self, now: float | None = None) -> ConsolidationReport:
        """Recalcula links após evoluções (as palavras-chave mudaram os vizinhos)."""
        report = ConsolidationReport(subsystem=self.name)
        for rec in list(self.store.scan(kind=MemoryKind.ZETTELKASTEN)):
            before = len(self._links.get(rec.id, {}))
            self._autolink(rec, self.now(now))
            report.links_created += max(0, len(self._links.get(rec.id, {})) - before)
        report.notes.append(f"{self._evolutions} evoluções acumuladas")
        return report

    def forget(self, now: float | None = None) -> ForgetReport:
        """Remove notas órfãs (grau 0) de baixa retenção."""
        t = self.now(now)
        evicted = 0
        for rec in list(self.store.scan(kind=MemoryKind.ZETTELKASTEN)):
            if not self._links.get(rec.id) and rec.retention(t) < 0.02 and rec.importance < 0.5:
                self.store.delete(rec.id)
                self._links.pop(rec.id, None)
                evicted += 1
        return ForgetReport(subsystem=self.name, evicted=evicted, retained=self.size())

    def stats(self) -> dict[str, Any]:
        s = super().stats()
        degrees = [len(v) for v in self._links.values()] or [0]
        s.update(
            {
                "links": sum(degrees) // 2,
                "mean_degree": sum(degrees) / len(degrees),
                "max_degree": max(degrees),
                "evolutions": self._evolutions,
                "orphans": sum(1 for d in degrees if d == 0),
            }
        )
        return s
