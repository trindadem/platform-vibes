"""As 21 categorias de memória — uma classe por categoria, todas com a mesma interface.

`SYSTEMS` mapeia `MemoryKind -> classe`; é o que o harness de avaliação e a
CLI usam para instanciar qualquer categoria pelo nome.
"""

from __future__ import annotations

from ..core.base import MemorySubsystem
from ..core.types import MemoryKind
from .affective import AffectiveMemory
from .agentic_os import AgenticOSMemory
from .buffer import ConversationBuffer
from .collective import CollectiveMemory
from .consolidated import ConsolidatedMemory
from .entity import EntityMemory
from .episodic import EpisodicMemory
from .hippocampal import HippocampalMemory
from .knowledge_graph import KnowledgeGraphMemory
from .latent import LatentMemory
from .neural import NeuralMemory
from .procedural import ProceduralMemory
from .prospective import ProspectiveMemory
from .reflective import ReflectiveMemory
from .semantic import SemanticMemory
from .sensory import SensoryMemory
from .summary import SummaryMemory
from .temporal_graph import TemporalKnowledgeGraph
from .vector import VectorMemory
from .working import WorkingMemory
from .zettelkasten import ZettelkastenMemory

SYSTEMS: dict[MemoryKind, type[MemorySubsystem]] = {
    MemoryKind.SENSORY: SensoryMemory,
    MemoryKind.WORKING: WorkingMemory,
    MemoryKind.EPISODIC: EpisodicMemory,
    MemoryKind.SEMANTIC: SemanticMemory,
    MemoryKind.PROCEDURAL: ProceduralMemory,
    MemoryKind.BUFFER: ConversationBuffer,
    MemoryKind.SUMMARY: SummaryMemory,
    MemoryKind.VECTOR: VectorMemory,
    MemoryKind.ENTITY: EntityMemory,
    MemoryKind.GRAPH: KnowledgeGraphMemory,
    MemoryKind.AGENTIC_OS: AgenticOSMemory,
    MemoryKind.ZETTELKASTEN: ZettelkastenMemory,
    MemoryKind.TEMPORAL_GRAPH: TemporalKnowledgeGraph,
    MemoryKind.REFLECTIVE: ReflectiveMemory,
    MemoryKind.NEURAL: NeuralMemory,
    MemoryKind.HIPPOCAMPAL: HippocampalMemory,
    MemoryKind.PROSPECTIVE: ProspectiveMemory,
    MemoryKind.AFFECTIVE: AffectiveMemory,
    MemoryKind.COLLECTIVE: CollectiveMemory,
    MemoryKind.LATENT: LatentMemory,
    MemoryKind.CONSOLIDATED: ConsolidatedMemory,
}

__all__ = [
    "SYSTEMS",
    "AffectiveMemory",
    "AgenticOSMemory",
    "CollectiveMemory",
    "ConsolidatedMemory",
    "ConversationBuffer",
    "EntityMemory",
    "EpisodicMemory",
    "HippocampalMemory",
    "KnowledgeGraphMemory",
    "LatentMemory",
    "NeuralMemory",
    "ProceduralMemory",
    "ProspectiveMemory",
    "ReflectiveMemory",
    "SemanticMemory",
    "SensoryMemory",
    "SummaryMemory",
    "TemporalKnowledgeGraph",
    "VectorMemory",
    "WorkingMemory",
    "ZettelkastenMemory",
]
