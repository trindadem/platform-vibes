"""[TRADICIONAL 10/10] Memória em grafo de conhecimento.

Representa a memória como triplas em vez de texto plano. Vantagem sobre RAG
denso, medida repetidamente na literatura (GraphRAG, Edge et al. 2024;
HippoRAG, Gutiérrez et al. 2024): perguntas **multi-hop** ("onde fica o país da
cidade onde o usuário mora?") exigem compor fatos que nunca aparecem juntos em
nenhum trecho — similaridade vetorial não compõe, travessia de grafo compõe.

Recuperação: os nós mencionados na consulta viram sementes de um Personalized
PageRank; as triplas são ranqueadas pela ativação dos seus extremos. É
*pattern completion* — a partir de um estímulo parcial, a rede reativa o padrão
completo (Teyler & DiScenna, 1986; Marr, 1971).
"""

from __future__ import annotations

from typing import Any

from ..core.base import (
    ConsolidationReport,
    ForgetReport,
    MemoryQuery,
    MemorySubsystem,
    Retrieved,
    WriteResult,
)
from ..core.extract import PatternTripleExtractor, Triple, TripleExtractor
from ..core.graph import Edge, Graph
from ..core.record import MemoryRecord
from ..core.similarity import cosine
from ..core.text import content_words, fold
from ..core.types import MemoryForm, MemoryFunction, MemoryKind, WriteOp

__all__ = ["KnowledgeGraphMemory"]


class KnowledgeGraphMemory(MemorySubsystem):
    """Grafo de triplas com recuperação por PPR e consultas multi-hop."""

    kind = MemoryKind.GRAPH

    def __init__(
        self,
        *,
        extractor: TripleExtractor | None = None,
        damping: float = 0.5,
        max_hops: int = 4,
        keep_source: bool = True,
        **kw: Any,
    ) -> None:
        super().__init__(**kw)
        self.extractor = extractor or PatternTripleExtractor()
        self.damping = damping
        self.max_hops = max_hops
        self.keep_source = keep_source
        self.graph = Graph()
        self._triple_records: dict[tuple[str, str, str], str] = {}

    # ------------------------------------------------------------- escrita
    def add_triple(
        self, triple: Triple, *, source_id: str = "", at: float | None = None
    ) -> WriteResult:
        now = self.now(at)
        key = (triple.subject, triple.relation, triple.object)
        existing_id = self._triple_records.get(key)
        if existing_id:
            rec = self.store.get(existing_id)
            if rec is not None:
                rec.decay.touch(now)
                rec.confidence = max(rec.confidence, triple.confidence)
                rec.payload["support"] = int(rec.payload.get("support", 1)) + 1
                self.store.put(rec)
                self.graph.add_edge(
                    Edge(triple.subject, triple.object, triple.relation, 0.5, existing_id)
                )
                return WriteResult(op=WriteOp.NOOP, record_id=existing_id, reason="tripla_reforcada")

        rec = MemoryRecord(
            content=triple.as_text(),
            kind=MemoryKind.GRAPH,
            created_at=now,
            updated_at=now,
            valid_from=now,
            form=MemoryForm.TOKEN,
            function=MemoryFunction.FACTUAL,
            confidence=triple.confidence,
            importance=0.6,
            payload={
                "subject": triple.subject,
                "relation": triple.relation,
                "object": triple.object,
                "support": 1,
                "source_id": source_id,
            },
        )
        self.ensure_embedding(rec)
        self.store.put(rec)
        self._triple_records[key] = rec.id
        self.graph.add_edge(Edge(triple.subject, triple.object, triple.relation, 1.0, rec.id))
        self.emit("triple_add", rec.id, triple=triple.as_text())
        return WriteResult(op=WriteOp.ADD, record_id=rec.id)

    def write(self, record: MemoryRecord) -> WriteResult:
        """Extrai triplas do texto e as insere. O texto original fica como fonte."""
        now = self.now()
        if record.created_at == 0.0:
            record.created_at = now
            record.updated_at = now
            record.decay.last_access = now
        triples = self.extractor.extract(record.content)
        if not triples:
            self.emit("extract_empty", record.id)
            return WriteResult(op=WriteOp.NOOP, record_id=record.id, reason="sem_triplas", accepted=False)
        if self.keep_source:
            self.ensure_embedding(record)
            record.payload.setdefault("is_source", True)
            self.store.put(record)
        ids = [self.add_triple(t, source_id=record.id, at=record.created_at).record_id for t in triples]
        return WriteResult(op=WriteOp.ADD, record_id=record.id, superseded=tuple(ids))

    # ------------------------------------------------------------- leitura
    def _seed_nodes(self, query_text: str) -> dict[str, float]:
        """Casa os termos da consulta com nós do grafo (exato e por prefixo)."""
        terms = set(content_words(query_text))
        seeds: dict[str, float] = {}
        for node in self.graph.nodes:
            parts = set(node.split("_"))
            hit = terms & parts
            if hit:
                seeds[node] = seeds.get(node, 0.0) + len(hit) / max(len(parts), 1)
        return seeds

    def read(self, query: MemoryQuery) -> list[Retrieved]:
        now = self.now(query.as_of)
        query.with_vector(self.embedder)
        seeds = self._seed_nodes(query.text)
        ranks = (
            self.graph.personalized_pagerank(seeds, damping=self.damping)
            if seeds
            else {}
        )
        out: list[Retrieved] = []
        for rec in self.candidates(query, now):
            if rec.payload.get("is_source"):
                continue
            s = rec.payload.get("subject", "")
            o = rec.payload.get("object", "")
            activation = ranks.get(s, 0.0) + ranks.get(o, 0.0)
            rel = cosine(query.vector, rec.embedding) if query.vector else 0.0
            support = float(rec.payload.get("support", 1))
            score = 0.6 * activation * 10.0 + 0.3 * rel + 0.1 * min(support / 5.0, 1.0)
            if score <= 0:
                continue
            out.append(
                Retrieved(
                    record=rec,
                    score=score,
                    subsystem=self.name,
                    rationale={
                        "ppr_activation": activation,
                        "relevance": rel,
                        "support": support,
                        "seeds": float(len(seeds)),
                    },
                )
            )
        out.sort(key=lambda r: -r.score)
        top = out[: query.top_k]
        self.touch_all([t.record for t in top], now)
        return top

    # ----------------------------------------------------------- multi-hop
    def connect(self, a: str, b: str) -> list[Triple]:
        """Cadeia de triplas que liga duas entidades — resposta multi-hop explicável."""
        path = self.graph.shortest_path(fold(a), fold(b), max_hops=self.max_hops)
        return [Triple(e.source, e.relation, e.target) for e in path]

    def neighbors_of(self, entity: str, *, hops: int = 1) -> dict[str, int]:
        return self.graph.k_hop(fold(entity), hops)

    def triples_of(self, entity: str) -> list[Triple]:
        node = fold(entity)
        edges = self.graph.out_edges(node) + self.graph.in_edges(node)
        return [Triple(e.source, e.relation, e.target) for e in edges]

    def consolidate(self, now: float | None = None) -> ConsolidationReport:
        """Detecta comunidades e anota cada tripla com a sua — visão de alto nível."""
        report = ConsolidationReport(subsystem=self.name)
        communities = self.graph.communities()
        node_to_comm = {n: c for c, nodes in communities.items() for n in nodes}
        for rec in self.store.scan(kind=MemoryKind.GRAPH):
            comm = node_to_comm.get(rec.payload.get("subject", ""))
            if comm and rec.payload.get("community") != comm:
                rec.payload["community"] = comm
                self.store.put(rec)
                report.links_created += 1
        report.notes.append(f"{len(communities)} comunidades")
        return report

    def forget(self, now: float | None = None) -> ForgetReport:
        """Poda triplas de suporte único, nunca acessadas e de baixa retenção."""
        t = self.now(now)
        evicted = 0
        for rec in list(self.store.scan(kind=MemoryKind.GRAPH)):
            if (
                int(rec.payload.get("support", 1)) <= 1
                and rec.decay.access_count == 0
                and rec.retention(t) < 0.01
            ):
                key = (rec.payload.get("subject", ""), rec.payload.get("relation", ""), rec.payload.get("object", ""))
                self.graph.remove_edge(key[0], key[1], key[2])
                self._triple_records.pop(key, None)
                self.store.delete(rec.id)
                evicted += 1
        return ForgetReport(subsystem=self.name, evicted=evicted, retained=self.size())

    def stats(self) -> dict[str, Any]:
        s = super().stats()
        s.update({"graph": self.graph.stats(), "triples": len(self._triple_records)})
        return s
