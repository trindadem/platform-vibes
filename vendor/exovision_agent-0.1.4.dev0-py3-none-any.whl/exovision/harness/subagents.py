"""Subagentes: delegação com janela própria, orçamento comum e um único traço.

Um subagente é um `Agent` completo — instrução, ferramentaria, política,
memória e orçamento próprios — exposto ao orquestrador **como ferramenta**.
É a mesma decisão que fez o servidor MCP virar `Toolset`: o laço não ganha um
caminho novo, ganha mais uma ferramentaria.

## O que a delegação compra, medido

O ganho não é "mais agentes, melhor". É **isolamento de contexto**: cada
subagente lê o que precisa e devolve a conclusão, e o orquestrador nunca vê
os caminhos que o subagente descartou. Isso ataca a degradação por
comprimento — a curva em U do "lost in the middle" (Liu et al., 2023,
arXiv:2307.03172) e o *context rot* medido depois — e é o que sustenta o
resultado do Chain-of-Agents, que lê o documento inteiro em janelas curtas e
bate RAG e janela longa em até 10% (Zhang et al., NeurIPS 2024,
arXiv:2406.02818). No sistema de pesquisa multiagente da Anthropic (2025), a
arquitetura orquestrador-trabalhador com 3 a 5 subagentes em paralelo rendeu
+90,2% sobre o agente único na avaliação interna.

O preço também está medido, e é alto: **cerca de 15 vezes os tokens** de uma interação de
chat, com o uso de tokens sozinho explicando ~80% da variância de desempenho.
Delegar é comprar qualidade com tokens. Um harness que não contabiliza isso
mente sobre o custo — daí o `Ledger`.

## O que a delegação quebra, e como este módulo se defende

O MAST (Cemri et al., 2025, arXiv:2503.13657) classificou 14 modos de falha
em sistemas multiagente sobre 1.600+ traços anotados. Três atingem
exatamente a fronteira orquestrador↔subagente, e cada um aqui tem uma
resposta estrutural, não uma instrução de prompt:

- **Terminação prematura** (FM-2.6): um subagente que fechou por orçamento
  devolve texto que *parece* conclusão. Aqui, `stop_reason` que começa com
  `budget:` ou `error` produz `ToolResult(ok=False)` — o orquestrador lê
  "não terminou", não "terminou".
- **Verificação ausente ou incompleta** (FM-3.3): `verify` é um gancho por
  subagente; o que ele reprova volta marcado como falha, com a razão.
- **Desalinhamento entre agentes** (FM-2.x): o contrato do que volta
  (`returns`) entra na descrição da ferramenta, que é o único lugar que o
  orquestrador lê antes de delegar.

E a fronteira de confiança não muda: a conclusão de um subagente chega ao
orquestrador **como resultado de ferramenta** — `UNTRUSTED`/`TOOL` na
memória. Um subagente que leu uma página envenenada não promove o que leu ao
status de fato só por ter passado por um agente.

## Traço

O subagente atravessa as **mesmas** costuras do conjunto fechado, e seus
eventos são reemitidos no `Seams` do pai com `agent` e `depth`. Duas
execuções — uma com delegação, outra sem — deixam traços da mesma forma, e
por isso se comparam. É a razão de o conjunto de costuras ser fechado.
"""

from __future__ import annotations

import threading
import time
from collections.abc import Callable, Iterable, Sequence
from dataclasses import dataclass, field
from typing import Any

from .budget import MAX_TURNS, Budget
from .loop import Agent, Outcome, run
from .models.provider import estimate_cost_usd
from .seams import Event, Seams
from .session import StateStore
from .tools import RISK_LEVELS, ToolResult

__all__ = [
    "Delegation",
    "Ledger",
    "Subagent",
    "Subagents",
    "budget_for_depth",
    "derived_risk",
    "fanout",
]


# --------------------------------------------------------------------------
# Razão compartilhada
# --------------------------------------------------------------------------


@dataclass
class Ledger:
    """O que a árvore inteira já gastou. Um orçamento por agente não é teto.

    Sem isto, `Budget(max_cost_usd=1.0)` no orquestrador significa "um dólar
    de orquestrador **mais** um dólar por subagente, vezes o número de
    delegações" — um teto que cresce com a profundidade não é teto.
    """

    limit: Budget = field(default_factory=Budget)
    usage: dict[str, int] = field(default_factory=dict)
    cost_usd: float = 0.0
    tool_calls: int = 0
    runs: int = 0
    started_at: float = field(default_factory=time.monotonic)
    _lock: threading.Lock = field(default_factory=threading.Lock, repr=False)

    def charge(self, outcome: Outcome, model: str = "") -> None:
        with self._lock:
            for k, v in outcome.usage.items():
                if isinstance(v, int):
                    self.usage[k] = self.usage.get(k, 0) + v
            self.cost_usd += outcome.cost_usd or estimate_cost_usd(model, outcome.usage)
            self.tool_calls += outcome.tool_calls
            self.runs += 1

    @property
    def elapsed_s(self) -> float:
        return time.monotonic() - self.started_at

    def exhausted(self) -> str | None:
        """O eixo da árvore que estourou, ou None."""
        b = self.limit
        if b.max_cost_usd is not None and self.cost_usd >= b.max_cost_usd:
            return f"ledger:max_cost_usd={b.max_cost_usd}"
        if b.max_tool_calls is not None and self.tool_calls >= b.max_tool_calls:
            return f"ledger:max_tool_calls={b.max_tool_calls}"
        if b.max_wall_s is not None and self.elapsed_s >= b.max_wall_s:
            return f"ledger:max_wall_s={b.max_wall_s}"
        out = self.usage.get("output_tokens", 0)
        if b.max_output_tokens is not None and out >= b.max_output_tokens:
            return f"ledger:max_output_tokens={b.max_output_tokens}"
        return None

    def derive(self, budget: Budget) -> Budget:
        """O orçamento do filho, apertado pelo que sobra na árvore."""
        remaining_cost = budget.max_cost_usd
        if self.limit.max_cost_usd is not None:
            left = max(0.0, self.limit.max_cost_usd - self.cost_usd)
            remaining_cost = left if remaining_cost is None else min(remaining_cost, left)
        remaining_wall = budget.max_wall_s
        if self.limit.max_wall_s is not None:
            left_s = max(0.0, self.limit.max_wall_s - self.elapsed_s)
            remaining_wall = left_s if remaining_wall is None else min(remaining_wall, left_s)
        return Budget(
            max_turns=budget.max_turns,
            max_input_tokens=budget.max_input_tokens,
            max_output_tokens=budget.max_output_tokens,
            max_cost_usd=remaining_cost,
            max_wall_s=remaining_wall,
            max_tool_calls=budget.max_tool_calls,
        )

    def to_dict(self) -> dict[str, Any]:
        return {
            "runs": self.runs,
            "cost_usd": round(self.cost_usd, 6),
            "tool_calls": self.tool_calls,
            "usage": dict(self.usage),
            "elapsed_s": round(self.elapsed_s, 3),
        }


# --------------------------------------------------------------------------
# Subagente e delegação
# --------------------------------------------------------------------------


def derived_risk(toolset: Any) -> str:
    """O risco de delegar é o maior risco que o delegado consegue causar."""
    try:
        defs = toolset.definitions()
    except Exception:  # pragma: no cover — ferramentaria quebrada
        return "irreversible"
    if not defs:
        return "read"
    fn = getattr(toolset, "risk", None)
    worst = 0
    for d in defs:
        name = str(d.get("name", ""))
        level = str(fn(name)) if callable(fn) else "irreversible"
        worst = max(
            worst, RISK_LEVELS.index(level) if level in RISK_LEVELS else len(RISK_LEVELS) - 1
        )
    return RISK_LEVELS[worst]


@dataclass
class Delegation:
    """O que uma delegação deixou — inclusive quando não terminou."""

    name: str
    task: str
    outcome: Outcome
    seconds: float = 0.0
    verdict: str = ""
    verified: bool = True

    @property
    def ok(self) -> bool:
        """Terminou de verdade: sem erro, sem teto de orçamento, aprovado."""
        return (
            self.outcome.ok
            and not self.outcome.stop_reason.startswith("budget:")
            and self.outcome.stop_reason != "refusal"
            and self.verified
        )

    @property
    def text(self) -> str:
        return self.outcome.text

    def to_result(self) -> ToolResult:
        """O que o orquestrador lê. Terminação prematura nunca vira 'pronto'."""
        head = self.outcome.text.strip() or "(o subagente não produziu texto)"
        meta = {
            "subagent": self.name,
            "stop_reason": self.outcome.stop_reason,
            "turns": self.outcome.turns,
            "tool_calls": self.outcome.tool_calls,
            "cost_usd": self.outcome.cost_usd,
            "seconds": round(self.seconds, 2),
        }
        if self.ok:
            return ToolResult(text=head, metadata=meta)
        reason = (
            self.outcome.error
            or (self.verdict if not self.verified else "")
            or f"parou por {self.outcome.stop_reason}"
        )
        return ToolResult(
            text=(
                f"[{self.name} NÃO concluiu: {reason}]\n"
                f"Trabalho parcial, trate como incompleto:\n{head}"
            ),
            ok=False,
            code=1,
            metadata={**meta, "incomplete": True, "reason": reason},
        )

    def to_dict(self) -> dict[str, Any]:
        return {
            "name": self.name,
            "task": self.task,
            "ok": self.ok,
            "verified": self.verified,
            "verdict": self.verdict,
            "seconds": round(self.seconds, 3),
            "outcome": self.outcome.to_dict(),
        }


@dataclass
class Subagent:
    """Um agente delegável: o `Agent` mais o contrato que o orquestrador lê."""

    name: str
    agent: Agent
    description: str
    #: o que o subagente devolve. Entra na descrição porque o desalinhamento
    #: entre agentes (MAST FM-2.x) começa no contrato que ninguém escreveu.
    returns: str = "um resumo do que fez, do que verificou e do que não conseguiu"
    #: `""` deriva do que a ferramentaria do filho consegue causar.
    risk: str = ""
    #: `None` deriva: só é paralelizável quem só lê.
    parallel_safe: bool | None = None
    #: gancho de verificação: `(Delegation) -> (aprovado, razão)`.
    verify: Callable[[Delegation], tuple[bool, str]] | None = None
    #: tentativas extras quando `verify` reprova.
    retries: int = 0
    #: orçamento próprio; apertado pelo que sobra no `Ledger`.
    budget: Budget | None = None

    def __post_init__(self) -> None:
        if not self.name or not self.name.replace("_", "").replace("-", "").isalnum():
            raise ValueError(f"nome de subagente inválido: {self.name!r}")
        if not self.description:
            raise ValueError(f"subagente {self.name!r} sem descrição: existe e nunca é escolhido")
        if self.risk and self.risk not in RISK_LEVELS:
            raise ValueError(f"risco {self.risk!r} fora de {RISK_LEVELS}")

    def resolved_risk(self) -> str:
        return self.risk or derived_risk(self.agent.resolved_toolset())

    def resolved_parallel(self) -> bool:
        if self.parallel_safe is not None:
            return self.parallel_safe
        return self.resolved_risk() == "read"

    def resolved_budget(self) -> Budget:
        return self.budget or self.agent.budget

    def definition(self) -> dict[str, Any]:
        return {
            "name": self.name,
            "description": (
                f"{self.description.strip()} "
                f"Delega a um subagente com janela de contexto própria; "
                f"devolve {self.returns.strip()}. "
                f"Descreva a tarefa por completo: o subagente não vê esta conversa."
            ),
            "input_schema": {
                "type": "object",
                "properties": {
                    "task": {
                        "type": "string",
                        "description": (
                            "a tarefa, autossuficiente: objetivo, contexto necessário, "
                            "critério de pronto e o formato da resposta"
                        ),
                    }
                },
                "required": ["task"],
            },
        }


# --------------------------------------------------------------------------
# Time
# --------------------------------------------------------------------------


class Subagents:
    """Subagentes com a superfície `Toolset`: delegar é chamar uma ferramenta.

        time = Subagents([Subagent("pesquisador", agent=pesq, description="Investiga ...")])
        chefe = Agent(provider=..., toolset=Composite(Workbench("."), time))

    Profundidade tem teto (`max_depth`): uma árvore que se aprofunda sozinha
    é o modo mais barato de queimar um orçamento sem produzir nada.
    """

    def __init__(
        self,
        subagents: Sequence[Subagent],
        *,
        ledger: Ledger | None = None,
        budget: Budget | None = None,
        max_depth: int = 2,
        depth: int = 0,
        state_store: StateStore | None = None,
        session: str = "",
        max_parallel: int = 8,
    ) -> None:
        self.subagents: dict[str, Subagent] = {}
        for s in subagents:
            if s.name in self.subagents:
                raise ValueError(f"subagente {s.name!r} declarado duas vezes")
            self.subagents[s.name] = s
        self.ledger = ledger if ledger is not None else Ledger(limit=budget or Budget())
        self.max_depth = max_depth
        self.depth = depth
        self.state_store = state_store
        self.session = session
        self.max_parallel = max_parallel
        self.delegations: list[Delegation] = []
        self._seams: Seams | None = None
        self._lock = threading.Lock()

    # --------------------------------------------------------- traço
    def attach(self, seams: Seams) -> Subagents:
        """Reemite no traço do pai o que os filhos atravessarem."""
        self._seams = seams
        return self

    def _forward(self, child_name: str, event: Event) -> None:
        parent = self._seams
        if parent is None:
            return
        with self._lock:
            parent.emit(
                event.seam,
                **{**event.data, "agent": child_name, "depth": self.depth + 1},
            )

    # --------------------------------------------------- superfície
    def definitions(self) -> list[dict[str, Any]]:
        return [s.definition() for s in self.subagents.values()]

    def names(self) -> list[str]:
        return list(self.subagents)

    def risk(self, name: str) -> str:
        s = self.subagents.get(name)
        return s.resolved_risk() if s else "irreversible"

    def parallel_safe(self, name: str) -> bool:
        s = self.subagents.get(name)
        return bool(s and s.resolved_parallel())

    def __len__(self) -> int:
        return len(self.subagents)

    def __call__(self, name: str, arguments: dict[str, Any]) -> ToolResult:
        s = self.subagents.get(name)
        if s is None:
            return ToolResult.error(
                f"subagente desconhecido: {name!r}. Disponíveis: {', '.join(self.subagents)}",
                code=404,
            )
        task = str(arguments.get("task") or "").strip()
        if not task:
            return ToolResult.error(
                f"{name} precisa de `task`: o subagente não vê esta conversa e "
                "não adivinha o objetivo",
                code=422,
            )
        return self.delegate(s, task).to_result()

    # -------------------------------------------------------- execução
    def delegate(self, s: Subagent | str, task: str, *, session: str = "") -> Delegation:
        """Roda um subagente e devolve a delegação — inclusive a que falhou."""
        sub = self.subagents[s] if isinstance(s, str) else s
        if self.depth >= self.max_depth:
            return self._refused(
                sub, task, f"profundidade máxima de delegação atingida ({self.max_depth})"
            )
        closed = self.ledger.exhausted()
        if closed:
            return self._refused(sub, task, f"orçamento da árvore fechado ({closed})")

        attempt = 0
        delegation: Delegation | None = None
        while True:
            delegation = self._run_once(sub, task, session=session, attempt=attempt)
            if delegation.verified or attempt >= sub.retries:
                break
            attempt += 1
            task = (
                f"{task}\n\n[nova tentativa {attempt}] A entrega anterior foi reprovada na "
                f"verificação: {delegation.verdict}. Corrija exatamente isso."
            )
        with self._lock:
            self.delegations.append(delegation)
        return delegation

    def _run_once(self, sub: Subagent, task: str, *, session: str, attempt: int) -> Delegation:
        child_session = session or f"{self.session or '-'}/{sub.name}"
        if attempt:
            child_session = f"{child_session}#{attempt}"
        child_seams = Seams(child_session)
        if self._seams is not None:
            nome = sub.name

            def encaminha(evento: Event, nome: str = nome) -> None:
                self._forward(nome, evento)

            child_seams.on("*", encaminha)
        child = _with_budget(sub.agent, self.ledger.derive(sub.resolved_budget()))
        t0 = time.perf_counter()
        try:
            outcome = run(
                child,
                task,
                session=child_session,
                state_store=self.state_store,
                seams=child_seams,
            )
        except Exception as erro:  # o filho não derruba o pai
            outcome = Outcome(
                text="",
                turns=0,
                stop_reason="error",
                session=child_session,
                error=f"{type(erro).__name__}: {erro}",
            )
        seconds = time.perf_counter() - t0
        self.ledger.charge(outcome, model=getattr(sub.agent.provider, "model", ""))
        delegation = Delegation(name=sub.name, task=task, outcome=outcome, seconds=seconds)
        if sub.verify is not None and delegation.outcome.ok:
            try:
                approved, verdict = sub.verify(delegation)
            except Exception as erro:
                approved, verdict = False, f"verificador falhou: {type(erro).__name__}: {erro}"
            delegation.verified = bool(approved)
            delegation.verdict = str(verdict or "")
        return delegation

    def _refused(self, sub: Subagent, task: str, reason: str) -> Delegation:
        return Delegation(
            name=sub.name,
            task=task,
            outcome=Outcome(text="", turns=0, stop_reason="refused", error=reason),
        )

    # ------------------------------------------------------- leque
    def fanout(
        self,
        s: Subagent | str,
        tasks: Iterable[str],
        *,
        max_workers: int | None = None,
    ) -> list[Delegation]:
        """Um subagente sobre muitas tarefas, em paralelo. Ordem preservada."""
        sub = self.subagents[s] if isinstance(s, str) else s
        items = list(tasks)
        if not items:
            return []
        workers = max(1, min(max_workers or self.max_parallel, len(items)))
        return fanout(self, sub, items, max_workers=workers)

    def report(self) -> dict[str, Any]:
        """O que a árvore fez — a contabilidade que torna o custo de delegar visível."""
        per: dict[str, dict[str, Any]] = {}
        for d in self.delegations:
            slot = per.setdefault(d.name, {"runs": 0, "ok": 0, "cost_usd": 0.0, "seconds": 0.0})
            slot["runs"] += 1
            slot["ok"] += int(d.ok)
            slot["cost_usd"] = round(slot["cost_usd"] + d.outcome.cost_usd, 6)
            slot["seconds"] = round(slot["seconds"] + d.seconds, 3)
        return {"ledger": self.ledger.to_dict(), "per_subagent": per}


def _with_budget(agent: Agent, budget: Budget) -> Agent:
    """Cópia rasa do agente com outro orçamento — sem tocar no original."""
    if budget == agent.budget:
        return agent
    clone = Agent(
        provider=agent.provider,
        instruction=agent.instruction,
        name=agent.name,
        toolset=agent.toolset,
        policy=agent.policy,
        memory=agent.memory,
        skills=agent.skills,
        budget=budget,
        workspace=agent.workspace,
        system_extra=agent.system_extra,
        max_parallel=agent.max_parallel,
        cache_system=agent.cache_system,
    )
    return clone


def fanout(
    team: Subagents,
    sub: Subagent | str,
    tasks: Sequence[str],
    *,
    max_workers: int = 4,
) -> list[Delegation]:
    """Leque paralelo de um subagente sobre tarefas independentes.

    Os resultados voltam **na ordem das tarefas**, não na de conclusão: a
    ordem de chegada é ruído de agendamento e faria duas execuções iguais
    produzirem contextos diferentes.
    """
    from concurrent.futures import ThreadPoolExecutor

    subagent = team.subagents[sub] if isinstance(sub, str) else sub
    items = list(tasks)
    if not items:
        return []
    if max_workers <= 1 or len(items) == 1:
        return [
            team.delegate(subagent, t, session=f"{team.session or '-'}/{subagent.name}#{i}")
            for i, t in enumerate(items)
        ]
    with ThreadPoolExecutor(max_workers=min(max_workers, len(items))) as pool:
        futures = [
            pool.submit(
                team.delegate,
                subagent,
                t,
                session=f"{team.session or '-'}/{subagent.name}#{i}",
            )
            for i, t in enumerate(items)
        ]
        return [f.result() for f in futures]


def budget_for_depth(total: Budget, depth: int, branching: int) -> Budget:
    """Orçamento por nó numa árvore de ramificação fixa.

    Uma árvore de profundidade `depth` e ramificação `branching` tem
    `(b^(d+1) - 1) / (b - 1)` nós; dividir o teto por esse número é o único
    jeito de o teto da raiz continuar sendo teto lá embaixo.
    """
    b = max(1, branching)
    nodes = depth + 1 if b == 1 else (b ** (depth + 1) - 1) // (b - 1)
    return Budget(
        max_turns=max(1, total.max_turns // max(1, nodes) if total.max_turns else MAX_TURNS),
        max_input_tokens=total.max_input_tokens,
        max_output_tokens=(total.max_output_tokens // nodes if total.max_output_tokens else None),
        max_cost_usd=(total.max_cost_usd / nodes if total.max_cost_usd else None),
        max_wall_s=total.max_wall_s,
        max_tool_calls=(total.max_tool_calls // nodes if total.max_tool_calls else None),
    )
