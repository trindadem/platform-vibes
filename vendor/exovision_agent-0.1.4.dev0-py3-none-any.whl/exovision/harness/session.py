"""Sessão nomeada, durável e retomável.

O que fica durável, e quando:

1. A resposta do modelo e **todas** as intenções de ferramenta ficam no disco
   ANTES do primeiro efeito (`pending_calls` com status `planned`).
2. Cada chamada vira `running` antes de executar e `completed` (com o
   resultado) depois.
3. Após um crash, `planned` pode rodar; `completed` é reutilizado sem repetir
   o efeito; `running` é **ambíguo** — o efeito pode ter acontecido ou não — e
   a retomada para pedindo intervenção (`StateConflict`). Repetir um `git push`
   às cegas é pior que parar.

`SQLiteStateStore` usa a stdlib; `InMemoryStateStore` serve testes. O
`system` fica no estado para que a retomada reproduza exatamente o contexto
original — reconsultar memória na retomada faria conhecimento novo mudar o
prompt e invalidar o checkpoint.
"""

from __future__ import annotations

import json
import sqlite3
import threading
import time
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Protocol, runtime_checkable

__all__ = [
    "InMemoryStateStore",
    "SQLiteStateStore",
    "SessionState",
    "StateConflict",
    "StateStore",
    "enable_wal",
]


def enable_wal(conn: sqlite3.Connection, *, timeout_s: float = 30.0) -> None:
    """Liga o WAL só se ainda não está ligado, esperando o lock se preciso.

    `PRAGMA journal_mode=WAL` exige lock exclusivo e **não** passa pelo busy
    handler: dois processos abrindo o mesmo arquivo ao mesmo tempo (a fila de
    tarefas, por exemplo) fariam o segundo morrer com `database is locked`.
    A consulta `PRAGMA journal_mode` não exige nada; se já é WAL, não há o que
    fazer. Se não é, tenta até o prazo.
    """
    deadline = time.monotonic() + timeout_s
    while True:
        try:
            if conn.execute("PRAGMA journal_mode").fetchone()[0].lower() == "wal":
                return
            conn.execute("PRAGMA journal_mode=WAL")
            return
        except sqlite3.OperationalError as erro:
            if "locked" not in str(erro).lower() or time.monotonic() >= deadline:
                raise
            time.sleep(0.02)


class StateConflict(RuntimeError):
    """Retomada impossível sem intervenção (efeito de ferramenta ambíguo)."""


@dataclass(slots=True)
class SessionState:
    name: str
    task: str
    system: list[dict[str, Any]]
    messages: list[dict[str, Any]] = field(default_factory=list)
    turn: int = 0
    usage: dict[str, int] = field(default_factory=dict)
    status: str = "running"  # running | completed | failed
    pending_calls: list[dict[str, Any]] = field(default_factory=list)
    outcome: dict[str, Any] | None = None
    created_at: float = 0.0
    updated_at: float = 0.0
    meta: dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> dict[str, Any]:
        return {
            "name": self.name,
            "task": self.task,
            "system": self.system,
            "messages": self.messages,
            "turn": self.turn,
            "usage": self.usage,
            "status": self.status,
            "pending_calls": self.pending_calls,
            "outcome": self.outcome,
            "created_at": self.created_at,
            "updated_at": self.updated_at,
            "meta": self.meta,
        }

    @classmethod
    def from_dict(cls, d: dict[str, Any]) -> SessionState:
        return cls(
            name=d["name"],
            task=d.get("task", ""),
            system=list(d.get("system") or []),
            messages=list(d.get("messages") or []),
            turn=int(d.get("turn", 0)),
            usage=dict(d.get("usage") or {}),
            status=str(d.get("status", "running")),
            pending_calls=list(d.get("pending_calls") or []),
            outcome=d.get("outcome"),
            created_at=float(d.get("created_at", 0.0)),
            updated_at=float(d.get("updated_at", 0.0)),
            meta=dict(d.get("meta") or {}),
        )

    # ------------------------------------------------------- journal
    def plan_calls(self, calls: list[dict[str, Any]]) -> None:
        self.pending_calls = [
            {
                "id": c["id"],
                "name": c["name"],
                "arguments": dict(c.get("arguments") or {}),
                "status": "planned",
                "result": None,
            }
            for c in calls
        ]

    def mark(self, call_id: str, status: str, result: dict[str, Any] | None = None) -> None:
        for c in self.pending_calls:
            if c["id"] == call_id:
                c["status"] = status
                if result is not None:
                    c["result"] = result
                return

    def ambiguous_calls(self) -> list[str]:
        return [c["id"] for c in self.pending_calls if c["status"] == "running"]

    def clear_calls(self) -> None:
        self.pending_calls = []


@runtime_checkable
class StateStore(Protocol):
    def load(self, name: str) -> SessionState | None: ...

    def save(self, state: SessionState) -> None: ...

    def begin(
        self, name: str, task: str, system: list[dict[str, Any]], resume: bool
    ) -> SessionState: ...

    def names(self) -> list[str]: ...


class _Base:
    def begin(
        self, name: str, task: str, system: list[dict[str, Any]], resume: bool
    ) -> SessionState:
        previous = self.load(name) if resume else None  # type: ignore[attr-defined]
        if previous is not None:
            return previous
        now = time.time()
        state = SessionState(name=name, task=task, system=system, created_at=now, updated_at=now)
        self.save(state)  # type: ignore[attr-defined]
        return state


class InMemoryStateStore(_Base):
    def __init__(self) -> None:
        self._states: dict[str, dict[str, Any]] = {}

    def load(self, name: str) -> SessionState | None:
        d = self._states.get(name)
        return SessionState.from_dict(json.loads(json.dumps(d))) if d else None

    def save(self, state: SessionState) -> None:
        state.updated_at = time.time()
        self._states[state.name] = json.loads(json.dumps(state.to_dict(), default=str))

    def names(self) -> list[str]:
        return sorted(self._states)


class SQLiteStateStore(_Base):
    """Um arquivo, uma tabela, uma linha por sessão. WAL para leitura concorrente."""

    def __init__(self, path: str | Path, *, busy_timeout_s: float = 30.0) -> None:
        self.path = Path(path)
        self.path.parent.mkdir(parents=True, exist_ok=True)
        self._lock = threading.Lock()
        # `timeout` é o busy handler: outro processo escrevendo não é erro, é espera.
        self._conn = sqlite3.connect(
            str(self.path), check_same_thread=False, timeout=busy_timeout_s
        )
        enable_wal(self._conn, timeout_s=busy_timeout_s)
        self._conn.execute(
            "CREATE TABLE IF NOT EXISTS sessions (name TEXT PRIMARY KEY, status TEXT, turn INTEGER, updated_at REAL, state TEXT NOT NULL)"
        )
        self._conn.commit()

    def load(self, name: str) -> SessionState | None:
        with self._lock:
            row = self._conn.execute(
                "SELECT state FROM sessions WHERE name = ?", (name,)
            ).fetchone()
        return SessionState.from_dict(json.loads(row[0])) if row else None

    def save(self, state: SessionState) -> None:
        state.updated_at = time.time()
        blob = json.dumps(state.to_dict(), ensure_ascii=False, default=str)
        with self._lock:
            self._conn.execute(
                "INSERT INTO sessions(name, status, turn, updated_at, state) VALUES (?,?,?,?,?) "
                "ON CONFLICT(name) DO UPDATE SET status=excluded.status, turn=excluded.turn, updated_at=excluded.updated_at, state=excluded.state",
                (state.name, state.status, state.turn, state.updated_at, blob),
            )
            self._conn.commit()

    def names(self) -> list[str]:
        with self._lock:
            rows = self._conn.execute("SELECT name FROM sessions ORDER BY name").fetchall()
        return [r[0] for r in rows]

    def delete(self, name: str) -> bool:
        with self._lock:
            cur = self._conn.execute("DELETE FROM sessions WHERE name = ?", (name,))
            self._conn.commit()
        return cur.rowcount > 0

    def close(self) -> None:
        with self._lock:
            self._conn.close()
