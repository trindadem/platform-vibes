"""Montagem de contexto: o que o modelo vê, e em que ordem.

A ordem é a do cache de prefixo: `tools -> system -> messages`, e um byte a
mais no prefixo invalida tudo depois. Então o **system é estável** dentro de
uma sessão (instrução + índice de skills + preâmbulo do workspace) e recebe o
breakpoint de cache; o que muda por tarefa — a memória recuperada — entra na
**primeira mensagem do usuário**, depois do breakpoint.

O preâmbulo é curto de propósito. A instrução do agente vem do documento e
nada é acrescentado além do que o harness precisa dizer sobre si: onde as
ferramentas rodam e como terminar. Andaime longo escrito para modelos
anteriores derruba a qualidade dos atuais.
"""

from __future__ import annotations

from pathlib import Path
from typing import Any

from .instruction import Instruction
from .memory.bridge import Recall

__all__ = ["MEMORY_CLOSE", "MEMORY_OPEN", "PREAMBLE", "assemble_system", "assemble_task"]

PREAMBLE = """\
Você trabalha em {workspace}. As ferramentas rodam ali dentro.

Quando terminar, responda com texto — sem chamar ferramenta — dizendo o que \
mudou e o que você verificou. Se não conseguiu terminar, diga o que faltou em \
vez de afirmar que está pronto."""

FINISH_ONLY = """\
Quando terminar, responda com texto — sem chamar ferramenta. Se não conseguiu \
terminar, diga o que faltou em vez de afirmar que está pronto."""

MEMORY_OPEN = "<memory>"
MEMORY_CLOSE = "</memory>"


def assemble_system(
    instruction: Instruction,
    *,
    skills_index: str = "",
    workspace: Path | str | None = None,
    extra: str = "",
    cache: bool = True,
) -> list[dict[str, Any]]:
    """Blocos de `system`. Um só bloco de texto, com breakpoint de cache no fim."""
    parts = [instruction.body.strip()]
    if skills_index:
        parts.append(skills_index.strip())
    parts.append(PREAMBLE.format(workspace=Path(workspace).resolve()) if workspace else FINISH_ONLY)
    if extra:
        parts.append(extra.strip())
    block: dict[str, Any] = {"type": "text", "text": "\n\n".join(p for p in parts if p)}
    if cache:
        block["cache_control"] = {"type": "ephemeral"}
    return [block]


def assemble_task(task: str, recall: Recall | None = None) -> str:
    """A primeira mensagem: memória recuperada (se houver) e a tarefa."""
    if recall is None or not recall.text:
        return task
    return f"{MEMORY_OPEN}\n{recall.text}\n{MEMORY_CLOSE}\n\n{task}"
