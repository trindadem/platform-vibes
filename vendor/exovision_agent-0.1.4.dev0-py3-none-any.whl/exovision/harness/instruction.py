"""A instrução é um documento, não uma string no código.

Prompt embutido em `.py` não tem diff legível, não tem versão e não tem como
alguém que não escreve Python revisar. A instrução mora num `.md` com
front-matter; o front-matter é metadado e **não entra no prompt**; o digest é
calculado sobre o corpo que de fato rodou — editar o texto sem refazer o digest
é mudança silenciosa, e o traço a denuncia (`startup` carrega o digest).

    ---
    name: revisor
    version: 1.2.0
    description: revisa PRs pequenos
    ---
    Você revisa pull requests...

`Library` monta uma biblioteca a partir de diretórios e resolve `nome@versão`.
Sem versão vem a maior, comparada por número — `1.10.0` é maior que `1.9.0`,
que a ordenação de texto erraria. Um caminho `.md` existente vence nome de
biblioteca, porque é o que alguém quis dizer ao apontar para um arquivo.
"""

from __future__ import annotations

import hashlib
import re
from collections.abc import Iterable
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

__all__ = ["Instruction", "InstructionError", "Library", "load_instruction", "parse_front_matter"]


class InstructionError(ValueError):
    """Documento malformado, ausente ou ambíguo."""


_FM = re.compile(r"\A---[ \t]*\r?\n(.*?)\r?\n---[ \t]*\r?\n?", re.DOTALL)


def _coerce(value: str) -> Any:
    v = value.strip()
    if not v:
        return ""
    if (v[0] == v[-1]) and v[0] in "\"'":
        return v[1:-1]
    low = v.lower()
    if low in ("true", "yes", "on"):
        return True
    if low in ("false", "no", "off"):
        return False
    if v.startswith("[") and v.endswith("]"):
        inner = v[1:-1].strip()
        return [_coerce(x) for x in inner.split(",")] if inner else []
    try:
        return int(v)
    except ValueError:
        pass
    try:
        return float(v)
    except ValueError:
        pass
    return v


def parse_front_matter(text: str) -> tuple[dict[str, Any], str]:
    """Front-matter YAML *plano* (chave: valor, listas inline) -> (meta, corpo).

    Subconjunto deliberado: sem aninhamento, sem âncoras. É o que uma instrução
    precisa, e não puxa um parser de YAML para a stdlib-only.
    """
    m = _FM.match(text)
    if not m:
        return {}, text
    meta: dict[str, Any] = {}
    for line in m.group(1).splitlines():
        s = line.strip()
        if not s or s.startswith("#"):
            continue
        if ":" not in s:
            raise InstructionError(f"linha de front-matter sem ':' -> {s!r}")
        key, _, val = s.partition(":")
        meta[key.strip()] = _coerce(val)
    return meta, text[m.end() :]


def _version_key(v: str) -> tuple[int, ...]:
    parts: list[int] = []
    for p in str(v).split("."):
        digits = "".join(ch for ch in p if ch.isdigit())
        parts.append(int(digits) if digits else 0)
    return tuple(parts)


@dataclass(frozen=True, slots=True)
class Instruction:
    """Um documento de instrução carregado."""

    name: str
    body: str
    version: str = "0.0.0"
    digest: str = ""
    path: str = ""
    meta: dict[str, Any] = field(default_factory=dict)

    @classmethod
    def from_text(cls, text: str, *, name: str = "", path: str = "") -> Instruction:
        meta, body = parse_front_matter(text)
        body = body.strip("\n")
        digest = hashlib.sha256(body.encode("utf-8")).hexdigest()
        nm = str(meta.get("name") or name or (Path(path).stem if path else "inline"))
        return cls(
            name=nm,
            body=body,
            version=str(meta.get("version", "0.0.0")),
            digest=digest,
            path=path,
            meta=meta,
        )

    @classmethod
    def inline(cls, text: str, *, name: str = "inline") -> Instruction:
        return cls.from_text(text, name=name)

    @property
    def ref(self) -> str:
        return f"{self.name}@{self.version}"

    @property
    def short_digest(self) -> str:
        return self.digest[:12]

    def to_dict(self) -> dict[str, Any]:
        return {
            "name": self.name,
            "version": self.version,
            "digest": self.digest,
            "path": self.path,
        }


def load_instruction(path: str | Path) -> Instruction:
    p = Path(path)
    if not p.is_file():
        raise InstructionError(f"instrução não encontrada: {p}")
    return Instruction.from_text(p.read_text(encoding="utf-8"), path=str(p))


class Library:
    """Biblioteca de instruções montada a partir de diretórios (`*.md`)."""

    def __init__(self, dirs: Iterable[str | Path] = ()) -> None:
        self._docs: dict[str, list[Instruction]] = {}
        for d in dirs:
            self.add_dir(d)

    def add_dir(self, d: str | Path) -> int:
        n = 0
        base = Path(d)
        if not base.is_dir():
            raise InstructionError(f"diretório de instruções não existe: {base}")
        for p in sorted(base.rglob("*.md")):
            if p.name.upper() == "SKILL.MD":
                continue  # skills têm carregador próprio
            doc = load_instruction(p)
            self._docs.setdefault(doc.name, []).append(doc)
            n += 1
        return n

    def add(self, doc: Instruction) -> None:
        self._docs.setdefault(doc.name, []).append(doc)

    def names(self) -> list[str]:
        return sorted(self._docs)

    def resolve(self, ref: str) -> Instruction:
        """`nome`, `nome@versão` ou um caminho `.md` existente."""
        p = Path(ref)
        if p.suffix.lower() == ".md" and p.is_file():
            return load_instruction(p)
        name, _, version = ref.partition("@")
        docs = self._docs.get(name)
        if not docs:
            raise InstructionError(f"instrução {name!r} não está na biblioteca: {self.names()}")
        if version:
            for d in docs:
                if d.version == version:
                    return d
            raise InstructionError(
                f"{name}@{version} não existe; versões: {[d.version for d in docs]}"
            )
        return max(docs, key=lambda d: _version_key(d.version))
