"""A bancada: bash, editor e busca, dentro de um workspace.

`bash_20250124` e `text_editor_20250728` são definidas pela Anthropic — nome,
esquema e semântica. O harness só as executa, e isso é decisão de projeto: o
modelo foi treinado nelas, e um `editar_arquivo` nosso gastaria contexto
ensinando o que ele já sabe. Elas vão **sem `input_schema`**.

`search` é nossa porque não há definida equivalente, e porque promover busca
a ferramenta própria paga: ela é seguramente paralelizável — pelo comando
opaco do bash o harness não distingue um `grep` de um `git push` — e o
resultado é ordenável, agrupado e com teto, que é contexto economizado.

O editor recusa `str_replace` quando o arquivo mudou depois da última leitura
e quando o trecho aparece mais de uma vez. São as duas invariantes que o bash
não consegue impor, e a razão de a edição não ser um `sed`.

Tudo é confinado ao workspace: caminho que resolve para fora é recusado.
"""

from __future__ import annotations

import os
import re
import subprocess
from pathlib import Path
from typing import Any

from .tools import ToolResult

__all__ = ["BASH_TYPE", "EDITOR_NAME", "EDITOR_TYPE", "Workbench"]

BASH_TYPE = "bash_20250124"
EDITOR_TYPE = "text_editor_20250728"
EDITOR_NAME = "str_replace_based_edit_tool"

_SKIP_DIRS = {
    ".git",
    "node_modules",
    ".venv",
    "venv",
    "__pycache__",
    ".ruff_cache",
    ".pytest_cache",
    ".mypy_cache",
    "dist",
    "build",
    ".tox",
}


def _truncate(text: str, limit: int) -> str:
    if len(text) <= limit:
        return text
    head = text[: limit // 2]
    tail = text[-(limit // 2) :]
    return f"{head}\n\n[... {len(text) - limit} caracteres omitidos ...]\n\n{tail}"


class Workbench:
    """Ferramentaria de workspace com a superfície `Toolset`."""

    def __init__(
        self,
        workspace: str | Path,
        *,
        timeout_s: float = 120.0,
        max_output_chars: int = 30_000,
        bash_risk: str = "write",
        env: dict[str, str] | None = None,
        search_max_results: int = 200,
    ) -> None:
        self.workspace = Path(workspace).resolve()
        if not self.workspace.is_dir():
            raise NotADirectoryError(f"workspace não existe: {self.workspace}")
        self.timeout_s = timeout_s
        self.max_output_chars = max_output_chars
        self.bash_risk = bash_risk
        self.env = env
        self.search_max_results = search_max_results
        #: mtime na última leitura, por arquivo — a invariante de obsolescência
        self._seen: dict[Path, float] = {}

    # ------------------------------------------------------- superfície
    def definitions(self) -> list[dict[str, Any]]:
        return [
            {"type": BASH_TYPE, "name": "bash"},
            {"type": EDITOR_TYPE, "name": EDITOR_NAME},
            {
                "name": "search",
                "description": "Busca uma expressão regular nos arquivos do workspace. Resultado agrupado por arquivo, com número de linha, limitado. Prefira a bash+grep: é paralelizável e não polui o contexto.",
                "input_schema": {
                    "type": "object",
                    "properties": {
                        "pattern": {"type": "string", "description": "expressão regular (Python)"},
                        "path": {
                            "type": "string",
                            "description": "subdiretório ou arquivo relativo ao workspace (padrão: raiz)",
                        },
                        "glob": {
                            "type": "string",
                            "description": "filtro de nome de arquivo, ex.: *.py",
                        },
                        "max_results": {
                            "type": "integer",
                            "description": "teto de linhas (padrão 200)",
                        },
                    },
                    "required": ["pattern"],
                },
            },
        ]

    def parallel_safe(self, name: str) -> bool:
        return name == "search"

    def risk(self, name: str) -> str:
        return {"bash": self.bash_risk, EDITOR_NAME: "write", "search": "read"}.get(
            name, "irreversible"
        )

    def __call__(self, name: str, arguments: dict[str, Any]) -> ToolResult:
        if name == "bash":
            return self.bash(**arguments)
        if name == EDITOR_NAME:
            return self.editor(**arguments)
        if name == "search":
            return self.search(**arguments)
        return ToolResult.error(f"ferramenta desconhecida na bancada: {name!r}", code=404)

    # ---------------------------------------------------------- caminhos
    def _resolve(self, path: str) -> Path:
        p = Path(path)
        p = (self.workspace / p) if not p.is_absolute() else p
        p = p.resolve()
        if p != self.workspace and self.workspace not in p.parents:
            raise PermissionError(f"caminho fora do workspace: {path}")
        return p

    # -------------------------------------------------------------- bash
    def bash(self, command: str = "", restart: bool = False, **_: Any) -> ToolResult:
        if restart:
            return ToolResult(
                text="shell reiniciado (cada comando roda num processo novo; não há estado a reiniciar)"
            )
        if not command.strip():
            return ToolResult.error("comando vazio", code=422)
        env = dict(os.environ)
        if self.env:
            env.update(self.env)
        try:
            proc = subprocess.run(
                ["bash", "-c", command],
                cwd=self.workspace,
                env=env,
                capture_output=True,
                text=True,
                timeout=self.timeout_s,
                errors="replace",
            )
        except subprocess.TimeoutExpired:
            return ToolResult.error(
                f"tempo esgotado após {self.timeout_s:.0f}s: {command[:80]}", code=124
            )
        except FileNotFoundError:
            return ToolResult.error("bash não encontrado neste ambiente", code=127)
        out = proc.stdout
        if proc.stderr:
            out = f"{out}\n[stderr]\n{proc.stderr}" if out else f"[stderr]\n{proc.stderr}"
        text = _truncate(out.rstrip("\n"), self.max_output_chars)
        if proc.returncode != 0:
            text = f"{text}\n[exit {proc.returncode}]" if text else f"[exit {proc.returncode}]"
        return ToolResult(
            text=text,
            ok=proc.returncode == 0,
            code=proc.returncode,
            metadata={"exit": proc.returncode},
        )

    # ------------------------------------------------------------ editor
    def editor(self, command: str = "", path: str = "", **kw: Any) -> ToolResult:
        try:
            p = self._resolve(path) if path else None
        except PermissionError as erro:
            return ToolResult.error(str(erro), code=403)
        if p is None:
            return ToolResult.error("`path` é obrigatório", code=422)
        try:
            if command == "view":
                return self._view(p, kw.get("view_range"))
            if command == "create":
                return self._create(p, kw.get("file_text", ""))
            if command == "str_replace":
                return self._str_replace(p, kw.get("old_str", ""), kw.get("new_str", ""))
            if command == "insert":
                return self._insert(p, int(kw.get("insert_line", 0)), kw.get("new_str", ""))
        except (OSError, ValueError) as erro:
            return ToolResult.error(f"{type(erro).__name__}: {erro}", code=500)
        return ToolResult.error(
            f"comando de editor desconhecido: {command!r} (view, create, str_replace, insert)",
            code=422,
        )

    def _remember(self, p: Path) -> None:
        self._seen[p] = p.stat().st_mtime_ns

    def _stale(self, p: Path) -> bool:
        seen = self._seen.get(p)
        return seen is None or p.stat().st_mtime_ns != seen

    def _view(self, p: Path, view_range: Any) -> ToolResult:
        if p.is_dir():
            entries = []
            for child in sorted(p.iterdir()):
                if child.name in _SKIP_DIRS:
                    continue
                entries.append(child.name + ("/" if child.is_dir() else ""))
            return ToolResult(text="\n".join(entries) or "(diretório vazio)")
        if not p.is_file():
            return ToolResult.error(f"não existe: {p.relative_to(self.workspace)}", code=404)
        lines = p.read_text(encoding="utf-8", errors="replace").splitlines()
        self._remember(p)
        start, end = 1, len(lines)
        if view_range:
            start = max(1, int(view_range[0]))
            end = len(lines) if int(view_range[1]) == -1 else min(len(lines), int(view_range[1]))
        numbered = [f"{i:6d}\t{lines[i - 1]}" for i in range(start, end + 1)]
        return ToolResult(
            text=_truncate("\n".join(numbered), self.max_output_chars),
            metadata={"lines": len(lines)},
        )

    def _create(self, p: Path, text: str) -> ToolResult:
        if p.exists():
            return ToolResult.error(
                f"já existe: {p.relative_to(self.workspace)} — use view + str_replace", code=409
            )
        p.parent.mkdir(parents=True, exist_ok=True)
        p.write_text(text, encoding="utf-8")
        self._remember(p)
        return ToolResult(
            text=f"criado {p.relative_to(self.workspace)} ({len(text.splitlines())} linhas)"
        )

    def _str_replace(self, p: Path, old: str, new: str) -> ToolResult:
        if not p.is_file():
            return ToolResult.error(f"não existe: {p.relative_to(self.workspace)}", code=404)
        if not old:
            return ToolResult.error("`old_str` vazio", code=422)
        if self._stale(p):
            return ToolResult.error(
                f"{p.relative_to(self.workspace)} mudou depois da última leitura (ou nunca foi lido): faça view antes de editar",
                code=409,
            )
        text = p.read_text(encoding="utf-8")
        n = text.count(old)
        if n == 0:
            return ToolResult.error(
                "`old_str` não encontrado no arquivo; confira espaços e indentação", code=404
            )
        if n > 1:
            return ToolResult.error(
                f"`old_str` aparece {n} vezes; inclua mais contexto para ficar único", code=409
            )
        p.write_text(text.replace(old, new, 1), encoding="utf-8")
        self._remember(p)
        line = text[: text.index(old)].count("\n") + 1
        return ToolResult(
            text=f"editado {p.relative_to(self.workspace)} na linha {line}", metadata={"line": line}
        )

    def _insert(self, p: Path, line: int, new: str) -> ToolResult:
        if not p.is_file():
            return ToolResult.error(f"não existe: {p.relative_to(self.workspace)}", code=404)
        if self._stale(p):
            return ToolResult.error(
                f"{p.relative_to(self.workspace)} mudou depois da última leitura (ou nunca foi lido): faça view antes de editar",
                code=409,
            )
        lines = p.read_text(encoding="utf-8").splitlines(keepends=True)
        if line < 0 or line > len(lines):
            return ToolResult.error(f"insert_line {line} fora de 0..{len(lines)}", code=422)
        ins = new if new.endswith("\n") else new + "\n"
        lines[line:line] = [ins]
        p.write_text("".join(lines), encoding="utf-8")
        self._remember(p)
        return ToolResult(text=f"inserido em {p.relative_to(self.workspace)} após a linha {line}")

    # ------------------------------------------------------------ search
    def search(
        self,
        pattern: str = "",
        path: str = "",
        glob: str = "",
        max_results: int | None = None,
        **_: Any,
    ) -> ToolResult:
        if not pattern:
            return ToolResult.error("`pattern` é obrigatório", code=422)
        try:
            rx = re.compile(pattern)
        except re.error as erro:
            return ToolResult.error(f"regex inválida: {erro}", code=422)
        try:
            root = self._resolve(path) if path else self.workspace
        except PermissionError as erro:
            return ToolResult.error(str(erro), code=403)
        cap = int(max_results or self.search_max_results)
        files = [root] if root.is_file() else sorted(self._walk(root, glob))
        hits: list[str] = []
        n_files = 0
        for f in files:
            try:
                text = f.read_text(encoding="utf-8")
            except (UnicodeDecodeError, OSError):
                continue
            found = [(i, ln) for i, ln in enumerate(text.splitlines(), 1) if rx.search(ln)]
            if not found:
                continue
            n_files += 1
            rel = f.relative_to(self.workspace)
            hits.append(f"{rel}:")
            for i, ln in found:
                hits.append(f"  {i}: {ln.strip()[:200]}")
                if len(hits) >= cap:
                    hits.append(f"[... teto de {cap} linhas atingido ...]")
                    return ToolResult(
                        text="\n".join(hits), metadata={"files": n_files, "truncated": True}
                    )
        return ToolResult(
            text="\n".join(hits) if hits else "(nenhuma ocorrência)", metadata={"files": n_files}
        )

    def _walk(self, root: Path, glob: str) -> list[Path]:
        out: list[Path] = []
        for dirpath, dirnames, filenames in os.walk(root):
            dirnames[:] = [d for d in dirnames if d not in _SKIP_DIRS and not d.startswith(".")]
            for fn in filenames:
                if fn.startswith("."):
                    continue
                p = Path(dirpath) / fn
                if glob and not p.match(glob):
                    continue
                out.append(p)
        return out
