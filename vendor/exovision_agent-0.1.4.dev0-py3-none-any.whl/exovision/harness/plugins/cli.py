"""`exovision-agent plugins`: o que está anexado, em que estado, e por quê.

    exovision-agent plugins ls ./plugins --trust-db .exovision/trust.db
    exovision-agent plugins show ./plugins/geo
    exovision-agent plugins verify ./plugins/geo --trust-db .exovision/trust.db   # suíte verde -> verified
    exovision-agent plugins trust ./plugins/geo --trust-db .exovision/trust.db    # decisão do operador
    exovision-agent plugins untrust geo --trust-db .exovision/trust.db
    exovision-agent plugins new ./plugins/meu --description "o que faz"
    exovision-agent plugins bench all                                             # docs/plugins/resultados/

Anexar é `exovision-agent run ... --plugin ./meu-plugin` (repetível); o
diretório `plugins/` do workspace é anexado sozinho. `--evolve` dá ao agente
o meta-toolset que cria plugins e tools (em draft; a suíte promove).
"""

from __future__ import annotations

import argparse
import json
import sys
import time
from pathlib import Path
from typing import Any

from .bench import BENCHMARKS, run_benchmark
from .plugin import PluginError, load_plugin, load_plugins
from .trust import SQLiteTrustStore, TrustStore, resolve, trust, untrust, verify

__all__ = ["add_parser", "trust_store"]


def trust_store(path: str | None) -> TrustStore | None:
    return SQLiteTrustStore(path) if path else None


def _line(pl: Any, state: str, reason: str) -> str:
    return f"{pl.name:20s} v{pl.version:8s} {state:9s} tools={len(pl.tools):<3d} skills={len(pl.skills):<2d} casos={len(pl.cases):<3d} {reason}"


def cmd_ls(a: argparse.Namespace) -> int:
    store = trust_store(a.trust_db)
    try:
        plugins = load_plugins(a.paths)
    except PluginError as erro:
        raise SystemExit(str(erro)) from None
    rows = []
    for pl in plugins:
        state, reason = resolve(pl, store)
        rows.append((pl, state, reason))
    if a.json:
        print(json.dumps([{**pl.summary(), "state": st, "reason": rs} for pl, st, rs in rows], ensure_ascii=False, indent=2))
        return 0
    for pl, st, rs in rows:
        print(_line(pl, st, rs))
        for w in pl.warnings:
            print(f"    ! {w}")
    return 0


def cmd_show(a: argparse.Namespace) -> int:
    try:
        pl = load_plugin(a.path)
    except PluginError as erro:
        raise SystemExit(str(erro)) from None
    state, reason = resolve(pl, trust_store(a.trust_db))
    if a.json:
        print(json.dumps({**pl.summary(), "state": state, "reason": reason, "tools_detail": [t.definition() for t in pl.tools]}, ensure_ascii=False, indent=2))
        return 0
    print(_line(pl, state, reason))
    for t in pl.tools:
        props = ", ".join(t.input_schema.get("properties", {}))
        print(f"  {pl.prefix}_{t.name}({props})  risco={t.risk} paralela={t.parallel_safe}\n      {t.description[:100]}")
    for s in pl.skills:
        print(f"  skill {s.name}: {s.description[:80]}")
    for m in pl.mcp:
        print(f"  mcp {m.get('spec')}")
    for w in pl.warnings:
        print(f"  ! {w}")
    return 0


def cmd_verify(a: argparse.Namespace) -> int:
    try:
        pl = load_plugin(a.path)
    except PluginError as erro:
        raise SystemExit(str(erro)) from None
    rep = verify(pl, store=trust_store(a.trust_db))
    print(json.dumps(rep.to_dict(), ensure_ascii=False, indent=2))
    return 0 if rep.ok else 1


def cmd_trust(a: argparse.Namespace) -> int:
    if not a.trust_db:
        raise SystemExit("trust precisa de --trust-db: a confiança é do operador e mora no disco")
    try:
        pl = load_plugin(a.path)
    except PluginError as erro:
        raise SystemExit(str(erro)) from None
    rec = trust(pl, SQLiteTrustStore(a.trust_db), note=a.note or "")
    print(f"{rec.name}: trusted ({rec.note})")
    return 0


def cmd_untrust(a: argparse.Namespace) -> int:
    if not a.trust_db:
        raise SystemExit("untrust precisa de --trust-db")
    ok = untrust(a.name, SQLiteTrustStore(a.trust_db))
    print("draft" if ok else f"sem registro para {a.name!r}")
    return 0 if ok else 1


def cmd_new(a: argparse.Namespace) -> int:
    d = Path(a.path)
    if (d / "PLUGIN.md").exists():
        raise SystemExit(f"já existe: {d / 'PLUGIN.md'}")
    (d / "tools").mkdir(parents=True, exist_ok=True)
    (d / "evals").mkdir(exist_ok=True)
    (d / "skills").mkdir(exist_ok=True)
    (d / "PLUGIN.md").write_text(
        f"---\nname: {a.name or d.name}\nversion: 0.1.0\ndescription: {a.description}\nauthor: {a.author or ''}\nrisk: write\n---\n\n"
        "O que este plugin faz, para quem lê. O front-matter acima é o que o harness lê.\n\n"
        "- `tools.py` ou `tools/*.py`: funções públicas com docstring e anotações de tipo (nível 0)\n"
        "- `tools/<nome>.md`: risco, parallel_safe, timeout_s, max_chars e exemplos ```json (nível 1)\n"
        "- `skills/<nome>/SKILL.md`, `instruction.md`, `mcp.json`, `requires.txt`\n"
        "- `evals/*.json`: casos [{tool, args, expect}] — verdes, promovem o plugin a verified\n",
        encoding="utf-8",
    )
    (d / "tools.py").write_text(
        '"""Ferramentas do plugin. Cada função pública com docstring vira uma tool."""\n\n\n'
        "def ola(nome: str) -> str:\n"
        '    """Cumprimenta alguém pelo nome.\n\n    Args:\n        nome: quem cumprimentar\n    """\n'
        '    return f"olá, {nome}!"\n',
        encoding="utf-8",
    )
    (d / "evals" / "cases.json").write_text(
        json.dumps([{"tool": "ola", "args": {"nome": "Ana"}, "expect": {"contains": "Ana"}}], ensure_ascii=False, indent=2),
        encoding="utf-8",
    )
    print(f"plugin criado em {d} (draft; `plugins verify` promove)")
    return 0


def cmd_bench(a: argparse.Namespace) -> int:
    quais = list(BENCHMARKS) if a.which == "all" else [a.which]
    for nome in quais:
        t0 = time.perf_counter()
        path = run_benchmark(nome, seed=a.seed, out_dir=a.out)
        sys.stderr.write(f"{nome}: {path} ({time.perf_counter() - t0:.1f}s)\n")
        print(path)
    return 0


def add_parser(sub: Any) -> None:
    sp = sub.add_parser(
        "plugins",
        help="plugins: listar, inspecionar, verificar, confiar, criar, medir",
        description=__doc__,
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )
    ss = sp.add_subparsers(dest="pcmd", required=True)

    def tdb(p: argparse.ArgumentParser) -> None:
        p.add_argument("--trust-db", default=None, help="SQLite com o estado de confiança (do operador)")

    ls = ss.add_parser("ls", help="lista plugins de um ou mais diretórios")
    ls.add_argument("paths", nargs="+")
    tdb(ls)
    ls.add_argument("--json", action="store_true")
    ls.set_defaults(fn=cmd_ls)

    sh = ss.add_parser("show", help="um plugin: tools, skills, estado e avisos")
    sh.add_argument("path")
    tdb(sh)
    sh.add_argument("--json", action="store_true")
    sh.set_defaults(fn=cmd_show)

    vf = ss.add_parser("verify", help="roda a suíte; verde e não vazia -> verified")
    vf.add_argument("path")
    tdb(vf)
    vf.set_defaults(fn=cmd_verify)

    tr = ss.add_parser("trust", help="decisão do operador: trusted (cai se o fingerprint mudar)")
    tr.add_argument("path")
    tdb(tr)
    tr.add_argument("--note")
    tr.set_defaults(fn=cmd_trust)

    ut = ss.add_parser("untrust", help="remove o registro: volta a draft")
    ut.add_argument("name")
    tdb(ut)
    ut.set_defaults(fn=cmd_untrust)

    nw = ss.add_parser("new", help="esqueleto de plugin: PLUGIN.md, tools.py, evals/cases.json")
    nw.add_argument("path")
    nw.add_argument("--description", required=True)
    nw.add_argument("--name")
    nw.add_argument("--author")
    nw.set_defaults(fn=cmd_new)

    bn = ss.add_parser("bench", help="os benchmarks do estudo (B1..B6), offline")
    bn.add_argument("which", choices=["all", *BENCHMARKS])
    bn.add_argument("--seed", type=int, default=0)
    bn.add_argument("--out", default=None, help="diretório (padrão docs/plugins/resultados)")
    bn.set_defaults(fn=cmd_bench)
