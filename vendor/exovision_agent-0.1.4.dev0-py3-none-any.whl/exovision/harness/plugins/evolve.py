"""Evolve: o agente escreve tools e plugins — em `draft`; só o verificador promove.

É o laço *gera → verifica → arquiva* de Voyager, da Darwin Gödel Machine e
do Alita, com o verificador no lugar onde antes ficava o contrato:

    evolve_new(plugin, descrição)           cria plugins/<plugin>/PLUGIN.md
    evolve_tool(plugin, nome, código)       escreve tools/<nome>.py (nível 0) e devolve o schema inferido
    evolve_case(plugin, tool, args, expect) anexa um caso a evals/cases.json
    evolve_verify(plugin)                   roda a suíte; verde -> verified (gravado com fingerprint)
    evolve_try(plugin, tool, arguments)     executa uma tool de draft agora, sob piso external
    evolve_plugins()                        o que existe, em que estado, e por quê

O código passa por validação **estrutural** — compila; define exatamente a
função pedida, com docstring; no topo do arquivo só imports, defs e
constantes (nada executa ao carregar). Segurança não é isto: é o piso de
risco de `draft` (`external`) e a política do agente. Uma tool nova entra na
ferramentaria do **próximo** laço (a ferramentaria é fixa dentro de um
`run`, pelo cache de prefixo); nesta sessão, `evolve_try` a alcança.

O que não se mede aqui, mede-se no benchmark B4: ganho de tool criada só
conta com compute igualado e holdout — a lição da reavaliação do TroVE.
"""

from __future__ import annotations

import ast
import json
import re
import time
from collections.abc import Callable
from pathlib import Path
from typing import Any

from ..tools import Registry, Tool, ToolResult
from .plugin import PluginError, PluginToolset, load_plugin, load_plugins
from .trust import TrustStore, resolve, verify

__all__ = ["Evolve", "check_tool_source"]

_IDENT = re.compile(r"^[a-z][a-z0-9_]{0,63}$")


def check_tool_source(code: str, name: str) -> list[str]:
    """Erros estruturais do código de uma tool nível 0. Vazio = aceito."""
    erros: list[str] = []
    try:
        tree = ast.parse(code)
    except SyntaxError as erro:
        return [f"não compila: {erro.msg} (linha {erro.lineno})"]
    defs = [n for n in tree.body if isinstance(n, (ast.FunctionDef, ast.AsyncFunctionDef))]
    target = next((d for d in defs if d.name == name), None)
    if target is None:
        erros.append(f"o arquivo precisa definir a função {name!r} no topo")
    elif not ast.get_docstring(target):
        erros.append(f"{name!r} sem docstring: existe e nunca é escolhida")
    for node in tree.body:
        if isinstance(node, (ast.Import, ast.ImportFrom, ast.FunctionDef, ast.AsyncFunctionDef, ast.ClassDef)):
            continue
        if isinstance(node, (ast.Assign, ast.AnnAssign)) and isinstance(getattr(node, "value", None), ast.Constant):
            continue
        if isinstance(node, ast.Expr) and isinstance(node.value, ast.Constant):
            continue  # docstring do módulo
        erros.append(f"linha {node.lineno}: no topo do arquivo só imports, defs e constantes (nada executa ao carregar)")
    return erros


class Evolve(Registry):
    """O meta-toolset. `root` é o diretório de plugins do workspace (`plugins/`)."""

    def __init__(
        self,
        root: str | Path,
        *,
        store: TrustStore | None = None,
        prefix: str = "evolve",
        clock: Callable[[], float] = time.time,
    ) -> None:
        self.root = Path(root)
        self.store = store
        self.prefix = prefix
        self._clock = clock
        p = f"{prefix}_" if prefix else ""
        super().__init__(
            [
                Tool(name=f"{p}plugins", description="Lista os plugins do workspace: nome, estado de confiança (draft/verified/trusted) e por quê, tools e número de casos.", fn=self._plugins, input_schema={"type": "object", "properties": {}}, parallel_safe=True, risk="read"),
                Tool(name=f"{p}new", description="Cria um plugin novo (em draft) no workspace: um diretório com PLUGIN.md. Use antes de escrever tools nele.", fn=self._new, input_schema={"type": "object", "properties": {"name": {"type": "string", "description": "nome: minúsculas, dígitos, - e _"}, "description": {"type": "string", "description": "uma frase: o que o plugin faz"}, "version": {"type": "string", "description": "padrão 0.1.0"}}, "required": ["name", "description"]}, risk="write"),
                Tool(name=f"{p}tool", description="Escreve (ou substitui) uma tool nível 0 num plugin: um arquivo Python que define a função `name` com docstring e anotações de tipo. Devolve o schema inferido — o contrato que o modelo verá. A tool entra na ferramentaria do próximo laço; nesta sessão use evolve_try.", fn=self._tool, input_schema={"type": "object", "properties": {"plugin": {"type": "string"}, "name": {"type": "string", "description": "nome da função/tool"}, "code": {"type": "string", "description": "código Python completo do arquivo (imports + def name(...) com docstring)"}}, "required": ["plugin", "name", "code"]}, risk="write"),
                Tool(name=f"{p}case", description="Anexa um caso de verificação ao plugin: chamar `tool` com `args` e conferir `expect` ({ok, contains, equals, code}). Casos verdes são o que promove o plugin de draft para verified.", fn=self._case, input_schema={"type": "object", "properties": {"plugin": {"type": "string"}, "tool": {"type": "string"}, "args": {"type": "object"}, "expect": {"type": "object", "description": "ex.: {\"contains\": \"42\"} ou {\"ok\": true}"}}, "required": ["plugin", "tool", "args"]}, risk="write"),
                Tool(name=f"{p}verify", description="Roda a suíte do plugin (exemplos dos manifestos + evals/). Tudo verde e não vazio -> verified; qualquer falha -> continua draft e o relatório diz por quê.", fn=self._verify, input_schema={"type": "object", "properties": {"plugin": {"type": "string"}}, "required": ["plugin"]}, risk="write"),
                Tool(name=f"{p}try", description="Executa agora uma tool de um plugin em draft, com os argumentos dados (sob piso de risco external). Serve para testar o que você acabou de escrever.", fn=self._try, input_schema={"type": "object", "properties": {"plugin": {"type": "string"}, "tool": {"type": "string"}, "arguments": {"type": "object"}}, "required": ["plugin", "tool"]}, risk="external"),
            ]
        )

    # ------------------------------------------------------------ apoio
    def _dir(self, plugin: str) -> Path:
        if not _IDENT.match(plugin.replace("-", "_")):
            raise ValueError(f"nome de plugin inválido: {plugin!r}")
        return self.root / plugin

    def _load(self, plugin: str):
        d = self._dir(plugin)
        if not (d / "PLUGIN.md").is_file():
            raise FileNotFoundError(f"plugin {plugin!r} não existe em {self.root}; crie com {self.prefix}_new")
        return load_plugin(d)

    # ------------------------------------------------------------ tools
    def _plugins(self) -> ToolResult:
        if not self.root.is_dir():
            return ToolResult(text="(nenhum plugin; use evolve_new)", metadata={"count": 0})
        try:
            plugins = load_plugins([self.root])
        except PluginError as erro:
            return ToolResult.error(str(erro), code=422)
        rows = []
        for pl in plugins:
            state, reason = resolve(pl, self.store)
            rows.append({"name": pl.name, "state": state, "reason": reason, "tools": [t.name for t in pl.tools], "cases": len(pl.cases), "warnings": pl.warnings})
        return ToolResult(text=json.dumps(rows, ensure_ascii=False, indent=2), metadata={"count": len(rows)})

    def _new(self, name: str, description: str, version: str = "0.1.0") -> ToolResult:
        try:
            d = self._dir(name)
        except ValueError as erro:
            return ToolResult.error(str(erro), code=422)
        if (d / "PLUGIN.md").is_file():
            return ToolResult.error(f"plugin {name!r} já existe", code=409)
        if not description.strip():
            return ToolResult.error("description vazia: existe e nunca é escolhido", code=422)
        (d / "tools").mkdir(parents=True, exist_ok=True)
        (d / "evals").mkdir(exist_ok=True)
        (d / "PLUGIN.md").write_text(
            f"---\nname: {name}\nversion: {version}\ndescription: {description.strip()}\nauthor: agent\n---\n\nCriado pelo agente via Evolve em {time.strftime('%Y-%m-%d')}. Em draft até a suíte passar.\n",
            encoding="utf-8",
        )
        return ToolResult(text=f"plugin {name!r} criado em {d} (draft)", metadata={"path": str(d)})

    def _tool(self, plugin: str, name: str, code: str) -> ToolResult:
        if not _IDENT.match(name):
            return ToolResult.error(f"nome de tool inválido: {name!r}", code=422)
        try:
            d = self._dir(plugin)
        except ValueError as erro:
            return ToolResult.error(str(erro), code=422)
        if not (d / "PLUGIN.md").is_file():
            return ToolResult.error(f"plugin {plugin!r} não existe; crie com {self.prefix}_new", code=404)
        erros = check_tool_source(code, name)
        if erros:
            return ToolResult.error("código recusado: " + "; ".join(erros), code=422)
        target = d / "tools" / f"{name}.py"
        target.parent.mkdir(parents=True, exist_ok=True)
        previous = target.read_text(encoding="utf-8") if target.is_file() else None
        target.write_text(code.rstrip() + "\n", encoding="utf-8")
        try:
            pl = load_plugin(d)
        except PluginError as erro:
            if previous is None:
                target.unlink(missing_ok=True)
            else:
                target.write_text(previous, encoding="utf-8")
            return ToolResult.error(f"código recusado ao carregar: {erro}", code=422)
        t = next((x for x in pl.tools if x.name == name), None)
        if t is None:
            why = next((w for w in pl.warnings if f":{name}:" in w), "não virou tool")
            if previous is None:
                target.unlink(missing_ok=True)
            else:
                target.write_text(previous, encoding="utf-8")
            return ToolResult.error(f"código recusado: {why}", code=422)
        state, reason = resolve(pl, self.store)
        return ToolResult(
            text=json.dumps({"tool": f"{pl.prefix}_{name}", "schema": t.input_schema, "risk": t.risk, "state": state, "reason": reason, "warnings": pl.warnings}, ensure_ascii=False, indent=2),
            metadata={"path": str(target), "state": state},
        )

    def _case(self, plugin: str, tool: str, args: dict[str, Any], expect: dict[str, Any] | None = None) -> ToolResult:
        try:
            pl = self._load(plugin)
        except (ValueError, FileNotFoundError, PluginError) as erro:
            return ToolResult.error(str(erro), code=404)
        if tool not in {t.name for t in pl.tools}:
            return ToolResult.error(f"tool {tool!r} não existe no plugin {plugin!r}: {[t.name for t in pl.tools]}", code=404)
        f = Path(pl.path) / "evals" / "cases.json"
        f.parent.mkdir(exist_ok=True)
        cases = json.loads(f.read_text(encoding="utf-8")) if f.is_file() else []
        cases.append({"tool": tool, "args": dict(args or {}), "expect": dict(expect or {})})
        f.write_text(json.dumps(cases, ensure_ascii=False, indent=2), encoding="utf-8")
        return ToolResult(text=f"caso {len(cases)} anexado a {plugin}/evals/cases.json", metadata={"cases": len(cases)})

    def _verify(self, plugin: str) -> ToolResult:
        try:
            pl = self._load(plugin)
        except (ValueError, FileNotFoundError, PluginError) as erro:
            return ToolResult.error(str(erro), code=404)
        rep = verify(pl, store=self.store, clock=self._clock)
        return ToolResult(text=json.dumps(rep.to_dict(), ensure_ascii=False, indent=2), ok=rep.ok, code=0 if rep.ok else 1, metadata={"state": rep.state})

    def _try(self, plugin: str, tool: str, arguments: dict[str, Any] | None = None) -> ToolResult:
        try:
            pl = self._load(plugin)
        except (ValueError, FileNotFoundError, PluginError) as erro:
            return ToolResult.error(str(erro), code=404)
        ts = PluginToolset(pl, risk_floor="external", prefix="")
        return ts(tool, dict(arguments or {}))

