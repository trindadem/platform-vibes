"""Tools em dois níveis de formalidade, um dial: a função (0) e o manifesto (1).

**Nível 0 — a função.** Um arquivo `.py` com funções públicas documentadas. O
schema vem da assinatura; a descrição, da docstring; o risco é `write` por
padrão (desce só por declaração; a política pode subir). A docstring é o
contrato que o modelo lê — documentação zero-shot iguala demonstrações
few-shot (Hsieh et al., 2023). Função sem docstring não vira tool: existe e
nunca é escolhida.

**Nível 1 — o manifesto.** `tools/<nome>.md` ao lado, com front-matter
(`risk`, `parallel_safe`, `timeout_s`, `max_chars`, `strict`), corpo que
substitui a descrição, e exemplos em blocos ```json que são **validados
contra o schema no carregamento e viram casos de verificação**. Formalidade
gradual (Siek & Taha, 2006): sobe onde o autor quer, e só ali.

O nível 2 é o servidor MCP (`mcp/`), que já existe.
"""

from __future__ import annotations

import concurrent.futures
import inspect
import json
import re
import sys
import types
from collections.abc import Callable
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

from ..instruction import parse_front_matter
from ..tools import (
    RISK_LEVELS,
    Tool,
    ToolAssemblyError,
    ToolResult,
    normalize,
    schema_from_signature,
)

__all__ = ["Case", "Manifest", "ToolFile", "load_manifest", "load_tool_file", "validate_args"]

_FENCE = re.compile(r"```json\s*\n(.*?)```", re.DOTALL)


@dataclass(frozen=True, slots=True)
class Case:
    """Um caso de verificação: chamar `tool` com `args` e conferir `expect`.

    `expect` aceita `ok` (bool), `contains` (substring do texto), `equals`
    (texto exato) e `code` (código do resultado). Vazio = só precisa rodar.
    """

    tool: str
    args: dict[str, Any] = field(default_factory=dict)
    expect: dict[str, Any] = field(default_factory=dict)
    origin: str = ""  # arquivo de onde veio

    def check(self, result: ToolResult) -> str:
        """`""` se passou; senão, a razão."""
        e = self.expect
        if "ok" in e and bool(e["ok"]) != result.ok:
            return f"esperava ok={e['ok']}, veio ok={result.ok}: {result.text[:120]}"
        if "code" in e and int(e["code"]) != result.code:
            return f"esperava code={e['code']}, veio {result.code}"
        if "contains" in e and str(e["contains"]) not in result.text:
            return f"esperava conter {e['contains']!r}, veio: {result.text[:120]!r}"
        if "equals" in e and str(e["equals"]) != result.text:
            return f"esperava {e['equals']!r}, veio {result.text[:120]!r}"
        return ""

    def to_dict(self) -> dict[str, Any]:
        return {"tool": self.tool, "args": self.args, "expect": self.expect}


@dataclass(slots=True)
class Manifest:
    """O que `tools/<nome>.md` declara. Tudo opcional; o que não está vem da função."""

    name: str
    description: str = ""
    risk: str | None = None
    parallel_safe: bool | None = None
    timeout_s: float | None = None
    max_chars: int | None = None
    strict: bool = False
    examples: list[Case] = field(default_factory=list)
    path: str = ""


def load_manifest(path: str | Path) -> Manifest:
    p = Path(path)
    # linhas em branco antes do front-matter são acidente de autoria, não ambiguidade
    meta, body = parse_front_matter(p.read_text(encoding="utf-8").lstrip("\r\n"))
    name = str(meta.get("name") or p.stem)
    risk = meta.get("risk")
    if risk is not None and str(risk) not in RISK_LEVELS:
        raise ToolAssemblyError(f"{p}: risco {risk!r} fora de {RISK_LEVELS}")
    examples: list[Case] = []
    for i, block in enumerate(_FENCE.findall(body)):
        try:
            data = json.loads(block)
        except json.JSONDecodeError as erro:
            raise ToolAssemblyError(f"{p}: exemplo {i + 1} não é JSON: {erro}") from None
        if not isinstance(data, dict) or "args" not in data:
            raise ToolAssemblyError(f"{p}: exemplo {i + 1} precisa de {{\"args\": ..., \"expect\": ...}}")
        examples.append(
            Case(tool=name, args=dict(data["args"]), expect=dict(data.get("expect") or {}), origin=str(p))
        )
    description = _FENCE.sub("", body).strip()
    return Manifest(
        name=name,
        description=description,
        risk=str(risk) if risk is not None else None,
        parallel_safe=(bool(meta["parallel_safe"]) if "parallel_safe" in meta else None),
        timeout_s=(float(meta["timeout_s"]) if meta.get("timeout_s") is not None else None),
        max_chars=(int(meta["max_chars"]) if meta.get("max_chars") is not None else None),
        strict=bool(meta.get("strict", False)),
        examples=examples,
        path=str(p),
    )


_JSON_TYPES: dict[str, tuple[type, ...]] = {
    "string": (str,),
    "integer": (int,),
    "number": (int, float),
    "boolean": (bool,),
    "array": (list, tuple),
    "object": (dict,),
}


def validate_args(schema: dict[str, Any], args: dict[str, Any]) -> list[str]:
    """Erros de um `args` contra o schema inferido (obrigatórios, tipos primitivos, enum)."""
    erros: list[str] = []
    props = schema.get("properties") or {}
    for req in schema.get("required") or []:
        if req not in args:
            erros.append(f"falta o argumento obrigatório {req!r}")
    for k, v in args.items():
        if k not in props:
            erros.append(f"argumento desconhecido {k!r}")
            continue
        spec = props[k]
        t = spec.get("type")
        if t in _JSON_TYPES and not isinstance(v, _JSON_TYPES[t]):
            erros.append(f"{k!r} deveria ser {t}, veio {type(v).__name__}")
        if t == "integer" and isinstance(v, bool):
            erros.append(f"{k!r} deveria ser integer, veio bool")
        if "enum" in spec and v not in spec["enum"]:
            erros.append(f"{k!r} fora de {spec['enum']}")
    return erros


@dataclass(slots=True)
class ToolFile:
    """O que um arquivo `.py` rendeu: tools, e o que foi pulado e por quê."""

    path: str
    tools: list[Tool] = field(default_factory=list)
    sources: dict[str, str] = field(default_factory=dict)  # nome -> fonte da função
    skipped: dict[str, str] = field(default_factory=dict)  # nome -> razão


def _wrap(fn: Callable[..., Any], *, timeout_s: float | None, max_chars: int | None) -> Callable[..., Any]:
    if timeout_s is None and max_chars is None:
        return fn

    def wrapped(**kw: Any) -> ToolResult:
        if timeout_s is not None:
            pool = concurrent.futures.ThreadPoolExecutor(max_workers=1)
            fut = pool.submit(fn, **kw)
            try:
                value = fut.result(timeout=timeout_s)
            except concurrent.futures.TimeoutError:
                pool.shutdown(wait=False, cancel_futures=True)
                return ToolResult.error(f"tempo esgotado ({timeout_s}s)", code=504)
            pool.shutdown(wait=False)
        else:
            value = fn(**kw)
        result = normalize(value)
        if max_chars is not None and len(result.text) > max_chars:
            result = ToolResult(
                text=result.text[:max_chars] + f"\n… [{len(result.text) - max_chars} caracteres cortados]",
                ok=result.ok,
                code=result.code,
                metadata={**result.metadata, "truncated": True},
                blocks=result.blocks,
            )
        return result

    wrapped.__name__ = getattr(fn, "__name__", "tool")
    wrapped.__doc__ = fn.__doc__
    wrapped.__signature__ = inspect.signature(fn)  # type: ignore[attr-defined]
    return wrapped


def load_tool_file(
    path: str | Path,
    *,
    manifests: dict[str, Manifest] | None = None,
    default_risk: str = "write",
    module_name: str | None = None,
) -> ToolFile:
    """Executa o arquivo num módulo próprio e colhe as tools.

    Colhe `Tool` já decoradas e funções públicas *definidas ali* com
    docstring. `manifests` (nível 1) sobrepõe descrição, risco, paralelismo e
    limites. Nada aqui decide segurança: o código roda no processo, sob a
    política e o piso de risco do plugin.
    """
    p = Path(path).resolve()
    manifests = manifests or {}
    name = module_name or f"exovision_plugin_{abs(hash(str(p)))}"
    mod = types.ModuleType(name)
    mod.__file__ = str(p)
    source = p.read_text(encoding="utf-8")
    code = compile(source, str(p), "exec")
    sys.modules[name] = mod
    try:
        exec(code, mod.__dict__)
    except Exception as erro:
        sys.modules.pop(name, None)
        raise ToolAssemblyError(f"{p}: falha ao carregar: {type(erro).__name__}: {erro}") from None
    out = ToolFile(path=str(p))
    seen: set[str] = set()
    for attr, obj in list(vars(mod).items()):
        if attr.startswith("_"):
            continue
        if isinstance(obj, Tool):
            t = _apply_manifest(obj, manifests.get(obj.name))
            out.tools.append(t)
            seen.add(t.name)
            with_src = getattr(obj.fn, "__wrapped__", obj.fn)
            out.sources[t.name] = _source_of(with_src, source)
            continue
        if not inspect.isfunction(obj) or obj.__module__ != name:
            continue
        if attr in seen:
            continue
        doc = inspect.getdoc(obj) or ""
        man = manifests.get(attr)
        description = (man.description if man and man.description else doc.split("\n\n")[0].strip())
        if not description:
            out.skipped[attr] = "sem docstring: existe e nunca é escolhida"
            continue
        try:
            t = Tool(
                name=attr,
                description=description,
                fn=_wrap(obj, timeout_s=man.timeout_s if man else None, max_chars=man.max_chars if man else None),
                input_schema=schema_from_signature(obj),
                parallel_safe=bool(man.parallel_safe) if man and man.parallel_safe is not None else False,
                risk=(man.risk if man and man.risk else default_risk),
                strict=bool(man.strict) if man else False,
            )
        except ToolAssemblyError as erro:
            out.skipped[attr] = str(erro)
            continue
        out.tools.append(t)
        seen.add(attr)
        out.sources[attr] = _source_of(obj, source)
    for man_name in manifests:
        if man_name not in seen and man_name not in out.skipped:
            out.skipped[man_name] = f"manifesto sem função correspondente em {p.name}"
    # exemplos do manifesto: validados contra o schema agora, não na hora de rodar
    by_name = {t.name: t for t in out.tools}
    for man in manifests.values():
        owner = by_name.get(man.name)
        if owner is None:
            continue
        for i, case in enumerate(man.examples):
            erros = validate_args(owner.input_schema, case.args)
            if erros:
                raise ToolAssemblyError(f"{man.path}: exemplo {i + 1} não casa o schema de {man.name!r}: {'; '.join(erros)}")
    return out


def _apply_manifest(t: Tool, man: Manifest | None) -> Tool:
    if man is None:
        return t
    return Tool(
        name=t.name,
        description=man.description or t.description,
        fn=_wrap(t.fn, timeout_s=man.timeout_s, max_chars=man.max_chars),
        input_schema=t.input_schema,
        parallel_safe=t.parallel_safe if man.parallel_safe is None else man.parallel_safe,
        risk=man.risk or t.risk,
        strict=man.strict or t.strict,
    )


def _source_of(fn: Callable[..., Any], fallback: str) -> str:
    try:
        return inspect.getsource(fn)
    except (OSError, TypeError):
        return fallback
