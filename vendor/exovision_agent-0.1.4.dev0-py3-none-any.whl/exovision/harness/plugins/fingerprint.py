"""Identidade de um plugin por componente: digest exato e fingerprint de família.

Um hash criptográfico responde "é o mesmo byte a byte?" e nada mais — uma
edição de um caractere embaralha o digest. A identidade útil para um plugin
que evolui é dupla: o **digest** por componente (o que foi aprovado é
exatamente isto?) e um **fingerprint sensível a localidade** por componente
(isto é a mesma família, só mudou o quê?), como propõe a decomposição por
componente para skills (prompt, código, tools). Aqui o fingerprint é um
SimHash de 64 bits sobre 3-gramas de tokens, **ponderado**: um shingle que
carrega um identificador (nome de função, parâmetro, palavra com dígito ou
sublinhado) pesa mais que um de prosa comum — a identidade de um código mora
nos nomes, e o esqueleto (docstrings, `return`, `Args:`) é igual em todo
plugin. A distância de Hamming é pequena para paráfrase e refatoração leve e
grande entre plugins diferentes. É *linhagem*, não equivalência de
comportamento — a equivalência quem diz é a suíte.
"""

from __future__ import annotations

import hashlib
import re
from collections.abc import Iterable, Mapping
from dataclasses import dataclass, field
from typing import Any

__all__ = ["COMPONENTS", "FAMILY_THRESHOLD", "Fingerprint", "canonical_code", "digest", "hamming", "simhash"]

COMPONENTS: tuple[str, ...] = ("prompt", "code", "tools")
_WORD = re.compile(r"[^\W\d]\w*|\d+|[^\s\w]")
_IDENT = re.compile(r"[^\W\d]*(?:_\w+|[^\W\d]+\d+|[a-z][A-Z])")
#: peso de um shingle com identificador vs prosa/pontuação
IDENT_WEIGHT = 4
#: distância de Hamming (de 64) até a qual dois fingerprints são "a mesma família".
#: Medido no B6: paráfrase e refatoração ficam abaixo; outro plugin, acima.
FAMILY_THRESHOLD = 12


def digest(text: str) -> str:
    return hashlib.sha256(text.encode("utf-8")).hexdigest()


def _shingles(text: str, n: int = 3) -> Iterable[str]:
    toks = _WORD.findall(text)
    if len(toks) < n:
        return [" ".join(toks)] if toks else []
    return (" ".join(toks[i : i + n]) for i in range(len(toks) - n + 1))


def _weight(shingle: str) -> int:
    return IDENT_WEIGHT if _IDENT.search(shingle) else 1


_KEYWORDS = frozenset(
    ["False", "None", "True", "and", "as", "assert", "async", "await", "break", "class", "continue", "def", "del", "elif", "else", "except", "finally", "for", "from", "global", "if", "import", "in", "is", "lambda", "nonlocal", "not", "or", "pass", "raise", "return", "try", "while", "with", "yield", "self", "cls", "str", "int", "float", "bool", "list", "dict", "set", "tuple", "len", "range", "print", "isinstance"]
)
_PUBLIC = re.compile(r"\b(?:def|class)\s+([^\W\d]\w*)")
_NAME = re.compile(r"[^\W\d]\w*")
_BLOCK = re.compile(r"\n(?=(?:def|class|async def|@)\b)")
_STRING = re.compile(r"(\"\"\"[\s\S]*?\"\"\"|'''[\s\S]*?'''|\"(?:\\.|[^\"\\\n])*\"|'(?:\\.|[^'\\\n])*')")
_COMMENT = re.compile(r"#[^\n]*")


def canonical_code(text: str) -> str:
    """Código com identificadores locais canonizados: renomear não muda a família.

    Nomes públicos (`def`/`class`), palavras-chave, builtins e o conteúdo das
    strings (docstrings incluídas) ficam; todo outro identificador vira
    `v<k>` pela ordem de primeira aparição **dentro do seu bloco de topo**
    (cada `def` numera do zero: reordenar funções não muda nada dentro
    delas); comentários saem. É a invariância de alfa-renomeação que a
    detecção de clones de código usa.
    """
    text = _COMMENT.sub("", text)
    public = set(_PUBLIC.findall(text))
    blocks: list[str] = []
    for block in _BLOCK.split(text):
        mapping: dict[str, str] = {}
        code_parts: list[str] = []
        strings: list[str] = []
        pos = 0
        for m in _STRING.finditer(block):
            code_parts.append(_canon_segment(block[pos : m.start()], public, mapping))
            strings.append(m.group(0))
            pos = m.end()
        code_parts.append(_canon_segment(block[pos:], public, mapping))
        # uma docstring que cita o parâmetro cita o parâmetro: o mesmo mapa vale lá dentro
        out: list[str] = []
        for i, part in enumerate(code_parts):
            out.append(part)
            if i < len(strings):
                out.append(_apply_map(strings[i], mapping))
        blocks.append("".join(out))
    return "\n".join(blocks)


def _apply_map(text: str, mapping: dict[str, str]) -> str:
    return _NAME.sub(lambda m: mapping.get(m.group(0), m.group(0)), text)


def _canon_segment(seg: str, public: set[str], mapping: dict[str, str]) -> str:
    def sub(m: re.Match[str]) -> str:
        tok = m.group(0)
        if tok in _KEYWORDS or tok in public:
            return tok
        if tok not in mapping:
            mapping[tok] = f"v{len(mapping) + 1}"
        return mapping[tok]

    return _NAME.sub(sub, seg)


def simhash(text: str, *, bits: int = 64) -> int:
    """SimHash (Charikar, 2002) sobre 3-gramas de tokens, ponderado por identificador. Vazio -> 0."""
    acc = [0] * bits
    for sh in _shingles(text):
        w = _weight(sh)
        h = int.from_bytes(hashlib.sha256(sh.encode("utf-8")).digest()[:8], "big")
        for b in range(bits):
            acc[b] += w if (h >> b) & 1 else -w
    out = 0
    for b in range(bits):
        if acc[b] > 0:
            out |= 1 << b
    return out


def hamming(a: int, b: int) -> int:
    return bin(a ^ b).count("1")


@dataclass(frozen=True, slots=True)
class Fingerprint:
    """Por componente: digest exato e simhash de família."""

    digests: dict[str, str] = field(default_factory=dict)
    hashes: dict[str, int] = field(default_factory=dict)

    @classmethod
    def of(cls, components: Mapping[str, str]) -> Fingerprint:
        """Digest do texto exato; simhash do texto — canonizado quando o componente é `code`."""
        return cls(
            digests={k: digest(v) for k, v in components.items()},
            hashes={k: simhash(canonical_code(v) if k == "code" else v) for k, v in components.items()},
        )

    def changed(self, other: Fingerprint) -> list[str]:
        """Componentes cujo digest difere do de `other`."""
        keys = sorted(set(self.digests) | set(other.digests))
        return [k for k in keys if self.digests.get(k) != other.digests.get(k)]

    def distance(self, other: Fingerprint) -> dict[str, int]:
        """Distância de Hamming por componente (64 = nada em comum)."""
        keys = sorted(set(self.hashes) | set(other.hashes))
        return {k: hamming(self.hashes.get(k, 0), other.hashes.get(k, 0)) for k in keys}

    def same_family(self, other: Fingerprint, *, threshold: int = FAMILY_THRESHOLD) -> bool:
        """Mesma linhagem: todo componente presente nos dois fica abaixo do limiar."""
        d = self.distance(other)
        common = [k for k in d if k in self.hashes and k in other.hashes]
        return bool(common) and all(d[k] <= threshold for k in common)

    def to_dict(self) -> dict[str, Any]:
        return {"digests": dict(self.digests), "hashes": {k: f"{v:016x}" for k, v in self.hashes.items()}}

    @classmethod
    def from_dict(cls, d: Mapping[str, Any]) -> Fingerprint:
        return cls(
            digests=dict(d.get("digests") or {}),
            hashes={k: int(v, 16) for k, v in (d.get("hashes") or {}).items()},
        )
