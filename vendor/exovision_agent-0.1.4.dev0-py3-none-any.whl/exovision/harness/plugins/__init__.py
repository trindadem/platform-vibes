"""exovision.harness.plugins — tools em três níveis, plugins como diretório, confiança por verificação, Evolve.

Módulo do kernel. Decorre do estudo em `docs/plugins-estudo.md`: o autor
declara o mínimo, o harness infere e impõe o máximo, e **só entra o que foi
verificado**. Formalidade é um dial — função (0), manifesto (1), servidor
MCP (2) — e o contrato migra da declaração para a evidência (suíte,
fingerprint, traço).

    tools        — nível 0 (função com docstring) e 1 (tools/<nome>.md: risco, limites, exemplos)
    plugin       — PLUGIN.md + tools + skills + instruction.md + mcp.json + evals/; PluginToolset (prefixo, piso, índice)
    fingerprint  — digest e SimHash por componente (prompt, código, tools): "é o mesmo?" e "é a mesma família?"
    trust        — draft -> verified -> trusted; TrustStore durável; verify() roda a suíte
    evolve       — o agente cria plugins e tools em draft; a suíte verde promove
    bench        — B1 a B6 do estudo, offline
    cli          — `exovision-agent plugins ls|show|verify|trust|untrust|new|bench`

    from exovision.harness.plugins import load_plugins, attach, SQLiteTrustStore, Evolve
    agent = attach(agent, load_plugins(["./plugins"]), store=SQLiteTrustStore(".exovision/trust.db"))
"""

from __future__ import annotations

from dataclasses import replace
from typing import Any

from ..loop import Agent
from ..skills import SkillLibrary
from ..tools import Composite, Registry, Toolset
from .evolve import Evolve, check_tool_source
from .fingerprint import Fingerprint, digest, hamming, simhash
from .plugin import Plugin, PluginError, PluginToolset, load_plugin, load_plugins, slug
from .tools import Case, Manifest, load_manifest, load_tool_file, validate_args
from .trust import (
    STATES,
    Report,
    SQLiteTrustStore,
    TrustRecord,
    TrustStore,
    resolve,
    trust,
    untrust,
    verify,
)

__all__ = [
    "STATES",
    "Case",
    "Evolve",
    "Fingerprint",
    "Manifest",
    "Plugin",
    "PluginError",
    "PluginToolset",
    "Report",
    "SQLiteTrustStore",
    "TrustRecord",
    "TrustStore",
    "attach",
    "check_tool_source",
    "digest",
    "floor_for",
    "hamming",
    "load_manifest",
    "load_plugin",
    "load_plugins",
    "load_tool_file",
    "resolve",
    "simhash",
    "slug",
    "toolsets",
    "trust",
    "untrust",
    "validate_args",
    "verify",
]


def floor_for(state: str, declared: str) -> str:
    """O piso de risco que o estado de confiança impõe sobre o declarado."""
    order = ("read", "write", "external", "irreversible")
    if state == "draft":
        return "external"
    if state == "verified":
        return max(declared, "write", key=order.index)
    return declared


def toolsets(
    plugins: list[Plugin],
    *,
    store: TrustStore | None = None,
    expose: str = "all",
    mcp_factory: Any = None,
) -> list[Toolset]:
    """Uma ferramentaria por plugin, com o piso de risco do estado de confiança.

    `draft` -> piso `external` (como servidor de terceiro). `verified` -> o
    declarado, mas nunca abaixo de `write`: a suíte prova que a tool faz o que
    os casos dizem, não que é inofensiva, e `read` é paralela e nunca passa por
    portão. `trusted` -> o declarado, porque foi o operador quem decidiu.
    `mcp_factory(spec_dict) -> Toolset` instancia os servidores de `mcp.json`.
    """
    out: list[Toolset] = []
    for pl in plugins:
        state, _reason = resolve(pl, store)
        floor = floor_for(state, pl.risk)
        if pl.tools:
            out.append(PluginToolset(pl, risk_floor=floor, expose=expose))
        if pl.mcp and mcp_factory is not None:
            for spec in pl.mcp:
                out.append(mcp_factory({**spec, "risk_floor": max(str(spec.get("risk_floor", floor)), floor, key=("read", "write", "external", "irreversible").index)}))
    return out


def attach(
    agent: Agent,
    plugins: list[Plugin],
    *,
    store: TrustStore | None = None,
    expose: str = "all",
    mcp_factory: Any = None,
    evolve: Evolve | None = None,
) -> Agent:
    """O agente com os plugins: ferramentaria composta, skills somadas, instruções anexadas.

    Cópia rasa — o agente original não muda. Fragmentos de `instruction.md`
    entram em `system_extra`, depois da instrução do agente, com o nome do
    plugin como cabeçalho; cada um tem digest próprio (no fingerprint).
    """
    sets: list[Toolset] = []
    base = agent.toolset
    if not (isinstance(base, Registry) and len(base) == 0):
        sets.append(base)
    sets.extend(toolsets(plugins, store=store, expose=expose, mcp_factory=mcp_factory))
    if evolve is not None:
        sets.append(evolve)
    toolset: Toolset = sets[0] if len(sets) == 1 else Composite(*sets) if sets else Registry()
    skills = [s for s in (agent.skills.get(n) for n in agent.skills.names()) if s is not None] if agent.skills is not None else []
    for pl in plugins:
        skills.extend(pl.skills)
    extra = [agent.system_extra.strip()] if agent.system_extra.strip() else []
    for pl in plugins:
        if pl.instruction:
            extra.append(f"## {pl.name}\n{pl.instruction}")
    return replace(
        agent,
        toolset=toolset,
        skills=SkillLibrary(skills) if skills else None,
        system_extra="\n\n".join(extra),
    )
