"""Confiança em três estados — e só o verificador promove.

    draft     sem suíte, ou mudou desde a aprovação: piso de risco `external`
              (como servidor de terceiro), o `Policy` decide
    verified  a suíte do plugin (exemplos dos manifestos + evals/) passou:
              o risco é o declarado
    trusted   decisão do operador; sobrevive só enquanto o fingerprint
              por componente bate — mudança silenciosa volta a `draft`

O estado não mora no plugin (o autor poderia escrever `trust: trusted`):
mora no `TrustStore` do operador, com o digest do que foi aprovado. É o
mesmo desenho do pino anti-rug pull do MCP, estendido a prompt, código e
tools. Verificar é executar os casos contra as tools do plugin **sem** piso
de risco — é o operador rodando a suíte, não o modelo chamando ferramenta.
"""

from __future__ import annotations

import json
import sqlite3
import threading
import time
from collections.abc import Callable
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Protocol, runtime_checkable

from ..session import enable_wal
from ..tools import Registry
from .fingerprint import Fingerprint
from .plugin import Plugin

__all__ = ["STATES", "Report", "SQLiteTrustStore", "TrustRecord", "TrustStore", "resolve", "verify"]

STATES: tuple[str, ...] = ("draft", "verified", "trusted")


@dataclass(frozen=True, slots=True)
class TrustRecord:
    name: str
    state: str
    fingerprint: Fingerprint
    at: float
    note: str = ""


@runtime_checkable
class TrustStore(Protocol):
    def get(self, name: str) -> TrustRecord | None: ...

    def put(self, record: TrustRecord) -> None: ...

    def delete(self, name: str) -> bool: ...

    def records(self) -> list[TrustRecord]: ...


class SQLiteTrustStore:
    """Uma tabela: nome do plugin -> estado, fingerprint aprovado, quando, nota."""

    def __init__(self, path: str | Path = ":memory:") -> None:
        self.path = str(path)
        if self.path != ":memory:":
            Path(self.path).parent.mkdir(parents=True, exist_ok=True)
        self._lock = threading.RLock()
        self._conn = sqlite3.connect(self.path, check_same_thread=False, timeout=30.0)
        with self._lock:
            if self.path != ":memory:":
                enable_wal(self._conn)
            self._conn.execute(
                "CREATE TABLE IF NOT EXISTS plugin_trust (name TEXT PRIMARY KEY, state TEXT NOT NULL, "
                "fingerprint TEXT NOT NULL, at REAL NOT NULL, note TEXT NOT NULL DEFAULT '')"
            )
            self._conn.commit()

    def get(self, name: str) -> TrustRecord | None:
        with self._lock:
            row = self._conn.execute(
                "SELECT name, state, fingerprint, at, note FROM plugin_trust WHERE name = ?", (name,)
            ).fetchone()
        if not row:
            return None
        return TrustRecord(row[0], row[1], Fingerprint.from_dict(json.loads(row[2])), float(row[3]), row[4] or "")

    def put(self, record: TrustRecord) -> None:
        with self._lock:
            self._conn.execute(
                "INSERT INTO plugin_trust(name, state, fingerprint, at, note) VALUES (?,?,?,?,?) "
                "ON CONFLICT(name) DO UPDATE SET state=excluded.state, fingerprint=excluded.fingerprint, "
                "at=excluded.at, note=excluded.note",
                (record.name, record.state, json.dumps(record.fingerprint.to_dict()), record.at, record.note),
            )
            self._conn.commit()

    def delete(self, name: str) -> bool:
        with self._lock:
            cur = self._conn.execute("DELETE FROM plugin_trust WHERE name = ?", (name,))
            self._conn.commit()
        return cur.rowcount == 1

    def records(self) -> list[TrustRecord]:
        with self._lock:
            rows = self._conn.execute("SELECT name FROM plugin_trust ORDER BY name").fetchall()
        return [r for r in (self.get(n) for (n,) in rows) if r is not None]

    def close(self) -> None:
        with self._lock:
            self._conn.close()


def resolve(plugin: Plugin, store: TrustStore | None) -> tuple[str, str]:
    """O estado efetivo do plugin agora, e a razão."""
    if store is None:
        return "draft", "sem registro de confiança"
    rec = store.get(plugin.name)
    if rec is None:
        return "draft", "nunca verificado"
    changed = rec.fingerprint.changed(plugin.fingerprint)
    if not changed:
        return rec.state, f"{rec.state}: fingerprint bate"
    family = rec.fingerprint.same_family(plugin.fingerprint)
    return "draft", (
        f"mudou desde {rec.state}: {', '.join(changed)}"
        + (" (mesma família: edição)" if family else " (outra coisa: não é o que foi aprovado)")
    )


@dataclass(slots=True)
class Report:
    plugin: str
    total: int = 0
    passed: int = 0
    failures: list[dict[str, Any]] = field(default_factory=list)
    state: str = "draft"
    reason: str = ""

    @property
    def ok(self) -> bool:
        return self.total > 0 and self.passed == self.total

    def to_dict(self) -> dict[str, Any]:
        return {
            "plugin": self.plugin,
            "total": self.total,
            "passed": self.passed,
            "failures": list(self.failures),
            "state": self.state,
            "reason": self.reason,
        }


def verify(
    plugin: Plugin,
    *,
    store: TrustStore | None = None,
    clock: Callable[[], float] = time.time,
) -> Report:
    """Roda a suíte do plugin. Verde e não vazia -> `verified` (gravado com o fingerprint)."""
    rep = Report(plugin=plugin.name)
    if plugin.missing:
        rep.reason = f"faltam dependências: {', '.join(plugin.missing)}"
        return rep
    registry = Registry(plugin.tools)
    for case in plugin.cases:
        rep.total += 1
        result = registry(case.tool, case.args)
        why = case.check(result)
        if why:
            rep.failures.append({"tool": case.tool, "args": case.args, "why": why, "origin": case.origin})
        else:
            rep.passed += 1
    if rep.total == 0:
        rep.reason = "sem casos: um plugin sem suíte continua draft"
        rep.state = "draft"
        return rep
    if rep.ok:
        rep.state = "verified"
        rep.reason = f"{rep.passed}/{rep.total} casos verdes"
        if store is not None:
            prev = store.get(plugin.name)
            state = "trusted" if (prev and prev.state == "trusted" and not prev.fingerprint.changed(plugin.fingerprint)) else "verified"
            store.put(TrustRecord(plugin.name, state, plugin.fingerprint, clock(), rep.reason))
            rep.state = state
    else:
        rep.state = "draft"
        rep.reason = f"{rep.passed}/{rep.total} casos; {len(rep.failures)} falharam"
        if store is not None:
            store.delete(plugin.name)  # o que falhou não continua aprovado
    return rep


def trust(plugin: Plugin, store: TrustStore, *, note: str = "", clock: Callable[[], float] = time.time) -> TrustRecord:
    """Decisão do operador. Grava o fingerprint: mudou, caiu."""
    rec = TrustRecord(plugin.name, "trusted", plugin.fingerprint, clock(), note or "confiado pelo operador")
    store.put(rec)
    return rec


def untrust(name: str, store: TrustStore) -> bool:
    return store.delete(name)
