"""O plugin: um diretório que compõe o que o harness já sabe carregar.

    meu-plugin/
      PLUGIN.md        front-matter: name, version, description (+ risk, requires); o corpo é para humanos
      tools.py         funções nível 0 (ou tools/*.py); tools/<nome>.md são os manifestos (nível 1)
      skills/*/SKILL.md
      instruction.md   fragmento para o system (entra depois da instrução do agente)
      mcp.json         servidores a anexar: [{"spec": "npx -y ...", "expose": "index", "risk_floor": "external"}]
      evals/*.json     casos [{"tool", "args", "expect"}] — o contrato empírico
      requires.txt     módulos Python que as tools importam (nada transitivo implícito)

Um plugin não cria uma quarta coisa: tools, skills e servidores MCP entram
pelas superfícies que já existem (`Toolset`, `SkillLibrary`, `MCPToolset`).
O que ele acrescenta é **identidade** (digest e fingerprint por componente:
prompt, código, tools) e **proveniência** (caminho, autor, versão) — o que a
confiança (`trust.py`) precisa para dizer se o que vai rodar é o que foi
aprovado.

As tools de um plugin entram com o nome do plugin como prefixo
(`meu_plugin_buscar`): namespacing é fronteira clara para o modelo e evita
colisão entre plugins. `expose="index"` publica só `<plugin>_find` e
`<plugin>_call` — o catálogo custa ordens de grandeza mais que o índice.
"""

from __future__ import annotations

import importlib.util
import json
import re
from collections.abc import Sequence
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

from ..instruction import parse_front_matter
from ..skills import Skill, SkillError, load_skills
from ..tools import RISK_LEVELS, Registry, Tool, ToolAssemblyError, ToolResult, normalize
from .fingerprint import Fingerprint
from .tools import Case, Manifest, ToolFile, load_manifest, load_tool_file, validate_args

__all__ = ["Plugin", "PluginError", "PluginToolset", "load_plugin", "load_plugins", "slug"]


class PluginError(ValueError):
    """Diretório que não é um plugin, ou plugin malformado."""


_NAME = re.compile(r"^[a-z][a-z0-9_-]{0,63}$")


def slug(name: str) -> str:
    """Nome de plugin como prefixo de ferramenta: `meu-plugin` -> `meu_plugin`."""
    return re.sub(r"[^a-z0-9_]", "_", name.lower())


@dataclass(slots=True)
class Plugin:
    name: str
    version: str
    description: str
    path: str
    risk: str = "write"  # piso declarado (vale quando verified/trusted)
    author: str = ""
    requires: tuple[str, ...] = ()
    missing: tuple[str, ...] = ()  # de `requires`, o que não está instalado
    tools: list[Tool] = field(default_factory=list)
    sources: dict[str, str] = field(default_factory=dict)  # tool -> fonte
    manifests: dict[str, Manifest] = field(default_factory=dict)
    skills: list[Skill] = field(default_factory=list)
    instruction: str = ""
    mcp: list[dict[str, Any]] = field(default_factory=list)
    cases: list[Case] = field(default_factory=list)
    warnings: list[str] = field(default_factory=list)
    meta: dict[str, Any] = field(default_factory=dict)
    fingerprint: Fingerprint = field(default_factory=Fingerprint)

    @property
    def prefix(self) -> str:
        return slug(self.name)

    def components(self) -> dict[str, str]:
        """Os três componentes cuja identidade importa: prompt, código, tools."""
        prompt = "\n\n".join(
            [self.instruction.strip()]
            + [f"{s.name}\n{s.description}\n{s.body}" for s in self.skills]
            + [t.description for t in self.tools]
        )
        code = "\n\n".join(self.sources[t.name] for t in self.tools if t.name in self.sources)
        tools = json.dumps(
            [{"name": t.name, "risk": t.risk, "schema": t.input_schema} for t in self.tools]
            + [{"mcp": m} for m in self.mcp],
            sort_keys=True,
            ensure_ascii=False,
        )
        return {"prompt": prompt, "code": code, "tools": tools}

    def summary(self) -> dict[str, Any]:
        return {
            "name": self.name,
            "version": self.version,
            "description": self.description,
            "path": self.path,
            "risk": self.risk,
            "author": self.author,
            "requires": list(self.requires),
            "missing": list(self.missing),
            "tools": [t.name for t in self.tools],
            "skills": [s.name for s in self.skills],
            "instruction_chars": len(self.instruction),
            "mcp": len(self.mcp),
            "cases": len(self.cases),
            "warnings": list(self.warnings),
            "fingerprint": self.fingerprint.to_dict(),
        }


def _requires(path: Path) -> tuple[tuple[str, ...], tuple[str, ...]]:
    f = path / "requires.txt"
    if not f.is_file():
        return (), ()
    req = tuple(
        ln.strip().split("#", 1)[0].strip()
        for ln in f.read_text(encoding="utf-8").splitlines()
        if ln.strip() and not ln.strip().startswith("#")
    )
    missing = tuple(r for r in req if importlib.util.find_spec(r.split("[")[0].split("=")[0].strip()) is None)
    return req, missing


def _load_cases(path: Path) -> list[Case]:
    out: list[Case] = []
    d = path / "evals"
    if not d.is_dir():
        return out
    for f in sorted(d.glob("*.json")):
        data = json.loads(f.read_text(encoding="utf-8"))
        items = data if isinstance(data, list) else data.get("cases") or []
        for i, c in enumerate(items):
            if not isinstance(c, dict) or "tool" not in c:
                raise PluginError(f"{f}: caso {i + 1} precisa de `tool`")
            out.append(Case(tool=str(c["tool"]), args=dict(c.get("args") or {}), expect=dict(c.get("expect") or {}), origin=str(f)))
    return out


def load_plugin(directory: str | Path) -> Plugin:
    """Lê o diretório. Falha só o que impede a montagem; o resto vira `warnings`."""
    d = Path(directory).resolve()
    md = d / "PLUGIN.md"
    if not md.is_file():
        raise PluginError(f"não é um plugin (sem PLUGIN.md): {d}")
    meta, _body = parse_front_matter(md.read_text(encoding="utf-8"))
    name = str(meta.get("name") or d.name)
    if not _NAME.match(name):
        raise PluginError(f"nome de plugin inválido: {name!r} (minúsculas, dígitos, - e _)")
    description = str(meta.get("description") or "").strip()
    if not description:
        raise PluginError(f"plugin {name!r} sem `description`: existe e nunca é escolhido")
    risk = str(meta.get("risk") or "write")
    if risk not in RISK_LEVELS:
        raise PluginError(f"plugin {name!r}: risco {risk!r} fora de {RISK_LEVELS}")
    requires, missing = _requires(d)
    plugin = Plugin(
        name=name,
        version=str(meta.get("version") or "0.0.0"),
        description=description,
        path=str(d),
        risk=risk,
        author=str(meta.get("author") or ""),
        requires=requires,
        missing=missing,
        meta=dict(meta),
    )

    # manifestos (nível 1)
    tools_dir = d / "tools"
    if tools_dir.is_dir():
        for f in sorted(tools_dir.glob("*.md")):
            man = load_manifest(f)
            plugin.manifests[man.name] = man

    # tools (nível 0): tools.py e/ou tools/*.py
    files = [f for f in [d / "tools.py"] if f.is_file()]
    if tools_dir.is_dir():
        files += sorted(tools_dir.glob("*.py"))
    if missing:
        plugin.warnings.append(f"tools desligadas: faltam {', '.join(missing)} (requires.txt)")
    else:
        for i, f in enumerate(files):
            try:
                tf: ToolFile = load_tool_file(f, manifests=plugin.manifests, default_risk="write", module_name=f"exovision_plugin_{plugin.prefix}_{i}")
            except ToolAssemblyError as erro:
                raise PluginError(str(erro)) from None
            for t in tf.tools:
                if any(x.name == t.name for x in plugin.tools):
                    raise PluginError(f"plugin {name!r}: tool {t.name!r} definida duas vezes")
                plugin.tools.append(t)
            plugin.sources.update(tf.sources)
            for skipped, why in tf.skipped.items():
                plugin.warnings.append(f"{f.name}:{skipped}: {why}")
    for man in plugin.manifests.values():
        plugin.cases.extend(man.examples)

    # skills
    sk = d / "skills"
    if sk.is_dir():
        try:
            plugin.skills = load_skills([sk])
        except SkillError as erro:
            raise PluginError(str(erro)) from None

    # instrução (fragmento)
    ins = d / "instruction.md"
    if ins.is_file():
        _m, body = parse_front_matter(ins.read_text(encoding="utf-8"))
        plugin.instruction = body.strip()

    # MCP
    mj = d / "mcp.json"
    if mj.is_file():
        data = json.loads(mj.read_text(encoding="utf-8"))
        specs = data if isinstance(data, list) else data.get("servers") or []
        for s in specs:
            if not isinstance(s, dict) or not s.get("spec"):
                raise PluginError(f"{mj}: cada servidor precisa de `spec`")
            plugin.mcp.append(dict(s))

    # evals
    plugin.cases.extend(_load_cases(d))
    known = {t.name for t in plugin.tools}
    for c in plugin.cases:
        if c.tool not in known and not missing:
            raise PluginError(f"{c.origin}: caso para tool desconhecida {c.tool!r}")
    plugin.fingerprint = Fingerprint.of(plugin.components())
    return plugin


def load_plugins(paths: Sequence[str | Path]) -> list[Plugin]:
    """Cada caminho é um plugin ou um diretório *de* plugins (subpastas com PLUGIN.md)."""
    out: list[Plugin] = []
    seen: set[str] = set()
    vistos: set[Path] = set()
    for p in paths:
        base = Path(p)
        if (base / "PLUGIN.md").is_file():
            cands = [base]
        elif base.is_dir():
            cands = [sub for sub in sorted(base.iterdir()) if (sub / "PLUGIN.md").is_file()]
        else:
            raise PluginError(f"diretório de plugins não existe: {base}")
        for c in cands:
            if c.resolve() in vistos:
                continue  # o mesmo diretório listado duas vezes (ex.: `plugins: [plugins/x]` e o `plugins/` do perfil)
            vistos.add(c.resolve())
            pl = load_plugin(c)
            if pl.name in seen:
                raise PluginError(f"plugin {pl.name!r} carregado duas vezes (de {c} e de outro diretório)")
            seen.add(pl.name)
            out.append(pl)
    return out


class PluginToolset:
    """As tools de um plugin, com prefixo, piso de risco e modo índice — a superfície `Toolset`."""

    def __init__(
        self,
        plugin: Plugin,
        *,
        risk_floor: str = "write",
        expose: str = "all",
        prefix: str | None = None,
    ) -> None:
        if expose not in ("all", "index"):
            raise PluginError(f"expose {expose!r}: use 'all' ou 'index'")
        if risk_floor not in RISK_LEVELS:
            raise PluginError(f"piso de risco {risk_floor!r} fora de {RISK_LEVELS}")
        self.plugin = plugin
        self.expose = expose
        self.risk_floor = risk_floor
        self.prefix = plugin.prefix if prefix is None else prefix
        self._registry = Registry(plugin.tools)
        self._local = {self._localname(t.name): t.name for t in plugin.tools}

    def _localname(self, name: str) -> str:
        return f"{self.prefix}_{name}" if self.prefix else name

    @property
    def find_name(self) -> str:
        return self._localname("find")

    @property
    def call_name(self) -> str:
        return self._localname("call")

    # ------------------------------------------------------ superfície
    def definitions(self) -> list[dict[str, Any]]:
        if self.expose == "index":
            return self._index_definitions()
        out = []
        for t in self.plugin.tools:
            d = t.definition()
            d["name"] = self._localname(t.name)
            out.append(d)
        return out

    def names(self) -> list[str]:
        return [d["name"] for d in self.definitions()]

    def _effective_risk(self, tool_risk: str) -> str:
        return max(tool_risk, self.risk_floor, key=RISK_LEVELS.index)

    def risk(self, name: str) -> str:
        if self.expose == "index":
            return "read" if name == self.find_name else self._effective_risk(self.plugin.risk)
        t = self._registry.get(self._local.get(name, ""))
        return self._effective_risk(t.risk) if t else "irreversible"

    def parallel_safe(self, name: str) -> bool:
        if self.expose == "index":
            return name == self.find_name
        t = self._registry.get(self._local.get(name, ""))
        return bool(t and t.parallel_safe)

    def catalog_chars(self) -> dict[str, int]:
        full = sum(len(json.dumps(d, ensure_ascii=False)) for d in self._all_definitions())
        index = sum(len(json.dumps(d, ensure_ascii=False)) for d in self._index_definitions())
        return {"all": full, "index": index, "tools": len(self.plugin.tools)}

    def _all_definitions(self) -> list[dict[str, Any]]:
        out = []
        for t in self.plugin.tools:
            d = t.definition()
            d["name"] = self._localname(t.name)
            out.append(d)
        return out

    def _index_definitions(self) -> list[dict[str, Any]]:
        return [
            {
                "name": self.find_name,
                "description": f"Procura ferramentas do plugin {self.plugin.name!r} ({self.plugin.description}) por palavra-chave; devolve nome, descrição e schema das que casam. Use antes de {self.call_name}.",
                "input_schema": {
                    "type": "object",
                    "properties": {
                        "query": {"type": "string", "description": "palavras-chave"},
                        "limit": {"type": "integer", "description": "máximo de resultados"},
                    },
                    "required": ["query"],
                },
            },
            {
                "name": self.call_name,
                "description": f"Chama uma ferramenta do plugin {self.plugin.name!r} pelo nome devolvido por {self.find_name}, com os argumentos do schema dela.",
                "input_schema": {
                    "type": "object",
                    "properties": {
                        "name": {"type": "string", "description": "nome da ferramenta"},
                        "arguments": {"type": "object", "description": "argumentos"},
                    },
                    "required": ["name"],
                },
            },
        ]

    def _find(self, query: str, limit: int = 5) -> ToolResult:
        terms = [w for w in str(query).lower().split() if w]
        scored: list[tuple[int, Tool]] = []
        for t in self.plugin.tools:
            hay = f"{t.name} {t.description}".lower()
            score = sum(hay.count(w) for w in terms)
            if score or not terms:
                scored.append((score, t))
        scored.sort(key=lambda x: (-x[0], x[1].name))
        chosen = [t for _s, t in scored[: max(1, int(limit or 5))]]
        if not chosen:
            return ToolResult(text=f"nenhuma ferramenta casa {query!r}. Disponíveis: {', '.join(t.name for t in self.plugin.tools)}", metadata={"matches": 0})
        payload = [{"name": t.name, "description": t.description, "input_schema": t.input_schema} for t in chosen]
        return ToolResult(text=json.dumps(payload, ensure_ascii=False, indent=2), metadata={"matches": len(chosen), "of": len(self.plugin.tools)})

    def __call__(self, name: str, arguments: dict[str, Any]) -> ToolResult:
        if self.expose == "index":
            if name == self.find_name:
                return self._find(str(arguments.get("query", "")), int(arguments.get("limit", 5) or 5))
            if name == self.call_name:
                inner = str(arguments.get("name") or "")
                return self._invoke(inner, dict(arguments.get("arguments") or {}))
            return ToolResult.error(f"ferramenta desconhecida: {name!r}", code=404)
        target = self._local.get(name)
        if target is None:
            return ToolResult.error(f"ferramenta desconhecida: {name!r}. Disponíveis: {', '.join(self._local)}", code=404)
        return self._invoke(target, arguments)

    def _invoke(self, inner: str, arguments: dict[str, Any]) -> ToolResult:
        t = self._registry.get(inner)
        if t is None:
            return ToolResult.error(f"ferramenta desconhecida no plugin {self.plugin.name!r}: {inner!r}", code=404)
        erros = validate_args(t.input_schema, arguments)
        if erros:
            return ToolResult.error(f"argumentos inválidos para {inner!r}: {'; '.join(erros)}", code=422)
        try:
            return normalize(self._registry(inner, arguments))
        except Exception as erro:
            return ToolResult.error(f"{type(erro).__name__}: {erro}", code=500)

    def __len__(self) -> int:
        return len(self.plugin.tools)

