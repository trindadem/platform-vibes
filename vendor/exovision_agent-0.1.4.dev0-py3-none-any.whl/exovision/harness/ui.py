"""A apresentação da linha de comando: cor, espera, perguntas e erros.

Um só lugar para o que o usuário vê, porque as três portas de entrada — o
assistente (`init`), o laço (`run`) e a conversa (`chat`) — têm de falar
igual. As regras são as de uma CLI (clig.dev):

- cor só quando a saída é um terminal (e nunca com `NO_COLOR`);
- pergunta só quando há terminal interativo; com `--no-input`, padrão ou erro;
- resposta errada não descarta o que já foi respondido: pergunta de novo;
- erro é uma frase mais a **ação** — `hint_for_error` traduz o que o servidor
  disse em o que fazer (foi um 400 de esforço não suportado, com a mensagem
  engolida, que motivou este módulo).

`Spinner` existe porque uma volta do modelo leva segundos e uma tela parada é
indistinguível de um travamento; ele some sozinho sem TTY (log, pipe, CI).
"""

from __future__ import annotations

import getpass
import itertools
import os
import re
import sys
import threading
import time
from collections.abc import Callable, Mapping, Sequence
from typing import Any, TextIO

__all__ = [
    "Prompter",
    "Spinner",
    "color_for",
    "format_outcome",
    "hint_for_error",
    "paint",
]

_ANSI = {"bold": "1", "dim": "2", "red": "31", "green": "32", "yellow": "33", "blue": "34", "magenta": "35", "cyan": "36"}


def color_for(stream: TextIO | None = None) -> bool:
    s = stream or sys.stdout
    if os.environ.get("NO_COLOR"):
        return False
    return bool(getattr(s, "isatty", lambda: False)())


def paint(style: str, text: str, *, enabled: bool = True) -> str:
    if not enabled or style not in _ANSI:
        return text
    return f"\033[{_ANSI[style]}m{text}\033[0m"


# ---------------------------------------------------------------- espera


class Spinner:
    """`with Spinner("pensando"):` — um fio que escreve e apaga; nada sem TTY."""

    FRAMES = "⠋⠙⠹⠸⠼⠴⠦⠧⠇⠏"

    def __init__(self, label: str = "pensando", *, stream: TextIO | None = None, enabled: bool | None = None) -> None:
        self.stream = stream or sys.stderr
        self.label = label
        self.enabled = color_for(self.stream) if enabled is None else enabled
        self._stop = threading.Event()
        self._thread: threading.Thread | None = None
        self._t0 = 0.0

    def update(self, label: str) -> None:
        self.label = label

    def _run(self) -> None:
        for frame in itertools.cycle(self.FRAMES):
            if self._stop.wait(0.09):
                return
            s = f"{time.perf_counter() - self._t0:.0f}s"
            self.stream.write(f"\r\033[2m{frame} {self.label} · {s}\033[0m\033[K")
            self.stream.flush()

    def __enter__(self) -> Spinner:
        self._t0 = time.perf_counter()
        if self.enabled:
            self._thread = threading.Thread(target=self._run, daemon=True)
            self._thread.start()
        return self

    def __exit__(self, *exc: object) -> None:
        self._stop.set()
        if self._thread is not None:
            self._thread.join(timeout=0.5)
            self.stream.write("\r\033[K")
            self.stream.flush()

    @property
    def elapsed(self) -> float:
        return time.perf_counter() - self._t0


# ---------------------------------------------------------------- erros

#: (padrão no texto do erro) -> o que fazer. O primeiro que casar responde.
HINTS: tuple[tuple[str, str], ...] = (
    (r"adaptive thinking is not supported|thinking.*not supported", "este modelo não aceita pensamento/esforço: troque o modelo (`/modelo`, ou `model:` no AGENT.md) ou veja `exovision-agent models catalog`"),
    (r"Could not resolve authentication|Expected one of api_key", "não há credencial no ambiente: `exovision-agent init <dir> --force` grava a sua, ou exporte ANTHROPIC_API_KEY"),
    (r"invalid x-api-key|authentication_error|401", "a credencial não foi aceita: `exovision-agent init <dir> --force` para regravá-la, ou exporte ANTHROPIC_API_KEY"),
    (r"credit balance|insufficient|billing", "a conta do provedor não tem saldo para esta chamada"),
    (r"rate_limit|429", "limite do provedor: espere um pouco, ou use `--limits lab.db --rpm N` para dividir o limite entre processos"),
    (r"o SDK `anthropic` não está", "instale o SDK: `pip install exovision-agent[anthropic]` (o binário já o traz)"),
    (r"API_KEY ausente|sem .*API_KEY", "falta a credencial no ambiente: `exovision-agent init <dir> --force`, ou exporte a variável"),
    (r"max_tokens.*greater|maximum.*tokens", "o teto de saída é maior do que este modelo aceita: baixe `max_tokens` ou troque o modelo"),
    (r"model.*not found|does not exist|invalid model", "o id do modelo não existe neste provedor: `exovision-agent models catalog`"),
    (r"Connection|timed out|Timeout|Name or service", "não consegui falar com o provedor: rede, ou `--base-url` errado"),
    (r"orçamento|budget", "o orçamento do agente fechou: aumente `budget:` no AGENT.md (`max_turns`, `max_cost_usd`)"),
)


def hint_for_error(error: str) -> str:
    """A ação para um erro conhecido, ou "" — nunca inventa."""
    for padrao, dica in HINTS:
        if re.search(padrao, error, re.I):
            return dica
    return ""


# ---------------------------------------------------------------- resultado


def format_outcome(outcome: Any, *, color: bool = False, elapsed: float = 0.0) -> tuple[str, str]:
    """(texto para stdout, rodapé para stderr). O erro nunca fica invisível."""
    corpo = (outcome.text or "").rstrip()
    partes = [f"{outcome.turns} volta{'s' if outcome.turns != 1 else ''}"]
    if outcome.tool_calls:
        partes.append(f"{outcome.tool_calls} ferramenta{'s' if outcome.tool_calls != 1 else ''}")
    if elapsed:
        partes.append(f"{elapsed:.1f}s")
    partes.append(f"US$ {outcome.cost_usd:.4f}")
    rodape = paint("dim", "   " + " · ".join(partes), enabled=color)
    if not outcome.ok or outcome.error:
        erro = outcome.error or f"parou em {outcome.stop_reason}"
        linhas = [paint("red", f"✗ {erro}", enabled=color)]
        dica = hint_for_error(erro)
        if dica:
            linhas.append(paint("yellow", f"  → {dica}", enabled=color))
        rodape = "\n".join([*linhas, rodape])
    return corpo, rodape


# ---------------------------------------------------------------- perguntas


class PromptAborted(KeyboardInterrupt):
    """Ctrl-C/Ctrl-D no meio de uma pergunta."""


class Prompter:
    """Perguntas com padrão, escolhas, validação e segredo.

    Em modo não-interativo devolve o padrão ou levanta o erro de quem chamou
    (`required`). Interativo: resposta inválida **pergunta de novo** — o
    usuário não perde as respostas anteriores por causa da última.
    """

    def __init__(
        self,
        *,
        interactive: bool | None = None,
        input_fn: Callable[[str], str] = input,
        getpass_fn: Callable[[str], str] = getpass.getpass,
        out: TextIO | None = None,
        on_invalid: Callable[[str], None] | None = None,
    ) -> None:
        self.out = out or sys.stdout
        if interactive is None:
            interactive = bool(getattr(sys.stdin, "isatty", lambda: False)() and getattr(self.out, "isatty", lambda: False)())
        self.interactive = interactive
        self._input = input_fn
        self._getpass = getpass_fn
        self.color = self.interactive and color_for(self.out)
        self._on_invalid = on_invalid

    # -------------------------------------------------------- saída
    def say(self, text: str = "") -> None:
        print(text, file=self.out)

    def title(self, text: str) -> None:
        if self.interactive:
            self.say(paint("bold", text, enabled=self.color))

    def note(self, text: str) -> None:
        if self.interactive:
            self.say(paint("dim", text, enabled=self.color))

    def warn(self, text: str) -> None:
        self.say(paint("yellow", text, enabled=self.color))

    # -------------------------------------------------------- entrada
    def ask(
        self,
        question: str,
        *,
        default: str = "",
        choices: Sequence[str] = (),
        labels: Mapping[str, str] | None = None,
        required: bool = False,
        flag: str = "",
        validate: Callable[[str], str | None] | None = None,
        error: type[Exception] = ValueError,
    ) -> str:
        """Pergunta até vir resposta válida. `validate` devolve a queixa, ou None."""
        if not self.interactive:
            if default or not required:
                if default and validate is not None and (queixa := validate(default)):
                    raise error(f"{flag or question}: {queixa}")
                return default
            raise error(f"falta {flag or question!s} (modo não-interativo)")
        if choices:
            largura = max(len(c) for c in choices)
            for i, c in enumerate(choices, 1):
                rotulo = f"  {(labels or {}).get(c, '')}" if labels and labels.get(c) else ""
                marca = paint("dim", "  (padrão)", enabled=self.color) if c == default else ""
                self.say(f"  {paint('cyan', str(i), enabled=self.color)}) {c:{largura}s}{rotulo}{marca}")
        sufixo = paint("dim", f" [{default}]", enabled=self.color) if default else ""
        while True:
            try:
                raw = self._input(f"{paint('cyan', question, enabled=self.color)}{sufixo}: ").strip()
            except (EOFError, KeyboardInterrupt) as erro:
                raise PromptAborted from erro
            if not raw:
                if default or not required:
                    if default and validate is not None and (queixa := validate(default)):
                        self._invalid(queixa)
                        continue
                    return default
                self._invalid("obrigatório")
                continue
            if choices:
                if raw.isdigit() and 1 <= int(raw) <= len(choices):
                    raw = choices[int(raw) - 1]
                elif raw not in choices:
                    self._invalid(f"escolha um de: {', '.join(choices)}")
                    continue
            if validate is not None and (queixa := validate(raw)):
                self._invalid(queixa)
                continue
            return raw

    def _invalid(self, queixa: str) -> None:
        if self._on_invalid is not None:
            self._on_invalid(queixa)
        else:
            self.say(paint("yellow", f"  {queixa}", enabled=self.color))

    def secret(self, question: str) -> str:
        if not self.interactive:
            return ""
        try:
            return self._getpass(f"{paint('cyan', question, enabled=self.color)}: ").strip()
        except (EOFError, KeyboardInterrupt) as erro:
            raise PromptAborted from erro

    def confirm(self, question: str, *, default: bool = False) -> bool:
        if not self.interactive:
            return default
        try:
            raw = self._input(f"{paint('cyan', question, enabled=self.color)} [{'S/n' if default else 's/N'}]: ").strip().lower()
        except (EOFError, KeyboardInterrupt) as erro:
            raise PromptAborted from erro
        return default if not raw else raw in ("s", "sim", "y", "yes")
