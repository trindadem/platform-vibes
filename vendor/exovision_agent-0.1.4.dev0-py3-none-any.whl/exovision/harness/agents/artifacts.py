"""Artefatos compartilhados: o quadro-negro versionado da equipe.

Um artefato é um arquivo em `shared/` com uma linha de índice (versão, dono,
quando). Escrever é **CAS**: quem escreve diz a versão que leu; se outro
escreveu antes, a escrita é recusada e o autor lê de novo — é o "primeiro
commit vence" de *fork-explore-commit* sem syscall. Toda escrita publica em
`team.<equipe>.artifacts.<nome>`: o quadro-negro de Hearsay-II dispara quem
assina. O que é de um perfil (notas) é arquivo no diretório dele e não passa
por aqui.
"""

from __future__ import annotations

import os
import sqlite3
import threading
import time
from collections.abc import Callable
from dataclasses import dataclass
from pathlib import Path
from typing import Any

from ..bus import Bus
from ..session import enable_wal
from .messages import artifact_subject

__all__ = ["Artifact", "ArtifactConflict", "Artifacts"]


class ArtifactConflict(RuntimeError):
    """A versão que você leu não é mais a atual."""


@dataclass(frozen=True, slots=True)
class Artifact:
    name: str
    version: int
    owner: str
    updated_at: float
    content: str = ""

    def to_dict(self) -> dict[str, Any]:
        return {"name": self.name, "version": self.version, "owner": self.owner, "updated_at": self.updated_at, "chars": len(self.content)}


class Artifacts:
    def __init__(
        self,
        directory: str | Path,
        *,
        db: str | Path = ":memory:",
        team: str = "",
        bus: Bus | None = None,
        clock: Callable[[], float] = time.time,
    ) -> None:
        self.dir = Path(directory)
        self.dir.mkdir(parents=True, exist_ok=True)
        self.team = team
        self.bus = bus
        self._clock = clock
        self._lock = threading.RLock()
        self._conn = sqlite3.connect(str(db), check_same_thread=False, timeout=30.0)
        with self._lock:
            if str(db) != ":memory:":
                enable_wal(self._conn)
            self._conn.execute(
                "CREATE TABLE IF NOT EXISTS artifacts (name TEXT PRIMARY KEY, version INTEGER NOT NULL, "
                "owner TEXT NOT NULL, updated_at REAL NOT NULL)"
            )
            self._conn.commit()

    def _path(self, name: str) -> Path:
        if "/" in name or name.startswith(".") or not name:
            raise ValueError(f"nome de artefato inválido: {name!r}")
        return self.dir / name

    def read(self, name: str) -> Artifact | None:
        """Versão e conteúdo lidos juntos, sob o lock: o que se leu é um estado, não dois."""
        p = self._path(name)
        with self._lock:
            row = self._conn.execute("SELECT version, owner, updated_at FROM artifacts WHERE name = ?", (name,)).fetchone()
            if not row:
                return None
            content = p.read_text(encoding="utf-8") if p.is_file() else ""
        return Artifact(name, int(row[0]), row[1], float(row[2]), content)

    def write(self, name: str, content: str, *, owner: str, expected_version: int | None = None) -> Artifact:
        """Escreve se `expected_version` é a atual (None = criar, ou sobrescrever sem checar)."""
        p = self._path(name)
        now = self._clock()
        with self._lock:
            row = self._conn.execute("SELECT version FROM artifacts WHERE name = ?", (name,)).fetchone()
            current = int(row[0]) if row else 0
            if expected_version is not None and expected_version != current:
                raise ArtifactConflict(f"{name}: você leu a versão {expected_version}, a atual é {current}")
            new = current + 1
            tmp = p.with_name(f".{p.name}.{new}.tmp")
            tmp.write_text(content, encoding="utf-8")
            os.replace(tmp, p)  # atômico: ninguém lê um arquivo pela metade
            self._conn.execute(
                "INSERT INTO artifacts(name, version, owner, updated_at) VALUES (?,?,?,?) "
                "ON CONFLICT(name) DO UPDATE SET version=excluded.version, owner=excluded.owner, updated_at=excluded.updated_at",
                (name, new, owner, now),
            )
            self._conn.commit()
        if self.bus is not None and self.team:
            self.bus.publish(artifact_subject(self.team, name), {"name": name, "version": new, "owner": owner, "chars": len(content)})
        return Artifact(name, new, owner, now, content)

    def list(self) -> list[Artifact]:
        with self._lock:
            rows = self._conn.execute("SELECT name, version, owner, updated_at FROM artifacts ORDER BY name").fetchall()
        return [Artifact(r[0], int(r[1]), r[2], float(r[3])) for r in rows]

    def close(self) -> None:
        with self._lock:
            self._conn.close()
