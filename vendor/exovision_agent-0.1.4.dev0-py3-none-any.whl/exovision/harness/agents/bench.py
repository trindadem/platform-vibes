"""Os benchmarks do estudo de equipes (E1..E6), offline, sem modelo.

Cada um responde a uma pergunta da seção 7 de `docs/equipes-estudo.md` e
grava JSON em `docs/equipes/resultados/` com máquina, semente e IC. Os que
rodam equipes de verdade usam provedores puros (sem rede); E3 e E5 são
simulações com hipóteses explícitas — medem a máquina, não o modelo.
"""

from __future__ import annotations

import json
import math
import os
import random
import tempfile
import threading
import time
from collections.abc import Callable
from pathlib import Path
from typing import Any

from ..models.provider import Reply, Request
from ..rag.eval.bench import environment
from ..rag.eval.metrics import bootstrap_ci
from .artifacts import ArtifactConflict, Artifacts
from .team import load_team

__all__ = ["BENCHMARKS", "results_dir", "run_benchmark"]


def results_dir() -> str:
    here = Path(__file__).resolve()
    for parent in here.parents:
        if (parent / "pyproject.toml").is_file():
            return str(parent / "docs" / "equipes" / "resultados")
    return str(Path.cwd() / "resultados")


def _write(name: str, payload: dict[str, Any], out_dir: str | None) -> str:
    d = out_dir or results_dir()
    os.makedirs(d, exist_ok=True)
    path = os.path.join(d, f"{name}.json")
    with open(path, "w", encoding="utf-8") as fh:
        json.dump({"environment": environment(), **payload}, fh, ensure_ascii=False, indent=2)
    return path


def _ci(values: list[float], seed: int = 0) -> dict[str, float]:
    m, lo, hi = bootstrap_ci(values, seed=seed)
    return {"mean": round(m, 4), "lo": round(lo, 4), "hi": round(hi, 4), "n": len(values)}


def _factory(provs: dict[str, Any]) -> Callable[[Any], Any]:
    def make(p: Any) -> Any:
        return provs.get(p.name) or _Ecoa()

    return make


class _Ecoa:
    model, effort = "scripted", "high"

    def __init__(self) -> None:
        self.calls = 0
        self._lock = threading.Lock()

    def complete(self, request: Request) -> Reply:
        with self._lock:
            self.calls += 1
        return Reply.of_text("feito", input_tokens=1, output_tokens=1)


def _team(root: Path, members: dict[str, dict[str, str]], *, channels: str = "", autonomy: str = "auto", workflows: str = "", roles: str = "") -> Path:
    d = root / "eq"
    (d / "members").mkdir(parents=True, exist_ok=True)
    for n, fm in members.items():
        linhas = [f"name: {n}", f"description: membro {n}"] + [f"{k}: {v}" for k, v in fm.items()]
        (d / "members" / n).mkdir(exist_ok=True)
        (d / "members" / n / "AGENT.md").write_text("---\n" + "\n".join(linhas) + "\n---\nVocê é " + n + ".\n", encoding="utf-8")
    cabecalho = ["name: eq", "description: equipe de bench", f"autonomy: {autonomy}"]
    if channels:
        cabecalho.append(f"channels: {channels}")
    if roles:
        cabecalho.append(f"roles: {roles}")
    if workflows:
        cabecalho.append(f"workflows: {workflows}")
    (d / "TEAM.md").write_text("---\n" + "\n".join(cabecalho) + "\n---\n", encoding="utf-8")
    return d


# --------------------------------------------------------------------------
# E1 — a difusão por canal acorda quem deve?
# --------------------------------------------------------------------------


def bench_diffusion(seed: int, out_dir: str | None) -> str:
    rows = []
    with tempfile.TemporaryDirectory() as tmp:
        for autonomy in ("auto", "ask", "never"):
            n = 6
            members: dict[str, dict[str, str]] = {f"m{i}": {} for i in range(n)}
            subs = ", ".join(f"m{i}" for i in range(n))
            d = _team(Path(tmp) / autonomy, members, channels=f"{{geral: [{subs}]}}", autonomy=autonomy)
            provs: dict[str, Any] = {k: _Ecoa() for k in members}
            rt = load_team(d).runtime(_factory(provs), db=Path(tmp) / autonomy / "eq.db")
            rt.start()
            rt.send("m0", "#geral", "inform", "achei um problema em X")
            t0 = time.perf_counter()
            rel = rt.drain()
            ms = (time.perf_counter() - t0) * 1000
            acordaram = sum(1 for k, pv in provs.items() if pv.calls and k != "m0")
            pendentes = rel["counts"]["pending"]
            rows.append({"autonomy": autonomy, "assinantes": n - 1, "acordaram": acordaram, "em_espera": pendentes, "autor_acordou": provs["m0"].calls, "ms": round(ms, 1)})
            rt.close()
    return _write("e1_difusao_por_canal", {"benchmark": "E1", "seed": seed, "rows": rows}, out_dir)


# --------------------------------------------------------------------------
# E2 — as obrigações do compromisso são cumpridas?
# --------------------------------------------------------------------------


def bench_commitments(seed: int, out_dir: str | None) -> str:
    rng = random.Random(seed)

    class Recusa:
        model, effort = "scripted", "high"

        def complete(self, request: Request) -> Reply:
            return Reply(content=[], stop_reason="refusal", stop_details={"category": "x"})

    class Cai:
        """Cai uma vez (transitório) e depois cumpre: a retomada fecha o compromisso."""

        model, effort = "scripted", "high"

        def __init__(self) -> None:
            self.calls = 0

        def complete(self, request: Request) -> Reply:
            self.calls += 1
            if self.calls == 1:
                from ..models.provider import ProviderError

                raise ProviderError("rede caiu")
            return Reply.of_text("feito", input_tokens=1, output_tokens=1)

    with tempfile.TemporaryDirectory() as tmp:
        kinds: dict[str, Any] = {"ok": _Ecoa, "recusa": Recusa, "cai": Cai}
        members: dict[str, dict[str, str]] = {f"{k}{i}": {} for k in kinds for i in range(3)}
        d = _team(Path(tmp), members, autonomy="auto")
        provs: dict[str, Any] = {n: kinds[n.rstrip("0123456789")]() for n in members}
        rt = load_team(d).runtime(_factory(provs), db=Path(tmp) / "eq.db")
        rt.start()
        convs = []
        for n in members:
            for _ in range(2):
                convs.append((n, rt.send("operator", n, "request", f"tarefa {rng.random():.3f}").conversation))
        rt.drain()
        por_tipo: dict[str, dict[str, int]] = {}
        for n, c in convs:
            k = n.rstrip("0123456789")
            com = rt.commitments.get(c)
            st = com.status if com else "missing"
            por_tipo.setdefault(k, {"done": 0, "failed": 0, "open": 0})
            por_tipo[k][st] = por_tipo[k].get(st, 0) + 1
        caixa = rt.peek("operator", limit=1000)
        desfechos = sum(1 for e in caixa if e.performative in ("inform", "failure"))
        abertos = rt.commitments.counts()["open"]
        rt.close()
    return _write(
        "e2_obrigacoes_do_compromisso",
        {"benchmark": "E2", "seed": seed, "pedidos": len(convs), "por_tipo_de_executor": por_tipo, "desfechos_na_caixa_do_pedinte": desfechos, "compromissos_abertos_ao_fim": abertos},
        out_dir,
    )


# --------------------------------------------------------------------------
# E3 — comunicar seletivamente compensa? (simulação à STEAM)
# --------------------------------------------------------------------------


def _coordination(seed: int, *, policy: str, k: int = 6, steps: int = 200, p_change: float = 0.2, p_relevant: float = 0.3, msg_cost: float = 1.0, miss_cost: float = 5.0) -> dict[str, float]:
    """K agentes; a cada passo, cada um pode mudar de estado; a mudança é relevante aos outros com p_relevant.

    always: comunica toda mudança; never: nenhuma; selective: comunica quando
    o custo esperado de descoordenar (p_relevant * miss_cost) supera o da
    mensagem — com uma estimativa ruidosa da relevância (o que STEAM chama de
    comunicação seletiva por decisão).
    """
    rng = random.Random(seed)
    msgs = 0
    misses = 0
    for _ in range(steps):
        for _a in range(k):
            if rng.random() >= p_change:
                continue
            relevant = rng.random() < p_relevant
            if policy == "always":
                msgs += 1
            elif policy == "never":
                misses += int(relevant)
            else:
                est = p_relevant + rng.gauss(0, 0.15) + (0.4 if relevant else -0.2)  # sinal ruidoso
                if est * miss_cost > msg_cost:
                    msgs += 1
                else:
                    misses += int(relevant)
    return {"messages": float(msgs), "misses": float(misses), "cost": msgs * msg_cost + misses * miss_cost}


def bench_selective(seed: int, out_dir: str | None) -> str:
    seeds = list(range(seed, seed + 30))
    out: dict[str, Any] = {"benchmark": "E3", "seed": seed, "runs": len(seeds), "hipoteses": {"p_change": 0.2, "p_relevant": 0.3, "msg_cost": 1.0, "miss_cost": 5.0, "k": 6, "steps": 200}, "politicas": {}}
    for pol in ("always", "never", "selective"):
        rows = [_coordination(s, policy=pol) for s in seeds]
        out["politicas"][pol] = {kk: _ci([r[kk] for r in rows], seed) for kk in rows[0]}
    return _write("e3_comunicacao_seletiva", out, out_dir)


# --------------------------------------------------------------------------
# E4 — isolamento sem concorrência: CAS vs escrita cega
# --------------------------------------------------------------------------


def bench_isolation(seed: int, out_dir: str | None) -> str:
    rows = []
    with tempfile.TemporaryDirectory() as tmp:
        for mode in ("cega", "cas"):
            art = Artifacts(Path(tmp) / mode, db=Path(tmp) / f"{mode}.db", team="eq")
            art.write("contador", "0", owner="init")
            n_writers, n_each = 8, 25
            conflitos = [0]
            lock = threading.Lock()

            def worker(name: str, _art: Artifacts = art, _mode: str = mode, _n: int = n_each, _c: list[int] = conflitos, _lock: threading.Lock = lock) -> None:
                for _ in range(_n):
                    while True:
                        a = _art.read("contador")
                        assert a is not None
                        val = int(a.content) + 1
                        try:
                            _art.write("contador", str(val), owner=name, expected_version=(a.version if _mode == "cas" else None))
                            break
                        except ArtifactConflict:
                            with _lock:
                                _c[0] += 1

            threads = [threading.Thread(target=worker, args=(f"w{i}",)) for i in range(n_writers)]
            for t in threads:
                t.start()
            for t in threads:
                t.join()
            final = int(art.read("contador").content)  # type: ignore[union-attr]
            esperado = n_writers * n_each
            rows.append({"modo": mode, "escritores": n_writers, "incrementos": esperado, "valor_final": final, "atualizacoes_perdidas": esperado - final, "conflitos_resolvidos": conflitos[0]})
            art.close()
    return _write("e4_isolamento_cas", {"benchmark": "E4", "seed": seed, "rows": rows}, out_dir)


# --------------------------------------------------------------------------
# E5 - equipe vs agente único, compute igualado (simulação)
# --------------------------------------------------------------------------


def _decomposable(seed: int, *, k: int, mode: str, p0: float = 0.95, decay: float = 0.08, overhead: float = 0.5) -> float:
    """Tarefa com k partes independentes.

    Hipótese explícita (Liu et al., 2023: degradação com o comprimento): a
    probabilidade de acertar uma parte cai com o contexto acumulado,
    p = p0 * exp(-decay * partes_ja_no_contexto). O agente único acumula
    contexto; cada membro da equipe começa limpo mas paga `overhead` partes
    de compute em coordenação — o compute total é igualado cortando partes.
    """
    rng = random.Random(seed)
    if mode == "single":
        ok = 0
        for i in range(k):
            ok += int(rng.random() < p0 * math.exp(-decay * i))
        return ok / k
    budget = k  # o mesmo compute do agente único, em partes
    coord = overhead * (k - 1)  # mensagens entre k membros
    parts = max(1, round(budget - coord))
    ok = 0
    for i in range(k):
        if i < parts:
            ok += int(rng.random() < p0)
    return ok / k


def bench_team_vs_single(seed: int, out_dir: str | None) -> str:
    seeds = list(range(seed, seed + 40))
    rows = []
    for overhead in (0.1, 0.5):
        for decay in (0.02, 0.08, 0.2):
            for k in (4, 8, 16):
                single = [_decomposable(s, k=k, mode="single", decay=decay, overhead=overhead) for s in seeds]
                team = [_decomposable(s, k=k, mode="team", decay=decay, overhead=overhead) for s in seeds]
                rows.append({"overhead": overhead, "decay": decay, "partes": k, "single": _ci(single, seed), "team": _ci(team, seed), "vence": "team" if sum(team) > sum(single) else "single"})
    return _write("e5_equipe_vs_unico_compute_igualado", {"benchmark": "E5", "seed": seed, "runs": len(seeds), "hipoteses": {"p0": 0.95, "overhead_por_membro": "partes de compute gastas em coordenação, por membro", "decay": "degradação por parte já no contexto (Liu et al., 2023)"}, "rows": rows}, out_dir)


# --------------------------------------------------------------------------
# E6 — anúncio e lance alocam melhor?
# --------------------------------------------------------------------------


def bench_allocation(seed: int, out_dir: str | None) -> str:
    rng = random.Random(seed)
    caps = ["python", "sql", "testes", "docs", "infra", "dados", "ui", "seguranca"]
    n_members, n_tasks = 6, 60
    members = {f"m{i}": rng.sample(caps, 3) for i in range(n_members)}
    tasks = [rng.sample(caps, 2) for _ in range(n_tasks)]

    def fit(m: str, needs: list[str]) -> float:
        return len(set(members[m]) & set(needs)) / len(needs)

    res = {}
    # contract net: quem mais cobre ganha (o `cfp` do runtime é este cálculo)
    res["contract_net"] = sum(max(fit(m, t) for m in members) for t in tasks) / n_tasks
    res["round_robin"] = sum(fit(f"m{i % n_members}", t) for i, t in enumerate(tasks)) / n_tasks
    res["direto_fixo"] = sum(fit("m0", t) for t in tasks) / n_tasks
    with tempfile.TemporaryDirectory() as tmp:
        fms: dict[str, dict[str, str]] = {m: {"capabilities": f"[{', '.join(c)}]"} for m, c in members.items()}
        fms["chefe"] = {}
        d = _team(Path(tmp), fms, autonomy="never", channels="{geral: [" + ", ".join([*members, "chefe"]) + "]}")
        rt = load_team(d).runtime(_factory({}), db=Path(tmp) / "eq.db")
        acertos = 0
        for t in tasks:
            winner, _bids = rt.cfp("chefe", t, "tarefa")
            best = max(members, key=lambda m: fit(m, t))
            acertos += int(winner is not None and fit(winner, t) == fit(best, t))
        rt.close()
    return _write("e6_alocacao_contract_net", {"benchmark": "E6", "seed": seed, "membros": n_members, "tarefas": n_tasks, "cobertura_media": {k: round(v, 4) for k, v in res.items()}, "cfp_do_runtime_escolhe_o_melhor": round(acertos / n_tasks, 4)}, out_dir)


BENCHMARKS: dict[str, Callable[[int, str | None], str]] = {
    "e1": bench_diffusion,
    "e2": bench_commitments,
    "e3": bench_selective,
    "e4": bench_isolation,
    "e5": bench_team_vs_single,
    "e6": bench_allocation,
}


def run_benchmark(name: str, *, seed: int = 0, out_dir: str | None = None) -> str:
    if name not in BENCHMARKS:
        raise KeyError(f"benchmark desconhecido: {name!r}; opções: {sorted(BENCHMARKS)}")
    return BENCHMARKS[name](seed, out_dir)
