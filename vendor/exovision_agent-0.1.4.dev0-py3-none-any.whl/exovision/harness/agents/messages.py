"""A gramática das mensagens entre perfis: performativos, envelope, compromissos.

Conversa livre entre agentes é redundância (28--73% dos tokens, AgentPrune); o
que funcionou no MetaGPT foi mensagem *estruturada* num pool por assunto. A
gramática aqui é a do FIPA-ACL: cada mensagem tem um **performativo** (o ato
de fala), remetente, destinatário, conteúdo e conversa.

    request           pede que o destinatário faça algo — abre um compromisso se aceito
    accept / refuse   o destinatário se compromete, ou não
    inform            comunica um fato ou uma conclusão (inclui `done`)
    failure           não conseguiu; diz por quê
    cfp               anúncio de tarefa: quem pode, propõe (Contract Net)
    propose / accept_proposal / reject_proposal
    query             pergunta que espera `inform`

Os assuntos vão no barramento que já existe: `agent.<perfil>.inbox` para a
caixa, `team.<equipe>.<canal>` para canais, `team.<equipe>.artifacts.<nome>`
para o quadro-negro.

**Compromissos.** Na teoria das intenções conjuntas, aceitar um pedido cria
um objetivo conjunto, e quem descobre que ele foi atingido, ficou impossível
ou irrelevante *tem de* comunicar. O harness registra o compromisso quando o
`request` vira tarefa e o fecha quando chega `inform`/`failure` na mesma
conversa; um compromisso aberto sem desfecho é visível — não é silêncio, é
erro de protocolo.
"""

from __future__ import annotations

import re
import sqlite3
import threading
import time
import uuid
from collections.abc import Callable
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

from ..bus import Bus, Message
from ..session import enable_wal

__all__ = [
    "PERFORMATIVES",
    "Commitment",
    "Commitments",
    "Envelope",
    "artifact_subject",
    "channel_subject",
    "inbox_subject",
    "new_conversation",
    "parse",
    "post",
]

PERFORMATIVES: tuple[str, ...] = (
    "request",
    "accept",
    "refuse",
    "inform",
    "failure",
    "cfp",
    "propose",
    "accept_proposal",
    "reject_proposal",
    "query",
)

_TOKEN = re.compile(r"^[a-z0-9][a-z0-9_-]{0,63}$")


def _tok(name: str, what: str) -> str:
    if not _TOKEN.match(name):
        raise ValueError(f"{what} inválido: {name!r} (minúsculas, dígitos, - e _)")
    return name.replace("-", "_")


def inbox_subject(profile: str) -> str:
    return f"agent.{_tok(profile, 'perfil')}.inbox"


def channel_subject(team: str, channel: str) -> str:
    return f"team.{_tok(team, 'equipe')}.{_tok(channel, 'canal')}"


def artifact_subject(team: str, name: str) -> str:
    """Nome de artefato vira token de assunto: `plano.md` -> `plano_md` (o nome real fica no dado)."""
    token = re.sub(r"[^a-z0-9_-]", "_", name.lower()).strip("_") or "artefato"
    return f"team.{_tok(team, 'equipe')}.artifacts.{token.replace('-', '_')}"


def new_conversation() -> str:
    return uuid.uuid4().hex[:12]


@dataclass(frozen=True, slots=True)
class Envelope:
    """Uma mensagem entre perfis. `to` é um perfil (caixa) ou `#canal`."""

    performative: str
    sender: str
    to: str
    content: str
    conversation: str = ""
    reply_to: str = ""
    data: dict[str, Any] = field(default_factory=dict)
    at: float = 0.0
    seq: int = 0

    def __post_init__(self) -> None:
        if self.performative not in PERFORMATIVES:
            raise ValueError(f"performativo {self.performative!r} fora de {PERFORMATIVES}")

    def to_data(self) -> dict[str, Any]:
        return {
            "performative": self.performative,
            "from": self.sender,
            "to": self.to,
            "content": self.content,
            "conversation": self.conversation,
            "reply_to": self.reply_to,
            **({"data": self.data} if self.data else {}),
        }

    def brief(self, limit: int = 200) -> str:
        c = self.content if len(self.content) <= limit else self.content[:limit] + "…"
        return f"[{self.performative}] {self.sender} -> {self.to} ({self.conversation or '-'}): {c}"


def parse(msg: Message) -> Envelope | None:
    """Mensagem do barramento -> envelope, ou None se não é uma mensagem de perfil."""
    d = msg.data if isinstance(msg.data, dict) else {}
    if "performative" not in d or "from" not in d:
        return None
    try:
        return Envelope(
            performative=str(d["performative"]),
            sender=str(d["from"]),
            to=str(d.get("to") or ""),
            content=str(d.get("content") or ""),
            conversation=str(d.get("conversation") or ""),
            reply_to=str(d.get("reply_to") or ""),
            data=dict(d.get("data") or {}),
            at=msg.at,
            seq=msg.seq,
        )
    except ValueError:
        return None


def post(bus: Bus, env: Envelope, *, team: str = "") -> Message:
    """Publica na caixa do destinatário ou no canal (`#canal`, exige `team`)."""
    if env.to.startswith("#"):
        if not team:
            raise ValueError("mensagem para canal precisa da equipe")
        subject = channel_subject(team, env.to[1:])
    else:
        subject = inbox_subject(env.to)
    return bus.publish(subject, env.to_data())


# --------------------------------------------------------------------------
# compromissos
# --------------------------------------------------------------------------


@dataclass(frozen=True, slots=True)
class Commitment:
    conversation: str
    requester: str
    executor: str
    task: str
    status: str = "open"  # open | done | failed | refused
    opened_at: float = 0.0
    closed_at: float | None = None
    outcome: str = ""

    def to_dict(self) -> dict[str, Any]:
        return {
            "conversation": self.conversation,
            "requester": self.requester,
            "executor": self.executor,
            "task": self.task,
            "status": self.status,
            "opened_at": self.opened_at,
            "closed_at": self.closed_at,
            "outcome": self.outcome,
        }


class Commitments:
    """O livro de compromissos da equipe — uma tabela no mesmo arquivo."""

    def __init__(self, path: str | Path = ":memory:", *, clock: Callable[[], float] = time.time) -> None:
        self.path = str(path)
        self._clock = clock
        self._lock = threading.RLock()
        if self.path != ":memory:":
            Path(self.path).parent.mkdir(parents=True, exist_ok=True)
        self._conn = sqlite3.connect(self.path, check_same_thread=False, timeout=30.0)
        with self._lock:
            if self.path != ":memory:":
                enable_wal(self._conn)
            self._conn.execute(
                "CREATE TABLE IF NOT EXISTS commitments (conversation TEXT PRIMARY KEY, requester TEXT NOT NULL, "
                "executor TEXT NOT NULL, task TEXT NOT NULL, status TEXT NOT NULL, opened_at REAL NOT NULL, "
                "closed_at REAL, outcome TEXT NOT NULL DEFAULT '')"
            )
            self._conn.commit()

    def open(self, conversation: str, requester: str, executor: str, task: str) -> Commitment:
        now = self._clock()
        with self._lock:
            self._conn.execute(
                "INSERT OR IGNORE INTO commitments(conversation, requester, executor, task, status, opened_at) "
                "VALUES (?,?,?,?,'open',?)",
                (conversation, requester, executor, task, now),
            )
            self._conn.commit()
        c = self.get(conversation)
        assert c is not None
        return c

    def close(self, conversation: str, status: str, outcome: str = "") -> bool:
        if status not in ("done", "failed", "refused"):
            raise ValueError("status: done | failed | refused")
        with self._lock:
            cur = self._conn.execute(
                "UPDATE commitments SET status = ?, closed_at = ?, outcome = ? WHERE conversation = ? AND status = 'open'",
                (status, self._clock(), outcome[:4000], conversation),
            )
            self._conn.commit()
        return cur.rowcount == 1

    def get(self, conversation: str) -> Commitment | None:
        with self._lock:
            row = self._conn.execute(
                "SELECT conversation, requester, executor, task, status, opened_at, closed_at, outcome "
                "FROM commitments WHERE conversation = ?",
                (conversation,),
            ).fetchone()
        return Commitment(*row) if row else None

    def all(self, status: str | None = None) -> list[Commitment]:
        with self._lock:
            if status:
                rows = self._conn.execute(
                    "SELECT conversation, requester, executor, task, status, opened_at, closed_at, outcome "
                    "FROM commitments WHERE status = ? ORDER BY opened_at",
                    (status,),
                ).fetchall()
            else:
                rows = self._conn.execute(
                    "SELECT conversation, requester, executor, task, status, opened_at, closed_at, outcome "
                    "FROM commitments ORDER BY opened_at"
                ).fetchall()
        return [Commitment(*r) for r in rows]

    def counts(self) -> dict[str, int]:
        out = {"open": 0, "done": 0, "failed": 0, "refused": 0}
        for c in self.all():
            out[c.status] = out.get(c.status, 0) + 1
        return out

    def close_all(self) -> None:
        with self._lock:
            self._conn.close()
