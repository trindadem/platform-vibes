"""`exovision-agent agents`: perfis e equipes pela linha de comando.

    exovision-agent agents new-profile ./agentes/revisor --description "revisa PRs" --capabilities revisao,python
    exovision-agent agents new-team ./equipe/lab --description "o laboratório" --members revisor,redator
    exovision-agent agents show ./equipe/lab                       # ou um perfil
    exovision-agent agents run ./agentes/revisor "revise o PR 42"   # um perfil, uma vez
    exovision-agent agents send ./equipe/lab --to revisor "revise o PR 42"        # request do operador
    exovision-agent agents serve ./equipe/lab --workers 4           # a equipe viva (Ctrl-C/SIGTERM para parar)
    exovision-agent agents serve ./equipe/lab --drain               # só o que há; sai
    exovision-agent agents inbox ./equipe/lab operator              # o que os perfis responderam
    exovision-agent agents commitments ./equipe/lab [--status open]
    exovision-agent agents approve ./equipe/lab <task-id>           # o dial `ask`
    exovision-agent agents artifacts ./equipe/lab
    exovision-agent agents bench all                                 # docs/equipes/resultados/

Sem rede: `--scripted revisor=r1.json --scripted redator=r2.json` (um
roteiro por perfil; `--scripted r.json` vale para todos).
"""

from __future__ import annotations

import argparse
import json
import sys
import time
from collections.abc import Callable
from pathlib import Path
from typing import Any

from ..models import make_provider
from ..models.provider import Provider, ProviderError
from ..plugins import PluginError
from .bench import BENCHMARKS, run_benchmark
from .messages import PERFORMATIVES
from .profile import Profile, ProfileError, load_profile, load_profiles
from .team import TeamError, load_team

__all__ = ["add_parser", "provider_factory"]


def provider_factory(scripted: list[str] | None) -> Callable[[Profile], Provider]:
    """`--scripted [perfil=]roteiro.json` (repetível) ou o driver do modelo do perfil (`model: [tipo:]modelo`)."""
    from ..cli import _scripted  # tarde, para não fechar um ciclo com harness.cli

    por_perfil: dict[str, str] = {}
    geral = ""
    for item in scripted or []:
        if "=" in item:
            k, _, v = item.partition("=")
            por_perfil[k] = v
        else:
            geral = item

    cache: dict[str, Provider] = {}

    def make(p: Profile) -> Provider:
        """Um provedor por perfil durante o processo: um roteiro é consumido uma vez, não a cada despertar."""
        if p.name not in cache:
            caminho = por_perfil.get(p.name) or geral
            cache[p.name] = _scripted(caminho) if caminho else make_provider(p.model or "", effort=p.effort or "")
        return cache[p.name]

    return make


def _line_profile(p: Profile) -> str:
    return f"{p.name:16s} v{p.version:8s} {p.autonomy:6s} caps={','.join(p.capabilities) or '-':20s} canais={','.join(p.channels) or '-':16s} {p.description[:50]}"


def cmd_new_profile(a: argparse.Namespace) -> int:
    d = Path(a.path)
    if (d / "AGENT.md").exists():
        raise SystemExit(f"já existe: {d / 'AGENT.md'}")
    d.mkdir(parents=True, exist_ok=True)
    (d / "notas").mkdir(exist_ok=True)
    linhas = [f"name: {a.name or d.name}", "version: 0.1.0", f"description: {a.description}"]
    if a.model:
        linhas.append(f"model: {a.model}")
    if a.capabilities:
        linhas.append(f"capabilities: [{a.capabilities}]")
    if a.channels:
        linhas.append(f"channels: [{a.channels}]")
    linhas.append(f"autonomy: {a.autonomy}")
    linhas.append("memory: [episodic, semantic, buffer]")
    linhas.append("policy: {deny_at: irreversible, taint: true}")
    (d / "AGENT.md").write_text(
        "---\n" + "\n".join(linhas) + "\n---\n"
        f"Você é {a.name or d.name}: {a.description}\n\n"
        "O que fazer, como decidir, o que devolver. Este corpo é a instrução (documento com digest).\n"
        "Para falar com a equipe: team_send, team_ask, team_cfp; para o quadro-negro: team_artifact_read/write.\n",
        encoding="utf-8",
    )
    print(f"perfil criado em {d}")
    return 0


def cmd_new_team(a: argparse.Namespace) -> int:
    d = Path(a.path)
    if (d / "TEAM.md").exists():
        raise SystemExit(f"já existe: {d / 'TEAM.md'}")
    (d / "members").mkdir(parents=True, exist_ok=True)
    (d / "shared").mkdir(exist_ok=True)
    nomes = [m.strip() for m in (a.members or "").split(",") if m.strip()]
    for n in nomes:
        sub = d / "members" / n
        if not (sub / "AGENT.md").exists():
            sub.mkdir(parents=True, exist_ok=True)
            (sub / "notas").mkdir(exist_ok=True)
            (sub / "AGENT.md").write_text(f"---\nname: {n}\nversion: 0.1.0\ndescription: membro {n}\nautonomy: ask\nchannels: [geral]\n---\nVocê é {n}. Descreva aqui o que faz e como.\n", encoding="utf-8")
    canais = "{geral: [" + ", ".join(nomes) + "]}" if nomes else "{}"
    (d / "TEAM.md").write_text(
        f"---\nname: {a.name or d.name}\nversion: 0.1.0\ndescription: {a.description}\nchannels: {canais}\nautonomy: ask\n"
        'workflows: []\n---\n\n'
        "Quem faz o quê, e como o trabalho passa de um para outro. O front-matter acima é o que o harness lê:\n"
        "- `channels`: quem assina o quê (mensagens num canal acordam quem assina)\n"
        "- `roles`: quem pode pedir a quem (vazio = todos)\n"
        '- `workflows`: JSON de [{"on": "done:<perfil>", "to": "<perfil>", "task": "... {{outcome}} ..."}]\n'
        "- `autonomy`: auto | ask | never (padrão dos membros)\n",
        encoding="utf-8",
    )
    print(f"equipe criada em {d} com membros {nomes or '(nenhum)'}")
    return 0


def cmd_show(a: argparse.Namespace) -> int:
    d = Path(a.path)
    if (d / "TEAM.md").is_file():
        try:
            t = load_team(d)
        except TeamError as erro:
            raise SystemExit(str(erro)) from None
        if a.json:
            print(json.dumps(t.summary(), ensure_ascii=False, indent=2))
            return 0
        print(f"equipe {t.name} v{t.version}: {t.description}")
        for p in t.members.values():
            print("  " + _line_profile(p))
        for ch, subs in t.channels.items():
            print(f"  #{ch}: {', '.join(subs)}")
        for w in t.workflows:
            print(f"  fluxo: {w['on']} -> {w['to']}: {w['task'][:60]}")
        return 0
    try:
        perfis = load_profiles([d]) if not (d / "AGENT.md").is_file() else [load_profile(d)]
    except ProfileError as erro:
        raise SystemExit(str(erro)) from None
    if a.json:
        print(json.dumps([p.summary() for p in perfis], ensure_ascii=False, indent=2))
        return 0
    for p in perfis:
        print(_line_profile(p))
    return 0


def cmd_run(a: argparse.Namespace) -> int:
    from ..loop import run

    try:
        p = load_profile(a.path)
        agent = p.build(provider_factory(a.scripted)(p), evolve=a.evolve)
    except (ProfileError, PluginError, ProviderError) as erro:
        raise SystemExit(f"{a.path}: {erro}") from None
    from ..session import SQLiteStateStore

    out = run(agent, a.task, session=a.session or "-", state_store=SQLiteStateStore(p.journal_db) if a.session else None)
    if a.json:
        print(json.dumps(out.to_dict(), ensure_ascii=False, indent=2))
    else:
        from ..ui import color_for, format_outcome

        corpo, rodape = format_outcome(out, color=color_for(sys.stderr))
        if corpo:
            print(corpo)
        sys.stderr.write(rodape + "\n")  # o erro NUNCA fica invisível (era só o stop_reason)
    return 0 if out.ok else 1


def _runtime(a: argparse.Namespace):
    try:
        t = load_team(a.path)
    except TeamError as erro:
        raise SystemExit(str(erro)) from None
    return t.runtime(
        provider_factory(getattr(a, "scripted", None)),
        workers=getattr(a, "workers", 2),
        evolve=bool(getattr(a, "evolve", False)),
        poll_s=getattr(a, "poll", 0.5),
        lease_s=getattr(a, "lease", 60.0),
    )


def cmd_serve(a: argparse.Namespace) -> int:
    rt = _runtime(a)
    rt.start()
    if a.drain:
        rel = rt.drain(timeout_s=a.timeout_s)
        print(json.dumps({**rt.report(), "executed": rel["executed"], "stopped": rel["stopped"]}, ensure_ascii=False, indent=2))
        return 0
    rt.serve_forever()
    sys.stderr.write("\nparado: as tarefas em curso terminaram\n")
    return 0


def cmd_send(a: argparse.Namespace) -> int:
    rt = _runtime(a)
    try:
        env = rt.send(a.sender, a.to, a.performative, a.content, conversation=a.conversation or "")
    except (ValueError, PermissionError) as erro:
        raise SystemExit(str(erro)) from None
    print(json.dumps({"conversation": env.conversation, "seq": env.seq, "to": env.to, "performative": env.performative}, ensure_ascii=False) if a.json else f"#{env.seq} {env.brief()}")
    return 0


def cmd_inbox(a: argparse.Namespace) -> int:
    rt = _runtime(a)
    envs = rt.peek(a.member, after=a.after, limit=a.limit)
    if a.json:
        print(json.dumps([{**e.to_data(), "seq": e.seq, "at": e.at} for e in envs], ensure_ascii=False, indent=2))
        return 0
    for e in envs:
        print(f"#{e.seq} {e.brief()}")
    return 0


def cmd_commitments(a: argparse.Namespace) -> int:
    rt = _runtime(a)
    rows = rt.commitments.all(a.status)
    if a.json:
        print(json.dumps([c.to_dict() for c in rows], ensure_ascii=False, indent=2))
        return 0
    for c in rows:
        print(f"{c.conversation}  {c.status:8s} {c.requester} -> {c.executor}: {c.task[:60]}" + (f"  => {c.outcome[:60]}" if c.outcome else ""))
    return 0


def cmd_approve(a: argparse.Namespace) -> int:
    rt = _runtime(a)
    ok = rt.approve(a.task_id)
    print("liberada" if ok else "sem efeito (não está pendente)")
    return 0 if ok else 1


def cmd_artifacts(a: argparse.Namespace) -> int:
    rt = _runtime(a)
    rows = rt.artifacts.list()
    if a.json:
        print(json.dumps([x.to_dict() for x in rows], ensure_ascii=False, indent=2))
        return 0
    for x in rows:
        print(f"{x.name:30s} v{x.version:<4d} {x.owner}")
    return 0


def cmd_bench(a: argparse.Namespace) -> int:
    quais = list(BENCHMARKS) if a.which == "all" else [a.which]
    for nome in quais:
        t0 = time.perf_counter()
        path = run_benchmark(nome, seed=a.seed, out_dir=a.out)
        sys.stderr.write(f"{nome}: {path} ({time.perf_counter() - t0:.1f}s)\n")
        print(path)
    return 0


def add_parser(sub: Any) -> None:
    sp = sub.add_parser("agents", help="perfis e equipes: criar, mostrar, rodar, servir, mensagens, compromissos", description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ss = sp.add_subparsers(dest="acmd", required=True)

    np_ = ss.add_parser("new-profile", help="esqueleto de perfil (AGENT.md)")
    np_.add_argument("path")
    np_.add_argument("--description", required=True)
    np_.add_argument("--name")
    np_.add_argument("--model")
    np_.add_argument("--capabilities", help="lista separada por vírgula")
    np_.add_argument("--channels", help="lista separada por vírgula")
    np_.add_argument("--autonomy", choices=["auto", "ask", "never"], default="ask")
    np_.set_defaults(fn=cmd_new_profile)

    nt = ss.add_parser("new-team", help="esqueleto de equipe (TEAM.md + members/)")
    nt.add_argument("path")
    nt.add_argument("--description", required=True)
    nt.add_argument("--name")
    nt.add_argument("--members", help="nomes separados por vírgula (cria os perfis)")
    nt.set_defaults(fn=cmd_new_team)

    sh = ss.add_parser("show", help="um perfil, um diretório de perfis ou uma equipe")
    sh.add_argument("path")
    sh.add_argument("--json", action="store_true")
    sh.set_defaults(fn=cmd_show)

    rn = ss.add_parser("run", help="roda um perfil uma vez")
    rn.add_argument("path")
    rn.add_argument("task")
    rn.add_argument("--scripted", action="append", help="[perfil=]roteiro.json (sem rede)")
    rn.add_argument("--session", help="nome da sessão no journal do perfil")
    rn.add_argument("--evolve", action="store_true")
    rn.add_argument("--json", action="store_true")
    rn.set_defaults(fn=cmd_run)

    def team_args(p: argparse.ArgumentParser) -> None:
        p.add_argument("path")
        p.add_argument("--scripted", action="append", help="[perfil=]roteiro.json (sem rede)")
        p.add_argument("--json", action="store_true")

    sv = ss.add_parser("serve", help="a equipe viva: caixas, canais e fluxos como gatilhos da fila")
    team_args(sv)
    sv.add_argument("--workers", type=int, default=2)
    sv.add_argument("--evolve", action="store_true")
    sv.add_argument("--drain", action="store_true", help="processa o que há e sai")
    sv.add_argument("--timeout-s", type=float, default=None)
    sv.add_argument("--poll", type=float, default=0.5)
    sv.add_argument("--lease", type=float, default=60.0)
    sv.set_defaults(fn=cmd_serve)

    sd = ss.add_parser("send", help="manda uma mensagem a um membro ou canal (#canal)")
    team_args(sd)
    sd.add_argument("content")
    sd.add_argument("--to", required=True)
    sd.add_argument("--performative", choices=list(PERFORMATIVES), default="request")
    sd.add_argument("--from", dest="sender", default="operator")
    sd.add_argument("--conversation")
    sd.set_defaults(fn=cmd_send)

    ib = ss.add_parser("inbox", help="lê a caixa de um membro (ou de `operator`)")
    team_args(ib)
    ib.add_argument("member")
    ib.add_argument("--after", type=int, default=0)
    ib.add_argument("--limit", type=int, default=50)
    ib.set_defaults(fn=cmd_inbox)

    cm = ss.add_parser("commitments", help="o livro de compromissos")
    team_args(cm)
    cm.add_argument("--status", choices=["open", "done", "failed", "refused"])
    cm.set_defaults(fn=cmd_commitments)

    ap = ss.add_parser("approve", help="libera uma tarefa em espera (dial `ask`)")
    team_args(ap)
    ap.add_argument("task_id")
    ap.set_defaults(fn=cmd_approve)

    ar = ss.add_parser("artifacts", help="os artefatos compartilhados")
    team_args(ar)
    ar.set_defaults(fn=cmd_artifacts)

    bn = ss.add_parser("bench", help="os benchmarks do estudo (E1..E6), offline")
    bn.add_argument("which", choices=["all", *BENCHMARKS])
    bn.add_argument("--seed", type=int, default=0)
    bn.add_argument("--out", default=None)
    bn.set_defaults(fn=cmd_bench)
