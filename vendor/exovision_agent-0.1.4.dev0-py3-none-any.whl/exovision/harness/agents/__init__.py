"""exovision.harness.agents — perfis duráveis e equipes fixas de agentes comunicantes.

Módulo do kernel. Decorre do estudo em `docs/equipes-estudo.md`: o perfil é
capacidade durável (não persona); a equipe é fixa e desenhada; a comunicação
de trabalho é obrigação do compromisso conjunto, alocada por anúncio; a
espontânea é difusão por canal que acorda quem assina; cada perfil é um ator
(uma execução por vez), e o compartilhado é quadro-negro versionado.

    profile    — AGENT.md -> Profile -> Agent (instrução, skills, plugins, memória, orçamento, política)
    team       — TEAM.md -> Team; TeamRuntime (barramento + fila + compromissos + artefatos, um arquivo);
                 TeamToolset (team_send/ask/cfp/inbox/artifact_*)
    messages   — performativos FIPA, Envelope, assuntos, Commitments
    artifacts  — artefatos compartilhados com versão e CAS
    bench      — E1..E6 do estudo, offline
    cli        — `exovision-agent agents ...`

    from exovision.harness.agents import load_team
    rt = load_team("./equipe/lab").runtime(lambda p: AnthropicProvider(model=p.model))
    rt.start(); rt.send("operator", "revisor", "request", "revise o PR 42"); rt.serve_forever()
"""

from __future__ import annotations

from .artifacts import Artifact, ArtifactConflict, Artifacts
from .messages import (
    PERFORMATIVES,
    Commitment,
    Commitments,
    Envelope,
    artifact_subject,
    channel_subject,
    inbox_subject,
    new_conversation,
    parse,
    post,
)
from .profile import AUTONOMY, Profile, ProfileError, load_profile, load_profiles
from .team import Team, TeamError, TeamRuntime, TeamToolset, load_team

__all__ = [
    "AUTONOMY",
    "PERFORMATIVES",
    "Artifact",
    "ArtifactConflict",
    "Artifacts",
    "Commitment",
    "Commitments",
    "Envelope",
    "Profile",
    "ProfileError",
    "Team",
    "TeamError",
    "TeamRuntime",
    "TeamToolset",
    "artifact_subject",
    "channel_subject",
    "inbox_subject",
    "load_profile",
    "load_profiles",
    "load_team",
    "new_conversation",
    "parse",
    "post",
]
