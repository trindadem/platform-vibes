"""A equipe: perfis fixos, canais explícitos, compromissos cobrados, um ator por perfil.

    equipe/lab/
      TEAM.md         front-matter: name, version, description, members, channels, roles,
                      workflows, budget, autonomy
      members/        perfis (AGENT.md) — ou `members:` aponta para outros diretórios
      shared/         artefatos compartilhados, versionados (CAS)
      lab.db          fila, agendas, gatilhos, barramento, compromissos, artefatos — um arquivo

Front-matter:

    members: [members/revisor, ../agentes/redator]     (padrão: members/*)
    channels: {geral: [revisor, redator], revisao: [revisor]}   quem assina o quê
    roles: {chefe: [revisor, redator]}                 quem pode pedir a quem (vazio = todos)
    workflows: [{on: "done:revisor", to: redator, task: "Redija a partir de: {{outcome}}"}]
    budget: {max_cost_usd: 20}                         o teto comum (Ledger)
    autonomy: ask                                      padrão dos membros sem `autonomy`

O que a equipe faz, e por quê:

- **Comunicação fixa de trabalho** = obrigações do compromisso conjunto
  (Cohen & Levesque): um `request` aceito abre um compromisso no livro da
  equipe; ao fim do laço do executor o harness publica `inform`/`failure` na
  conversa e fecha. Compromisso aberto sem desfecho é visível.
- **Alocação** = Contract Net (Smith, 1980): `cfp` com `needs`; os perfis
  cujas `capabilities` casam propõem (mecanicamente, sem modelo), o melhor
  recebe o `request`.
- **Espontânea** = difusão por canal: quem assina recebe; o dial de
  autonomia decide se acorda (`auto`), se espera aprovação (`ask`) ou se
  só guarda (`never`).
- **Isolamento** = ator: a caixa de cada perfil é um gatilho da fila, e a
  lease da fila garante uma execução por perfil por vez; perfis diferentes
  correm em paralelo; o compartilhado passa pelos artefatos (CAS).
"""

from __future__ import annotations

import json
import re
import time
from collections.abc import Callable, Sequence
from dataclasses import dataclass, field, replace
from pathlib import Path
from typing import Any

from ..budget import Budget
from ..bus import Bus
from ..instruction import parse_front_matter
from ..loop import Outcome, run
from ..models.provider import Provider
from ..session import SQLiteStateStore
from ..subagents import Ledger
from ..tasks import AgentRunner, Scheduler, SQLiteTaskStore, TaskContext
from ..tasks.types import Cancelled, Permanent, Transient
from ..tools import Registry, Tool, ToolResult
from .artifacts import ArtifactConflict, Artifacts
from .messages import (
    PERFORMATIVES,
    Commitments,
    Envelope,
    channel_subject,
    inbox_subject,
    new_conversation,
    parse,
    post,
)
from .profile import AUTONOMY, Profile, ProfileError, load_profiles

__all__ = ["BOOKKEEPING", "Team", "TeamError", "TeamRuntime", "TeamToolset", "load_team"]

#: Performativos que registram, não pedem ação: ficam na caixa e não acordam o perfil.
#: Aceitar cria o compromisso; quem pediu não precisa agir por isso (Cohen & Levesque).
BOOKKEEPING: frozenset[str] = frozenset({"accept", "accept_proposal", "reject_proposal"})

_NAME = re.compile(r"^[a-z][a-z0-9_-]{0,63}$")


class TeamError(ValueError):
    """Diretório que não é uma equipe, ou equipe malformada."""


def _parse_map_of_lists(v: Any) -> dict[str, list[str]]:
    """`{geral: [a, b], revisao: [a]}` (front-matter simples) ou dict já pronto."""
    if isinstance(v, dict):
        return {str(k): [str(x) for x in (val if isinstance(val, list) else str(val).strip("[]").split(","))] for k, val in v.items()}
    if not v:
        return {}
    s = str(v).strip().strip("{}")
    out: dict[str, list[str]] = {}
    for m in re.finditer(r"([a-z0-9_-]+)\s*:\s*\[([^\]]*)\]", s):
        out[m.group(1)] = [x.strip() for x in m.group(2).split(",") if x.strip()]
    return out


_FM_BLOCK = re.compile(r"\A---[ \t]*\r?\n(.*?)\r?\n---", re.DOTALL)


def _raw_value(text: str, key: str) -> str:
    """O valor bruto de uma chave do front-matter (o parser plano parte listas JSON em vírgulas)."""
    m = _FM_BLOCK.match(text)
    if not m:
        return ""
    for line in m.group(1).splitlines():
        k, sep, v = line.partition(":")
        if sep and k.strip() == key:
            return v.strip()
    return ""


def _parse_workflows(raw: str) -> list[dict[str, str]]:
    if not raw:
        return []
    try:
        data = json.loads(raw)
    except json.JSONDecodeError:
        raise TeamError(f"workflows precisa ser JSON (lista de {{on, to, task}}): {raw[:80]!r}") from None
    if not isinstance(data, list):
        raise TeamError("workflows precisa ser uma lista")
    return [{str(k): str(x) for k, x in w.items()} for w in data if isinstance(w, dict)]


@dataclass(slots=True)
class Team:
    name: str
    description: str
    path: str
    version: str = "0.1.0"
    members: dict[str, Profile] = field(default_factory=dict)
    channels: dict[str, list[str]] = field(default_factory=dict)  # canal -> assinantes
    roles: dict[str, list[str]] = field(default_factory=dict)  # quem -> a quem pode pedir
    workflows: list[dict[str, str]] = field(default_factory=list)
    budget: Budget = field(default_factory=Budget)
    autonomy: str = "ask"
    meta: dict[str, Any] = field(default_factory=dict)

    @property
    def dir(self) -> Path:
        return Path(self.path)

    @property
    def db(self) -> Path:
        return self.dir / f"{self.name}.db"

    @property
    def shared_dir(self) -> Path:
        return self.dir / "shared"

    def autonomy_of(self, member: str) -> str:
        p = self.members.get(member)
        if p is None:
            return self.autonomy
        return p.autonomy if "autonomy" in p.meta else self.autonomy

    def may_request(self, sender: str, to: str) -> bool:
        """`roles` vazio: todos podem pedir a todos. `operator` sempre pode."""
        if sender == "operator" or not self.roles:
            return True
        return to in self.roles.get(sender, [])

    def subscribers(self, channel: str) -> list[str]:
        return list(self.channels.get(channel, []))

    def summary(self) -> dict[str, Any]:
        return {
            "name": self.name,
            "version": self.version,
            "description": self.description,
            "path": self.path,
            "members": {n: p.summary() for n, p in self.members.items()},
            "channels": dict(self.channels),
            "roles": dict(self.roles),
            "workflows": list(self.workflows),
            "autonomy": self.autonomy,
            "budget": {"max_cost_usd": self.budget.max_cost_usd, "max_turns": self.budget.max_turns},
        }

    def runtime(self, provider_factory: Callable[[Profile], Provider], **kw: Any) -> TeamRuntime:
        return TeamRuntime(self, provider_factory, **kw)


def load_team(directory: str | Path) -> Team:
    d = Path(directory).resolve()
    md = d / "TEAM.md"
    if not md.is_file():
        raise TeamError(f"não é uma equipe (sem TEAM.md): {d}")
    text = md.read_text(encoding="utf-8")
    meta, _body = parse_front_matter(text)
    name = str(meta.get("name") or d.name)
    if not _NAME.match(name):
        raise TeamError(f"nome de equipe inválido: {name!r}")
    description = str(meta.get("description") or "").strip()
    if not description:
        raise TeamError(f"equipe {name!r} sem `description`")
    autonomy = str(meta.get("autonomy") or "ask")
    if autonomy not in AUTONOMY:
        raise TeamError(f"equipe {name!r}: autonomy {autonomy!r} fora de {AUTONOMY}")
    raw_members = meta.get("members")
    paths: list[Path] = []
    if raw_members:
        items = raw_members if isinstance(raw_members, list) else [x.strip() for x in str(raw_members).strip("[]").split(",") if x.strip()]
        for m in items:
            p = Path(str(m))
            paths.append(p if p.is_absolute() else (d / p))
    elif (d / "members").is_dir():
        paths.append(d / "members")
    try:
        profiles = load_profiles(paths) if paths else []
    except ProfileError as erro:
        raise TeamError(str(erro)) from None
    if not profiles:
        raise TeamError(f"equipe {name!r} sem membros (members/ ou `members:`)")
    members = {p.name: p for p in profiles}
    channels = _parse_map_of_lists(meta.get("channels"))
    for ch, subs in channels.items():
        for s in subs:
            if s not in members:
                raise TeamError(f"canal {ch!r} assinado por {s!r}, que não é membro")
    for prof in profiles:  # canais declarados no perfil também valem
        for ch in prof.channels:
            channels.setdefault(ch, [])
            if prof.name not in channels[ch]:
                channels[ch].append(prof.name)
    roles = _parse_map_of_lists(meta.get("roles"))
    for who, targets in roles.items():
        for t in targets:
            if t not in members or who not in members:
                raise TeamError(f"roles: {who!r} -> {t!r} cita quem não é membro")
    workflows = _parse_workflows(_raw_value(text, "workflows"))
    for w in workflows:
        if "on" not in w or "to" not in w or "task" not in w:
            raise TeamError(f"workflow precisa de on, to e task: {w}")
        if w["to"] not in members:
            raise TeamError(f"workflow para {w['to']!r}, que não é membro")
    b = meta.get("budget")
    braw = b if isinstance(b, dict) else {}
    if isinstance(b, str):
        for part in b.strip("{}").split(","):
            if ":" in part:
                k, _, v = part.partition(":")
                braw[k.strip()] = v.strip()
    budget = Budget(
        max_turns=int(braw.get("max_turns", 60)),
        max_cost_usd=(float(braw["max_cost_usd"]) if braw.get("max_cost_usd") is not None else None),
    )
    return Team(
        name=name,
        description=description,
        path=str(d),
        version=str(meta.get("version") or "0.1.0"),
        members=members,
        channels=channels,
        roles=roles,
        workflows=workflows,
        budget=budget,
        autonomy=autonomy,
        meta=dict(meta),
    )


# --------------------------------------------------------------------------
# runtime
# --------------------------------------------------------------------------


class TeamToolset(Registry):
    """As ferramentas de equipe do perfil que está rodando: falar, pedir, anunciar, ler, artefatos."""

    def __init__(self, rt: TeamRuntime, me: str) -> None:
        self.rt = rt
        self.me = me
        t = rt.team.name
        super().__init__(
            [
                Tool(name="team_members", description=f"Os membros da equipe {t!r}: nome, descrição, capacidades e canais.", fn=self._members, input_schema={"type": "object", "properties": {}}, parallel_safe=True, risk="read"),
                Tool(name="team_send", description="Envia uma mensagem a um membro (to=nome) ou a um canal (to=#canal): performativo (request, inform, propose, query, ...), conteúdo e conversa. Um request aceito vira compromisso.", fn=self._send, input_schema={"type": "object", "properties": {"to": {"type": "string"}, "performative": {"type": "string", "enum": list(PERFORMATIVES)}, "content": {"type": "string"}, "conversation": {"type": "string", "description": "id da conversa (resposta) ou vazio (nova)"}}, "required": ["to", "performative", "content"]}, risk="write"),
                Tool(name="team_ask", description="Pede a um membro que faça algo (request) numa conversa nova; a resposta (inform/failure) chega à sua caixa. Devolve o id da conversa.", fn=self._ask, input_schema={"type": "object", "properties": {"to": {"type": "string"}, "content": {"type": "string"}}, "required": ["to", "content"]}, risk="write"),
                Tool(name="team_cfp", description="Anuncia uma tarefa (Contract Net): os membros cujas capacidades casam `needs` propõem, o melhor recebe o pedido. Devolve quem ficou com ela.", fn=self._cfp, input_schema={"type": "object", "properties": {"needs": {"type": "array", "items": {"type": "string"}}, "content": {"type": "string"}}, "required": ["needs", "content"]}, risk="write"),
                Tool(name="team_inbox", description="Lê as mensagens novas da sua caixa (desde a última leitura).", fn=self._inbox, input_schema={"type": "object", "properties": {"limit": {"type": "integer"}}}, parallel_safe=True, risk="read"),
                Tool(name="team_artifacts", description="Lista os artefatos compartilhados da equipe (nome, versão, dono).", fn=self._artifacts, input_schema={"type": "object", "properties": {}}, parallel_safe=True, risk="read"),
                Tool(name="team_artifact_read", description="Lê um artefato compartilhado; devolve o conteúdo e a versão (use-a ao escrever).", fn=self._art_read, input_schema={"type": "object", "properties": {"name": {"type": "string"}}, "required": ["name"]}, parallel_safe=True, risk="read"),
                Tool(name="team_artifact_write", description="Escreve um artefato compartilhado. `version` é a que você leu (CAS): se outro escreveu antes, a escrita é recusada — leia de novo.", fn=self._art_write, input_schema={"type": "object", "properties": {"name": {"type": "string"}, "content": {"type": "string"}, "version": {"type": "integer", "description": "a versão lida; 0 para criar"}}, "required": ["name", "content"]}, risk="write"),
            ]
        )

    def _members(self) -> ToolResult:
        rows = [{"name": p.name, "description": p.description, "capabilities": list(p.capabilities), "channels": list(p.channels), "autonomy": self.rt.team.autonomy_of(p.name)} for p in self.rt.team.members.values()]
        return ToolResult(text=json.dumps(rows, ensure_ascii=False, indent=2), metadata={"count": len(rows)})

    def _send(self, to: str, performative: str, content: str, conversation: str = "") -> ToolResult:
        try:
            env = self.rt.send(self.me, to, performative, content, conversation=conversation)
        except (ValueError, PermissionError) as erro:
            return ToolResult.error(str(erro), code=403 if isinstance(erro, PermissionError) else 422)
        return ToolResult(text=f"enviada: {env.brief()}", metadata={"conversation": env.conversation, "seq": env.seq})

    def _ask(self, to: str, content: str) -> ToolResult:
        try:
            env = self.rt.send(self.me, to, "request", content)
        except (ValueError, PermissionError) as erro:
            return ToolResult.error(str(erro), code=403 if isinstance(erro, PermissionError) else 422)
        return ToolResult(text=f"pedido a {to} na conversa {env.conversation}; a resposta chega à sua caixa (team_inbox)", metadata={"conversation": env.conversation})

    def _cfp(self, needs: list[str], content: str) -> ToolResult:
        winner, bids = self.rt.cfp(self.me, needs, content)
        if winner is None:
            return ToolResult.error(f"ninguém propôs para {needs}: {bids}", code=404)
        return ToolResult(text=f"{winner} ficou com a tarefa (lances: {bids})", metadata={"winner": winner, "bids": bids})

    def _inbox(self, limit: int = 20) -> ToolResult:
        envs = self.rt.inbox(self.me, limit=limit)
        if not envs:
            return ToolResult(text="(nenhuma mensagem nova)", metadata={"count": 0})
        return ToolResult(text="\n".join(e.brief() for e in envs), metadata={"count": len(envs)})

    def _artifacts(self) -> ToolResult:
        rows = [a.to_dict() for a in self.rt.artifacts.list()]
        return ToolResult(text=json.dumps(rows, ensure_ascii=False, indent=2), metadata={"count": len(rows)})

    def _art_read(self, name: str) -> ToolResult:
        try:
            a = self.rt.artifacts.read(name)
        except ValueError as erro:
            return ToolResult.error(str(erro), code=422)
        if a is None:
            return ToolResult.error(f"artefato {name!r} não existe", code=404)
        return ToolResult(text=f"[versão {a.version}, de {a.owner}]\n{a.content}", metadata={"version": a.version})

    def _art_write(self, name: str, content: str, version: int = 0) -> ToolResult:
        try:
            a = self.rt.artifacts.write(name, content, owner=self.me, expected_version=version)
        except ArtifactConflict as erro:
            return ToolResult.error(str(erro), code=409)
        except ValueError as erro:
            return ToolResult.error(str(erro), code=422)
        return ToolResult(text=f"{name}: versão {a.version} gravada", metadata={"version": a.version})


class TeamRuntime:
    """A equipe viva: barramento, fila, compromissos e artefatos no mesmo arquivo; um handler por perfil."""

    def __init__(
        self,
        team: Team,
        provider_factory: Callable[[Profile], Provider],
        *,
        db: str | Path | None = None,
        workers: int = 4,
        trust_store: Any = None,
        evolve: bool = False,
        clock: Callable[[], float] = time.time,
        sleep: Callable[[float], None] = time.sleep,
        poll_s: float = 0.5,
        lease_s: float = 60.0,
    ) -> None:
        self.team = team
        self.provider_factory = provider_factory
        self.db = Path(db) if db is not None else team.db
        self.bus = Bus(self.db, clock=clock)
        self.commitments = Commitments(self.db, clock=clock)
        self.artifacts = Artifacts(team.shared_dir, db=self.db, team=team.name, bus=self.bus, clock=clock)
        self.trust_store = trust_store
        self.evolve = evolve
        self.ledger = Ledger(limit=team.budget)
        self.scheduler = Scheduler(
            SQLiteTaskStore(self.db),
            {"profile": self.handle},
            workers=workers,
            bus=self.bus,
            ledger=self.ledger,
            clock=clock,
            sleep=sleep,
            poll_s=poll_s,
            lease_s=lease_s,
        )
        self._clock = clock
        self._runners: dict[str, AgentRunner] = {}

    # ----------------------------------------------------------- ligar
    def start(self) -> None:
        """Registra os gatilhos: caixa de cada perfil, canais, e os fluxos fixos."""
        for name in self.team.members:
            auto = self.team.autonomy_of(name)
            if auto == "never":
                continue
            self.scheduler.on(
                f"inbox:{name}",
                inbox_subject(name),
                "profile",
                {"profile": name, "envelope": "{{data}}", "seq": "{{seq}}"},
                hold=(auto == "ask"),
                start="all",  # o que chegou antes de a equipe subir também conta
            )
        for ch, subs in self.team.channels.items():
            for name in subs:
                auto = self.team.autonomy_of(name)
                if auto == "never":
                    continue
                self.scheduler.on(
                    f"channel:{ch}:{name}",
                    channel_subject(self.team.name, ch),
                    "profile",
                    {"profile": name, "envelope": "{{data}}", "seq": "{{seq}}", "channel": ch},
                    hold=(auto == "ask"),
                    start="all",
                )
        for i, w in enumerate(self.team.workflows):
            on = w["on"]
            pattern = on
            if on.startswith("done:"):  # "done:<perfil>" é o atalho para o assunto de conclusão
                pattern = f"team.{self.team.name.replace('-', '_')}.done.{on[5:].replace('-', '_')}"
            # o molde do fluxo fala em {{outcome}}/{{profile}}/{{from}}; o gatilho os lê do dado da mensagem
            task = w["task"]
            for chave in ("outcome", "profile", "from", "conversation"):
                task = task.replace("{{" + chave + "}}", "{{data." + chave + "}}")
            self.scheduler.on(
                f"workflow:{i}",
                pattern,
                "profile",
                {"profile": w["to"], "task": task, "workflow": str(i), "envelope": "{{data}}"},
                hold=(self.team.autonomy_of(w["to"]) == "ask"),
                start="all",
            )

    def serve_forever(self) -> None:
        self.scheduler.serve_forever()

    def drain(self, **kw: Any) -> dict[str, Any]:
        return self.scheduler.drain(**kw)

    def approve(self, task_id: str) -> bool:
        return self.scheduler.approve(task_id)

    # ------------------------------------------------------- mensagens
    def send(self, sender: str, to: str, performative: str, content: str, *, conversation: str = "", data: dict[str, Any] | None = None) -> Envelope:
        if performative not in PERFORMATIVES:
            raise ValueError(f"performativo {performative!r} fora de {PERFORMATIVES}")
        target = to[1:] if to.startswith("#") else to
        if to.startswith("#"):
            if target not in self.team.channels:
                raise ValueError(f"canal desconhecido: {target!r}; canais: {sorted(self.team.channels)}")
        elif target not in self.team.members and target != "operator":
            raise ValueError(f"destinatário desconhecido: {target!r}; membros: {sorted(self.team.members)}")
        if performative == "request" and not to.startswith("#") and not self.team.may_request(sender, target):
            raise PermissionError(f"{sender} não pode pedir a {target} (roles)")
        env = Envelope(performative=performative, sender=sender, to=to, content=content, conversation=conversation or new_conversation(), data=dict(data or {}))
        msg = post(self.bus, env, team=self.team.name)
        return replace(env, at=msg.at, seq=msg.seq)

    def inbox(self, member: str, *, limit: int = 20) -> list[Envelope]:
        """Mensagens novas da caixa (consumidor durável por perfil: uma leitura, um avanço)."""
        sub = self.bus.subscribe(inbox_subject(member), name=f"inbox-read:{member}", start="all")
        msgs = sub.pull(limit)
        out = [e for e in (parse(m) for m in msgs) if e is not None]
        if msgs:
            sub.ack(msgs[-1].seq)
        return out

    def peek(self, member: str, *, after: int = 0, limit: int = 50) -> list[Envelope]:
        """Leitura sem estado da caixa (para o operador)."""
        return [e for e in (parse(m) for m in self.bus.read(inbox_subject(member), after=after, limit=limit)) if e is not None]

    def cfp(self, sender: str, needs: Sequence[str], content: str) -> tuple[str | None, dict[str, int]]:
        """Contract Net mecânico: anúncio, lances por capacidade declarada, adjudicação, pedido."""
        wanted = {n.lower() for n in needs}
        bids: dict[str, int] = {}
        for name, p in self.team.members.items():
            if name == sender or not self.team.may_request(sender, name):
                continue
            score = len(wanted & {c.lower() for c in p.capabilities})
            if score:
                bids[name] = score
        conv = new_conversation()
        if self.team.channels:  # o anúncio é público: fica no primeiro canal da equipe
            first = next(iter(self.team.channels))
            post(self.bus, Envelope("cfp", sender, f"#{first}", content, conversation=conv, data={"needs": list(needs), "bids": bids}), team=self.team.name)
        if not bids:
            return None, bids
        winner = max(sorted(bids), key=lambda n: bids[n])
        post(self.bus, Envelope("propose", winner, sender, f"posso: {bids[winner]} de {len(wanted)} capacidades", conversation=conv, data={"score": bids[winner]}), team=self.team.name)
        post(self.bus, Envelope("accept_proposal", sender, winner, "adjudicado", conversation=conv), team=self.team.name)
        self.send(sender, winner, "request", content, conversation=conv)
        return winner, bids

    # ---------------------------------------------------------- perfil
    def _runner(self, profile: Profile) -> AgentRunner:
        r = self._runners.get(profile.name)
        if r is None:
            r = AgentRunner({}, state_store=SQLiteStateStore(profile.journal_db))
            self._runners[profile.name] = r
        return r

    def build_agent(self, profile: Profile):
        provider = self.provider_factory(profile)
        tools = TeamToolset(self, profile.name)
        return profile.build(
            provider,
            extra=[tools],
            trust_store=self.trust_store,
            evolve=self.evolve,
            untrusted=lambda n: n in ("team_inbox", "team_artifact_read"),  # o que outros escreveram é de fora
        )

    def handle(self, ctx: TaskContext) -> Outcome | dict[str, Any]:
        """O handler da fila: acorda o perfil com a mensagem (ou a tarefa do fluxo) e cobra o desfecho."""
        payload = ctx.task.payload
        name = str(payload.get("profile") or "")
        profile = self.team.members.get(name)
        if profile is None:
            raise Permanent(f"perfil desconhecido na equipe: {name!r}")
        env_data = payload.get("envelope") or {}
        env = parse_like(env_data) if isinstance(env_data, dict) else None
        if env is not None and env.sender == name:
            return {"ignored": "própria mensagem"}
        if env is not None and env.performative in BOOKKEEPING:
            return {"ignored": f"reconhecimento ({env.performative}) fica na caixa, não acorda"}
        if payload.get("task"):  # fluxo fixo: o gatilho já preencheu o molde
            text = str(payload["task"])
            conversation = str(payload.get("conversation") or new_conversation())
            requester = "workflow"
        elif env is not None:
            conversation = env.conversation
            requester = env.sender
            if env.performative == "request":
                text = env.content
                self.commitments.open(conversation, requester, name, text)
                post(self.bus, Envelope("accept", name, requester, "aceito", conversation=conversation), team=self.team.name)
            else:
                text = (
                    f"Você recebeu de {env.sender} uma mensagem [{env.performative}]"
                    + (f" no canal #{payload['channel']}" if payload.get("channel") else "")
                    + f" (conversa {conversation}):\n\n{env.content}\n\n"
                    "Decida se e como agir. Responda com team_send na mesma conversa quando houver o que dizer; "
                    "se não houver nada a fazer, diga isso e termine."
                )
        else:
            raise Permanent("tarefa de perfil sem envelope nem task")
        agent = self.build_agent(profile)
        session = f"{name}:{conversation}"
        is_request = env is not None and env.performative == "request"

        def fail(reason: str) -> None:
            """O desfecho final negativo: fecha o compromisso e avisa quem pediu."""
            if is_request:
                self.commitments.close(conversation, "failed", reason)
                post(self.bus, Envelope("failure", name, requester, reason, conversation=conversation), team=self.team.name)

        try:
            outcome = run(agent, text, session=session, state_store=self._runner(profile).state_store, resume=ctx.attempt > 1)
        except Exception as erro:
            # StateConflict -> blocked (gente destrava; o compromisso segue aberto); o resto é falha final
            if type(erro).__name__ != "StateConflict":
                fail(f"{type(erro).__name__}: {erro}")
            raise
        if ctx.cancelled:
            fail("cancelada")
            raise Cancelled("cancelada")
        if outcome.error and outcome.stop_reason == "error":
            if ctx.task.tries < ctx.task.retry.max_attempts:
                raise Transient(outcome.error)  # a retomada fecha; o compromisso continua aberto
            fail(outcome.error)
            raise Transient(outcome.error)
        ok = outcome.ok and not outcome.stop_reason.startswith("budget:") and outcome.stop_reason != "refusal"
        if not ok:
            fail(outcome.error or outcome.stop_reason)
            raise Permanent(f"{outcome.stop_reason}: {outcome.error or 'o perfil parou antes de terminar'}")
        if is_request:
            self.commitments.close(conversation, "done", outcome.text)
            post(self.bus, Envelope("inform", name, requester, outcome.text, conversation=conversation, data={"done": True}), team=self.team.name)
        self.bus.publish(f"team.{self.team.name.replace('-', '_')}.done.{name.replace('-', '_')}", {"profile": name, "conversation": conversation, "outcome": outcome.text, "from": requester})
        return outcome

    def report(self) -> dict[str, Any]:
        return {
            "team": self.team.name,
            "members": list(self.team.members),
            "tasks": self.scheduler.report()["counts"],
            "commitments": self.commitments.counts(),
            "artifacts": [a.to_dict() for a in self.artifacts.list()],
            "ledger": self.ledger.to_dict(),
        }

    def close(self) -> None:
        self.commitments.close_all()
        self.artifacts.close()
        self.bus.close()


def parse_like(d: dict[str, Any]) -> Envelope | None:
    """Envelope a partir do dict gravado na tarefa (o `data` da mensagem)."""
    if "performative" not in d or "from" not in d:
        return None
    try:
        return Envelope(
            performative=str(d["performative"]),
            sender=str(d["from"]),
            to=str(d.get("to") or ""),
            content=str(d.get("content") or ""),
            conversation=str(d.get("conversation") or ""),
            reply_to=str(d.get("reply_to") or ""),
            data=dict(d.get("data") or {}),
        )
    except ValueError:
        return None

