"""O perfil: o que um agente é quando não está rodando.

    agentes/revisor/
      AGENT.md      front-matter + corpo (a instrução, salvo `instruction:` apontar para um .md)
      memory.db     as categorias de memória deste perfil
      journal.db    o journal do laço deste perfil
      plugins/      o que este perfil pode (e o que o Evolve dele criou)
      notas/        artefatos individuais

Front-matter (tudo opcional exceto `description`):

    name, version, description
    model, effort                 o provedor é montado por quem instancia
    instruction: caminho.md       senão, o corpo do AGENT.md é a instrução
    skills: [dir, ...]            plugins: [dir, ...]   (mais `plugins/` do perfil, sempre)
    memory: [episodic, semantic, buffer]
    budget: {max_turns, max_cost_usd, max_wall_s}
    policy: {deny_at, taint}      taint=true: o que vem de plugin não confiável ou de outro perfil contamina
    workspace: dir                bash/editor/busca confinados ali
    capabilities: [tag, ...]      para o anúncio (Contract Net)
    channels: [nome, ...]         canais da equipe que este perfil assina
    autonomy: auto | ask | never  ao receber mensagem: age, espera aprovação, ou só guarda

Persona não é capacidade (Zheng et al., 2023): o que muda o comportamento
está nas linhas acima, e é isso que o perfil guarda. O `Agent` é o perfil
instanciado; o perfil tem digest, como a instrução e o plugin.
"""

from __future__ import annotations

import hashlib
import re
from collections.abc import Callable, Sequence
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

from ..budget import Budget
from ..instruction import Instruction, load_instruction, parse_front_matter
from ..loop import Agent
from ..memory.bridge import MemoryBridge, NullMemory
from ..models.provider import Provider
from ..policy import AllowAll, Chain, DenyRisk, Policy, Taint
from ..skills import SkillLibrary, load_skills
from ..tools import RISK_LEVELS, Composite, Registry, Toolset
from ..workbench import Workbench

__all__ = ["AUTONOMY", "Profile", "ProfileError", "load_profile", "load_profiles"]

AUTONOMY: tuple[str, ...] = ("auto", "ask", "never")
_NAME = re.compile(r"^[a-z][a-z0-9_-]{0,63}$")


class ProfileError(ValueError):
    """Diretório que não é um perfil, ou perfil malformado."""


def _list(v: Any) -> list[str]:
    if v is None:
        return []
    if isinstance(v, str):
        return [x.strip() for x in v.strip("[]").split(",") if x.strip()]
    return [str(x) for x in v]


def _mapping(v: Any) -> dict[str, Any]:
    """`{a: 1, b: x}` no front-matter simples vira dict; dict já vem dict."""
    if isinstance(v, dict):
        return dict(v)
    if not v:
        return {}
    s = str(v).strip().strip("{}")
    out: dict[str, Any] = {}
    for part in s.split(","):
        if ":" in part:
            k, _, val = part.partition(":")
            val = val.strip()
            try:
                out[k.strip()] = int(val) if re.fullmatch(r"-?\d+", val) else float(val) if re.fullmatch(r"-?\d+\.\d+", val) else val
            except ValueError:
                out[k.strip()] = val
    return out


@dataclass(slots=True)
class Profile:
    name: str
    description: str
    path: str
    version: str = "0.1.0"
    model: str = ""
    effort: str = ""
    instruction: str = ""  # corpo (inline) — ou vazio quando `instruction_path`
    instruction_path: str = ""
    skills: tuple[str, ...] = ()
    plugins: tuple[str, ...] = ()
    memory: tuple[str, ...] = ("episodic", "semantic", "buffer")
    budget: Budget = field(default_factory=Budget)
    deny_at: str = ""
    taint: bool = True
    workspace: str = ""
    capabilities: tuple[str, ...] = ()
    channels: tuple[str, ...] = ()
    autonomy: str = "ask"
    digest: str = ""
    meta: dict[str, Any] = field(default_factory=dict)

    # ------------------------------------------------------------ caminhos
    @property
    def dir(self) -> Path:
        return Path(self.path)

    @property
    def memory_db(self) -> Path:
        return self.dir / "memory.db"

    @property
    def journal_db(self) -> Path:
        return self.dir / "journal.db"

    @property
    def plugins_dir(self) -> Path:
        return self.dir / "plugins"

    @property
    def notes_dir(self) -> Path:
        return self.dir / "notas"

    def summary(self) -> dict[str, Any]:
        return {
            "name": self.name,
            "version": self.version,
            "description": self.description,
            "path": self.path,
            "model": self.model,
            "effort": self.effort,
            "instruction": self.instruction_path or "(inline)",
            "skills": list(self.skills),
            "plugins": list(self.plugins),
            "memory": list(self.memory),
            "budget": {"max_turns": self.budget.max_turns, "max_cost_usd": self.budget.max_cost_usd, "max_wall_s": self.budget.max_wall_s},
            "deny_at": self.deny_at,
            "taint": self.taint,
            "workspace": self.workspace,
            "capabilities": list(self.capabilities),
            "channels": list(self.channels),
            "autonomy": self.autonomy,
            "digest": self.digest[:12],
        }

    # ------------------------------------------------------------ montagem
    def resolved_instruction(self) -> Instruction:
        if self.instruction_path:
            return load_instruction(self.instruction_path)
        body = self.instruction or f"Você é {self.name}: {self.description}"
        return Instruction.from_text(f"---\nname: {self.name}\nversion: {self.version}\n---\n{body}", name=self.name, path=str(self.dir / "AGENT.md"))

    def memory_port(self) -> MemoryBridge:
        from ..memory.cli import open_memory

        systems = [open_memory(kind, db=str(self.memory_db)) for kind in self.memory]
        return MemoryBridge(systems, agent_id=self.name)

    def build(
        self,
        provider: Provider,
        *,
        extra: Sequence[Toolset] = (),
        trust_store: Any = None,
        evolve: bool = False,
        mcp_factory: Any = None,
        untrusted: Callable[[str], bool] | None = None,
    ) -> Agent:
        """O `Agent` deste perfil: instrução, skills, plugins, memória, orçamento, política."""
        from ..plugins import Evolve, attach, floor_for, load_plugins, resolve

        instruction = self.resolved_instruction()
        skills = load_skills([str(self.dir / s) if not Path(s).is_absolute() else s for s in self.skills]) if self.skills else []
        ws = Path(self.workspace) if self.workspace else None
        if ws is not None and not ws.is_absolute():
            ws = (self.dir / ws).resolve()
        sets: list[Toolset] = [Workbench(ws)] if ws else []
        sets.extend(extra)
        toolset: Toolset = sets[0] if len(sets) == 1 else Composite(*sets) if sets else Registry()
        agent = Agent(
            provider=provider,
            instruction=instruction,
            name=self.name,
            toolset=toolset,
            memory=self.memory_port() if self.memory else NullMemory(),
            skills=SkillLibrary(skills) if skills else None,
            budget=self.budget,
            workspace=ws,
        )
        paths = [str(self.dir / p) if not Path(p).is_absolute() else p for p in self.plugins]
        if self.plugins_dir.is_dir() and any((sub / "PLUGIN.md").is_file() for sub in self.plugins_dir.iterdir()):
            paths.append(str(self.plugins_dir))
        plugins = load_plugins(paths) if paths else []
        ev = Evolve(self.plugins_dir, store=trust_store) if evolve else None
        if plugins or ev is not None:
            agent = attach(agent, plugins, store=trust_store, mcp_factory=mcp_factory, evolve=ev)
        # política: negar por risco + contaminação por fonte não confiável
        policies: list[Policy] = []
        if self.deny_at:
            policies.append(DenyRisk(at_or_above=self.deny_at))
        if self.taint:
            suspeitos: set[str] = set()
            for pl in plugins:
                state, _ = resolve(pl, trust_store)
                if floor_for(state, pl.risk) != pl.risk or state != "trusted":
                    suspeitos.add(pl.prefix)

            def desconfia(name: str, _s: set[str] = suspeitos, _u: Callable[[str], bool] | None = untrusted) -> bool:
                if _u is not None and _u(name):
                    return True
                return any(name.startswith(p + "_") for p in _s)

            policies.append(Taint(match=desconfia, at_or_above="write"))
        agent.policy = Chain(policies) if policies else AllowAll()
        return agent


def load_profile(directory: str | Path) -> Profile:
    d = Path(directory).resolve()
    md = d / "AGENT.md"
    if not md.is_file():
        raise ProfileError(f"não é um perfil (sem AGENT.md): {d}")
    text = md.read_text(encoding="utf-8")
    meta, body = parse_front_matter(text)
    name = str(meta.get("name") or d.name)
    if not _NAME.match(name):
        raise ProfileError(f"nome de perfil inválido: {name!r}")
    description = str(meta.get("description") or "").strip()
    if not description:
        raise ProfileError(f"perfil {name!r} sem `description`: existe e ninguém sabe para quê")
    budget_raw = _mapping(meta.get("budget"))
    policy_raw = _mapping(meta.get("policy"))
    deny_at = str(policy_raw.get("deny_at") or meta.get("deny_at") or "")
    if deny_at and deny_at not in RISK_LEVELS:
        raise ProfileError(f"perfil {name!r}: deny_at {deny_at!r} fora de {RISK_LEVELS}")
    autonomy = str(meta.get("autonomy") or "ask")
    if autonomy not in AUTONOMY:
        raise ProfileError(f"perfil {name!r}: autonomy {autonomy!r} fora de {AUTONOMY}")
    instr = str(meta.get("instruction") or "")
    instr_path = ""
    if instr:
        p = Path(instr)
        instr_path = str(p if p.is_absolute() else (d / p).resolve())
        if not Path(instr_path).is_file():
            raise ProfileError(f"perfil {name!r}: instruction não existe: {instr_path}")
    taint_raw = policy_raw.get("taint", meta.get("taint", True))
    taint = str(taint_raw).lower() not in ("false", "0", "no", "não")
    return Profile(
        name=name,
        description=description,
        path=str(d),
        version=str(meta.get("version") or "0.1.0"),
        model=str(meta.get("model") or ""),
        effort=str(meta.get("effort") or ""),
        instruction=body.strip() if not instr_path else "",
        instruction_path=instr_path,
        skills=tuple(_list(meta.get("skills"))),
        plugins=tuple(_list(meta.get("plugins"))),
        memory=tuple(_list(meta.get("memory"))) if meta.get("memory") is not None else ("episodic", "semantic", "buffer"),
        budget=Budget(
            max_turns=int(budget_raw.get("max_turns", 60)),
            max_cost_usd=(float(budget_raw["max_cost_usd"]) if budget_raw.get("max_cost_usd") is not None else None),
            max_wall_s=(float(budget_raw["max_wall_s"]) if budget_raw.get("max_wall_s") is not None else None),
        ),
        deny_at=deny_at,
        taint=taint,
        workspace=str(meta.get("workspace") or ""),
        capabilities=tuple(_list(meta.get("capabilities"))),
        channels=tuple(_list(meta.get("channels"))),
        autonomy=autonomy,
        digest=hashlib.sha256(text.encode("utf-8")).hexdigest(),
        meta=dict(meta),
    )


def load_profiles(paths: Sequence[str | Path]) -> list[Profile]:
    """Cada caminho é um perfil ou um diretório *de* perfis (subpastas com AGENT.md)."""
    out: list[Profile] = []
    seen: set[str] = set()
    for p in paths:
        base = Path(p)
        if (base / "AGENT.md").is_file():
            cands = [base]
        elif base.is_dir():
            cands = [sub for sub in sorted(base.iterdir()) if (sub / "AGENT.md").is_file()]
        else:
            raise ProfileError(f"diretório de perfis não existe: {base}")
        for c in cands:
            pr = load_profile(c)
            if pr.name in seen:
                raise ProfileError(f"perfil {pr.name!r} carregado duas vezes")
            seen.add(pr.name)
            out.append(pr)
    return out
