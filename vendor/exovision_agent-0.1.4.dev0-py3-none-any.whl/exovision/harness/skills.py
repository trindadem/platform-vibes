"""Skills: índice no prompt, procedimento sob demanda.

Uma skill é um diretório com `SKILL.md`. Vinte skills coladas na instrução são
vinte procedimentos que o modelo lê para usar um: o que entra no system prompt
é só o **índice** — nome e descrição — e o corpo chega pela ferramenta `skill`
quando o modelo pede. Arquivos vizinhos entram como **caminho**, não como
conteúdo: o modelo tem bash e editor, e ler anexo que não vai usar é o gasto
que a divulgação progressiva existe para evitar.

Skill sem `description` é recusada no carregamento — sem ela a skill existe e
nunca é escolhida. Skill declarada e ausente do disco derruba a montagem,
porque rodar sem uma capacidade pedida é rodar outro agente.
"""

from __future__ import annotations

from collections.abc import Iterable
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

from .instruction import InstructionError, parse_front_matter
from .tools import Tool, ToolResult

__all__ = ["Skill", "SkillError", "SkillLibrary", "load_skill", "load_skills"]


class SkillError(InstructionError):
    """Skill malformada ou ausente."""


@dataclass(frozen=True, slots=True)
class Skill:
    name: str
    description: str
    body: str
    path: str
    files: tuple[str, ...] = ()
    meta: dict[str, Any] = field(default_factory=dict)

    def render(self) -> str:
        out = [f"# skill: {self.name}", "", self.body.strip()]
        if self.files:
            out += ["", "Arquivos desta skill (caminhos absolutos):"] + [
                f"- {f}" for f in self.files
            ]
        return "\n".join(out)


def load_skill(directory: str | Path) -> Skill:
    d = Path(directory)
    md = d / "SKILL.md"
    if not md.is_file():
        raise SkillError(f"skill sem SKILL.md: {d}")
    meta, body = parse_front_matter(md.read_text(encoding="utf-8"))
    name = str(meta.get("name") or d.name)
    desc = str(meta.get("description") or "").strip()
    if not desc:
        raise SkillError(f"skill {name!r} sem `description`: existe e nunca é escolhida")
    files = tuple(sorted(str(p.resolve()) for p in d.rglob("*") if p.is_file() and p != md))
    return Skill(
        name=name,
        description=desc,
        body=body.strip(),
        path=str(d.resolve()),
        files=files,
        meta=meta,
    )


def load_skills(dirs: Iterable[str | Path]) -> list[Skill]:
    """Cada diretório é uma skill, ou um diretório *de* skills (subpastas com SKILL.md)."""
    out: list[Skill] = []
    for d in dirs:
        base = Path(d)
        if (base / "SKILL.md").is_file():
            out.append(load_skill(base))
            continue
        if not base.is_dir():
            raise SkillError(f"diretório de skills não existe: {base}")
        for sub in sorted(base.iterdir()):
            if (sub / "SKILL.md").is_file():
                out.append(load_skill(sub))
    return out


class SkillLibrary:
    """O índice (para o prompt) e a ferramenta `skill` (para o corpo)."""

    def __init__(self, skills: Iterable[Skill] = ()) -> None:
        self._skills: dict[str, Skill] = {}
        for s in skills:
            if s.name in self._skills:
                raise SkillError(f"skill {s.name!r} carregada duas vezes")
            self._skills[s.name] = s

    def __len__(self) -> int:
        return len(self._skills)

    def __contains__(self, name: str) -> bool:
        return name in self._skills

    def names(self) -> list[str]:
        return list(self._skills)

    def get(self, name: str) -> Skill | None:
        return self._skills.get(name)

    def require(self, names: Iterable[str]) -> None:
        missing = [n for n in names if n not in self._skills]
        if missing:
            raise SkillError(f"skills declaradas e ausentes: {missing}")

    def index(self) -> str:
        if not self._skills:
            return ""
        lines = ["Skills disponíveis (peça o procedimento com a ferramenta `skill`):"]
        lines += [f"- {s.name}: {s.description}" for s in self._skills.values()]
        return "\n".join(lines)

    def tool(self) -> Tool:
        lib = self

        def skill(name: str) -> ToolResult:
            s = lib.get(name)
            if s is None:
                return ToolResult.error(
                    f"skill desconhecida: {name!r}. Disponíveis: {', '.join(lib.names())}", code=404
                )
            return ToolResult(text=s.render(), metadata={"skill": name})

        return Tool(
            name="skill",
            description="Carrega o procedimento completo de uma skill listada no índice. Use antes de executar uma tarefa que a skill cobre.",
            fn=skill,
            input_schema={
                "type": "object",
                "properties": {"name": {"type": "string", "description": "nome da skill"}},
                "required": ["name"],
            },
            parallel_safe=True,
            risk="read",
        )
