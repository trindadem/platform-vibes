"""Governança de ações: quem decide se uma ferramenta roda, e com que argumentos.

O modelo emite pedidos; o harness decide. O modelo não conhece a fronteira de
segurança da aplicação, a política de aprovação nem a superfície de UX — e não
deve conhecer: essa decisão mora aqui, num ponto único, e cada decisão passa
pela costura `policy.decision` (auditável, comparável entre execuções).

Uma recusa **volta para o modelo como resultado de ferramenta** (`is_error`),
nunca como exceção: o modelo precisa saber que foi recusado para escolher outro
caminho. O que derruba o laço é falha de infraestrutura, não de política.

A composição é uma cadeia: a primeira política que nega, nega; argumentos
transformados por uma passam à seguinte. `AllowAll` é o padrão explícito —
não existe "sem política", existe uma política que permite tudo.
"""

from __future__ import annotations

from collections.abc import Callable, Iterable
from dataclasses import dataclass, field
from typing import Any, Protocol, runtime_checkable

from .tools import RISK_LEVELS, ToolCall, ToolResult

__all__ = [
    "AllowAll",
    "Allowlist",
    "Ask",
    "Chain",
    "Decision",
    "DenyRisk",
    "Policy",
    "RedactResults",
    "Taint",
]


@dataclass(frozen=True, slots=True)
class Decision:
    allow: bool
    reason: str = ""
    #: argumentos possivelmente transformados (ex.: caminho normalizado).
    arguments: dict[str, Any] | None = None
    policy: str = ""

    @classmethod
    def ok(
        cls, reason: str = "", *, arguments: dict[str, Any] | None = None, policy: str = ""
    ) -> Decision:
        return cls(True, reason, arguments, policy)

    @classmethod
    def deny(cls, reason: str, *, policy: str = "") -> Decision:
        return cls(False, reason, None, policy)

    def to_result(self) -> ToolResult:
        return ToolResult.error(
            f"recusado pela política ({self.policy or 'policy'}): {self.reason}",
            code=403,
            policy=self.policy,
        )


@runtime_checkable
class Policy(Protocol):
    name: str

    def before_tool(self, call: ToolCall, risk: str) -> Decision: ...

    def after_tool(self, call: ToolCall, result: ToolResult) -> ToolResult: ...


class _Base:
    name = "policy"

    def before_tool(self, call: ToolCall, risk: str) -> Decision:
        return Decision.ok(policy=self.name)

    def after_tool(self, call: ToolCall, result: ToolResult) -> ToolResult:
        return result


class AllowAll(_Base):
    name = "allow_all"


class DenyRisk(_Base):
    """Nega ferramentas cujo risco esteja no conjunto (ou acima do limiar)."""

    name = "deny_risk"

    def __init__(self, *, at_or_above: str | None = None, levels: Iterable[str] = ()) -> None:
        denied = set(levels)
        if at_or_above is not None:
            if at_or_above not in RISK_LEVELS:
                raise ValueError(f"risco {at_or_above!r} fora de {RISK_LEVELS}")
            denied |= set(RISK_LEVELS[RISK_LEVELS.index(at_or_above) :])
        self.denied = frozenset(denied)

    def before_tool(self, call: ToolCall, risk: str) -> Decision:
        if risk in self.denied:
            return Decision.deny(
                f"{call.name} tem risco {risk!r}, fora do permitido nesta sessão", policy=self.name
            )
        return Decision.ok(policy=self.name)


class Allowlist(_Base):
    """Só as ferramentas nomeadas rodam."""

    name = "allowlist"

    def __init__(self, names: Iterable[str]) -> None:
        self.names = frozenset(names)

    def before_tool(self, call: ToolCall, risk: str) -> Decision:
        if call.name not in self.names:
            return Decision.deny(
                f"{call.name} não está na allowlist {sorted(self.names)}", policy=self.name
            )
        return Decision.ok(policy=self.name)


class Ask(_Base):
    """Portão humano: chama `prompt(call, risk) -> bool` para ações a partir de um risco.

    O callback é da aplicação (terminal, UI, fila de aprovação). Aqui só se
    garante que o portão existe e que a decisão fica no traço.
    """

    name = "ask"

    def __init__(
        self, prompt: Callable[[ToolCall, str], bool], *, at_or_above: str = "external"
    ) -> None:
        if at_or_above not in RISK_LEVELS:
            raise ValueError(f"risco {at_or_above!r} fora de {RISK_LEVELS}")
        self.prompt = prompt
        self.gated = frozenset(RISK_LEVELS[RISK_LEVELS.index(at_or_above) :])

    def before_tool(self, call: ToolCall, risk: str) -> Decision:
        if risk not in self.gated:
            return Decision.ok(policy=self.name)
        try:
            approved = bool(self.prompt(call, risk))
        except Exception as erro:
            return Decision.deny(f"portão humano falhou: {erro}", policy=self.name)
        if approved:
            return Decision.ok("aprovado pelo operador", policy=self.name)
        return Decision.deny("o operador não aprovou esta ação", policy=self.name)


class Taint(_Base):
    """Fluxo de informação: dado não confiável não autoriza ação privilegiada.

    Injeção indireta chega pelo *resultado* de uma ferramenta (Greshake et al.,
    2023) e o modelo obedece — 24 a 47% das vezes com GPT-4 (InjecAgent). A
    defesa que funciona por desenho é a do CaMeL (Debenedetti et al., 2025):
    o que veio de fonte não confiável não pode decidir uma chamada de maior
    privilégio. Aqui, simplificado e auditável: depois que uma ferramenta de
    `sources` devolve algo, a sessão fica *contaminada*, e toda chamada a
    partir de `at_or_above` é negada (ou passa pelo portão `prompt`, se
    houver) até `clear()`. `sources` é normalmente o conjunto de tools de
    plugins em draft/verified e de servidores MCP de terceiros.
    """

    name = "taint"

    def __init__(
        self,
        sources: Iterable[str] = (),
        *,
        at_or_above: str = "write",
        prompt: Callable[[ToolCall, str], bool] | None = None,
        match: Callable[[str], bool] | None = None,
    ) -> None:
        if at_or_above not in RISK_LEVELS:
            raise ValueError(f"risco {at_or_above!r} fora de {RISK_LEVELS}")
        self.sources = frozenset(sources)
        self.match = match
        self.gated = frozenset(RISK_LEVELS[RISK_LEVELS.index(at_or_above) :])
        self.prompt = prompt
        self.tainted_by: list[str] = []

    @property
    def tainted(self) -> bool:
        return bool(self.tainted_by)

    def clear(self) -> None:
        self.tainted_by = []

    def _untrusted(self, name: str) -> bool:
        return name in self.sources or (self.match is not None and bool(self.match(name)))

    def before_tool(self, call: ToolCall, risk: str) -> Decision:
        if not self.tainted or risk not in self.gated:
            return Decision.ok(policy=self.name)
        origem = ", ".join(self.tainted_by[-3:])
        if self.prompt is not None:
            try:
                if bool(self.prompt(call, risk)):
                    return Decision.ok("aprovado pelo operador (sessão contaminada)", policy=self.name)
            except Exception as erro:
                return Decision.deny(f"portão humano falhou: {erro}", policy=self.name)
        return Decision.deny(
            f"sessão contaminada por dado não confiável ({origem}): ação de risco {risk} "
            "não pode ser decidida a partir dele",
            policy=self.name,
        )

    def after_tool(self, call: ToolCall, result: ToolResult) -> ToolResult:
        if self._untrusted(call.name) and call.name not in self.tainted_by:
            self.tainted_by.append(call.name)
        return result


class RedactResults(_Base):
    """Mascara segredos no texto que volta para o modelo (chaves, tokens)."""

    name = "redact"

    def __init__(self, patterns: Iterable[str] = ()) -> None:
        import re

        default = (
            r"sk-ant-[A-Za-z0-9_\-]{8,}",
            r"(?i)(api[_-]?key|token|secret|password)\s*[=:]\s*['\"]?[A-Za-z0-9_\-\.]{8,}",
            r"AKIA[0-9A-Z]{16}",
        )
        self._rx = [re.compile(p) for p in (*default, *patterns)]

    def redact_text(self, text: str) -> tuple[str, int]:
        """(texto mascarado, ocorrências). Também usado pela destilação de traços."""
        hits = 0
        for rx in self._rx:
            text, n = rx.subn("[REDIGIDO]", text)
            hits += n
        return text, hits

    def after_tool(self, call: ToolCall, result: ToolResult) -> ToolResult:
        text, hits = self.redact_text(result.text)
        if not hits:
            return result
        return ToolResult(
            text=text,
            ok=result.ok,
            code=result.code,
            metadata={**result.metadata, "redacted": hits},
            blocks=result.blocks,
        )


@dataclass
class Chain:
    """Cadeia de políticas: a primeira que nega, nega; `after_tool` em ordem."""

    policies: list[Policy] = field(default_factory=list)
    name: str = "chain"

    def before_tool(self, call: ToolCall, risk: str) -> Decision:
        args = call.arguments
        for p in self.policies:
            d = p.before_tool(ToolCall(call.id, call.name, args), risk)
            if not d.allow:
                return d
            if d.arguments is not None:
                args = d.arguments
        return Decision.ok(policy=self.name, arguments=None if args is call.arguments else args)

    def after_tool(self, call: ToolCall, result: ToolResult) -> ToolResult:
        for p in self.policies:
            result = p.after_tool(call, result)
        return result
