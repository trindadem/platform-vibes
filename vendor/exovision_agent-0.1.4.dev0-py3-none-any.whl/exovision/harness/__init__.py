"""EXOVISION-I · harness — o kernel agêntico e os módulos que o compõem.

Um agente é um `Agent`: provedor de modelo, instrução (documento), ferramentaria,
política de governança, porta de memória, skills, orçamento e workspace. `run`
executa uma tarefa e devolve um `Outcome`; tudo o que aconteceu passou pelas
costuras (`Seams`) e está no traço.

    from exovision.harness import Agent, run, AnthropicProvider, Workbench
    agent = Agent(provider=AnthropicProvider(), instruction=load_instruction("revisor.md"),
                  toolset=Workbench("."), workspace=".")
    outcome = run(agent, "conserte o teste que falha", session="pr-42")

Módulos:
    seams        — conjunto fechado de costuras e o traço
    models       — o subsistema que toca o modelo: o driver Anthropic (provider) e os
                   drivers OpenAI/compatível/local/Google em stdlib (drivers, wire),
                   catálogo, primitivas (ask/extract/classify/judge/rank), cassete
                   (gravar uma vez, reexecutar por digest), balde de fichas compartilhado
                   e disjuntor, livro-razão, janela (compactação simples, auditoria de
                   prefixo), roteador — decorre de docs/modelos-estudo.md
    tools        — Tool, ToolResult, @tool, Registry, Composite
    workbench    — bash, editor e busca dentro de um workspace
    instruction  — documentos .md com front-matter e digest; Library
    skills       — SKILL.md: índice no prompt, corpo sob demanda
    policy       — governança de ações (Decision, Chain, Ask, DenyRisk, Taint, ...)
    budget       — Budget/Meter: voltas, tokens, custo, tempo
    session      — estado durável e retomável (SQLite)
    bus          — barramento embarcado (SQLite): assuntos NATS-compatíveis com
                   curingas, consumidores duráveis, retenção; `attach(seams)` põe
                   o traço nele; `BusToolset` deixa agentes conversarem
    context      — montagem do system e da primeira mensagem
    loop         — Agent, Outcome, run
    mcp          — MCP completo: ferramentas, recursos, prompts, tarefas, e o que
                   o servidor pede de volta (sampling, elicitation, roots)
    subagents    — delegação por ferramenta (Subagents): janela própria, orçamento comum, traço único
    batch        — Message Batches API, rollouts repetidos e leis de escala
    specialize   — especialização profunda: a expertise como diretório (regras
                   com votos, exemplos por kNN, glossário, corpus, ferramentas em
                   allowlist), compilada em Agent, medida numa suíte com holdout,
                   evoluída por reflexão e destilada em dados
    memory       — memória de agente de nível laboratorial: 21 categorias com a
                   mesma interface (write/read/consolidate/forget/stats), registro
                   bi-temporal, conflito simbólico, fusão RRF, orçamento; e a
                   ponte (`memory/bridge.py`): `MemoryPort`, a porta pela qual o
                   laço a alcança — `MemoryBridge` sobre qualquer conjunto de
                   subsistemas, `NullMemory` como padrão explícito
    rag          — recuperação aumentada: segmentação, embeddings, índices,
                   esparso e fusão, reranking, consulta, quatro RAG sobre grafo,
                   laços, e a entrada no laço (RAGToolset, RAGMemoryPort)
    tasks        — tarefas paralelas, simultâneas, duráveis e resilientes: fila
                   em SQLite com claim atômico, lease com fencing, backoff com
                   jitter determinístico, DAG com cancelamento em cascata,
                   `blocked` para efeito ambíguo; a tarefa de agente retoma o
                   journal do laço em vez de repetir (AgentRunner); agendas
                   (intervalo e cron) e gatilhos (mensagem -> tarefa) no mesmo
                   arquivo — tudo embarcado, sem serviço a instalar

    plugins      — tools em três níveis (função, manifesto, MCP), plugin como
                   diretório, confiança draft/verified/trusted por verificação,
                   fingerprint por componente, Evolve (o agente cria; a suíte
                   promove) — decorre de docs/plugins-estudo.md

    agents       — perfis duráveis (AGENT.md -> Agent) e equipes fixas (TEAM.md):
                   mensagens FIPA no barramento, compromissos cobrados pelo
                   harness, Contract Net, canais que acordam, artefatos com CAS,
                   um ator por perfil — decorre de docs/equipes-estudo.md

`rag`, `specialize`, `tasks`, `plugins` e `agents` carregam sob demanda (`import exovision.harness.rag`);
de `models`, `import exovision.harness` puxa o pacote inteiro (é stdlib e pequeno) e reexporta o driver;
de `memory`, `import exovision.harness` puxa só `bridge` e `core/` — as categorias
em `memory/systems` carregam quando você as importa. O resto está neste namespace.
(`exovision.harness.Task` é a tarefa **MCP**; a da fila é `exovision.harness.tasks.Task`.)
"""

from __future__ import annotations

from .batch import (
    BATCH_DISCOUNT,
    AnthropicBatchBackend,
    BatchBackend,
    BatchError,
    BatchItem,
    BatchProvider,
    BatchResult,
    Rollouts,
    ScriptedBatchBackend,
    coverage_curve,
    fit_coverage_law,
    majority_vote,
    pass_at_k,
    predict_coverage,
    rollouts,
    submit_and_wait,
)
from .budget import MAX_TURNS, Budget, Meter
from .bus import Bus, BusToolset
from .context import assemble_system, assemble_task
from .instruction import Instruction, InstructionError, Library, load_instruction
from .loop import Agent, Outcome, run
from .mcp import (
    PROTOCOL_VERSION,
    CallbackElicitor,
    Elicitation,
    LoopbackTransport,
    MCPClient,
    MCPDenied,
    MCPError,
    MCPIntegrityError,
    MCPTool,
    MCPToolset,
    Prompt,
    PromptLibrary,
    PromptMessage,
    ProviderSampler,
    Resource,
    ResourceContent,
    ResourceTemplate,
    ResourceToolset,
    Root,
    SamplingBudget,
    StaticRoots,
    StdioTransport,
    StreamableHTTPTransport,
    Task,
    conceal_scan,
    fingerprint,
    looks_like_secret,
    prompt_as_instruction,
    resources_as_context,
    sanitize,
    validate_form,
    watch_resources,
)
from .memory.bridge import MemoryBridge, MemoryPort, NullMemory, Recall
from .models.provider import (
    AnthropicProvider,
    Provider,
    ProviderError,
    Reply,
    Request,
    ScriptedProvider,
    ToolUse,
    estimate_cost_usd,
)
from .policy import (
    AllowAll,
    Allowlist,
    Ask,
    Chain,
    Decision,
    DenyRisk,
    Policy,
    RedactResults,
    Taint,
)
from .seams import SEAMS, Event, SeamError, Seams
from .session import InMemoryStateStore, SessionState, SQLiteStateStore, StateConflict, StateStore
from .skills import Skill, SkillError, SkillLibrary, load_skill, load_skills
from .subagents import (
    Delegation,
    Ledger,
    Subagent,
    Subagents,
    budget_for_depth,
    derived_risk,
    fanout,
)
from .tools import (
    Composite,
    Registry,
    Tool,
    ToolAssemblyError,
    ToolCall,
    ToolResult,
    Toolset,
    anthropic_defined,
    tool,
)
from .workbench import Workbench

__all__ = [
    "BATCH_DISCOUNT",
    "MAX_TURNS",
    "PROTOCOL_VERSION",
    "SEAMS",
    "Agent",
    "AllowAll",
    "Allowlist",
    "AnthropicBatchBackend",
    "AnthropicProvider",
    "Ask",
    "BatchBackend",
    "BatchError",
    "BatchItem",
    "BatchProvider",
    "BatchResult",
    "Budget",
    "Bus",
    "BusToolset",
    "CallbackElicitor",
    "Chain",
    "Composite",
    "Decision",
    "Delegation",
    "DenyRisk",
    "Elicitation",
    "Event",
    "InMemoryStateStore",
    "Instruction",
    "InstructionError",
    "Ledger",
    "Library",
    "LoopbackTransport",
    "MCPClient",
    "MCPDenied",
    "MCPError",
    "MCPIntegrityError",
    "MCPTool",
    "MCPToolset",
    "MemoryBridge",
    "MemoryPort",
    "Meter",
    "NullMemory",
    "Outcome",
    "Policy",
    "Prompt",
    "PromptLibrary",
    "PromptMessage",
    "Provider",
    "ProviderError",
    "ProviderSampler",
    "Recall",
    "RedactResults",
    "Registry",
    "Reply",
    "Request",
    "Resource",
    "ResourceContent",
    "ResourceTemplate",
    "ResourceToolset",
    "Rollouts",
    "Root",
    "SQLiteStateStore",
    "SamplingBudget",
    "ScriptedBatchBackend",
    "ScriptedProvider",
    "SeamError",
    "Seams",
    "SessionState",
    "Skill",
    "SkillError",
    "SkillLibrary",
    "StateConflict",
    "StateStore",
    "StaticRoots",
    "StdioTransport",
    "StreamableHTTPTransport",
    "Subagent",
    "Subagents",
    "Taint",
    "Task",
    "Tool",
    "ToolAssemblyError",
    "ToolCall",
    "ToolResult",
    "ToolUse",
    "Toolset",
    "Workbench",
    "anthropic_defined",
    "assemble_system",
    "assemble_task",
    "budget_for_depth",
    "conceal_scan",
    "coverage_curve",
    "derived_risk",
    "estimate_cost_usd",
    "fanout",
    "fingerprint",
    "fit_coverage_law",
    "load_instruction",
    "load_skill",
    "load_skills",
    "looks_like_secret",
    "majority_vote",
    "pass_at_k",
    "predict_coverage",
    "prompt_as_instruction",
    "resources_as_context",
    "rollouts",
    "run",
    "sanitize",
    "submit_and_wait",
    "tool",
    "validate_form",
    "watch_resources",
]
