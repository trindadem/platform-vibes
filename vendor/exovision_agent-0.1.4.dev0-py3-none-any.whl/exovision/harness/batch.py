"""Batch: o eixo em que agente não é laço, é população.

Há dois motivos independentes para rodar em lote, e confundi-los produz
harnesses ruins:

1. **Preço e vazão.** A Message Batches API processa até 100.000 requisições
   (ou 256 MB) de forma assíncrona por **metade do preço** de entrada e de
   saída, com a maioria dos lotes fechando em menos de 1 hora e teto rígido de
   24 h. Não aceita `stream`, `speed` nem `max_tokens: 0`; aceita ferramentas,
   visão e pensamento estendido. Cada item leva um `custom_id`
   (`^[a-zA-Z0-9_-]{1,64}$`) porque **a ordem do resultado não é garantida**.
2. **Qualidade por amostragem repetida.** Amostrar K vezes e escolher é um
   eixo de escala de compute de inferência com lei própria: a *cobertura* — a
   fração de problemas resolvida por *alguma* amostra — cresce com K ao longo
   de quatro ordens de grandeza e se ajusta a uma lei de potência
   exponenciada (Brown et al., 2024, arXiv:2407.21787); em SWE-bench Lite,
   15,9% com 1 amostra e 56% com 250. Onde há verificador automático, isso
   vira desempenho direto; onde não há, voto majoritário e modelos de
   recompensa **estabilizam** depois de algumas centenas de amostras — e é
   honesto dizer isso, porque é o limite do método.

A raiz estatística do voto é a autoconsistência (Wang et al., ICLR 2023,
arXiv:2203.11171) e sua forma multiagente, amostrar-e-votar, cujo ganho cresce
com o número de agentes e com a dificuldade da tarefa (Li et al., 2024,
arXiv:2402.05120). A métrica é o estimador **não enviesado** de `pass@k`
(Chen et al., 2021, arXiv:2107.03374): gerar `n ≥ k` amostras, contar `c`
corretas e calcular `1 - C(n-c, k)/C(n, k)`. Entrar com a média —
`1 - (1 - p̂)^k`, `p̂ = c/n` — é enviesado **para baixo** por Jensen, e a
diferença não é decorativa: com `n=20`, `c=3`, `k=5` são 0,601 contra 0,556.

## O desenho: um provedor que coalesce, não um laço novo

O laço agêntico é sequencial por natureza — a volta *t+1* depende do resultado
da volta *t*. Não dá para "batchificar" um laço; dá para batchificar **K laços
independentes**. `BatchProvider` é um `Provider` comum que, chamado por K
threads, **junta** as K chamadas daquela volta numa submissão só e devolve a
cada thread a sua resposta. O laço não muda uma linha, os traços continuam
tendo a mesma forma, e o desconto de 50% aparece no `Outcome.cost_usd` porque
o provedor declara `cost_discount`.

    prov = BatchProvider(AnthropicBatchBackend(AnthropicProvider()), size=16)
    r = rollouts(Agent(provider=prov, ...), tarefa, k=16, verifier=passa_nos_testes)
    r.pass_at_k(4), r.coverage, r.law()

`ScriptedBatchBackend` produz exatamente a mesma forma de fio, sem rede: é o
que os testes usam.
"""

from __future__ import annotations

import json
import math
import re
import threading
import time
from collections import Counter
from collections.abc import Callable, Iterable, Mapping, Sequence
from concurrent.futures import ThreadPoolExecutor
from dataclasses import dataclass, field
from typing import Any, Protocol, runtime_checkable

from .loop import Agent, Outcome, run
from .models.provider import ProviderError, Reply, Request
from .seams import Event, Seams

__all__ = [
    "BATCH_DISCOUNT",
    "MAX_BATCH_BYTES",
    "MAX_BATCH_REQUESTS",
    "AnthropicBatchBackend",
    "BatchBackend",
    "BatchError",
    "BatchItem",
    "BatchProvider",
    "BatchResult",
    "Rollouts",
    "ScriptedBatchBackend",
    "coverage_curve",
    "fit_coverage_law",
    "majority_vote",
    "pass_at_k",
    "predict_coverage",
    "rollouts",
    "submit_and_wait",
]

#: Desconto da Message Batches API sobre entrada e saída.
BATCH_DISCOUNT = 0.5
#: Tetos de um lote, o que vier primeiro.
MAX_BATCH_REQUESTS = 100_000
MAX_BATCH_BYTES = 256 * 1024 * 1024
#: O lote expira em 24 h; os resultados ficam 29 dias.
BATCH_EXPIRY_S = 24 * 3600

_CUSTOM_ID = re.compile(r"^[a-zA-Z0-9_-]{1,64}$")
_TERMINAL = ("succeeded", "errored", "canceled", "expired")


class BatchError(RuntimeError):
    """O lote não pôde ser submetido, ou voltou o que não dá para usar."""


# --------------------------------------------------------------------------
# Itens e resultados
# --------------------------------------------------------------------------


@dataclass(frozen=True, slots=True)
class BatchItem:
    """Uma requisição do lote. `custom_id` é a única âncora: a ordem não volta."""

    custom_id: str
    request: Request

    def __post_init__(self) -> None:
        if not _CUSTOM_ID.match(self.custom_id):
            raise BatchError(
                f"custom_id {self.custom_id!r} fora de ^[a-zA-Z0-9_-]{{1,64}}$ — "
                "a API recusa o lote inteiro por causa de um item"
            )


@dataclass(slots=True)
class BatchResult:
    """O que um item do lote produziu. `type` é o do fio, não uma invenção nossa."""

    custom_id: str
    type: str = "succeeded"
    reply: Reply | None = None
    error: str = ""

    @property
    def ok(self) -> bool:
        return self.type == "succeeded" and self.reply is not None

    @property
    def billable(self) -> bool:
        """Só `succeeded` é cobrado; errored/canceled/expired, não."""
        return self.type == "succeeded"


@runtime_checkable
class BatchBackend(Protocol):
    """O fio do lote: submeter, perguntar, colher, cancelar."""

    def submit(self, items: Sequence[BatchItem]) -> str: ...

    def status(self, batch_id: str) -> dict[str, Any]: ...

    def results(self, batch_id: str) -> list[BatchResult]: ...

    def cancel(self, batch_id: str) -> None: ...


def _validate(items: Sequence[BatchItem]) -> int:
    if not items:
        raise BatchError("lote vazio")
    if len(items) > MAX_BATCH_REQUESTS:
        raise BatchError(f"{len(items)} requisições excedem o teto de {MAX_BATCH_REQUESTS}")
    seen: set[str] = set()
    size = 0
    for it in items:
        if it.custom_id in seen:
            raise BatchError(f"custom_id repetido no lote: {it.custom_id!r}")
        seen.add(it.custom_id)
        size += len(
            json.dumps(
                {
                    "system": it.request.system,
                    "messages": it.request.messages,
                    "tools": it.request.tools,
                },
                ensure_ascii=False,
                default=str,
            )
        )
    if size > MAX_BATCH_BYTES:
        raise BatchError(f"lote com ~{size} bytes excede o teto de {MAX_BATCH_BYTES}")
    return size


# --------------------------------------------------------------------------
# Backends
# --------------------------------------------------------------------------


class ScriptedBatchBackend:
    """Lote em processo: uma função pura `Request -> Reply`, sem rede.

    A função precisa ser **pura e reentrante**: o lote roda os itens em
    paralelo, e um roteiro que consome de uma lista compartilhada tornaria o
    teste dependente da ordem de agendamento — que é exatamente o que um lote
    não garante.
    """

    def __init__(
        self,
        responder: Callable[[Request], Reply],
        *,
        model: str = "scripted-batch",
        fail: Mapping[str, str] | None = None,
        expire: Iterable[str] = (),
        latency_s: float = 0.0,
    ) -> None:
        self.responder = responder
        self.model = model
        self.fail = dict(fail or {})
        self.expire = frozenset(expire)
        self.latency_s = latency_s
        self.batches: dict[str, list[BatchItem]] = {}
        self.submissions: list[list[str]] = []
        self.canceled: set[str] = set()
        self._n = 0
        self._lock = threading.Lock()

    def submit(self, items: Sequence[BatchItem]) -> str:
        _validate(items)
        with self._lock:
            self._n += 1
            batch_id = f"msgbatch_scripted_{self._n:04d}"
            self.batches[batch_id] = list(items)
            self.submissions.append([i.custom_id for i in items])
        return batch_id

    def status(self, batch_id: str) -> dict[str, Any]:
        items = self.batches.get(batch_id)
        if items is None:
            raise BatchError(f"lote desconhecido: {batch_id!r}")
        if batch_id in self.canceled:
            return {"processing_status": "ended", "request_counts": {"canceled": len(items)}}
        return {
            "processing_status": "ended",
            "request_counts": {"processing": 0, "succeeded": len(items)},
        }

    def results(self, batch_id: str) -> list[BatchResult]:
        items = self.batches.get(batch_id)
        if items is None:
            raise BatchError(f"lote desconhecido: {batch_id!r}")
        if self.latency_s:
            time.sleep(self.latency_s)
        out: list[BatchResult] = []
        for it in items:
            if batch_id in self.canceled:
                out.append(BatchResult(it.custom_id, "canceled"))
                continue
            if it.custom_id in self.expire:
                out.append(BatchResult(it.custom_id, "expired"))
                continue
            if it.custom_id in self.fail:
                out.append(BatchResult(it.custom_id, "errored", error=self.fail[it.custom_id]))
                continue
            try:
                reply = self.responder(it.request)
            except Exception as erro:
                out.append(
                    BatchResult(it.custom_id, "errored", error=f"{type(erro).__name__}: {erro}")
                )
                continue
            if not reply.model:
                reply.model = self.model
            out.append(BatchResult(it.custom_id, "succeeded", reply=reply))
        # A ordem do fio não é a da submissão. Embaralhar de forma
        # determinística garante que quem depender da ordem quebre no teste,
        # não em produção.
        return list(reversed(out))

    def cancel(self, batch_id: str) -> None:
        self.canceled.add(batch_id)


class AnthropicBatchBackend:
    """Message Batches API pelo SDK oficial, reusando a montagem do provedor.

    O corpo de cada item é o **mesmo** `build_kwargs` da chamada síncrona —
    incluindo `thinking`, `output_config.effort`, `cache_control` e as betas.
    Duas coisas mudam por exigência da API: não há `stream` (o lote é
    assíncrono por definição) e `max_tokens` precisa ser ≥ 1.
    """

    def __init__(
        self,
        provider: Any,
        *,
        client: Any = None,
        poll_s: float = 15.0,
        timeout_s: float = BATCH_EXPIRY_S,
    ) -> None:
        self.provider = provider
        self.client = client
        self.poll_s = poll_s
        self.timeout_s = timeout_s
        self.model = getattr(provider, "model", "")

    def _client(self) -> Any:
        if self.client is None:
            self.client = getattr(self.provider, "_client")()  # noqa: B009
        return self.client

    def _params(self, request: Request) -> tuple[dict[str, Any], list[str]]:
        kwargs, betas = self.provider.build_kwargs(request)
        kwargs.pop("stream", None)
        if int(kwargs.get("max_tokens") or 0) < 1:
            kwargs["max_tokens"] = 1
        return kwargs, betas

    def submit(self, items: Sequence[BatchItem]) -> str:
        _validate(items)
        requests: list[dict[str, Any]] = []
        betas: list[str] = []
        for it in items:
            params, item_betas = self._params(it.request)
            for b in item_betas:
                if b not in betas:
                    betas.append(b)
            requests.append({"custom_id": it.custom_id, "params": params})
        client = self._client()
        try:
            if betas:
                batch = client.beta.messages.batches.create(requests=requests, betas=betas)
            else:
                batch = client.messages.batches.create(requests=requests)
        except Exception as erro:
            raise BatchError(f"submissão do lote falhou: {type(erro).__name__}: {erro}") from erro
        return str(getattr(batch, "id", "") or batch["id"])

    def status(self, batch_id: str) -> dict[str, Any]:
        client = self._client()
        batch = client.messages.batches.retrieve(batch_id)
        data = batch.to_dict() if hasattr(batch, "to_dict") else dict(batch)
        return {
            "processing_status": str(data.get("processing_status") or ""),
            "request_counts": dict(data.get("request_counts") or {}),
            "results_url": data.get("results_url"),
            "ended_at": data.get("ended_at"),
            "expires_at": data.get("expires_at"),
        }

    def results(self, batch_id: str) -> list[BatchResult]:
        client = self._client()
        out: list[BatchResult] = []
        for entry in client.messages.batches.results(batch_id):
            data = entry.to_dict() if hasattr(entry, "to_dict") else dict(entry)
            custom_id = str(data.get("custom_id") or "")
            result = data.get("result") or {}
            kind = str(result.get("type") or "errored")
            if kind == "succeeded":
                message = result.get("message") or {}
                out.append(
                    BatchResult(
                        custom_id,
                        "succeeded",
                        reply=self.provider._to_reply(message),
                    )
                )
            else:
                err = result.get("error") or {}
                detail = err.get("error") if isinstance(err, Mapping) else err
                out.append(
                    BatchResult(
                        custom_id,
                        kind if kind in _TERMINAL else "errored",
                        error=json.dumps(detail, ensure_ascii=False, default=str),
                    )
                )
        return out

    def cancel(self, batch_id: str) -> None:
        self._client().messages.batches.cancel(batch_id)


def submit_and_wait(
    backend: BatchBackend,
    items: Sequence[BatchItem],
    *,
    poll_s: float = 15.0,
    timeout_s: float = BATCH_EXPIRY_S,
    on_poll: Callable[[dict[str, Any]], None] | None = None,
    sleep: Callable[[float], None] = time.sleep,
) -> list[BatchResult]:
    """Submete, espera `processing_status == "ended"`, colhe. Cancela no estouro."""
    batch_id = backend.submit(items)
    deadline = time.monotonic() + timeout_s
    while True:
        state = backend.status(batch_id)
        if on_poll:
            on_poll({**state, "batch_id": batch_id})
        if str(state.get("processing_status")) == "ended":
            return backend.results(batch_id)
        if time.monotonic() > deadline:
            backend.cancel(batch_id)
            raise BatchError(
                f"lote {batch_id} não fechou em {timeout_s}s (status {state.get('processing_status')!r})"
            )
        sleep(poll_s)


# --------------------------------------------------------------------------
# BatchProvider — coalescência
# --------------------------------------------------------------------------


@dataclass
class _Waiter:
    request: Request
    custom_id: str
    event: threading.Event = field(default_factory=threading.Event)
    reply: Reply | None = None
    error: str = ""


class BatchProvider:
    """Um `Provider` que junta chamadas concorrentes numa submissão de lote.

    Chamado por K threads (K rollouts independentes), acumula até `size`
    pedidos ou até a janela `window_s` fechar, submete tudo de uma vez e
    devolve a cada chamador a resposta do seu `custom_id`. O laço não sabe que
    está num lote — e é justamente por isso que o traço continua comparável
    com o de uma execução síncrona.

    `cost_discount = 0.5` é lido pelo `Meter`: o custo relatado no `Outcome` é
    o do lote, não o de lista.
    """

    cost_discount = BATCH_DISCOUNT

    def __init__(
        self,
        backend: BatchBackend,
        *,
        size: int = 32,
        window_s: float = 0.25,
        max_wait_s: float = BATCH_EXPIRY_S,
        poll_s: float = 15.0,
        model: str = "",
        effort: str = "",
    ) -> None:
        if size < 1:
            raise BatchError("size precisa ser >= 1")
        self.backend = backend
        self.size = size
        self.window_s = window_s
        self.max_wait_s = max_wait_s
        self.poll_s = poll_s
        self.model = (
            model
            or getattr(backend, "model", "")
            or getattr(getattr(backend, "provider", None), "model", "")
        )
        self.effort = effort or getattr(getattr(backend, "provider", None), "effort", "")
        self.batches = 0
        self.items = 0
        self._pending: list[_Waiter] = []
        self._lock = threading.Lock()
        self._timer: threading.Timer | None = None
        self._n = 0

    # -------------------------------------------------------- Provider
    def complete(self, request: Request) -> Reply:
        with self._lock:
            self._n += 1
            waiter = _Waiter(request=request, custom_id=f"r{self._n:06d}")
            self._pending.append(waiter)
            group: list[_Waiter] | None = None
            if len(self._pending) >= self.size:
                group, self._pending = self._pending, []
                self._cancel_timer_locked()
            elif self._timer is None and self.window_s > 0:
                self._timer = threading.Timer(self.window_s, self._flush_timer)
                self._timer.daemon = True
                self._timer.start()
        if group is not None:
            self._dispatch(group)
        elif self.window_s <= 0:
            self.flush()
        if not waiter.event.wait(self.max_wait_s):
            raise ProviderError(f"lote não devolveu {waiter.custom_id} em {self.max_wait_s}s")
        if waiter.error:
            raise ProviderError(waiter.error)
        if waiter.reply is None:  # pragma: no cover — defesa
            raise ProviderError(f"lote devolveu {waiter.custom_id} sem resposta")
        return waiter.reply

    # ---------------------------------------------------------- lote
    def flush(self) -> int:
        """Submete o que estiver pendente agora. Devolve quantos itens foram."""
        with self._lock:
            group, self._pending = self._pending, []
            self._cancel_timer_locked()
        if not group:
            return 0
        self._dispatch(group)
        return len(group)

    def _flush_timer(self) -> None:
        with self._lock:
            self._timer = None
            group, self._pending = self._pending, []
        if group:
            self._dispatch(group)

    def _cancel_timer_locked(self) -> None:
        if self._timer is not None:
            self._timer.cancel()
            self._timer = None

    def _dispatch(self, group: Sequence[_Waiter]) -> None:
        by_id: dict[str, _Waiter] = {w.custom_id: w for w in group}
        items = [BatchItem(custom_id=w.custom_id, request=w.request) for w in group]
        try:
            results = submit_and_wait(
                self.backend, items, poll_s=self.poll_s, timeout_s=self.max_wait_s
            )
        except Exception as erro:
            for w in group:
                w.error = f"{type(erro).__name__}: {erro}"
                w.event.set()
            return
        with self._lock:
            self.batches += 1
            self.items += len(items)
        for r in results:
            alvo = by_id.pop(r.custom_id, None)
            if alvo is None:  # resultado de um item que não é nosso
                continue
            if r.ok and r.reply is not None:
                alvo.reply = r.reply
            else:
                alvo.error = (
                    f"lote devolveu {r.type} para {r.custom_id}: {r.error or '(sem detalhe)'}"
                )
            alvo.event.set()
        for pendente in by_id.values():  # item que nunca voltou
            pendente.error = f"lote não devolveu {pendente.custom_id}"
            pendente.event.set()


# --------------------------------------------------------------------------
# Amostragem repetida: métricas e leis
# --------------------------------------------------------------------------


def pass_at_k(n: int, c: int, k: int) -> float:
    """Estimador **não enviesado** de `pass@k` (Chen et al., 2021, arXiv:2107.03374).

    Com `n` amostras das quais `c` passam,

    .. math:: \\widehat{\\text{pass@}k} = 1 - \\frac{\\binom{n-c}{k}}{\\binom{n}{k}}
              = 1 - \\prod_{i=n-c+1}^{n}\\left(1 - \\frac{k}{i}\\right)

    A forma do produto é a que se calcula: os binomiais estouram para `n`
    grande.

    O estimador de entrar-com-a-média, `1 - (1 - c/n)^k`, é **enviesado para
    baixo**: `(1 - p̂)^k` é convexa em `p̂`, então por Jensen
    `E[(1-p̂)^k] ≥ (1-p)^k` e o estimador subestima o `pass@k` verdadeiro. O
    estimador hipergeométrico acima tem esperança exatamente `1 - (1-p)^k` —
    sortear `k` das `n` amostras sem reposição é sortear `k` amostras iid.
    `tests/harness/test_harness_batch.py` verifica as duas afirmações somando
    sobre a binomial, sem Monte Carlo.

    >>> round(pass_at_k(10, 1, 1), 6)
    0.1
    >>> round(pass_at_k(10, 1, 10), 6)
    1.0
    """
    if k <= 0 or n <= 0:
        return 0.0
    if k > n:
        raise ValueError(f"pass@k exige k <= n; recebeu k={k}, n={n}")
    if c <= 0:
        return 0.0
    if n - c < k:
        return 1.0
    prod = 1.0
    for i in range(n - c + 1, n + 1):
        prod *= 1.0 - k / i
    return 1.0 - prod


def coverage_curve(
    successes: Sequence[Sequence[bool]], ks: Sequence[int] | None = None
) -> dict[int, float]:
    """Cobertura média por `k`: a fração de problemas resolvida por *alguma* amostra.

    `successes[p][i]` diz se a amostra `i` do problema `p` passou. Para cada
    `k` devolve a média de `pass@k` sobre os problemas — que é o estimador da
    cobertura usado em Brown et al. (2024).
    """
    if not successes:
        return {}
    n = min(len(row) for row in successes)
    if n == 0:
        return {}
    grid = list(ks) if ks else [k for k in (1, 2, 4, 8, 16, 32, 64, 128, 256) if k <= n]
    if not grid:
        grid = [n]
    out: dict[int, float] = {}
    for k in grid:
        if k > n:
            continue
        out[k] = sum(pass_at_k(n, sum(1 for s in row[:n] if s), k) for row in successes) / len(
            successes
        )
    return out


def fit_coverage_law(curve: Mapping[int, float]) -> dict[str, float]:
    """Ajusta a lei de potência exponenciada de Brown et al. (2024).

    .. math:: \\text{cov}(k) \\approx \\exp\\!\\left(-a\\,k^{-b}\\right)

    Tomando :math:`y = -\\log \\text{cov}(k)`, a lei vira uma reta em escala
    log-log: :math:`\\log y = \\log a - b \\log k`. O ajuste é mínimos
    quadrados nessa reta — stdlib pura, sem `numpy`.

    Devolve `a`, `b`, `r2` e `n` (pontos usados). Cobertura 0 ou 1 não entra:
    `log 0` e `log(-log 1)` não existem, e fingir que existem produziria um
    ajuste que parece bom e não é.
    """
    xs: list[float] = []
    ys: list[float] = []
    for k, cov in sorted(curve.items()):
        if k <= 0 or cov <= 0.0 or cov >= 1.0:
            continue
        xs.append(math.log(k))
        ys.append(math.log(-math.log(cov)))
    n = len(xs)
    if n < 2:
        return {"a": float("nan"), "b": float("nan"), "r2": float("nan"), "n": n}
    mx = sum(xs) / n
    my = sum(ys) / n
    sxx = sum((x - mx) ** 2 for x in xs)
    if sxx == 0.0:
        return {"a": float("nan"), "b": float("nan"), "r2": float("nan"), "n": n}
    sxy = sum((x - mx) * (y - my) for x, y in zip(xs, ys, strict=True))
    slope = sxy / sxx
    intercept = my - slope * mx
    ss_tot = sum((y - my) ** 2 for y in ys)
    ss_res = sum((y - (intercept + slope * x)) ** 2 for x, y in zip(xs, ys, strict=True))
    r2 = 1.0 - (ss_res / ss_tot) if ss_tot > 0 else 1.0
    return {"a": math.exp(intercept), "b": -slope, "r2": r2, "n": n}


def predict_coverage(law: Mapping[str, float], k: int) -> float:
    """`cov(k)` pela lei ajustada. Extrapolação é extrapolação: use com o `r2` à vista."""
    a, b = float(law.get("a", float("nan"))), float(law.get("b", float("nan")))
    if math.isnan(a) or math.isnan(b) or k <= 0:
        return float("nan")
    return math.exp(-a * (k**-b))


def majority_vote(
    answers: Sequence[str], *, key: Callable[[str], str] | None = None
) -> tuple[str, int, int]:
    """Autoconsistência: a resposta modal, seus votos e o total.

    `key` normaliza antes de contar (tirar espaço, extrair o número final).
    Empate é resolvido pela primeira ocorrência — determinístico de propósito.
    """
    usable = [a for a in answers if a is not None]
    if not usable:
        return "", 0, 0
    norm = key or (lambda s: s.strip())
    tally: Counter[str] = Counter(norm(a) for a in usable)
    best, votes = max(tally.items(), key=lambda kv: (kv[1], -list(tally).index(kv[0])))
    for a in usable:  # devolve a forma original, não a normalizada
        if norm(a) == best:
            return a, votes, len(usable)
    return best, votes, len(usable)  # pragma: no cover


# --------------------------------------------------------------------------
# Rollouts
# --------------------------------------------------------------------------


@dataclass
class Rollouts:
    """K execuções independentes da mesma tarefa, e o que se conclui delas."""

    task: str
    outcomes: list[Outcome] = field(default_factory=list)
    successes: list[bool] = field(default_factory=list)
    seconds: float = 0.0
    batches: int = 0

    @property
    def k(self) -> int:
        return len(self.outcomes)

    @property
    def solved(self) -> int:
        return sum(1 for s in self.successes if s)

    @property
    def coverage(self) -> float:
        """Alguma amostra resolveu? 1.0 ou 0.0 para uma tarefa só."""
        return 1.0 if self.solved else 0.0

    @property
    def cost_usd(self) -> float:
        return round(sum(o.cost_usd for o in self.outcomes), 6)

    def pass_at_k(self, k: int) -> float:
        return pass_at_k(self.k, self.solved, k)

    def curve(self, ks: Sequence[int] | None = None) -> dict[int, float]:
        return coverage_curve([self.successes], ks)

    def best(self, score: Callable[[Outcome], float] | None = None) -> Outcome | None:
        """A melhor amostra por um verificador/juiz. Sem ele, a primeira que passou."""
        if not self.outcomes:
            return None
        if score is None:
            for o, ok in zip(self.outcomes, self.successes, strict=True):
                if ok:
                    return o
            return self.outcomes[0]
        return max(self.outcomes, key=score)

    def consensus(self, *, key: Callable[[str], str] | None = None) -> tuple[str, int, int]:
        return majority_vote([o.text for o in self.outcomes], key=key)

    def to_dict(self) -> dict[str, Any]:
        return {
            "task": self.task,
            "k": self.k,
            "solved": self.solved,
            "coverage": self.coverage,
            "cost_usd": self.cost_usd,
            "seconds": round(self.seconds, 3),
            "batches": self.batches,
            "pass_at_1": round(self.pass_at_k(1), 6) if self.k else 0.0,
            "stop_reasons": dict(Counter(o.stop_reason for o in self.outcomes)),
        }


def rollouts(
    agent: Agent,
    task: str,
    *,
    k: int = 8,
    verifier: Callable[[Outcome], bool] | None = None,
    session: str = "-",
    max_workers: int | None = None,
    seams: Seams | None = None,
) -> Rollouts:
    """K execuções independentes da mesma tarefa, em paralelo.

    Cada rollout tem sessão própria (`sessão#i`) e, quando `seams` é dado, o
    traço do rollout é reemitido no traço comum com `rollout=i` — mesma forma
    de evento, uma execução comparável com a outra.

    Com um `BatchProvider` no agente, as K chamadas de cada volta viram uma
    submissão de lote só: metade do preço, uma ida à rede. Sem ele, as K
    execuções rodam em threads e pagam preço de lista — a mesma API, outro
    regime de custo.
    """
    if k < 1:
        raise ValueError("k precisa ser >= 1")
    workers = max(1, min(max_workers or k, k))
    lock = threading.Lock()

    def one(i: int) -> Outcome:
        child = Seams(f"{session}#{i}")
        if seams is not None:

            def forward(e: Event, idx: int = i) -> None:
                with lock:
                    seams.emit(e.seam, **{**e.data, "rollout": idx})

            child.on("*", forward)
        try:
            return run(agent, task, session=f"{session}#{i}", seams=child)
        except Exception as erro:  # um rollout ruim não derruba a população
            return Outcome(
                text="",
                turns=0,
                stop_reason="error",
                session=f"{session}#{i}",
                error=f"{type(erro).__name__}: {erro}",
            )

    t0 = time.perf_counter()
    if workers == 1:
        outcomes = [one(i) for i in range(k)]
    else:
        with ThreadPoolExecutor(max_workers=workers) as pool:
            outcomes = list(pool.map(one, range(k)))
    seconds = time.perf_counter() - t0
    successes = [bool(verifier(o)) if verifier else o.ok for o in outcomes]
    provider = agent.provider
    return Rollouts(
        task=task,
        outcomes=outcomes,
        successes=successes,
        seconds=seconds,
        batches=int(getattr(provider, "batches", 0)),
    )
