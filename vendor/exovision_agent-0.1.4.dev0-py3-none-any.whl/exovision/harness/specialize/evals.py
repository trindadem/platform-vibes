"""A suíte do domínio: a expertise é medida, não afirmada.

`evals/tasks.jsonl`, uma tarefa por linha:

    {"id": "t1", "prompt": "...", "expected": "PROTO-7", "verifier": "exact",
     "split": "train", "in_scope": true, "tags": ["amostra"]}

Verificadores: `exact` (igualdade normalizada), `contains`, `regex`, `any_of`
(`expected` é lista) e `rubric` (um juiz devolve nota 0..1 — o LLM-como-juiz de
Zheng et al., 2023 — e o limiar é 0,5). Tarefas com `in_scope: false` medem
**calibração**: o acerto é abster-se (Kadavath et al., 2022: o modelo sabe, na
maior parte das vezes, o que não sabe — o harness precisa deixar isso valer
ponto). Uma resposta confiante fora do escopo é um erro de tipo pior que um
erro dentro dele, e o relatório os separa.

**Split.** Sem `split` na tarefa, o harness decide por hash do id
(60/20/20): estável entre execuções e independente da ordem do arquivo. O
`test` só é lido no fim — Recht et al. (2019) mostram o que acontece com
métricas escolhidas contra o próprio conjunto de teste, e a evolução
(`evolve.py`) seleciona no `dev` justamente para não fazer isso.

**Estatística.** Média com intervalo de confiança por bootstrap sobre as
tarefas (Efron, 1979) e comparação pareada entre duas execuções por
permutação (Smucker et al., 2007) — as funções são as de `rag.eval.metrics`.
"""

from __future__ import annotations

import hashlib
import json
import re
import time
from collections.abc import Callable, Iterable, Mapping, Sequence
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

from ..batch import pass_at_k, rollouts
from ..loop import Agent, Outcome, run
from ..memory.core.text import fold
from ..rag.eval.metrics import bootstrap_ci, paired_permutation_test
from ..seams import Seams
from ..session import InMemoryStateStore
from .spec import DEFAULT_ABSTAIN_MARKERS

__all__ = [
    "SPLITS",
    "Judge",
    "Lesson",
    "Report",
    "Suite",
    "Task",
    "Trajectory",
    "Verdict",
    "compare",
    "evaluate",
    "is_abstention",
    "load_suite",
    "verify",
]

SPLITS: tuple[str, ...] = ("train", "dev", "test")
VERIFIERS: tuple[str, ...] = ("exact", "contains", "regex", "any_of", "rubric")

#: (tarefa, resposta) -> nota em [0, 1]
Judge = Callable[["Task", str], float]


@dataclass(frozen=True, slots=True)
class Task:
    id: str
    prompt: str
    expected: Any = ""
    verifier: str = "exact"
    split: str = ""
    in_scope: bool = True
    tags: tuple[str, ...] = ()
    meta: dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> dict[str, Any]:
        return {"id": self.id, "prompt": self.prompt, "expected": self.expected, "verifier": self.verifier, "split": self.split, "in_scope": self.in_scope, "tags": list(self.tags), **({"meta": self.meta} if self.meta else {})}


def auto_split(task_id: str) -> str:
    """60/20/20 por hash do id — a mesma tarefa cai sempre no mesmo split."""
    h = int(hashlib.sha256(task_id.encode("utf-8")).hexdigest(), 16) % 100
    return "train" if h < 60 else "dev" if h < 80 else "test"


class Suite:
    def __init__(self, tasks: Iterable[Task], *, name: str = "suite") -> None:
        self.name = name
        self.tasks: list[Task] = []
        seen: set[str] = set()
        for t in tasks:
            if t.id in seen:
                raise ValueError(f"tarefa {t.id!r} duplicada na suíte")
            seen.add(t.id)
            if t.verifier not in VERIFIERS:
                raise ValueError(f"tarefa {t.id!r}: verificador {t.verifier!r} fora de {VERIFIERS}")
            split = t.split or auto_split(t.id)
            if split not in SPLITS:
                raise ValueError(f"tarefa {t.id!r}: split {split!r} fora de {SPLITS}")
            self.tasks.append(Task(t.id, t.prompt, t.expected, t.verifier, split, t.in_scope, t.tags, dict(t.meta)))

    def __len__(self) -> int:
        return len(self.tasks)

    def split(self, name: str) -> list[Task]:
        if name == "all":
            return list(self.tasks)
        if name not in SPLITS:
            raise ValueError(f"split {name!r} fora de {SPLITS}")
        return [t for t in self.tasks if t.split == name]

    def counts(self) -> dict[str, int]:
        out = dict.fromkeys(SPLITS, 0)
        for t in self.tasks:
            out[t.split] += 1
        return out

    def save(self, path: str | Path) -> int:
        p = Path(path)
        p.parent.mkdir(parents=True, exist_ok=True)
        with p.open("w", encoding="utf-8") as fh:
            for t in self.tasks:
                fh.write(json.dumps(t.to_dict(), ensure_ascii=False) + "\n")
        return len(self.tasks)


def load_suite(path: str | Path, *, name: str | None = None) -> Suite:
    p = Path(path)
    if not p.is_file():
        raise FileNotFoundError(f"suíte não encontrada: {p}")
    tasks: list[Task] = []
    for i, line in enumerate(p.read_text(encoding="utf-8").splitlines()):
        if not line.strip():
            continue
        d = json.loads(line)
        tasks.append(Task(str(d.get("id") or f"t{i}"), str(d["prompt"]), d.get("expected", ""), str(d.get("verifier", "exact")), str(d.get("split", "")), bool(d.get("in_scope", True)), tuple(str(x) for x in d.get("tags", ())), dict(d.get("meta", {}))))
    return Suite(tasks, name=name or p.parent.parent.name)


# --------------------------------------------------------------------------
# verificação
# --------------------------------------------------------------------------


@dataclass(frozen=True, slots=True)
class Verdict:
    ok: bool
    score: float
    abstained: bool = False
    reason: str = ""


def _norm(text: str) -> str:
    return re.sub(r"[^a-z0-9]+", " ", fold(text)).strip()


def is_abstention(text: str, markers: Sequence[str] = DEFAULT_ABSTAIN_MARKERS) -> bool:
    t = fold(text)
    return any(fold(m) in t for m in markers)


def verify(task: Task, answer: str, *, judge: Judge | None = None, markers: Sequence[str] = DEFAULT_ABSTAIN_MARKERS) -> Verdict:
    """Aplica o verificador da tarefa. Fora do escopo, o acerto é a abstenção."""
    abstained = is_abstention(answer, markers)
    if not task.in_scope:
        return Verdict(abstained, 1.0 if abstained else 0.0, abstained, "abstenção correta" if abstained else "resposta confiante fora do escopo")
    if abstained:
        return Verdict(False, 0.0, True, "abstenção dentro do escopo")
    v = task.verifier
    if v == "exact":
        ok = _norm(answer) == _norm(str(task.expected))
        return Verdict(ok, float(ok), False, "" if ok else f"esperado {task.expected!r}")
    if v == "contains":
        exp = _norm(str(task.expected))
        ok = bool(exp) and re.search(r"(?<!\S)" + re.escape(exp) + r"(?!\S)", _norm(answer)) is not None
        return Verdict(ok, float(ok), False, "" if ok else f"não contém {task.expected!r}")
    if v == "regex":
        ok = re.search(str(task.expected), answer, re.I | re.S) is not None
        return Verdict(ok, float(ok), False, "" if ok else f"não casa /{task.expected}/")
    if v == "any_of":
        opts = task.expected if isinstance(task.expected, (list, tuple)) else [task.expected]
        na = _norm(answer)
        ok = any(_norm(str(o)) == na for o in opts)
        return Verdict(ok, float(ok), False, "" if ok else f"esperado um de {list(opts)!r}")
    if v == "rubric":
        if judge is None:
            raise ValueError(f"tarefa {task.id!r} usa rubrica e nenhum juiz foi dado")
        score = max(0.0, min(1.0, float(judge(task, answer))))
        return Verdict(score >= 0.5, score, False, f"rubrica {score:.2f}")
    raise ValueError(f"verificador desconhecido: {v!r}")


# --------------------------------------------------------------------------
# relatório
# --------------------------------------------------------------------------


@dataclass(slots=True)
class Lesson:
    """O que uma execução avaliada deixou: a matéria-prima da reflexão (Reflexion / ExpeL)."""

    task_id: str
    prompt: str
    expected: Any
    answer: str
    ok: bool
    abstained: bool
    in_scope: bool
    reason: str = ""
    tags: tuple[str, ...] = ()

    def to_dict(self) -> dict[str, Any]:
        return {"task_id": self.task_id, "prompt": self.prompt, "expected": self.expected, "answer": self.answer, "ok": self.ok, "abstained": self.abstained, "in_scope": self.in_scope, "reason": self.reason, "tags": list(self.tags)}


@dataclass(slots=True)
class Trajectory:
    task_id: str
    system: list[dict[str, Any]]
    messages: list[dict[str, Any]]
    ok: bool


@dataclass(slots=True)
class Report:
    split: str
    n: int = 0
    per_task: dict[str, float] = field(default_factory=dict)
    mean: float = 0.0
    ci: tuple[float, float] = (0.0, 0.0)
    in_scope_accuracy: float = 0.0
    abstention: dict[str, float] = field(default_factory=dict)
    tokens: dict[str, int] = field(default_factory=dict)
    cost_usd: float = 0.0
    seconds: float = 0.0
    lessons: list[Lesson] = field(default_factory=list)
    trajectories: list[Trajectory] = field(default_factory=list)
    k: int = 1

    def failures(self) -> list[Lesson]:
        return [le for le in self.lessons if not le.ok]

    def successes(self) -> list[Lesson]:
        return [le for le in self.lessons if le.ok]

    def to_dict(self) -> dict[str, Any]:
        return {
            "split": self.split,
            "n": self.n,
            "k": self.k,
            "mean": round(self.mean, 4),
            "ci": [round(self.ci[0], 4), round(self.ci[1], 4)],
            "in_scope_accuracy": round(self.in_scope_accuracy, 4),
            "abstention": {k: round(v, 4) for k, v in self.abstention.items()},
            "tokens": dict(self.tokens),
            "cost_usd": round(self.cost_usd, 6),
            "seconds": round(self.seconds, 3),
            "per_task": {k: round(v, 4) for k, v in self.per_task.items()},
        }


def _abstention_metrics(lessons: Sequence[Lesson]) -> tuple[dict[str, float], float]:
    out_scope = [le for le in lessons if not le.in_scope]
    in_scope = [le for le in lessons if le.in_scope]
    abstained = [le for le in lessons if le.abstained]
    m: dict[str, float] = {
        "out_of_scope": float(len(out_scope)),
        "abstained": float(len(abstained)),
        # das tarefas fora do escopo, quantas abstiveram (recall da abstenção)
        "recall": (sum(1 for le in out_scope if le.abstained) / len(out_scope)) if out_scope else 1.0,
        # das abstenções, quantas eram de fato fora do escopo (precisão)
        "precision": (sum(1 for le in abstained if not le.in_scope) / len(abstained)) if abstained else 1.0,
        # respostas confiantes fora do escopo: o erro que mais custa
        "confident_errors": float(sum(1 for le in out_scope if not le.abstained)),
        # abstenções dentro do escopo: excesso de cautela
        "false_abstentions": float(sum(1 for le in in_scope if le.abstained)),
    }
    acc_in = (sum(1 for le in in_scope if le.ok) / len(in_scope)) if in_scope else 0.0
    return m, acc_in


def evaluate(
    agent: Agent | Callable[[], Agent],
    suite: Suite,
    split: str = "dev",
    *,
    judge: Judge | None = None,
    markers: Sequence[str] = DEFAULT_ABSTAIN_MARKERS,
    k: int = 1,
    keep_trajectories: bool = False,
    seams: Seams | None = None,
    session_prefix: str = "",
) -> Report:
    """Roda cada tarefa do split e verifica. `agent` pode ser uma fábrica (uma instância por tarefa).

    Com `k > 1`, cada tarefa roda `k` vezes (`batch.rollouts`) e a nota é o
    estimador não enviesado de pass@1 (Chen et al., 2021)."""
    tasks = suite.split(split)
    report = Report(split=split, n=len(tasks), k=k)
    t0 = time.perf_counter()
    tokens: dict[str, int] = {}
    for task in tasks:
        ag = agent() if callable(agent) and not isinstance(agent, Agent) else agent
        session = f"{session_prefix}{split}/{task.id}"
        if k > 1:

            def passes(o: Outcome, t: Task = task) -> bool:
                return verify(t, o.text, judge=judge, markers=markers).ok

            rr = rollouts(ag, task.prompt, k=k, verifier=passes, session=session, seams=seams)
            score = pass_at_k(rr.k, rr.solved, 1)
            best = rr.best()
            outcome = best if best is not None else Outcome(text="", turns=0, stop_reason="none")
            verdict = verify(task, outcome.text, judge=judge, markers=markers)
            report.cost_usd += rr.cost_usd
            for o in rr.outcomes:
                for key, v in o.usage.items():
                    tokens[key] = tokens.get(key, 0) + int(v)
        else:
            store = InMemoryStateStore() if keep_trajectories else None
            outcome = run(ag, task.prompt, session=session, state_store=store, seams=seams)
            verdict = verify(task, outcome.text, judge=judge, markers=markers)
            score = verdict.score
            report.cost_usd += outcome.cost_usd
            for key, v in outcome.usage.items():
                tokens[key] = tokens.get(key, 0) + int(v)
            if store is not None:
                st = store.load(session)
                if st is not None:
                    report.trajectories.append(Trajectory(task.id, list(st.system), list(st.messages), verdict.ok))
        report.per_task[task.id] = score
        report.lessons.append(Lesson(task.id, task.prompt, task.expected, outcome.text, verdict.ok, verdict.abstained, task.in_scope, verdict.reason, task.tags))
    report.seconds = time.perf_counter() - t0
    report.tokens = tokens
    vals = list(report.per_task.values())
    if vals:
        mean, lo, hi = bootstrap_ci(vals)
        report.mean, report.ci = mean, (lo, hi)
    report.abstention, report.in_scope_accuracy = _abstention_metrics(report.lessons)
    return report


def compare(a: Report, b: Report) -> dict[str, float]:
    """`a` contra `b` nas tarefas em comum: diferença média e valor-p (permutação pareada)."""
    common = {k: v for k, v in a.per_task.items() if k in b.per_task}
    if not common:
        return {"diff": 0.0, "p_value": 1.0, "n": 0.0}
    diff, p = paired_permutation_test(common, {k: b.per_task[k] for k in common})
    return {"diff": round(diff, 4), "p_value": round(p, 4), "n": float(len(common))}


def write_lessons(path: str | Path, lessons: Iterable[Lesson], *, append: bool = True) -> int:
    p = Path(path)
    p.parent.mkdir(parents=True, exist_ok=True)
    n = 0
    with p.open("a" if append else "w", encoding="utf-8") as fh:
        for le in lessons:
            fh.write(json.dumps(le.to_dict(), ensure_ascii=False) + "\n")
            n += 1
    return n


def read_lessons(path: str | Path) -> list[Lesson]:
    p = Path(path)
    if not p.is_file():
        return []
    out: list[Lesson] = []
    for line in p.read_text(encoding="utf-8").splitlines():
        if line.strip():
            d: Mapping[str, Any] = json.loads(line)
            out.append(Lesson(str(d["task_id"]), str(d["prompt"]), d.get("expected", ""), str(d.get("answer", "")), bool(d.get("ok")), bool(d.get("abstained")), bool(d.get("in_scope", True)), str(d.get("reason", "")), tuple(d.get("tags", ()))))
    return out
