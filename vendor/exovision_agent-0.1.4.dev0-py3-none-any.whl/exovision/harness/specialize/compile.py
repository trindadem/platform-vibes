"""Compilar a especialidade num `Agent` — e poder tirar qualquer parte para medir o que ela vale.

O system estável recebe: papel (SPEC.md), regras ativas que cabem no orçamento
(mais votadas primeiro), escopo com a cláusula de abstenção. O que depende da
tarefa (exemplos, glossário, corpus) entra pela `SpecializationPort`. As
ferramentas viram `Allowlist` + `DenyRisk` — o agente especializado tem as
ferramentas do domínio, não todas.

**Ablação.** Toda seção é desligável por nome em `ablate`: `persona`, `rules`,
`examples`, `glossary`, `knowledge`, `skills`, `abstention`, `tools`. É o
estudo de ablação clássico (Meyes et al., 2019) aplicado ao prompt: uma seção
que não muda o resultado quando some não estava fazendo nada além de gastar
tokens — e o relatório de compilação diz quantos.
"""

from __future__ import annotations

from collections.abc import Iterable
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

from ..budget import Budget
from ..instruction import Instruction
from ..loop import Agent
from ..memory.bridge import MemoryPort, NullMemory
from ..memory.core.budget import estimate_tokens
from ..memory.core.embeddings import Embedder
from ..models.provider import Provider
from ..policy import AllowAll, Allowlist, Chain, DenyRisk, Policy
from ..skills import SkillLibrary, load_skills
from ..tools import Registry, Toolset
from .port import SpecializationPort
from .select import pack_rules, render_rules
from .spec import Specialization

__all__ = ["SECTIONS", "Compiled", "compile_specialization", "render_system"]

SECTIONS: tuple[str, ...] = ("persona", "rules", "examples", "glossary", "knowledge", "skills", "abstention", "tools")

ABSTENTION_CLAUSE = (
    "Se a tarefa está fora do escopo acima, ou se você não tem base para responder com "
    "confiança, diga explicitamente que está fora do seu escopo ou que não sabe — "
    "não invente. Uma abstenção honesta vale mais que uma resposta confiante e errada."
)


@dataclass(slots=True)
class Compiled:
    """O agente e a conta do que a especialização custou em tokens por seção."""

    agent: Agent
    spec: Specialization
    ablated: tuple[str, ...]
    tokens: dict[str, int] = field(default_factory=dict)
    rules_in_prompt: int = 0
    rules_dropped: int = 0
    system_text: str = ""

    def to_dict(self) -> dict[str, Any]:
        return {
            "spec": self.spec.ref,
            "digest": self.spec.digest[:12],
            "ablated": list(self.ablated),
            "tokens": dict(self.tokens),
            "rules_in_prompt": self.rules_in_prompt,
            "rules_dropped": self.rules_dropped,
        }


def render_system(spec: Specialization, *, ablate: Iterable[str] = ()) -> tuple[str, dict[str, int], int, int]:
    """O texto do system e a conta por seção. Devolve (texto, tokens, regras no prompt, regras descartadas)."""
    off = _check(ablate)
    parts: list[str] = []
    tokens: dict[str, int] = {}
    if "persona" not in off:
        parts.append(spec.role.strip())
        tokens["persona"] = estimate_tokens(spec.role)
    else:
        parts.append(f"Você é um assistente para {spec.domain or spec.name}.")
    kept: list = []
    dropped = 0
    if "rules" not in off and len(spec.rules.active()):
        kept, dropped = pack_rules(spec.rules.active(), spec.budgets.get("rules", 0))
        block = render_rules(kept)
        if block:
            parts.append(block)
            tokens["rules"] = estimate_tokens(block)
    scope: list[str] = []
    if spec.scope_in:
        scope.append("Dentro do escopo: " + "; ".join(spec.scope_in) + ".")
    if spec.scope_out:
        scope.append("Fora do escopo: " + "; ".join(spec.scope_out) + ".")
    if spec.abstain and "abstention" not in off:
        scope.append(ABSTENTION_CLAUSE)
    if scope:
        block = "## Escopo\n" + "\n".join(scope)
        parts.append(block)
        tokens["scope"] = estimate_tokens(block)
    text = "\n\n".join(p for p in parts if p)
    return text, tokens, len(kept), dropped


def compile_specialization(
    spec: Specialization,
    provider: Provider,
    *,
    ablate: Iterable[str] = (),
    toolset: Toolset | None = None,
    knowledge: MemoryPort | None = None,
    embedder: Embedder | None = None,
    budget: Budget | None = None,
    workspace: str | Path | None = None,
    policy: Policy | None = None,
    example_order: str = "similar_last",
    example_selection: str = "knn",
    name: str | None = None,
) -> Compiled:
    """Monta o `Agent`. `knowledge` é a porta do corpus (ex.: `RAGMemoryPort`); `toolset` as ferramentas disponíveis, que o SPEC filtra."""
    off = _check(ablate)
    text, tokens, n_rules, dropped = render_system(spec, ablate=off)
    instruction = Instruction.from_text(f"---\nname: {spec.name}\nversion: {spec.version}\n---\n{text}", name=spec.name)

    skills: SkillLibrary | None = None
    if "skills" not in off and spec.skills_dir is not None:
        loaded = load_skills([spec.skills_dir])
        if loaded:
            skills = SkillLibrary(loaded)
            tokens["skills_index"] = estimate_tokens(skills.index())

    use_examples = "examples" not in off and bool(spec.examples)
    use_glossary = "glossary" not in off and len(spec.glossary) > 0
    use_knowledge = "knowledge" not in off and knowledge is not None
    memory: MemoryPort
    if use_examples or use_glossary or use_knowledge:
        memory = SpecializationPort(spec, embedder=embedder, knowledge=knowledge if use_knowledge else None, examples=use_examples, glossary=use_glossary, example_order=example_order, example_selection=example_selection)
    else:
        memory = NullMemory()

    if policy is None:
        chain: list[Policy] = []
        if "tools" not in off and spec.tools:
            chain.append(Allowlist(spec.tools))
        if "tools" not in off and spec.risk_ceiling:
            chain.append(DenyRisk(at_or_above=spec.risk_ceiling))
        policy = Chain(chain) if chain else AllowAll()

    agent = Agent(
        provider=provider,
        instruction=instruction,
        name=name or spec.name,
        toolset=toolset if toolset is not None else Registry(),
        policy=policy,
        memory=memory,
        skills=skills,
        budget=budget or Budget(),
        workspace=workspace,
    )
    return Compiled(agent=agent, spec=spec, ablated=tuple(sorted(off)), tokens=tokens, rules_in_prompt=n_rules, rules_dropped=dropped, system_text=text)


def _check(ablate: Iterable[str]) -> frozenset[str]:
    off = frozenset(ablate)
    bad = sorted(off - set(SECTIONS))
    if bad:
        raise ValueError(f"seções desconhecidas para ablação: {bad}; opções: {list(SECTIONS)}")
    return off
