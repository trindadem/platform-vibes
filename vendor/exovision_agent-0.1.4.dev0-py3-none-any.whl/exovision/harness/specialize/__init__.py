"""exovision.harness.specialize — especialização profunda, medida.

Uma especialidade é um diretório (`spec.py`) compilado em `Agent`
(`compile.py`): papel curto, regras com votos e evidência, exemplos por
similaridade sob orçamento, glossário sob demanda, corpus por recuperação,
ferramentas em allowlist, cláusula de abstenção. A expertise é medida por uma
suíte com split e estatística (`evals.py`), melhorada por evolução reflexiva
com holdout (`evolve.py`) e destilada em dados (`distill.py`). O especialista
simulado e o domínio sintético (`simulate.py`) medem a máquina sem rede.

    spec = load_specialization("especialidades/protocolos-lab")
    agent = compile_specialization(spec, AnthropicProvider()).agent
    report = evaluate(agent, load_suite(spec.evals_path), "test")

Os experimentos do estudo (`bench.py`) rodam sobre o simulador e gravam em
`docs/especializacao/resultados/`; a linha de comando é
`exovision-agent specialize` (`cli.py`). O estudo, a bibliografia e a tabela
afirmação -> teste estão em `docs/especializacao.tex`,
`docs/especializacao.bib` e `docs/especializacao-estudo.md`.
"""

from __future__ import annotations

from .bench import BENCHMARKS, run_benchmark, wrong_rules
from .compile import SECTIONS, Compiled, compile_specialization, render_system
from .distill import export, redact_messages
from .evals import (
    SPLITS,
    Judge,
    Lesson,
    Report,
    Suite,
    Task,
    Trajectory,
    Verdict,
    compare,
    evaluate,
    is_abstention,
    load_suite,
    read_lessons,
    verify,
    write_lessons,
)
from .evolve import (
    EvolutionReport,
    HeuristicReflector,
    Iteration,
    Proposal,
    ProviderReflector,
    Reflector,
    apply_proposals,
    evolve,
    parse_proposals,
)
from .port import SpecializationPort
from .select import ExampleSelector, pack_rules, render_examples, render_rules
from .simulate import SimulatedExpert, synthetic_domain
from .spec import (
    DEFAULT_ABSTAIN_MARKERS,
    Example,
    Glossary,
    Rule,
    RuleBook,
    Specialization,
    SpecializationError,
    load_specialization,
)

__all__ = [
    "BENCHMARKS",
    "DEFAULT_ABSTAIN_MARKERS",
    "SECTIONS",
    "SPLITS",
    "Compiled",
    "EvolutionReport",
    "Example",
    "ExampleSelector",
    "Glossary",
    "HeuristicReflector",
    "Iteration",
    "Judge",
    "Lesson",
    "Proposal",
    "ProviderReflector",
    "Reflector",
    "Report",
    "Rule",
    "RuleBook",
    "SimulatedExpert",
    "Specialization",
    "SpecializationError",
    "SpecializationPort",
    "Suite",
    "Task",
    "Trajectory",
    "Verdict",
    "apply_proposals",
    "compare",
    "compile_specialization",
    "evaluate",
    "evolve",
    "export",
    "is_abstention",
    "load_specialization",
    "load_suite",
    "pack_rules",
    "parse_proposals",
    "read_lessons",
    "redact_messages",
    "render_examples",
    "render_rules",
    "render_system",
    "run_benchmark",
    "synthetic_domain",
    "verify",
    "write_lessons",
    "wrong_rules",
]
