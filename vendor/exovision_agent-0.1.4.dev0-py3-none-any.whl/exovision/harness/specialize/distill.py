"""Traços viram dados: a especialidade pode ser destilada.

O que uma execução avaliada deixa — system, mensagens, chamadas de ferramenta,
veredito — é exatamente o que um conjunto de fine-tuning supervisionado
precisa. O STaR (Zelikman et al., 2022) treina só nos raciocínios que levaram à
resposta certa; o *rejection sampling fine-tuning* generaliza: gera K, mantém
os verificados. Aqui: `export` grava as trajetórias como JSONL no formato de
mensagens, **só as verificadas** por padrão, com segredos mascarados pela mesma
regex de `RedactResults`. Treinar é fora do harness; o dado sai pronto e
auditável (cada linha aponta a tarefa e o veredito).
"""

from __future__ import annotations

import json
from collections.abc import Iterable, Sequence
from pathlib import Path
from typing import Any

from ..policy import RedactResults
from .evals import Trajectory

__all__ = ["export", "redact_messages"]


def _redact_value(v: Any, red: RedactResults) -> tuple[Any, int]:
    if isinstance(v, str):
        return red.redact_text(v)
    if isinstance(v, list):
        out = []
        hits = 0
        for item in v:
            r, h = _redact_value(item, red)
            out.append(r)
            hits += h
        return out, hits
    if isinstance(v, dict):
        outd: dict[str, Any] = {}
        hits = 0
        for k, item in v.items():
            r, h = _redact_value(item, red)
            outd[k] = r
            hits += h
        return outd, hits
    return v, 0


def redact_messages(messages: Sequence[dict[str, Any]], *, patterns: Iterable[str] = ()) -> tuple[list[dict[str, Any]], int]:
    red = RedactResults(patterns)
    out, hits = _redact_value(list(messages), red)
    return out, hits


def export(trajectories: Iterable[Trajectory], path: str | Path, *, only_success: bool = True, redact: bool = True, patterns: Iterable[str] = (), tag: str = "") -> dict[str, int]:
    """Grava JSONL: uma trajetória por linha (`task_id`, `ok`, `system`, `messages`, `redacted`)."""
    p = Path(path)
    p.parent.mkdir(parents=True, exist_ok=True)
    written = skipped = redacted = 0
    with p.open("w", encoding="utf-8") as fh:
        for t in trajectories:
            if only_success and not t.ok:
                skipped += 1
                continue
            system = t.system
            messages = t.messages
            hits = 0
            if redact:
                system, h1 = _redact_value(list(system), RedactResults(patterns))
                messages, h2 = redact_messages(messages, patterns=patterns)
                hits = h1 + h2
            redacted += hits
            row = {"task_id": t.task_id, "ok": t.ok, "system": system, "messages": messages, "redacted": hits}
            if tag:
                row["tag"] = tag
            fh.write(json.dumps(row, ensure_ascii=False) + "\n")
            written += 1
    return {"written": written, "skipped": skipped, "redacted": redacted}
