"""Seleção por tarefa: exemplos por similaridade, regras por voto, termos por presença — tudo sob orçamento.

Três resultados da literatura de aprendizado em contexto governam este módulo:

* **Quais exemplos**: os mais próximos da tarefa no espaço de embedding (KATE,
  Liu et al., 2022) batem seleção aleatória de forma consistente; é uma busca
  kNN, e o embedder é o mesmo da memória (hashing por padrão, determinístico).
* **Em que ordem**: a ordem dos exemplos muda o resultado (Lu et al., 2022,
  "fantastically ordered prompts"), então ela precisa ser *fixa e declarada*:
  aqui, similaridade crescente — o exemplo mais parecido fica por último,
  colado na tarefa, onde Liu et al. (2023) medem que o modelo lê melhor.
* **Quantos**: mais exemplos ajudam até saturar (Agarwal et al., 2024,
  many-shot), e cada um custa tokens em toda chamada; `k` e o orçamento são
  do SPEC, e a curva acerto x k está medida no estudo.

Min et al. (2022) mostram que o *formato* dos exemplos importa mais que a
correção dos rótulos — por isso todo exemplo é renderizado no mesmo molde
(`Tarefa:` / `Raciocínio:` / `Resposta:`), sem exceção.
"""

from __future__ import annotations

import random
from collections.abc import Sequence

from ..memory.core.budget import estimate_tokens
from ..memory.core.embeddings import Embedder, HashingEmbedder
from ..memory.core.similarity import cosine
from .spec import Example, Rule

__all__ = ["ExampleSelector", "pack_rules", "render_examples", "render_rules"]


class ExampleSelector:
    """kNN sobre `example.task`, com orçamento e ordem fixa."""

    def __init__(self, examples: Sequence[Example], *, embedder: Embedder | None = None) -> None:
        self.examples = list(examples)
        self.embedder = embedder or HashingEmbedder(256)
        self._vectors = self.embedder.encode_batch([e.task for e in self.examples]) if self.examples else []

    def __len__(self) -> int:
        return len(self.examples)

    def ranked(self, task: str) -> list[tuple[Example, float]]:
        """Todos os exemplos, do mais ao menos similar; empate por id."""
        if not self.examples:
            return []
        q = self.embedder.encode(task)
        scored = [(e, cosine(q, v)) for e, v in zip(self.examples, self._vectors, strict=True)]
        scored.sort(key=lambda es: (-es[1], es[0].id))
        return scored

    def select(self, task: str, *, k: int, budget_tokens: int, order: str = "similar_last") -> list[Example]:
        """Os `k` mais similares que cabem no orçamento, na ordem declarada.

        `order`: `similar_last` (padrão), `similar_first`, ou `id` (estável,
        para ablação da ordem)."""
        chosen: list[tuple[Example, float]] = []
        used = 0
        for e, s in self.ranked(task):
            if len(chosen) >= k:
                break
            cost = estimate_tokens(e.render()) + 4
            if used + cost > budget_tokens:
                continue
            chosen.append((e, s))
            used += cost
        if order == "similar_last":
            chosen.reverse()
        elif order == "id":
            chosen.sort(key=lambda es: es[0].id)
        elif order != "similar_first":
            raise ValueError("order: similar_last | similar_first | id")
        return [e for e, _ in chosen]

    def random(self, *, k: int, budget_tokens: int, seed: int = 0) -> list[Example]:
        """Linha de base para o estudo: `k` exemplos ao acaso, mesmo orçamento."""
        rng = random.Random(seed)
        pool = list(self.examples)
        rng.shuffle(pool)
        chosen: list[Example] = []
        used = 0
        for e in pool:
            if len(chosen) >= k:
                break
            cost = estimate_tokens(e.render()) + 4
            if used + cost > budget_tokens:
                continue
            chosen.append(e)
            used += cost
        return chosen


def render_examples(examples: Sequence[Example]) -> str:
    if not examples:
        return ""
    blocks = [f"### Exemplo {i + 1}\n{e.render()}" for i, e in enumerate(examples)]
    return "Exemplos resolvidos do domínio (mesmo formato; o último é o mais parecido com a tarefa):\n\n" + "\n\n".join(blocks)


def pack_rules(rules: Sequence[Rule], budget_tokens: int) -> tuple[list[Rule], int]:
    """As regras que cabem, na ordem dada (mais votadas primeiro). Devolve (regras, descartadas)."""
    out: list[Rule] = []
    used = 0
    dropped = 0
    for r in rules:
        cost = estimate_tokens(r.text) + 2
        if used + cost > budget_tokens:
            dropped += 1
            continue
        out.append(r)
        used += cost
    return out, dropped


def render_rules(rules: Sequence[Rule]) -> str:
    if not rules:
        return ""
    return "## Regras do domínio\n" + "\n".join(f"- {r.text.strip()}" for r in rules)
