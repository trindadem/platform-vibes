"""Evolução reflexiva da especialidade — com holdout, ou não vale.

A família é a da otimização de instrução por linguagem natural: APE (Zhou et
al., 2022) gera e seleciona instruções; OPRO (Yang et al., 2023) usa o próprio
modelo como otimizador sobre um histórico de (instrução, nota); DSPy/MIPRO
(Khattab et al., 2023; Opsahl-Ong et al., 2024) otimiza instruções e
demonstrações por programa; TextGrad (Yuksekgonul et al., 2024) propaga
"gradientes textuais"; e o GEPA (Agrawal et al., 2025) mostra que **refletir
sobre os traços de execução** em linguagem natural e evoluir a instrução por
edições propostas supera RL com uma fração dos rollouts. É este último o
desenho aqui, restrito ao que uma especialidade tem de editável — as regras:

    avaliar em `train` -> refletir sobre as falhas -> propor edições (ExpeL:
    add / edit / upvote / downvote) -> aplicar numa *candidata* -> avaliar em
    `dev` -> aceitar só se melhorou -> repetir; ao fim, uma única leitura em `test`.

O `dev` decide, o `test` só reporta. Sem essa separação, o laço otimiza contra
a régua e o número final não diz nada (Recht et al., 2019) — o estudo mede a
diferença: `holdout=False` seleciona no `train`, e o `test` mostra a
distância. O refletor é injetável: `ProviderReflector` pede ao modelo (JSON);
`HeuristicReflector` é offline e **extrativo** (a regra nasce das palavras da
tarefa e da resposta esperada), o que o torna determinístico e testável — e
declaradamente limitado a generalizar até onde as palavras-chave alcançam.
"""

from __future__ import annotations

import json
import random
from collections import Counter
from collections.abc import Callable, Sequence
from dataclasses import dataclass, field
from typing import Any, Protocol

from ..loop import Agent
from ..memory.core.text import content_words, fold
from ..models.provider import Provider
from .evals import Judge, Lesson, Report, Suite, evaluate
from .spec import Specialization

__all__ = ["EvolutionReport", "HeuristicReflector", "Iteration", "Proposal", "ProviderReflector", "Reflector", "apply_proposals", "evolve"]

OPS: tuple[str, ...] = ("add", "edit", "upvote", "downvote")


@dataclass(frozen=True, slots=True)
class Proposal:
    op: str
    text: str = ""
    rule_id: str = ""
    evidence: tuple[str, ...] = ()
    rationale: str = ""

    def to_dict(self) -> dict[str, Any]:
        return {"op": self.op, "text": self.text, "rule_id": self.rule_id, "evidence": list(self.evidence), "rationale": self.rationale}


class Reflector(Protocol):
    def __call__(self, spec: Specialization, failures: Sequence[Lesson], successes: Sequence[Lesson], *, exclude: frozenset[str] = frozenset()) -> list[Proposal]: ...


# --------------------------------------------------------------------------
# refletor offline (extrativo)
# --------------------------------------------------------------------------


class HeuristicReflector:
    """Sem modelo: regra = frase-chave da tarefa + resposta esperada; votos por casamento literal.

    Palavras que aparecem em mais de `generic_df` das tarefas vistas são
    tratadas como genéricas e não viram frase-chave — o que sobra é o que
    distingue a tarefa. Falhas em assunto que **nenhuma regra ativa cobre**
    vêm primeiro; falhas que contradizem uma regra existente (rótulo ruidoso
    ou regra errada) vêm depois — e `exclude` (textos já rejeitados pelo
    holdout) nunca é proposto de novo. Determinístico dado `seed`."""

    name = "heuristic"

    def __init__(self, *, max_proposals: int = 8, key_words: int = 3, generic_df: float = 0.5, seed: int = 0) -> None:
        self.max_proposals = max_proposals
        self.key_words = key_words
        self.generic_df = generic_df
        self.seed = seed

    def _keys(self, prompt: str, df: Counter[str], n: int) -> list[str]:
        """As palavras mais *raras* da tarefa entre as vistas — nem genéricas (df alto)
        nem únicas (df = 1: números de lote, referências), nem números."""
        cands = []
        for w in dict.fromkeys(content_words(prompt)):
            if w.isdigit() or df[w] <= 1 or df[w] / n > self.generic_df:
                continue
            cands.append(w)
        cands.sort(key=lambda w: (df[w], w))
        return cands[: self.key_words]

    def __call__(self, spec: Specialization, failures: Sequence[Lesson], successes: Sequence[Lesson], *, exclude: frozenset[str] = frozenset()) -> list[Proposal]:
        lessons = [*failures, *successes]
        df: Counter[str] = Counter()
        for le in lessons:
            df.update(set(content_words(le.prompt)))
        n = max(len(lessons), 1)
        proposals: list[Proposal] = []
        active = spec.rules.active()
        active_text = [fold(r.text) for r in active]

        def covered(keys: Sequence[str]) -> bool:
            return any(k in rt for k in keys for rt in active_text)

        # 1. falhas dentro do escopo com resposta esperada textual -> regra nova
        rng = random.Random(self.seed)
        fails = [le for le in failures if le.in_scope and isinstance(le.expected, str) and le.expected.strip()]
        rng.shuffle(fails)
        keyed = [(le, self._keys(le.prompt, df, n)) for le in fails]
        # descoberto antes de disputado: assunto sem regra primeiro, depois por id (estável)
        keyed.sort(key=lambda lk: (covered(lk[1]), lk[0].task_id))
        adds = 0
        for le, keys in keyed:
            if not keys:
                continue
            text = f"Quando a tarefa menciona {', '.join(keys)}: a resposta correta é «{le.expected.strip()}»."
            if text in exclude:
                continue
            proposals.append(Proposal("add", text=text, evidence=(le.task_id,), rationale=f"falhou em {le.task_id}: respondeu {le.answer.strip()[:60]!r}"))
            adds += 1
            if adds >= self.max_proposals:
                break
        # 2. regras que casam com sucessos -> upvote; que sugeriram a resposta errada -> downvote
        #    (um voto por regra por rodada, com toda a evidência junta)
        up: dict[str, list[str]] = {}
        down: dict[str, list[str]] = {}
        for le in successes:
            if not le.in_scope or not isinstance(le.expected, str):
                continue
            keys = self._keys(le.prompt, df, n)
            for r in active:
                rt = fold(r.text)
                if fold(le.expected.strip()) in rt and any(k in rt for k in keys):
                    up.setdefault(r.id, []).append(le.task_id)
        for le in failures:
            if not le.in_scope or le.abstained or not le.answer.strip():
                continue
            keys = self._keys(le.prompt, df, n)
            wrong = fold(le.answer.strip())
            for r in active:
                rt = fold(r.text)
                if wrong and wrong in rt and any(k in rt for k in keys) and (not isinstance(le.expected, str) or fold(le.expected.strip()) not in rt):
                    down.setdefault(r.id, []).append(le.task_id)
        for rid, ev in sorted(up.items()):
            proposals.append(Proposal("upvote", rule_id=rid, evidence=tuple(ev), rationale=f"sustentou {len(ev)} acerto(s)"))
        for rid, ev in sorted(down.items()):
            proposals.append(Proposal("downvote", rule_id=rid, evidence=tuple(ev), rationale=f"sugeriu a resposta errada em {len(ev)} tarefa(s)"))
        return proposals


# --------------------------------------------------------------------------
# refletor por modelo
# --------------------------------------------------------------------------

REFLECT_SYSTEM = (
    "Você melhora as regras de um agente especialista a partir das falhas dele. "
    "Responda SOMENTE com uma lista JSON de propostas; cada proposta é um objeto com "
    '"op" (add | edit | upvote | downvote), "text" (para add/edit), "rule_id" (para edit/upvote/downvote), '
    '"evidence" (ids das tarefas) e "rationale". Regras devem ser gerais, curtas e verificáveis; '
    "não copie a tarefa."
)


class ProviderReflector:
    """Pede ao modelo as propostas (GEPA: reflexão em linguagem natural sobre os traços)."""

    name = "provider"

    def __init__(self, provider: Provider, *, max_failures: int = 12, max_tokens: int = 1200) -> None:
        self.provider = provider
        self.max_failures = max_failures
        self.max_tokens = max_tokens

    def __call__(self, spec: Specialization, failures: Sequence[Lesson], successes: Sequence[Lesson], *, exclude: frozenset[str] = frozenset()) -> list[Proposal]:
        from ..rag.llm import ask

        rules = "\n".join(f"- [{r.id}] (votos {r.votes}) {r.text}" for r in spec.rules.active()) or "(nenhuma)"
        fails = "\n\n".join(f"[{le.task_id}] tarefa: {le.prompt[:400]}\nesperado: {le.expected}\nresposta: {le.answer[:300]}\nmotivo: {le.reason}" for le in failures[: self.max_failures])
        rejected = ("\n\nPropostas já rejeitadas (não repita):\n" + "\n".join(f"- {t}" for t in sorted(exclude))) if exclude else ""
        user = f"Especialidade: {spec.name} ({spec.domain}).\n\nRegras atuais:\n{rules}\n\nFalhas em treino:\n{fails or '(nenhuma)'}\n\nAcertos: {len(successes)}.{rejected}\n\nProponha edições."
        text = ask(self.provider, REFLECT_SYSTEM, user, max_tokens=self.max_tokens)
        return [p for p in parse_proposals(text) if p.text not in exclude]


def parse_proposals(text: str) -> list[Proposal]:
    """Extrai a lista JSON do texto do modelo; lixo em volta é ignorado, item inválido é pulado."""
    try:
        start = text.index("[")
        end = text.rindex("]")
        data = json.loads(text[start : end + 1])
    except (ValueError, json.JSONDecodeError):
        return []
    out: list[Proposal] = []
    for item in data if isinstance(data, list) else []:
        if not isinstance(item, dict):
            continue
        op = str(item.get("op", "")).lower()
        if op not in OPS:
            continue
        ev = item.get("evidence", ())
        if isinstance(ev, str):
            ev = [ev]
        out.append(Proposal(op, str(item.get("text", "")), str(item.get("rule_id", "")), tuple(str(e) for e in ev), str(item.get("rationale", ""))))
    return out


# --------------------------------------------------------------------------
# aplicar e evoluir
# --------------------------------------------------------------------------


def apply_proposals(spec: Specialization, proposals: Sequence[Proposal]) -> dict[str, int]:
    """Aplica na própria `spec` (use uma cópia para candidatas). Devolve a contagem por op."""
    counts = dict.fromkeys(OPS, 0)
    counts["ignored"] = 0
    for p in proposals:
        try:
            if p.op == "add" and p.text.strip():
                spec.rules.add(p.text, evidence=p.evidence, origin="evolve", note=p.rationale)
            elif p.op == "edit" and p.rule_id and p.text.strip():
                spec.rules.edit(p.rule_id, p.text, evidence=p.evidence)
            elif p.op == "upvote" and p.rule_id:
                spec.rules.upvote(p.rule_id, evidence=p.evidence)
            elif p.op == "downvote" and p.rule_id:
                spec.rules.downvote(p.rule_id, evidence=p.evidence)
            else:
                counts["ignored"] += 1
                continue
            counts[p.op] += 1
        except Exception:  # regra desconhecida, texto vazio: proposta inválida não derruba o laço
            counts["ignored"] += 1
    return counts


@dataclass(slots=True)
class Iteration:
    index: int
    proposals: int
    applied: dict[str, int]
    train: float
    dev: float
    accepted: bool
    best_dev_before: float
    rules_active: int
    note: str = ""

    def to_dict(self) -> dict[str, Any]:
        return {"index": self.index, "proposals": self.proposals, "applied": dict(self.applied), "train": round(self.train, 4), "dev": round(self.dev, 4), "accepted": self.accepted, "best_dev_before": round(self.best_dev_before, 4), "rules_active": self.rules_active, "note": self.note}


@dataclass(slots=True)
class EvolutionReport:
    holdout: bool
    reflector: str
    baseline: dict[str, float] = field(default_factory=dict)
    final: dict[str, float] = field(default_factory=dict)
    iterations: list[Iteration] = field(default_factory=list)
    accepted: int = 0
    rules_before: int = 0
    rules_after: int = 0
    evaluations: int = 0

    def to_dict(self) -> dict[str, Any]:
        return {"holdout": self.holdout, "reflector": self.reflector, "baseline": {k: round(v, 4) for k, v in self.baseline.items()}, "final": {k: round(v, 4) for k, v in self.final.items()}, "iterations": [i.to_dict() for i in self.iterations], "accepted": self.accepted, "rules_before": self.rules_before, "rules_after": self.rules_after, "evaluations": self.evaluations}


def evolve(
    spec: Specialization,
    suite: Suite,
    make_agent: Callable[[Specialization], Agent],
    *,
    reflector: Reflector,
    iterations: int = 5,
    min_gain: float = 0.0,
    holdout: bool = True,
    judge: Judge | None = None,
    k: int = 1,
    report_test: bool = True,
) -> tuple[Specialization, EvolutionReport]:
    """Evolui as regras de `spec` e devolve (especialidade evoluída, relatório).

    `make_agent(spec)` compila uma candidata em `Agent` (ex.: `lambda s: compile(s, provider).agent`).
    Com `holdout=True` a seleção é no `dev`; com `False`, no `train` (só para
    mostrar o que isso custa). O `test` é lido no início e no fim, nunca no meio."""
    def score(s: Specialization, split: str) -> Report:
        return evaluate(make_agent(s), suite, split, judge=judge, markers=s.abstain_markers, k=k)

    current = spec.copy()
    rep = EvolutionReport(holdout=holdout, reflector=getattr(reflector, "name", type(reflector).__name__), rules_before=len(current.rules.active()))
    train = score(current, "train")
    dev = score(current, "dev")
    rep.evaluations += 2
    rep.baseline = {"train": train.mean, "dev": dev.mean}
    if report_test:
        rep.baseline["test"] = score(current, "test").mean
        rep.evaluations += 1
    best_select = dev.mean if holdout else train.mean
    tabu: set[str] = set()  # textos de regra rejeitados: o refletor não os propõe de novo
    for i in range(iterations):
        proposals = reflector(current, train.failures(), train.successes(), exclude=frozenset(tabu))
        if not any(p.op in ("add", "edit") for p in proposals):
            rep.iterations.append(Iteration(i, len(proposals), {}, train.mean, dev.mean, False, best_select, len(current.rules.active()), "refletor sem proposta nova"))
            break
        cand = current.copy()
        applied = apply_proposals(cand, proposals)
        c_train = score(cand, "train")
        c_dev = score(cand, "dev")
        rep.evaluations += 2
        selector = c_dev.mean if holdout else c_train.mean
        accepted = selector > best_select + min_gain
        rep.iterations.append(Iteration(i, len(proposals), applied, c_train.mean, c_dev.mean, accepted, best_select, len(cand.rules.active())))
        if accepted:
            current, train, dev = cand, c_train, c_dev
            best_select = selector
            rep.accepted += 1
        else:
            tabu.update(p.text for p in proposals if p.op in ("add", "edit") and p.text)
    rep.final = {"train": train.mean, "dev": dev.mean}
    if report_test:
        rep.final["test"] = score(current, "test").mean
        rep.evaluations += 1
    rep.rules_after = len(current.rules.active())
    return current, rep
