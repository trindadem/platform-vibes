"""O especialista simulado e o domínio sintético: o instrumento de medição.

Nenhum número deste módulo diz algo sobre um modelo real. O `SimulatedExpert`
é um `Provider` determinístico que responde certo **se e somente se** o
contexto que recebeu contém, num mesmo segmento (uma linha de regra, um bloco
de exemplo, uma entrada de glossário), o gatilho da tarefa e a resposta. Ele
mede a *máquina* da especialização — seleção, orçamento, ablação, evolução,
holdout — bit a bit e sem rede, do mesmo modo que o `ScriptedBatchBackend`
mede o lote sem a API. Três hipóteses estão embutidas nele e ficam
declaradas:

1. **Persona não muda a resposta.** É a leitura de Zheng et al. (2023): a
   substância vem do conhecimento, não do papel. No simulador isso é por
   construção; num modelo real é uma hipótese a medir.
2. **Conflito resolve por primazia.** Se duas regras dão respostas diferentes
   para o mesmo gatilho, vale a que aparece primeiro — e as regras são
   renderizadas das mais votadas às menos. É uma escolha, não um fato sobre
   modelos (Liu et al., 2023 medem que começo e fim do contexto pesam mais).
3. **Sem conhecimento, o simulador chuta** uma resposta padrão errada; fora
   do escopo, abstém-se só se a cláusula de abstenção está no system. É a
   calibração que Kadavath et al. (2022) medem em modelos reais, reduzida a
   um interruptor.

`synthetic_domain` escreve um diretório de especialidade completo — tipos de
amostra, protocolos, regras parciais, exemplos parciais, glossário parcial,
suíte com split — e o `truth.json` que o simulador lê. Parte dos rótulos de
`train` é ruidosa (`train_noise`): é o que dá ao holdout algo para pegar.
"""

from __future__ import annotations

import json
import random
import re
from collections.abc import Mapping
from pathlib import Path
from typing import Any

from ..context import MEMORY_CLOSE, MEMORY_OPEN
from ..memory.core.budget import estimate_tokens
from ..memory.core.text import fold
from ..models.provider import Reply, Request
from .evals import Suite, Task
from .spec import Example, Rule

__all__ = ["DEFAULT_WRONG", "SimulatedExpert", "synthetic_domain"]

DEFAULT_WRONG = "PROTO-0"
ABSTAIN_TEXT = "Isso está fora do meu escopo; não posso afirmar."


def _segments(text: str) -> list[str]:
    """Linhas soltas + parágrafos que começam com `###` (um bloco de exemplo), tudo dobrado.

    Um parágrafo termina na linha em branco: o bloco do último exemplo não
    "vaza" para a seção seguinte."""
    text = text.replace(MEMORY_OPEN, "")
    out: list[str] = [ln for ln in text.splitlines() if ln.strip()]
    for para in re.split(r"\n\s*\n", text):
        if para.lstrip().startswith("###"):
            out.append(para)
    return [fold(s) for s in out]


class SimulatedExpert:
    """`Provider` que sabe o que está no contexto — e só isso."""

    model = "simulated-expert"
    effort = "n/a"
    cost_discount = 1.0

    def __init__(self, truth: Mapping[str, str], *, wrong: str = DEFAULT_WRONG, abstain_text: str = ABSTAIN_TEXT) -> None:
        # gatilho (dobrado) -> resposta correta
        self.truth = {fold(k): v for k, v in truth.items()}
        self.wrong = wrong
        self.abstain_text = abstain_text
        self.requests: list[Request] = []
        self.calls = 0
        self.decisions: list[dict[str, Any]] = []

    @staticmethod
    def _text(content: Any) -> str:
        if isinstance(content, str):
            return content
        if isinstance(content, list):
            return "\n".join(str(b.get("text", "")) for b in content if isinstance(b, dict))
        return str(content)

    def complete(self, request: Request) -> Reply:
        self.calls += 1
        self.requests.append(request)
        system = "\n".join(str(b.get("text", "")) for b in request.system)
        first = self._text(request.messages[0]["content"]) if request.messages else ""
        if MEMORY_CLOSE in first:
            memory, _, task = first.partition(MEMORY_CLOSE)
        else:
            memory, task = "", first
        ftask = fold(task)
        triggers = [t for t in self.truth if re.search(r"(?<![a-z0-9])" + re.escape(t) + r"(?![a-z0-9])", ftask)]
        context_segments = _segments(system) + _segments(memory)
        decision: dict[str, Any] = {"triggers": triggers}
        if not triggers:
            # fora do escopo do domínio
            clause = "fora do seu escopo" in fold(system) or "nao sabe" in fold(system)
            answer = self.abstain_text if clause else self.wrong
            decision["kind"] = "abstain" if clause else "confident_error"
        else:
            trig = triggers[0]
            correct = self.truth[trig]
            answer = self.wrong
            decision["kind"] = "guess"
            for seg in context_segments:  # primazia: o primeiro segmento que casa decide
                if re.search(r"(?<![a-z0-9])" + re.escape(trig) + r"(?![a-z0-9])", seg):
                    m = re.search(r"proto-\d+", seg)
                    if m:
                        answer = m.group(0).upper()
                        decision["kind"] = "known" if answer == correct else "misled"
                        break
        self.decisions.append(decision)
        text = answer if answer == self.abstain_text else f"Protocolo: {answer}."
        usage = {"input_tokens": estimate_tokens(system) + estimate_tokens(first), "output_tokens": estimate_tokens(text)}
        return Reply(content=[{"type": "text", "text": text}], stop_reason="end_turn", usage=usage, model=self.model)


# --------------------------------------------------------------------------
# domínio sintético
# --------------------------------------------------------------------------

_MATERIALS = ["plasma", "solo", "sedimento", "lixiviado", "biofilme", "polímero", "efluente", "cerâmica", "aerossol", "resina", "salmoura", "lodo", "tecido", "grafeno", "esporo", "argila", "vidro", "látex"]
_PHRASINGS = [
    "Chegou uma amostra de {m} para análise. Qual protocolo aplicar?",
    "Recebemos {m} do lote {n}; qual é o protocolo correto?",
    "Para uma amostra de {m}, que protocolo o laboratório usa?",
    "O técnico perguntou qual protocolo vale para {m}. Responda com o código.",
    "Amostra classificada como {m} (referência {n}): indique o protocolo.",
    "Qual protocolo se aplica quando o material é {m}?",
    "Precisamos processar {m} hoje; qual o código do protocolo?",
]
_OUT_OF_SCOPE = [
    "Qual é a alíquota de ICMS para equipamentos importados?",
    "Como calcular o imposto de renda sobre bolsa de pesquisa?",
    "Qual o melhor tratamento para uma infecção urinária?",
    "Quantos dias de férias um técnico tem por ano?",
    "Qual a capital da Mongólia?",
    "Como configurar o roteador do laboratório para Wi-Fi 6?",
    "Qual a dosagem de paracetamol para adultos?",
    "O contrato de manutenção da centrífuga vence quando?",
    "Como preencher a declaração de bens do servidor?",
    "Quais os sintomas de intoxicação alimentar?",
    "Qual a previsão do tempo para amanhã?",
    "Como funciona a aposentadoria especial?",
]


def synthetic_domain(
    root: str | Path,
    *,
    n_types: int = 12,
    tasks_per_type: int = 5,
    out_of_scope: int = 10,
    covered_by_rules: int = 4,
    covered_by_examples: int = 4,
    covered_by_glossary: int = 2,
    train_noise: float = 0.15,
    seed: int = 0,
    budgets: Mapping[str, int] | None = None,
    examples_k: int = 4,
) -> tuple[Path, dict[str, str]]:
    """Escreve a especialidade sintética em `root` e devolve (diretório, verdade gatilho -> protocolo).

    Cobertura: `covered_by_rules` tipos têm regra do autor, `covered_by_examples`
    outros têm exemplo, `covered_by_glossary` outros têm o protocolo na
    definição do glossário; o resto só a evolução descobre (a partir das
    falhas de `train`). Os tipos cobertos são disjuntos por construção."""
    if covered_by_rules + covered_by_examples + covered_by_glossary > n_types:
        raise ValueError("cobertura maior que o número de tipos")
    if n_types > len(_MATERIALS):
        raise ValueError(f"no máximo {len(_MATERIALS)} tipos")
    rng = random.Random(seed)
    materials = _MATERIALS[:n_types]
    protocols = rng.sample(range(10, 99), n_types)
    truth = {m: f"PROTO-{p}" for m, p in zip(materials, protocols, strict=True)}
    d = Path(root)
    d.mkdir(parents=True, exist_ok=True)

    spec = "\n".join([
        "---",
        "name: protocolos-lab",
        "version: 1.0.0",
        "domain: protocolos de processamento de amostras do laboratório",
        "scope_in: [escolha de protocolo por tipo de amostra, códigos PROTO-n]",
        "scope_out: [tributação e finanças, saúde e medicina, administração de pessoal, informática, geografia]",
        "abstain: true",
        f"budget_rules: {int((budgets or {}).get('rules', 800))}",
        f"budget_examples: {int((budgets or {}).get('examples', 1200))}",
        f"budget_glossary: {int((budgets or {}).get('glossary', 300))}",
        f"examples_k: {examples_k}",
        "---",
        "Você é o especialista em protocolos de processamento de amostras do laboratório.",
        "Responda com o código do protocolo (PROTO-n) e nada mais. Seja direto.",
        "",
    ])
    (d / "SPEC.md").write_text(spec, encoding="utf-8")

    by_rule = materials[:covered_by_rules]
    by_example = materials[covered_by_rules : covered_by_rules + covered_by_examples]
    by_glossary = materials[covered_by_rules + covered_by_examples : covered_by_rules + covered_by_examples + covered_by_glossary]

    rules_dir = d / "rules"
    rules_dir.mkdir(exist_ok=True)
    for p in rules_dir.glob("*.md"):
        p.unlink()
    for i, m in enumerate(by_rule):
        r = Rule(f"r{i + 1}-{m}", f"Amostras de {m} seguem o {truth[m]}.", evidence=("manual",), origin="author")
        (rules_dir / f"{r.id}.md").write_text(r.to_markdown(), encoding="utf-8")

    ex_dir = d / "examples"
    ex_dir.mkdir(exist_ok=True)
    for p in ex_dir.glob("*.md"):
        p.unlink()
    for i, m in enumerate(by_example):
        e = Example(f"e{i + 1}-{m}", _PHRASINGS[0].format(m=m, n=100 + i), truth[m], f"O material é {m}; o manual atribui {truth[m]} a esse tipo.", (m,))
        (ex_dir / f"{e.id}.md").write_text(e.to_markdown(), encoding="utf-8")

    gl = ["# Glossário", ""]
    for m in materials:
        if m in by_glossary:
            gl.append(f"- {m}: material do tipo {m}; o manual atribui o {truth[m]} a este tipo")
        else:
            gl.append(f"- {m}: material do tipo {m}, recebido com ficha de cadeia de custódia")
    (d / "glossary.md").write_text("\n".join(gl) + "\n", encoding="utf-8")

    tasks: list[Task] = []
    splits = ["train", "train", "train", "dev", "test"]
    noisy: list[str] = []
    for ti, m in enumerate(materials):
        for j in range(tasks_per_type):
            phr = _PHRASINGS[(ti + j) % len(_PHRASINGS)]
            split = splits[j % len(splits)]
            expected = truth[m]
            tid = f"{m}-{j}"
            if split == "train" and rng.random() < train_noise:
                others = [p for p in truth.values() if p != expected]
                expected = rng.choice(others)
                noisy.append(tid)
            tasks.append(Task(tid, phr.format(m=m, n=rng.randint(10, 999)), expected, "contains", split, True, (m,), {"noisy": tid in noisy}))
    for j in range(out_of_scope):
        tasks.append(Task(f"fora-{j}", _OUT_OF_SCOPE[j % len(_OUT_OF_SCOPE)], "", "contains", splits[j % len(splits)], False, ("fora",)))
    suite = Suite(tasks, name="protocolos-lab")
    suite.save(d / "evals" / "tasks.jsonl")
    (d / "evals" / "truth.json").write_text(json.dumps({"truth": truth, "noisy_train_tasks": noisy, "covered": {"rules": by_rule, "examples": by_example, "glossary": by_glossary, "uncovered": materials[covered_by_rules + covered_by_examples + covered_by_glossary :]}}, ensure_ascii=False, indent=2), encoding="utf-8")
    return d, truth
