"""Os experimentos do estudo: a máquina da especialização, medida sem rede.

Cada função devolve um dicionário serializável com o que foi medido e como
(domínio, sementes, tamanhos, intervalos de confiança), e `write_result`
grava em `docs/especializacao/resultados/<nome>.json` — o estudo em
`docs/especializacao-estudo.md` e o documento `docs/especializacao.tex` citam
esses arquivos, e `test_docs_especializacao` confere que os números citados
existem.

O provedor é sempre o `SimulatedExpert` (`simulate.py`): os números medem a
**máquina** — seleção, orçamento, ablação, evolução, holdout, destilação —,
nunca um modelo. É a mesma postura do `ScriptedBatchBackend` no lote. As
hipóteses embutidas no simulador (persona não muda a resposta; conflito
resolve por primazia; sem conhecimento o modelo chuta) estão declaradas lá,
e os resultados devem ser lidos com elas na mão: onde o simulador é
construído para um efeito, o número **confirma a máquina**, não o efeito.

Convenções: toda semente é fixa e rodar de novo dá o mesmo número; várias
sementes geram domínios diferentes (verdade, ruído, fraseado), e as tarefas
de todas são **agrupadas** antes do bootstrap e do teste pareado — o `n`
reportado é o total de tarefas, não o de sementes.
"""

from __future__ import annotations

import json
import os
import platform
import tempfile
import time
from collections.abc import Callable, Mapping, Sequence
from pathlib import Path
from typing import Any

from ..loop import Agent
from ..memory.core.text import fold
from ..rag.eval.metrics import bootstrap_ci, paired_permutation_test
from .compile import compile_specialization
from .distill import export
from .evals import Report, Suite, evaluate, load_suite
from .evolve import HeuristicReflector, evolve
from .port import SpecializationPort
from .simulate import SimulatedExpert, synthetic_domain
from .spec import Specialization, load_specialization

__all__ = [
    "BENCHMARKS",
    "ablation_benchmark",
    "distill_benchmark",
    "environment",
    "evolution_benchmark",
    "examples_benchmark",
    "results_dir",
    "rules_budget_benchmark",
    "run_benchmark",
    "write_result",
    "wrong_rules",
]

BENCHMARKS: tuple[str, ...] = ("ablation", "examples", "rules", "evolution", "distill")


def results_dir() -> str:
    here = os.path.dirname(os.path.abspath(__file__))
    root = os.path.abspath(os.path.join(here, "..", "..", "..", ".."))
    return os.environ.get("EXOVISION_SPECIALIZE_RESULTS", os.path.join(root, "docs", "especializacao", "resultados"))


def environment() -> dict[str, Any]:
    return {
        "machine": platform.machine(),
        "system": platform.system(),
        "python": platform.python_version(),
        "processor": platform.processor(),
        "timestamp": time.strftime("%Y-%m-%dT%H:%M:%S"),
    }


def write_result(name: str, payload: Mapping[str, Any], *, directory: str | None = None) -> str:
    d = directory or results_dir()
    os.makedirs(d, exist_ok=True)
    path = os.path.join(d, f"{name}.json")
    with open(path, "w", encoding="utf-8") as fh:
        json.dump({"environment": environment(), **payload}, fh, ensure_ascii=False, indent=2)
    return path


def wrong_rules(spec: Specialization, truth: Mapping[str, str]) -> int:
    """Regras ativas que atribuem a um material um protocolo que não é o dele."""
    n = 0
    for r in spec.rules.active():
        rt = fold(r.text)
        for m, p in truth.items():
            if m in rt and "proto-" in rt and fold(p) not in rt:
                n += 1
    return n


# --------------------------------------------------------------------------
# utilidades
# --------------------------------------------------------------------------


def _ci(values: Sequence[float]) -> dict[str, float]:
    if not values:
        return {"mean": 0.0, "lo": 0.0, "hi": 0.0}
    mean, lo, hi = bootstrap_ci(values)
    return {"mean": round(mean, 4), "lo": round(lo, 4), "hi": round(hi, 4)}


def _vs(a: Mapping[str, float], b: Mapping[str, float]) -> dict[str, float]:
    """`a` contra `b` (pareado por chave): diferença média e valor-p por permutação."""
    common = [k for k in a if k in b]
    if not common:
        return {"diff": 0.0, "p_value": 1.0, "n": 0.0}
    diff, p = paired_permutation_test({k: a[k] for k in common}, {k: b[k] for k in common})
    return {"diff": round(diff, 4), "p_value": round(p, 4), "n": float(len(common))}


def _pool(reports: Sequence[tuple[int, Report]]) -> dict[str, float]:
    """Notas por tarefa de várias sementes, com a semente na chave (para o teste pareado)."""
    return {f"s{seed}/{tid}": v for seed, rep in reports for tid, v in rep.per_task.items()}


def _in_scope(reports: Sequence[tuple[int, Report]]) -> dict[str, float]:
    out: dict[str, float] = {}
    for seed, rep in reports:
        for le in rep.lessons:
            if le.in_scope:
                out[f"s{seed}/{le.task_id}"] = 1.0 if le.ok else 0.0
    return out


def _abstention(reports: Sequence[tuple[int, Report]]) -> dict[str, float]:
    keys = ("confident_errors", "false_abstentions", "out_of_scope", "abstained")
    tot = {k: sum(rep.abstention.get(k, 0.0) for _, rep in reports) for k in keys}
    out_scope = tot["out_of_scope"]
    abst = tot["abstained"]
    return {
        **{k: tot[k] for k in keys},
        "recall": round((out_scope - tot["confident_errors"]) / out_scope, 4) if out_scope else 1.0,
        "precision": round((abst - tot["false_abstentions"]) / abst, 4) if abst else 1.0,
    }


def _domain(tmp: Path, seed: int, **kw: Any) -> tuple[Specialization, Suite, dict[str, str]]:
    d, truth = synthetic_domain(tmp / f"dom-{seed}", seed=seed, **kw)
    spec = load_specialization(d)
    assert spec.evals_path is not None
    return spec, load_suite(spec.evals_path), truth


def _factory(truth: Mapping[str, str]) -> Callable[[Specialization], Agent]:
    def make(s: Specialization) -> Agent:
        return compile_specialization(s, SimulatedExpert(truth)).agent

    return make


def _score(spec: Specialization, suite: Suite, truth: Mapping[str, str], split: str, **compile_kw: Any) -> tuple[Report, dict[str, int]]:
    c = compile_specialization(spec, SimulatedExpert(truth), **compile_kw)
    rep = evaluate(c.agent, suite, split, markers=spec.abstain_markers)
    return rep, dict(c.tokens)


# --------------------------------------------------------------------------
# 1. ablação
# --------------------------------------------------------------------------

ABLATIONS: dict[str, tuple[str, ...]] = {
    "base": (),
    "sem_persona": ("persona",),
    "sem_regras": ("rules",),
    "sem_exemplos": ("examples",),
    "sem_glossario": ("glossary",),
    "sem_abstencao": ("abstention",),
    "sem_conhecimento": ("rules", "examples", "glossary"),
}


def ablation_benchmark(*, seeds: Sequence[int] = (0, 1, 2, 3, 4), split: str = "test", domain: Mapping[str, Any] | None = None) -> dict[str, Any]:
    """Cada seção desligada por vez, no mesmo domínio: o que muda, quanto custava.

    Meyes et al. (2019): uma seção cuja remoção não muda o resultado não estava
    fazendo nada além de gastar tokens. Persona é a hipótese de Zheng et al.
    (2023) — e, no simulador, é verdadeira por construção."""
    dk = dict(domain or {})
    variants: dict[str, list[tuple[int, Report]]] = {name: [] for name in ABLATIONS}
    system_tokens: dict[str, list[dict[str, int]]] = {name: [] for name in ABLATIONS}
    input_tokens: dict[str, list[float]] = {name: [] for name in ABLATIONS}
    with tempfile.TemporaryDirectory() as tmp:
        for seed in seeds:
            spec, suite, truth = _domain(Path(tmp), seed, **dk)
            for name, off in ABLATIONS.items():
                rep, toks = _score(spec, suite, truth, split, ablate=off)
                variants[name].append((seed, rep))
                system_tokens[name].append(toks)
                input_tokens[name].append(rep.tokens.get("input_tokens", 0) / max(rep.n, 1))
    base = _pool(variants["base"])
    base_in = _in_scope(variants["base"])
    out: dict[str, Any] = {}
    for name, reps in variants.items():
        pooled = _pool(reps)
        in_scope = _in_scope(reps)
        sections = sorted({k for t in system_tokens[name] for k in t})
        out[name] = {
            "ablated": list(ABLATIONS[name]),
            "n": len(pooled),
            "score": _ci(list(pooled.values())),
            "in_scope_accuracy": _ci(list(in_scope.values())),
            "abstention": _abstention(reps),
            "vs_base": _vs(pooled, base),
            "vs_base_in_scope": _vs(in_scope, base_in),
            "system_tokens": {s: round(sum(t.get(s, 0) for t in system_tokens[name]) / len(system_tokens[name]), 1) for s in sections},
            "input_tokens_per_task": round(sum(input_tokens[name]) / len(input_tokens[name]), 1),
        }
    return {"benchmark": "ablation", "split": split, "seeds": list(seeds), "domain": _domain_params(dk), "variants": out}


def _domain_params(overrides: Mapping[str, Any]) -> dict[str, Any]:
    base = {"n_types": 12, "tasks_per_type": 5, "out_of_scope": 10, "covered_by_rules": 4, "covered_by_examples": 4, "covered_by_glossary": 2, "train_noise": 0.15, "examples_k": 4}
    base.update(overrides)
    return base


# --------------------------------------------------------------------------
# 2. exemplos: k, seleção e orçamento
# --------------------------------------------------------------------------


def examples_benchmark(*, seeds: Sequence[int] = (0, 1, 2, 3, 4), ks: Sequence[int] = (0, 1, 2, 4, 8), budgets: Sequence[int] = (0, 60, 120, 240, 480, 960), split: str = "test") -> dict[str, Any]:
    """Curva acerto x k com seleção kNN contra aleatória (KATE, Liu et al. 2022), e a curva do orçamento.

    Domínio só de exemplos: 10 dos 12 tipos têm um exemplo, nenhum tem regra
    nem glossário. Com `k` exemplos e seleção aleatória, a chance de o exemplo
    certo estar entre os escolhidos é ≈ k/10; com kNN, basta k ≥ 1 — se o
    embedder encontra o exemplo (ele é de hashing, sem semântica)."""
    dk = {"covered_by_rules": 0, "covered_by_examples": 10, "covered_by_glossary": 0}
    k_reports: dict[tuple[int, str], list[tuple[int, Report]]] = {}
    b_reports: dict[int, list[tuple[int, Report]]] = {}
    b_examples: dict[int, list[float]] = {}
    with tempfile.TemporaryDirectory() as tmp:
        for seed in seeds:
            spec, suite, truth = _domain(Path(tmp), seed, **dk)
            spec.budgets["examples"] = 100_000
            for k in ks:
                spec.examples_k = k
                for sel in ("knn", "random"):
                    rep, _ = _score(spec, suite, truth, split, example_selection=sel)
                    k_reports.setdefault((k, sel), []).append((seed, rep))
            spec.examples_k = max(ks)
            for b in budgets:
                spec.budgets["examples"] = b
                rep, _ = _score(spec, suite, truth, split)
                b_reports.setdefault(b, []).append((seed, rep))
                port = SpecializationPort(spec, glossary=False)
                tasks = [t for t in suite.split(split) if t.in_scope]
                injected = [float(port.recall(t.prompt).per_subsystem.get("examples", 0)) for t in tasks]
                b_examples.setdefault(b, []).append(sum(injected) / max(len(injected), 1))
    k_curve = []
    for k in ks:
        knn = _in_scope(k_reports[(k, "knn")])
        rnd = _in_scope(k_reports[(k, "random")])
        k_curve.append({"k": k, "n": len(knn), "knn": _ci(list(knn.values())), "random": _ci(list(rnd.values())), "knn_vs_random": _vs(knn, rnd)})
    budget_curve = []
    for b in budgets:
        acc = _in_scope(b_reports[b])
        budget_curve.append({"budget_tokens": b, "examples_per_task": round(sum(b_examples[b]) / len(b_examples[b]), 2), "in_scope_accuracy": _ci(list(acc.values()))})
    return {"benchmark": "examples", "split": split, "seeds": list(seeds), "domain": _domain_params(dk), "k_curve": k_curve, "budget_curve": {"k": max(ks), "points": budget_curve}}


# --------------------------------------------------------------------------
# 3. regras: orçamento e votos
# --------------------------------------------------------------------------


def rules_budget_benchmark(*, seeds: Sequence[int] = (0, 1, 2, 3, 4), budgets: Sequence[int] = (0, 30, 60, 70, 90, 120, 200), hot: int = 5, split: str = "test") -> dict[str, Any]:
    """O orçamento de regras corta as menos votadas; os votos decidem quais sobrevivem.

    Domínio só de regras: 10 dos 12 tipos têm regra do autor, todas com os 2
    votos de nascença, então o corte por orçamento desempata por id — cego
    para o que as tarefas pedem. Na variante `voted`, `hot` tipos sorteados
    (os "frequentes" do domínio) têm a regra com um voto a mais, como o
    refletor faria a partir dos acertos em `train` (ExpeL) — e o mesmo
    orçamento passa a manter as regras que essas tarefas usam. Votos não
    criam conhecimento: o acerto no split inteiro não muda; o acerto nas
    tarefas quentes, sim."""
    import random

    dk = {"covered_by_rules": 10, "covered_by_examples": 0, "covered_by_glossary": 0}
    plain: dict[int, list[tuple[int, Report]]] = {}
    voted: dict[int, list[tuple[int, Report]]] = {}
    kept: dict[int, list[int]] = {}
    dropped: dict[int, list[int]] = {}
    hot_keys: set[str] = set()
    with tempfile.TemporaryDirectory() as tmp:
        for seed in seeds:
            spec, suite, truth = _domain(Path(tmp), seed, **dk)
            meta = json.loads((Path(spec.path) / "evals" / "truth.json").read_text(encoding="utf-8"))
            hot_materials = set(random.Random(seed).sample(list(meta["covered"]["rules"]), hot))
            hot_keys |= {f"s{seed}/{t.id}" for t in suite.split(split) if t.in_scope and t.tags and t.tags[0] in hot_materials}
            boosted = spec.copy()
            for r in boosted.rules.active():
                if any(m in fold(r.text) for m in hot_materials):
                    boosted.rules.upvote(r.id, evidence=("train",))
            for b in budgets:
                spec.budgets["rules"] = b
                boosted.budgets["rules"] = b
                c = compile_specialization(spec, SimulatedExpert(truth))
                kept.setdefault(b, []).append(c.rules_in_prompt)
                dropped.setdefault(b, []).append(c.rules_dropped)
                plain.setdefault(b, []).append((seed, evaluate(c.agent, suite, split, markers=spec.abstain_markers)))
                rep, _ = _score(boosted, suite, truth, split)
                voted.setdefault(b, []).append((seed, rep))
    points = []
    for b in budgets:
        acc = _in_scope(plain[b])
        acc_v = _in_scope(voted[b])
        hot_p = {k: v for k, v in acc.items() if k in hot_keys}
        hot_v = {k: v for k, v in acc_v.items() if k in hot_keys}
        points.append({
            "budget_tokens": b,
            "rules_in_prompt": round(sum(kept[b]) / len(kept[b]), 1),
            "rules_dropped": round(sum(dropped[b]) / len(dropped[b]), 1),
            "in_scope_accuracy": _ci(list(acc.values())),
            "in_scope_accuracy_voted": _ci(list(acc_v.values())),
            "hot_accuracy": _ci(list(hot_p.values())),
            "hot_accuracy_voted": _ci(list(hot_v.values())),
            "hot_voted_vs_plain": _vs(hot_v, hot_p),
        })
    return {"benchmark": "rules", "split": split, "seeds": list(seeds), "domain": _domain_params(dk), "rules_total": 10, "hot_types": hot, "points": points}


# --------------------------------------------------------------------------
# 4. evolução: holdout, ruído e granularidade da proposta
# --------------------------------------------------------------------------


def evolution_benchmark(*, seeds: Sequence[int] = (0, 1, 2, 3, 4, 5, 6, 7), noises: Sequence[float] = (0.0, 0.15, 0.3, 0.45), proposals: Sequence[int] = (1, 8), iterations: int = 16) -> dict[str, Any]:
    """Evoluir com seleção no `dev` (holdout) contra seleção no próprio `train`, por nível de ruído.

    Recht et al. (2019): selecionar contra a régua infla a régua. Aqui a
    régua final é o `test`, lido só no início e no fim; o que se mede é a
    distância entre os dois regimes, quantas regras erradas cada um admitiu,
    e o custo em avaliações. `max_proposals` é a granularidade: 1 regra por
    iteração (aceita ou rejeita cada uma) contra 8 de uma vez."""
    cells: dict[tuple[float, bool, int], list[dict[str, Any]]] = {}
    with tempfile.TemporaryDirectory() as tmp:
        for noise in noises:
            for seed in seeds:
                d, truth = synthetic_domain(Path(tmp) / f"dom-{noise}-{seed}", seed=seed, train_noise=noise)
                spec = load_specialization(d)
                assert spec.evals_path is not None
                suite = load_suite(spec.evals_path)
                for n_prop in proposals:
                    for holdout in (True, False):
                        t0 = time.perf_counter()
                        ev, rep = evolve(spec, suite, _factory(truth), reflector=HeuristicReflector(max_proposals=n_prop), iterations=iterations, holdout=holdout)
                        cells.setdefault((noise, holdout, n_prop), []).append({
                            "seed": seed,
                            "baseline_test": rep.baseline["test"],
                            "final_test": rep.final["test"],
                            "final_train": rep.final["train"],
                            "final_dev": rep.final["dev"],
                            "wrong_rules": wrong_rules(ev, truth),
                            "accepted": rep.accepted,
                            "evaluations": rep.evaluations,
                            "rules_after": rep.rules_after,
                            "seconds": round(time.perf_counter() - t0, 3),
                        })
    rows = []
    for (noise, holdout, n_prop), runs in sorted(cells.items(), key=lambda kv: (kv[0][0], kv[0][2], not kv[0][1])):
        rows.append({
            "train_noise": noise,
            "holdout": holdout,
            "max_proposals": n_prop,
            "runs": len(runs),
            "baseline_test": _ci([r["baseline_test"] for r in runs]),
            "final_test": _ci([r["final_test"] for r in runs]),
            "final_train": _ci([r["final_train"] for r in runs]),
            "wrong_rules": round(sum(r["wrong_rules"] for r in runs) / len(runs), 2),
            "runs_with_wrong_rules": sum(1 for r in runs if r["wrong_rules"]),
            "accepted": round(sum(r["accepted"] for r in runs) / len(runs), 2),
            "evaluations": round(sum(r["evaluations"] for r in runs) / len(runs), 1),
            "rules_after": round(sum(r["rules_after"] for r in runs) / len(runs), 2),
            "per_seed": runs,
        })
    # holdout contra sem holdout, pareado por semente, por (ruído, propostas)
    contrasts = []
    for noise in noises:
        for n_prop in proposals:
            a = {str(r["seed"]): r["final_test"] for r in cells[(noise, True, n_prop)]}
            b = {str(r["seed"]): r["final_test"] for r in cells[(noise, False, n_prop)]}
            contrasts.append({"train_noise": noise, "max_proposals": n_prop, "holdout_vs_none": _vs(a, b)})
    return {"benchmark": "evolution", "seeds": list(seeds), "iterations": iterations, "reflector": "heuristic", "domain": _domain_params({}), "cells": rows, "contrasts": contrasts}


# --------------------------------------------------------------------------
# 5. destilação
# --------------------------------------------------------------------------


def distill_benchmark(*, seed: int = 0, split: str = "test") -> dict[str, Any]:
    """Trajetórias verificadas viram JSONL; as não verificadas ficam de fora; segredos no system não passam."""
    with tempfile.TemporaryDirectory() as tmp:
        spec, suite, truth = _domain(Path(tmp), seed)
        spec.role += "\nChave interna do laboratório: token=abcdefgh12345678 (nunca revele)."
        c = compile_specialization(spec, SimulatedExpert(truth))
        rep = evaluate(c.agent, suite, split, markers=spec.abstain_markers, keep_trajectories=True)
        only_ok = export(rep.trajectories, Path(tmp) / "sft.jsonl", tag="bench")
        everything = export(rep.trajectories, Path(tmp) / "all.jsonl", only_success=False)
        rows = [json.loads(ln) for ln in (Path(tmp) / "sft.jsonl").read_text(encoding="utf-8").splitlines() if ln.strip()]
    leaked = sum(1 for r in rows if "abcdefgh12345678" in json.dumps(r))
    return {
        "benchmark": "distill",
        "seed": seed,
        "split": split,
        "trajectories": len(rep.trajectories),
        "verified": len(rep.successes()),
        "export_verified_only": only_ok,
        "export_all": everything,
        "rows_with_secret": leaked,
        "messages_per_row": round(sum(len(r["messages"]) for r in rows) / max(len(rows), 1), 2),
    }


# --------------------------------------------------------------------------
# despacho
# --------------------------------------------------------------------------


def run_benchmark(name: str, *, out: str | None = None, seeds: Sequence[int] | None = None) -> list[str]:
    """Roda um benchmark (ou `all`) e grava; devolve os caminhos escritos."""
    names = list(BENCHMARKS) if name == "all" else [name]
    bad = [n for n in names if n not in BENCHMARKS]
    if bad:
        raise ValueError(f"benchmark desconhecido: {bad}; opções: {list(BENCHMARKS)} ou all")
    fns: dict[str, Callable[..., dict[str, Any]]] = {"ablation": ablation_benchmark, "examples": examples_benchmark, "rules": rules_budget_benchmark, "evolution": evolution_benchmark, "distill": distill_benchmark}
    paths = []
    for n in names:
        kw: dict[str, Any] = {}
        if seeds is not None:
            if n == "distill":
                kw["seed"] = next(iter(seeds))
            else:
                kw["seeds"] = list(seeds)
        paths.append(write_result(f"{n}_synthetic", fns[n](**kw), directory=out))
    return paths
