"""`exovision-agent specialize`: a especialidade pela linha de comando.

    exovision-agent specialize synth ./protocolos-lab --seed 0          # domínio sintético com truth.json
    exovision-agent specialize show ./protocolos-lab --system           # o que entra no prompt, e quanto custa
    exovision-agent specialize eval ./protocolos-lab --split test --simulated
    exovision-agent specialize ablate ./protocolos-lab --simulated       # cada seção desligada por vez
    exovision-agent specialize evolve ./protocolos-lab --simulated --iterations 10 --save
    exovision-agent specialize eval ./esp --split dev --lessons --distill sft.jsonl   # modelo real
    exovision-agent specialize bench all                                 # docs/especializacao/resultados/

O provedor segue a regra do `run`: sem `--simulated` nem `--scripted`, é o
o driver de `--model` (`[tipo:]modelo`; credencial do ambiente). `--simulated` lê o
`evals/truth.json` do diretório (escrito por `synth`) e responde certo se e
só se o contexto contém o gatilho e a resposta — mede a máquina, não o modelo.
"""

from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path
from typing import Any

from ..models import make_provider
from ..models.provider import Provider, Reply, ScriptedProvider
from .bench import BENCHMARKS, run_benchmark
from .compile import SECTIONS, compile_specialization
from .distill import export
from .evals import Report, compare, evaluate, load_suite, write_lessons
from .evolve import HeuristicReflector, ProviderReflector, Reflector, evolve
from .simulate import SimulatedExpert, synthetic_domain
from .spec import Specialization, load_specialization

__all__ = ["add_parser"]


def _provider(args: argparse.Namespace, spec: Specialization) -> Provider:
    if getattr(args, "simulated", False):
        truth_path = Path(spec.path) / "evals" / "truth.json"
        if not truth_path.is_file():
            raise SystemExit(f"--simulated precisa de {truth_path} (gerado por `specialize synth`)")
        truth = json.loads(truth_path.read_text(encoding="utf-8")).get("truth", {})
        return SimulatedExpert(truth)
    if getattr(args, "scripted", None):
        data = json.loads(Path(args.scripted).read_text(encoding="utf-8"))
        return ScriptedProvider([Reply(content=item["content"], stop_reason=item.get("stop_reason", "end_turn"), usage=item.get("usage", {})) for item in data], model="scripted")
    return make_provider(getattr(args, "model", "") or "", effort=getattr(args, "effort", "") or "")


def _suite(spec: Specialization):
    if spec.evals_path is None:
        raise SystemExit(f"{spec.path} não tem evals/tasks.jsonl")
    return load_suite(spec.evals_path)


def _print_report(rep: Report, *, label: str = "") -> None:
    head = f"{label}: " if label else ""
    print(f"{head}{rep.split} n={rep.n} k={rep.k} média={rep.mean:.3f} IC95=[{rep.ci[0]:.3f}, {rep.ci[1]:.3f}] acerto_no_escopo={rep.in_scope_accuracy:.3f}")
    a = rep.abstention
    print(f"  abstenção: fora_do_escopo={int(a.get('out_of_scope', 0))} erros_confiantes={int(a.get('confident_errors', 0))} falsas_abstenções={int(a.get('false_abstentions', 0))} recall={a.get('recall', 0):.2f} precisão={a.get('precision', 0):.2f}")
    print(f"  tokens={rep.tokens} custo=US${rep.cost_usd:.4f} tempo={rep.seconds:.2f}s")


# --------------------------------------------------------------------------
# comandos
# --------------------------------------------------------------------------


def cmd_show(args: argparse.Namespace) -> int:
    spec = load_specialization(args.spec)
    c = compile_specialization(spec, SimulatedExpert({}), ablate=args.ablate or ())
    out: dict[str, Any] = {**spec.to_dict(), "compiled": c.to_dict()}
    if args.system:
        print(c.system_text)
        print()
    print(json.dumps(out, ensure_ascii=False, indent=2))
    return 0


def cmd_synth(args: argparse.Namespace) -> int:
    d, truth = synthetic_domain(
        args.spec,
        n_types=args.n_types,
        tasks_per_type=args.tasks_per_type,
        out_of_scope=args.out_of_scope,
        covered_by_rules=args.rules,
        covered_by_examples=args.examples,
        covered_by_glossary=args.glossary,
        train_noise=args.noise,
        seed=args.seed,
    )
    spec = load_specialization(d)
    print(json.dumps({"path": str(d), "types": len(truth), **spec.to_dict(), "suite": _suite(spec).counts()}, ensure_ascii=False, indent=2))
    return 0


def cmd_eval(args: argparse.Namespace) -> int:
    spec = load_specialization(args.spec)
    suite = _suite(spec)
    c = compile_specialization(spec, _provider(args, spec), ablate=args.ablate or ())
    rep = evaluate(c.agent, suite, args.split, markers=spec.abstain_markers, k=args.k, keep_trajectories=bool(args.distill))
    if args.json:
        print(json.dumps({"compiled": c.to_dict(), "report": rep.to_dict()}, ensure_ascii=False, indent=2))
    else:
        _print_report(rep, label=spec.ref)
        for le in rep.failures():
            print(f"  ✗ {le.task_id}: {le.reason} — respondeu {le.answer.strip()[:80]!r}")
    if args.lessons:
        n = write_lessons(spec.lessons_path, rep.lessons)
        print(f"{n} lições em {spec.lessons_path}", file=sys.stderr)
    if args.distill:
        stats = export(rep.trajectories, args.distill, only_success=not args.distill_all, tag=spec.ref)
        print(f"destilação: {stats} -> {args.distill}", file=sys.stderr)
    return 0 if rep.n == 0 or rep.mean > 0 else 1


def cmd_ablate(args: argparse.Namespace) -> int:
    spec = load_specialization(args.spec)
    suite = _suite(spec)
    provider = _provider(args, spec)
    base = evaluate(compile_specialization(spec, provider).agent, suite, args.split, markers=spec.abstain_markers)
    rows: list[dict[str, Any]] = [{"ablated": "-", "mean": base.mean, "in_scope": base.in_scope_accuracy, "confident_errors": base.abstention.get("confident_errors", 0), "diff": 0.0, "p_value": 1.0}]
    for section in args.sections or [s for s in SECTIONS if s not in ("tools", "skills", "knowledge")]:
        rep = evaluate(compile_specialization(spec, provider, ablate=[section]).agent, suite, args.split, markers=spec.abstain_markers)
        cmp = compare(rep, base)
        rows.append({"ablated": section, "mean": rep.mean, "in_scope": rep.in_scope_accuracy, "confident_errors": rep.abstention.get("confident_errors", 0), "diff": cmp["diff"], "p_value": cmp["p_value"]})
    if args.json:
        print(json.dumps({"split": args.split, "n": base.n, "rows": rows}, ensure_ascii=False, indent=2))
        return 0
    print(f"{'sem':<12} {'média':>7} {'escopo':>7} {'err.conf':>9} {'Δ':>7} {'p':>7}")
    for r in rows:
        print(f"{r['ablated']:<12} {r['mean']:>7.3f} {r['in_scope']:>7.3f} {int(r['confident_errors']):>9} {r['diff']:>+7.3f} {r['p_value']:>7.3f}")
    return 0


def cmd_evolve(args: argparse.Namespace) -> int:
    spec = load_specialization(args.spec)
    suite = _suite(spec)
    provider = _provider(args, spec)
    reflector: Reflector
    if args.reflector == "provider":
        if isinstance(provider, SimulatedExpert):
            raise SystemExit("--reflector provider precisa de um modelo (o simulador não reflete); use heuristic")
        reflector = ProviderReflector(provider)
    else:
        reflector = HeuristicReflector(max_proposals=args.proposals)
    evolved, rep = evolve(spec, suite, lambda s: compile_specialization(s, provider).agent, reflector=reflector, iterations=args.iterations, min_gain=args.min_gain, holdout=not args.no_holdout)
    if args.json:
        print(json.dumps({**rep.to_dict(), "rules": [r.to_markdown() for r in evolved.rules.active()]}, ensure_ascii=False, indent=2))
    else:
        b, f = rep.baseline, rep.final
        print(f"{spec.ref} holdout={rep.holdout} refletor={rep.reflector} avaliações={rep.evaluations}")
        print(f"  train {b.get('train', 0):.3f} -> {f.get('train', 0):.3f}   dev {b.get('dev', 0):.3f} -> {f.get('dev', 0):.3f}   test {b.get('test', 0):.3f} -> {f.get('test', 0):.3f}")
        print(f"  regras ativas {rep.rules_before} -> {rep.rules_after}; iterações aceitas {rep.accepted}/{len(rep.iterations)}")
        for it in rep.iterations:
            print(f"  [{it.index}] propostas={it.proposals} aplicadas={it.applied} train={it.train:.3f} dev={it.dev:.3f} {'aceita' if it.accepted else 'rejeitada'} {it.note}")
    if args.save:
        evolved.path = spec.path
        n = evolved.save_rules()
        print(f"{n} regras gravadas em {Path(spec.path) / 'rules'}", file=sys.stderr)
    return 0


def cmd_bench(args: argparse.Namespace) -> int:
    seeds = list(range(args.seeds)) if args.seeds else None
    for path in run_benchmark(args.name, out=args.out, seeds=seeds):
        print(path)
    return 0


# --------------------------------------------------------------------------
# parser
# --------------------------------------------------------------------------


def _provider_flags(p: argparse.ArgumentParser) -> None:
    p.add_argument("--simulated", action="store_true", help="SimulatedExpert lendo evals/truth.json (sem rede)")
    p.add_argument("--scripted", help="JSON com respostas roteirizadas (sem rede)")
    p.add_argument("--model")
    p.add_argument("--effort")


def add_parser(sub: Any) -> None:
    sp = sub.add_parser("specialize", help="especialidade: mostrar, avaliar, ablar, evoluir, destilar, medir")
    ss = sp.add_subparsers(dest="scmd", required=True)

    show = ss.add_parser("show", help="o que a especialidade põe no prompt e quanto custa")
    show.add_argument("spec")
    show.add_argument("--ablate", nargs="*", choices=SECTIONS)
    show.add_argument("--system", action="store_true", help="imprime o texto do system")
    show.set_defaults(fn=cmd_show)

    synth = ss.add_parser("synth", help="escreve um domínio sintético (com truth.json para --simulated)")
    synth.add_argument("spec")
    synth.add_argument("--n-types", type=int, default=12)
    synth.add_argument("--tasks-per-type", type=int, default=5)
    synth.add_argument("--out-of-scope", type=int, default=10)
    synth.add_argument("--rules", type=int, default=4, help="tipos cobertos por regra do autor")
    synth.add_argument("--examples", type=int, default=4, help="tipos cobertos por exemplo")
    synth.add_argument("--glossary", type=int, default=2, help="tipos cobertos pelo glossário")
    synth.add_argument("--noise", type=float, default=0.15, help="fração de rótulos ruidosos em train")
    synth.add_argument("--seed", type=int, default=0)
    synth.set_defaults(fn=cmd_synth)

    ev = ss.add_parser("eval", help="roda a suíte num split e verifica")
    ev.add_argument("spec")
    ev.add_argument("--split", default="dev", choices=["train", "dev", "test", "all"])
    ev.add_argument("--k", type=int, default=1, help="rollouts por tarefa (pass@1 não enviesado)")
    ev.add_argument("--ablate", nargs="*", choices=SECTIONS)
    ev.add_argument("--lessons", action="store_true", help="anexa as lições a lessons.jsonl")
    ev.add_argument("--distill", metavar="JSONL", help="exporta trajetórias verificadas (SFT)")
    ev.add_argument("--distill-all", action="store_true", help="exporta também as não verificadas")
    ev.add_argument("--json", action="store_true")
    _provider_flags(ev)
    ev.set_defaults(fn=cmd_eval)

    ab = ss.add_parser("ablate", help="cada seção desligada por vez, com comparação pareada")
    ab.add_argument("spec")
    ab.add_argument("--split", default="dev", choices=["train", "dev", "test", "all"])
    ab.add_argument("--sections", nargs="*", choices=SECTIONS)
    ab.add_argument("--json", action="store_true")
    _provider_flags(ab)
    ab.set_defaults(fn=cmd_ablate)

    evo = ss.add_parser("evolve", help="evolui as regras (seleção no dev; test só no fim)")
    evo.add_argument("spec")
    evo.add_argument("--iterations", type=int, default=5)
    evo.add_argument("--min-gain", type=float, default=0.0)
    evo.add_argument("--no-holdout", action="store_true", help="seleciona no train (só para ver o que custa)")
    evo.add_argument("--reflector", choices=["heuristic", "provider"], default="heuristic")
    evo.add_argument("--proposals", type=int, default=1, help="propostas por iteração do refletor heurístico")
    evo.add_argument("--save", action="store_true", help="grava as regras evoluídas em rules/")
    evo.add_argument("--json", action="store_true")
    _provider_flags(evo)
    evo.set_defaults(fn=cmd_evolve)

    b = ss.add_parser("bench", help="roda um experimento do estudo e grava o JSON")
    b.add_argument("name", choices=[*BENCHMARKS, "all"])
    b.add_argument("--out", help="diretório de saída (padrão docs/especializacao/resultados)")
    b.add_argument("--seeds", type=int, help="número de sementes (padrão do experimento)")
    b.set_defaults(fn=cmd_bench)
