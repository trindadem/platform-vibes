"""A especialização é um diretório, não uma string.

Uma especialidade profunda tem partes de natureza diferente, e cada uma mora
num arquivo com o formato que a torna revisável por quem não escreve Python:

    especialidade/
      SPEC.md          papel e escopo — curto: a evidência de que persona longa
                       ajuda é fraca (Zheng et al., 2023); a substância mora abaixo
      glossary.md      terminologia: `- termo: definição`, injetada só quando o
                       termo aparece na tarefa
      rules/*.md       heurísticas com evidência e votos (ExpeL, Zhao et al., 2024):
                       nascem com 2 votos, saem do prompt em <= 0
      examples/*.md    casos resolvidos (tarefa, resposta, raciocínio) — entram
                       por similaridade com a tarefa, sob orçamento
      knowledge/       corpus para `exovision.harness.rag` (opcional)
      skills/          SKILL.md (opcional; carregador do harness)
      evals/tasks.jsonl suíte do domínio com split train/dev/test
      lessons.jsonl    lições de execuções avaliadas (Reflexion) — candidatas a regra

O front-matter do `SPEC.md` declara o resto: ferramentas permitidas, teto de
risco, orçamentos de tokens por seção, marcadores de abstenção e o que está
fora do escopo. O `digest` cobre tudo o que entra no prompt de forma estável
(papel, regras ativas, escopo, ferramentas) e vai para o traço em `startup`:
editar uma regra sem refazer o digest é mudança silenciosa, e o traço a
denuncia — a mesma regra da instrução.
"""

from __future__ import annotations

import hashlib
import re
from collections.abc import Iterable, Sequence
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

from ..instruction import InstructionError, parse_front_matter

__all__ = [
    "DEFAULT_ABSTAIN_MARKERS",
    "Example",
    "Glossary",
    "Rule",
    "RuleBook",
    "Specialization",
    "SpecializationError",
    "load_specialization",
]


class SpecializationError(InstructionError):
    """Diretório de especialização malformado ou incompleto."""


#: frases que o verificador reconhece como abstenção (o SPEC pode acrescentar)
DEFAULT_ABSTAIN_MARKERS: tuple[str, ...] = (
    "fora do meu escopo",
    "fora do escopo",
    "não sei",
    "nao sei",
    "não posso afirmar",
    "não tenho como afirmar",
    "não é possível responder",
    "i don't know",
    "out of scope",
)

_SLUG = re.compile(r"[^a-z0-9]+")


def slug(text: str) -> str:
    return _SLUG.sub("-", text.lower()).strip("-")[:48] or "x"


# --------------------------------------------------------------------------
# regras (ExpeL)
# --------------------------------------------------------------------------

#: ExpeL: um insight nasce com 2 votos e é removido quando chega a 0.
INITIAL_VOTES = 2


@dataclass(slots=True)
class Rule:
    """Uma heurística do domínio, com a evidência que a sustenta e os votos que recebeu."""

    id: str
    text: str
    votes: int = INITIAL_VOTES
    evidence: tuple[str, ...] = ()
    origin: str = "author"  # author | lesson | evolve
    note: str = ""

    @property
    def active(self) -> bool:
        return self.votes > 0

    def to_markdown(self) -> str:
        ev = "[" + ", ".join(self.evidence) + "]"
        head = [
            "---",
            f"id: {self.id}",
            f"votes: {self.votes}",
            f"origin: {self.origin}",
            f"evidence: {ev}",
        ]
        if self.note:
            head.append("note: " + " ".join(self.note.split()))
        head.append("---")
        return "\n".join(head) + "\n" + self.text.strip() + "\n"

    @classmethod
    def from_markdown(cls, text: str, *, default_id: str) -> Rule:
        meta, body = parse_front_matter(text)
        ev = meta.get("evidence", ())
        if isinstance(ev, str):
            ev = [ev] if ev else []
        return cls(
            id=str(meta.get("id") or default_id),
            text=body.strip(),
            votes=int(meta.get("votes", INITIAL_VOTES)),
            evidence=tuple(str(e) for e in ev),
            origin=str(meta.get("origin", "author")),
            note=str(meta.get("note", "")),
        )


class RuleBook:
    """As regras, com as operações do ExpeL: add, edit, upvote, downvote — e a poda."""

    def __init__(self, rules: Iterable[Rule] = ()) -> None:
        self._rules: dict[str, Rule] = {}
        for r in rules:
            if r.id in self._rules:
                raise SpecializationError(f"regra {r.id!r} duplicada")
            self._rules[r.id] = r

    def __len__(self) -> int:
        return len(self._rules)

    def __iter__(self):
        return iter(self._rules.values())

    def __contains__(self, rule_id: str) -> bool:
        return rule_id in self._rules

    def get(self, rule_id: str) -> Rule | None:
        return self._rules.get(rule_id)

    def active(self) -> list[Rule]:
        """Ativas, dos mais votados aos menos; empate por id (determinístico)."""
        return sorted((r for r in self._rules.values() if r.active), key=lambda r: (-r.votes, r.id))

    def add(self, text: str, *, evidence: Sequence[str] = (), origin: str = "evolve", note: str = "", rule_id: str | None = None) -> Rule:
        text = text.strip()
        if not text:
            raise SpecializationError("regra vazia")
        for r in self._rules.values():
            if r.text == text:
                # ExpeL: propor de novo o que já existe é um voto a favor
                r.votes += 1
                r.evidence = tuple(dict.fromkeys((*r.evidence, *evidence)))
                return r
        rid = rule_id or self._fresh_id(text)
        rule = Rule(rid, text, INITIAL_VOTES, tuple(evidence), origin, note)
        self._rules[rid] = rule
        return rule

    def edit(self, rule_id: str, text: str, *, evidence: Sequence[str] = ()) -> Rule:
        r = self._require(rule_id)
        r.text = text.strip()
        r.evidence = tuple(dict.fromkeys((*r.evidence, *evidence)))
        return r

    def upvote(self, rule_id: str, *, evidence: Sequence[str] = ()) -> Rule:
        r = self._require(rule_id)
        r.votes += 1
        r.evidence = tuple(dict.fromkeys((*r.evidence, *evidence)))
        return r

    def downvote(self, rule_id: str, *, evidence: Sequence[str] = ()) -> Rule:
        r = self._require(rule_id)
        r.votes -= 1
        r.evidence = tuple(dict.fromkeys((*r.evidence, *evidence)))
        return r

    def retired(self) -> list[Rule]:
        return sorted((r for r in self._rules.values() if not r.active), key=lambda r: r.id)

    def copy(self) -> RuleBook:
        return RuleBook(Rule(r.id, r.text, r.votes, r.evidence, r.origin, r.note) for r in self._rules.values())

    def _require(self, rule_id: str) -> Rule:
        r = self._rules.get(rule_id)
        if r is None:
            raise SpecializationError(f"regra desconhecida: {rule_id!r}")
        return r

    def _fresh_id(self, text: str) -> str:
        base = slug(" ".join(text.split()[:5]))
        rid, n = base, 2
        while rid in self._rules:
            rid, n = f"{base}-{n}", n + 1
        return rid

    # ------------------------------------------------------------- disco
    @classmethod
    def load(cls, directory: Path) -> RuleBook:
        rules: list[Rule] = []
        if directory.is_dir():
            for p in sorted(directory.glob("*.md")):
                rules.append(Rule.from_markdown(p.read_text(encoding="utf-8"), default_id=p.stem))
        return cls(rules)

    def save(self, directory: Path) -> int:
        directory.mkdir(parents=True, exist_ok=True)
        keep = set()
        for r in self._rules.values():
            (directory / f"{r.id}.md").write_text(r.to_markdown(), encoding="utf-8")
            keep.add(f"{r.id}.md")
        for p in directory.glob("*.md"):
            if p.name not in keep:
                p.unlink()
        return len(self._rules)


# --------------------------------------------------------------------------
# exemplos
# --------------------------------------------------------------------------


@dataclass(frozen=True, slots=True)
class Example:
    """Um caso resolvido: tarefa, resposta e (opcional) o raciocínio."""

    id: str
    task: str
    answer: str
    rationale: str = ""
    tags: tuple[str, ...] = ()

    def render(self) -> str:
        parts = [f"Tarefa: {self.task.strip()}"]
        if self.rationale.strip():
            parts.append(f"Raciocínio: {self.rationale.strip()}")
        parts.append(f"Resposta: {self.answer.strip()}")
        return "\n".join(parts)

    def to_markdown(self) -> str:
        tags = "[" + ", ".join(self.tags) + "]"
        out = ["---", f"id: {self.id}", f"tags: {tags}", "---", "## Tarefa", self.task.strip(), "", "## Resposta", self.answer.strip()]
        if self.rationale.strip():
            out += ["", "## Raciocínio", self.rationale.strip()]
        return "\n".join(out) + "\n"

    @classmethod
    def from_markdown(cls, text: str, *, default_id: str) -> Example:
        meta, body = parse_front_matter(text)
        sections = _sections(body)
        task = sections.get("tarefa", "").strip()
        answer = sections.get("resposta", "").strip()
        if not task or not answer:
            raise SpecializationError(f"exemplo {default_id!r} precisa de '## Tarefa' e '## Resposta'")
        tags = meta.get("tags", ())
        if isinstance(tags, str):
            tags = [tags] if tags else []
        return cls(str(meta.get("id") or default_id), task, answer, sections.get("raciocinio", "").strip(), tuple(str(t) for t in tags))


_H2 = re.compile(r"^##\s+(.+?)\s*$", re.M)


def _sections(body: str) -> dict[str, str]:
    """`## Título` -> texto até o próximo `##`; chaves sem acento e minúsculas."""
    out: dict[str, str] = {}
    matches = list(_H2.finditer(body))
    for i, m in enumerate(matches):
        end = matches[i + 1].start() if i + 1 < len(matches) else len(body)
        key = _fold(m.group(1))
        out[key] = body[m.end() : end]
    return out


def _fold(text: str) -> str:
    import unicodedata

    d = unicodedata.normalize("NFKD", text.lower())
    return "".join(c for c in d if not unicodedata.combining(c)).strip()


def load_examples(directory: Path) -> list[Example]:
    out: list[Example] = []
    if directory.is_dir():
        for p in sorted(directory.glob("*.md")):
            out.append(Example.from_markdown(p.read_text(encoding="utf-8"), default_id=p.stem))
    return out


# --------------------------------------------------------------------------
# glossário
# --------------------------------------------------------------------------

_TERM = re.compile(r"^\s*[-*]\s*\**([^:*]+?)\**\s*:\s*(.+?)\s*$")


class Glossary:
    """`- termo: definição`, uma por linha. Seleção por presença do termo na tarefa."""

    def __init__(self, terms: Iterable[tuple[str, str]] = ()) -> None:
        self._terms: dict[str, str] = {}
        self._folded: dict[str, str] = {}
        for t, d in terms:
            self._terms[t] = d
            self._folded[_fold(t)] = t

    def __len__(self) -> int:
        return len(self._terms)

    def terms(self) -> list[str]:
        return list(self._terms)

    def definition(self, term: str) -> str | None:
        return self._terms.get(term)

    def present_in(self, text: str) -> list[str]:
        """Termos que aparecem no texto (comparação sem acento nem caixa, por palavra inteira)."""
        folded = _fold(text)
        out: list[str] = []
        for key, term in self._folded.items():
            if re.search(r"(?<![a-z0-9])" + re.escape(key) + r"(?![a-z0-9])", folded):
                out.append(term)
        return out

    def render(self, terms: Sequence[str]) -> str:
        return "\n".join(f"- {t}: {self._terms[t]}" for t in terms if t in self._terms)

    @classmethod
    def parse(cls, text: str) -> Glossary:
        _, body = parse_front_matter(text)
        pairs = []
        for line in body.splitlines():
            m = _TERM.match(line)
            if m:
                pairs.append((m.group(1).strip(), m.group(2).strip()))
        return cls(pairs)

    @classmethod
    def load(cls, path: Path) -> Glossary:
        return cls.parse(path.read_text(encoding="utf-8")) if path.is_file() else cls()


# --------------------------------------------------------------------------
# o documento
# --------------------------------------------------------------------------


def _as_list(v: Any) -> list[str]:
    if v is None or v == "":
        return []
    if isinstance(v, str):
        return [v]
    return [str(x) for x in v]


@dataclass(slots=True)
class Specialization:
    """Uma especialidade carregada do disco (ou montada em memória)."""

    name: str
    role: str  # corpo do SPEC.md: papel e postura
    version: str = "0.0.0"
    domain: str = ""
    scope_in: list[str] = field(default_factory=list)
    scope_out: list[str] = field(default_factory=list)
    tools: list[str] = field(default_factory=list)
    risk_ceiling: str = ""  # ex.: "write" -> nega write e acima
    abstain: bool = True
    abstain_markers: list[str] = field(default_factory=lambda: list(DEFAULT_ABSTAIN_MARKERS))
    budgets: dict[str, int] = field(default_factory=lambda: {"rules": 800, "examples": 1200, "glossary": 300, "knowledge": 1500})
    examples_k: int = 4
    rules: RuleBook = field(default_factory=RuleBook)
    examples: list[Example] = field(default_factory=list)
    glossary: Glossary = field(default_factory=Glossary)
    path: str = ""
    meta: dict[str, Any] = field(default_factory=dict)

    # ------------------------------------------------------------- caminhos
    def _sub(self, name: str) -> Path | None:
        if not self.path:
            return None
        p = Path(self.path) / name
        return p if p.exists() else None

    @property
    def knowledge_dir(self) -> Path | None:
        return self._sub("knowledge")

    @property
    def skills_dir(self) -> Path | None:
        return self._sub("skills")

    @property
    def evals_path(self) -> Path | None:
        return self._sub("evals/tasks.jsonl")

    @property
    def lessons_path(self) -> Path:
        return Path(self.path or ".") / "lessons.jsonl"

    # ------------------------------------------------------------- digest
    def digest_text(self) -> str:
        parts = [self.role.strip(), "\n".join(f"{r.id}\t{r.votes}\t{r.text}" for r in self.rules.active()), "\n".join(self.scope_in), "\n".join(self.scope_out), "\n".join(self.tools), self.risk_ceiling, str(self.abstain)]
        return "\n\x00\n".join(parts)

    @property
    def digest(self) -> str:
        return hashlib.sha256(self.digest_text().encode("utf-8")).hexdigest()

    @property
    def ref(self) -> str:
        return f"{self.name}@{self.version}"

    def copy(self) -> Specialization:
        """Cópia independente (a evolução trabalha numa candidata e só promove a que melhora)."""
        return Specialization(
            name=self.name,
            role=self.role,
            version=self.version,
            domain=self.domain,
            scope_in=list(self.scope_in),
            scope_out=list(self.scope_out),
            tools=list(self.tools),
            risk_ceiling=self.risk_ceiling,
            abstain=self.abstain,
            abstain_markers=list(self.abstain_markers),
            budgets=dict(self.budgets),
            examples_k=self.examples_k,
            rules=self.rules.copy(),
            examples=list(self.examples),
            glossary=self.glossary,
            path=self.path,
            meta=dict(self.meta),
        )

    def save_rules(self) -> int:
        if not self.path:
            raise SpecializationError("especialização sem diretório: nada onde gravar regras")
        return self.rules.save(Path(self.path) / "rules")

    def to_dict(self) -> dict[str, Any]:
        return {
            "name": self.name,
            "version": self.version,
            "domain": self.domain,
            "digest": self.digest,
            "rules": {"total": len(self.rules), "active": len(self.rules.active())},
            "examples": len(self.examples),
            "glossary": len(self.glossary),
            "tools": list(self.tools),
            "abstain": self.abstain,
            "budgets": dict(self.budgets),
        }


def load_specialization(directory: str | Path) -> Specialization:
    d = Path(directory)
    spec_md = d / "SPEC.md"
    if not spec_md.is_file():
        raise SpecializationError(f"especialização sem SPEC.md: {d}")
    meta, body = parse_front_matter(spec_md.read_text(encoding="utf-8"))
    body = body.strip()
    if not body:
        raise SpecializationError(f"SPEC.md de {d.name!r} sem corpo: o papel é obrigatório")
    name = str(meta.get("name") or d.name)
    budgets = {"rules": 800, "examples": 1200, "glossary": 300, "knowledge": 1500}
    for k in list(budgets):
        if f"budget_{k}" in meta:
            budgets[k] = int(meta[f"budget_{k}"])
    markers = list(DEFAULT_ABSTAIN_MARKERS) + _as_list(meta.get("abstain_markers"))
    abstain = meta.get("abstain", True)
    spec = Specialization(
        name=name,
        role=body,
        version=str(meta.get("version", "0.0.0")),
        domain=str(meta.get("domain", "")),
        scope_in=_as_list(meta.get("scope_in")),
        scope_out=_as_list(meta.get("scope_out")),
        tools=_as_list(meta.get("tools")),
        risk_ceiling=str(meta.get("risk_ceiling", "") or ""),
        abstain=bool(abstain) if not isinstance(abstain, str) else abstain.lower() not in ("false", "no", "off"),
        abstain_markers=markers,
        budgets=budgets,
        examples_k=int(meta.get("examples_k", 4)),
        rules=RuleBook.load(d / "rules"),
        examples=load_examples(d / "examples"),
        glossary=Glossary.load(d / "glossary.md"),
        path=str(d.resolve()),
        meta=meta,
    )
    return spec
