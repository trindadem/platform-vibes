"""A porta: o que muda por tarefa entra pela primeira mensagem, não pelo system.

O system é estável na sessão e leva o breakpoint de cache (`context.py`); o
que depende da tarefa — exemplos parecidos, termos do glossário presentes,
trechos do corpus — entra depois do breakpoint, pela mesma porta que a
memória usa (`MemoryPort.recall`). Assim a especialização não inventa um
caminho novo no laço: `memory.recall` é a costura, e o traço registra quantos
tokens cada parte gastou (`per_subsystem`).

Cada item chega como `Retrieved` com proveniência: exemplo e glossário são do
**autor** da especialidade (`SYSTEM`, `VERIFIED`); o corpus é `OBSERVED`
(porta de conhecimento, ex. `RAGMemoryPort`).
"""

from __future__ import annotations

from typing import Any

from ..memory.bridge import MemoryPort, Recall
from ..memory.core.base import Retrieved
from ..memory.core.budget import estimate_tokens
from ..memory.core.embeddings import Embedder
from ..memory.core.record import MemoryRecord, Provenance
from ..memory.core.types import MemoryKind, ProvenanceKind, TrustTier
from .select import ExampleSelector, render_examples
from .spec import Specialization

__all__ = ["SpecializationPort"]


class SpecializationPort:
    """`MemoryPort` da especialidade: exemplos por similaridade, glossário por presença, conhecimento por dentro."""

    def __init__(
        self,
        spec: Specialization,
        *,
        embedder: Embedder | None = None,
        knowledge: MemoryPort | None = None,
        examples: bool = True,
        glossary: bool = True,
        example_order: str = "similar_last",
        example_selection: str = "knn",
    ) -> None:
        if example_selection not in ("knn", "random"):
            raise ValueError("example_selection: knn | random")
        self.spec = spec
        self.selector = ExampleSelector(spec.examples, embedder=embedder) if examples else ExampleSelector([])
        self.use_glossary = glossary
        self.knowledge = knowledge
        self.example_order = example_order
        self.example_selection = example_selection  # `random` é a linha de base do estudo
        self.last: Recall = Recall()
        self.calls = 0

    def recall(self, text: str, *, session: str = "", actor: str = "") -> Recall:
        self.calls += 1
        parts: list[str] = []
        items: list[Retrieved] = []
        per: dict[str, int] = {}
        tokens = 0
        dropped = 0

        k, budget = self.spec.examples_k, self.spec.budgets.get("examples", 0)
        if self.example_selection == "random":
            chosen = self.selector.random(k=k, budget_tokens=budget, seed=self.calls)
        else:
            chosen = self.selector.select(text, k=k, budget_tokens=budget, order=self.example_order)
        if chosen:
            block = render_examples(chosen)
            parts.append(block)
            t = estimate_tokens(block)
            tokens += t
            per["examples"] = len(chosen)
            for e in chosen:
                items.append(Retrieved(record=_record(e.id, e.render(), "example"), score=1.0, subsystem="examples", rationale={"k": float(self.spec.examples_k)}))

        if self.use_glossary and len(self.spec.glossary):
            terms = self.spec.glossary.present_in(text)
            kept: list[str] = []
            used = 0
            budget = self.spec.budgets.get("glossary", 0)
            for term in terms:
                line = f"- {term}: {self.spec.glossary.definition(term)}"
                cost = estimate_tokens(line)
                if used + cost > budget:
                    dropped += 1
                    continue
                kept.append(term)
                used += cost
            if kept:
                block = "Terminologia do domínio presente na tarefa:\n" + self.spec.glossary.render(kept)
                parts.append(block)
                tokens += used
                per["glossary"] = len(kept)
                for term in kept:
                    items.append(Retrieved(record=_record(f"term:{term}", f"{term}: {self.spec.glossary.definition(term)}", "glossary"), score=1.0, subsystem="glossary"))

        if self.knowledge is not None:
            inner = self.knowledge.recall(text, session=session, actor=actor)
            if inner.text:
                parts.append(inner.text)
                tokens += inner.tokens
                dropped += inner.dropped
                items.extend(inner.items)
                per["knowledge"] = len(inner.items)

        self.last = Recall(text="\n\n".join(parts), items=items, tokens=tokens, dropped=dropped, per_subsystem=per)
        return self.last

    def observe(self, kind: str, content: str, *, session: str = "", turn: int = 0, **detail: Any) -> None:
        if self.knowledge is not None:
            self.knowledge.observe(kind, content, session=session, turn=turn, **detail)

    def commit(self) -> dict[str, Any]:
        out: dict[str, Any] = {"specialization": {"examples": len(self.selector), "glossary": len(self.spec.glossary), "recalls": self.calls}}
        if self.knowledge is not None:
            out.update(self.knowledge.commit())
        return out


def _record(rid: str, content: str, kind: str) -> MemoryRecord:
    return MemoryRecord(
        content=content,
        kind=MemoryKind.SEMANTIC,
        id=rid,
        trust=TrustTier.VERIFIED,
        provenance=Provenance(kind=ProvenanceKind.SYSTEM, source_id=rid, uri=f"specialization:{kind}"),
        payload={"section": kind},
    )
