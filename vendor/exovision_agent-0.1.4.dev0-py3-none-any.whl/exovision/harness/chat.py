"""A conversa: `exovision-agent` e o agente está lá, pronto para responder.

Sem subcomando, sem flag, sem decorar nada. O que se digita é a tarefa; o que
começa com `/` é comando. A conversa tem um agente, um modelo e uma sessão,
e os três se trocam em uma linha (`/agente`, `/modelo`, `/sessao`) — o que
antes exigia editar o `AGENT.md` e rodar de novo.

Como o agente é encontrado, nesta ordem: o que o `--agent` disser; um
`AGENT.md`/`TEAM.md` no diretório atual; um único perfil num subdiretório;
o último usado (guardado em `config.state_path()`); e, se não houver nenhum,
a conversa oferece criar um ali mesmo — o `init` é a primeira resposta, não
um comando a descobrir.

Continuidade: cada mensagem é um laço (`run`) com a mesma sessão, e o que
liga uma mensagem à seguinte é a **memória do perfil** (buffer e episódica,
recuperadas antes do primeiro turno). Não é histórico literal: é o que o
harness já faz com qualquer tarefa, e por isso vale para a conversa também.

As ferramentas aparecem enquanto rodam (`⚙ bash …`), porque uma volta demora
segundos e o usuário tem direito de ver o que está acontecendo.
"""

from __future__ import annotations

import argparse
import contextlib
import os
import sys
import time
from collections.abc import Callable, Sequence
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, TextIO

from .. import __version__
from .config import load_state, save_state
from .ui import PromptAborted, Prompter, Spinner, format_outcome, paint

__all__ = ["Chat", "add_parser", "cmd_chat", "find_agents", "resolve_agent"]

BANNER_HINT = "digite a tarefa; /ajuda para comandos, /sair para sair"


# ---------------------------------------------------------------- descoberta


def find_agents(base: Path | str = ".", *, depth: int = 2) -> list[Path]:
    """Perfis e equipes em `base` e nos subdiretórios (sem entrar em ocultos e venvs)."""
    raiz = Path(base)
    achados: list[Path] = []
    if (raiz / "AGENT.md").is_file() or (raiz / "TEAM.md").is_file():
        achados.append(raiz)
    pular = {".venv", "venv", "node_modules", "__pycache__", ".git", "dist", "build", ".exovision"}
    fila: list[tuple[Path, int]] = [(raiz, 0)]
    while fila:
        d, nivel = fila.pop(0)
        if nivel >= depth:
            continue
        with contextlib.suppress(OSError):
            for sub in sorted(d.iterdir()):
                if not sub.is_dir() or sub.name.startswith(".") or sub.name in pular:
                    continue
                if (sub / "AGENT.md").is_file() or (sub / "TEAM.md").is_file():
                    achados.append(sub)
                else:
                    fila.append((sub, nivel + 1))
    return achados


def resolve_agent(explicit: str | None = None, *, cwd: Path | str = ".") -> tuple[Path | None, list[Path]]:
    """(o agente, os candidatos). `None` quando não há nenhum — quem chama oferece criar."""
    if explicit:
        d = Path(explicit)
        if not ((d / "AGENT.md").is_file() or (d / "TEAM.md").is_file()):
            raise FileNotFoundError(f"{d}: sem AGENT.md nem TEAM.md (crie com `exovision-agent init {d}`)")
        return d, [d]
    achados = find_agents(cwd)
    if len(achados) == 1:
        return achados[0], achados
    if achados:
        ultimo = load_state().get("agent")
        if ultimo:
            for a in achados:
                if a.resolve() == Path(ultimo).resolve():
                    return a, achados
        return achados[0], achados
    ultimo = load_state().get("agent")
    if ultimo and ((Path(ultimo) / "AGENT.md").is_file() or (Path(ultimo) / "TEAM.md").is_file()):
        return Path(ultimo), [Path(ultimo)]
    return None, []


# ---------------------------------------------------------------- a conversa


@dataclass
class Turn:
    """Uma pergunta e o que ela custou."""

    text: str
    outcome: Any
    seconds: float


@dataclass
class Chat:
    """O laço da conversa. `handle()` é puro o bastante para a suíte dirigir."""

    path: Path
    prompter: Prompter
    session: str = "conversa"
    model: str = ""       # vazio: o do AGENT.md
    effort: str = ""
    scripted: str = ""    # roteiro JSON, para a suíte e para demonstração sem rede
    out: TextIO = field(default_factory=lambda: sys.stdout)
    err: TextIO = field(default_factory=lambda: sys.stderr)
    turns: list[Turn] = field(default_factory=list)
    _profile: Any = None
    _provider: Any = None
    _provider_key: str = ""
    _tools_seen: list[str] = field(default_factory=list)

    # ------------------------------------------------------------ apoio
    @property
    def color(self) -> bool:
        return self.prompter.color

    def say(self, text: str = "") -> None:
        print(text, file=self.out)

    def profile(self, *, reload: bool = False) -> Any:
        from .agents.profile import load_profile

        if self._profile is None or reload:
            self._profile = load_profile(self.path)
        return self._profile

    def provider(self) -> Any:
        """Um provedor por (agente, modelo, esforço): o cliente e o roteiro sobrevivem à mensagem.

        Reconstruir a cada mensagem custava uma conexão nova por volta — e
        fazia um roteiro recomeçar do zero a cada pergunta.
        """
        from .agents.cli import provider_factory

        chave = f"{self.path}|{self.model_spec()}|{self.effort_now()}|{self.scripted}"
        if self._provider is None or self._provider_key != chave:
            p = self.profile()
            if self.scripted:
                self._provider = provider_factory([self.scripted])(p)
            elif self.model:
                from .models import make_provider

                self._provider = make_provider(self.model, effort=self.effort_now())
            else:
                self._provider = provider_factory(None)(p)
            self._provider_key = chave
        return self._provider

    def is_team(self) -> bool:
        return (self.path / "TEAM.md").is_file()

    def model_spec(self) -> str:
        return self.model or (self.profile().model if not self.is_team() else "") or "anthropic:claude-sonnet-5"

    def effort_now(self) -> str:
        return self.effort or (self.profile().effort if not self.is_team() else "") or "high"

    def cost(self) -> float:
        return sum(t.outcome.cost_usd for t in self.turns)

    def header(self) -> str:
        nome = self.profile().name if not self.is_team() else self.path.name
        modelo = self.model_spec().split(":", 1)[-1].split("@", 1)[0]
        return (
            paint("bold", f"exovision-agent {__version__}", enabled=self.color)
            + paint("dim", f" · {nome} · {modelo} · sessão {self.session}", enabled=self.color)
        )

    # ------------------------------------------------------------ o laço
    def greet(self) -> None:
        self.say(self.header())
        for aviso in self.warnings():
            self.say(paint("yellow", f"⚠ {aviso}", enabled=self.color))
        self.say(paint("dim", BANNER_HINT, enabled=self.color))
        self.say()

    def warnings(self) -> list[str]:
        """O que vai quebrar a primeira mensagem — dito antes dela, não depois."""
        if self.scripted:
            return []
        from .models import parse_spec
        from .models.catalog import resolve
        from .onboarding import PROVIDERS, key_present

        kind, model, _ = parse_spec(self.model_spec())
        card = resolve(model)
        kind = kind or card.provider or os.environ.get("EXOVISION_PROVIDER", "anthropic")
        info = PROVIDERS.get(kind)
        out: list[str] = []
        if info is not None and info.key_var and not key_present(info, os.environ):
            out.append(f"sem {info.key_var} no ambiente: `exovision-agent init {self.path} --force` grava a sua, ou exporte a variável")
        if not self.is_team() and (ws := getattr(self.profile(), "workspace", "")) and not Path(ws).is_dir():
            out.append(f"a bancada {ws} não existe: crie a pasta, ou tire `workspace:` do AGENT.md")
        return out

    def loop(self, *, greet: bool = True) -> int:
        """Lê, responde, repete. Ctrl-D, Ctrl-C ou /sair terminam."""
        if greet:
            self.greet()
        with contextlib.suppress(ImportError):
            import readline  # noqa: F401 — histórico e edição de linha, se houver

        while True:
            try:
                linha = self.prompter._input(paint("cyan", "› ", enabled=self.color))  # noqa: RUF001 — o prompt é um sinal, não um maior-que
            except (EOFError, KeyboardInterrupt, PromptAborted):
                self.say()
                break
            if not self.handle(linha):
                break
        self.bye()
        return 0

    def bye(self) -> None:
        if self.turns:
            self.say(paint("dim", f"{len(self.turns)} mensagem(ns) · US$ {self.cost():.4f} · sessão {self.session}", enabled=self.color))
        save_state(agent=str(self.path.resolve()), session=self.session)

    def handle(self, linha: str) -> bool:
        """Trata uma linha. `False` encerra a conversa."""
        linha = linha.strip()
        if not linha:
            return True
        if linha.startswith("/"):
            return self.command(linha[1:])
        self.ask_agent(linha)
        return True

    # ------------------------------------------------------------ mensagem
    def ask_agent(self, tarefa: str) -> Any:
        from .loop import run
        from .session import SQLiteStateStore

        p = self.profile()
        agent = p.build(self.provider())
        self._tools_seen = []
        t0 = time.perf_counter()
        spin = Spinner(f"{self.model_spec().split(':')[-1]} pensando", stream=self.err)
        try:
            with spin:
                out = run(
                    agent,
                    tarefa,
                    session=self.session,
                    state_store=SQLiteStateStore(str(p.journal_db)),
                    on_event=self._on_event(spin),
                )
        except Exception as erro:
            from .loop import Outcome

            out = Outcome(text="", turns=0, stop_reason="error", error=f"{type(erro).__name__}: {erro}")
        segundos = time.perf_counter() - t0
        corpo, rodape = format_outcome(out, color=self.color, elapsed=segundos)
        if corpo:
            self.say(corpo)
        print(rodape, file=self.err)
        self.say()
        self.turns.append(Turn(text=tarefa, outcome=out, seconds=segundos))
        return out

    def _on_event(self, spin: Spinner) -> Callable[[Any], None]:
        def on_event(ev: Any) -> None:
            nome = getattr(ev, "name", "") or getattr(ev, "kind", "")
            dados = getattr(ev, "data", {}) or {}
            if nome == "tool.call":
                tool = str(dados.get("tool") or dados.get("name") or "ferramenta")
                self._tools_seen.append(tool)
                arg = dados.get("input") or dados.get("args") or {}
                resumo = ""
                if isinstance(arg, dict) and arg:
                    k = next(iter(arg))
                    resumo = f" {k}={str(arg[k])[:60]}"
                self.err.write("\r\033[K" + paint("dim", f"⚙ {tool}{resumo}", enabled=self.color) + "\n")
                self.err.flush()
                spin.update(f"{tool} rodando")
            elif nome == "llm.request":
                spin.update(f"{self.model_spec().split(':')[-1]} pensando")

        return on_event

    # ------------------------------------------------------------ comandos
    def command(self, cmd: str) -> bool:
        nome, _, arg = cmd.partition(" ")
        nome, arg = nome.strip().lower(), arg.strip()
        alias = {
            "?": "ajuda", "h": "ajuda", "help": "ajuda",
            "q": "sair", "quit": "sair", "exit": "sair",
            "m": "modelo", "model": "modelo",
            "esforco": "esforco", "esforço": "esforco", "effort": "esforco",
            "a": "agente", "agent": "agente",
            "sessao": "sessao", "sessão": "sessao", "session": "sessao",
            "memoria": "memoria", "memória": "memoria",
            "custo": "custo", "cost": "custo",
        }
        nome = alias.get(nome, nome)
        fn = getattr(self, f"_cmd_{nome}", None)
        if fn is None:
            self.say(paint("yellow", f"comando desconhecido: /{nome} (/ajuda lista os que existem)", enabled=self.color))
            return True
        return bool(fn(arg))

    def _cmd_ajuda(self, _: str = "") -> bool:
        linhas = [
            ("/modelo [id]", "lista o catálogo, ou troca o modelo desta conversa"),
            ("/esforco [n]", "low medium high xhigh max (só para modelos que aceitam)"),
            ("/agente [dir]", "lista os agentes daqui, ou troca de agente"),
            ("/novo [dir]", "cria um agente novo (o assistente)"),
            ("/sessao [nome]", "troca a sessão (o fio da conversa e o journal)"),
            ("/custo", "o que esta conversa gastou, por mensagem"),
            ("/memoria [busca]", "o que este agente lembra"),
            ("/salvar", "grava modelo e esforço no AGENT.md"),
            ("/editar", "abre o AGENT.md no seu $EDITOR"),
            ("/sair", "encerra (Ctrl-D também)"),
        ]
        larg = max(len(a) for a, _ in linhas)
        for c, d in linhas:
            self.say(f"  {paint('cyan', c.ljust(larg), enabled=self.color)}  {paint('dim', d, enabled=self.color)}")
        return True

    def _cmd_sair(self, _: str = "") -> bool:
        return False

    def _cmd_modelo(self, arg: str) -> bool:
        from .models import parse_spec
        from .models.catalog import cards, resolve

        if not arg:
            atual = self.model_spec()
            for c in cards():
                marca = "→" if c.id in atual else " "
                esf = "/".join(c.efforts) or "sem esforço"
                self.say(f" {marca} {paint('cyan', c.id.ljust(20), enabled=self.color)} {paint('dim', f'US$ {c.price_in}/{c.price_out} por Mtok · {esf}', enabled=self.color)}")
            self.say(paint("dim", "  /modelo <id> troca; ids de outros provedores também (openai:gpt-5.4-mini, local:qwen2.5:1.5b)", enabled=self.color))
            return True
        kind, model, _url = parse_spec(arg)
        card = resolve(model)
        self.model = arg if kind else (f"{card.provider}:{card.id}" if card.provider else arg)
        if card.efforts and self.effort_now() not in card.efforts:
            self.effort = card.efforts[-1]
            self.say(paint("yellow", f"  esforço ajustado para {self.effort} (este modelo aceita {', '.join(card.efforts)})", enabled=self.color))
        elif not card.efforts and card.verified:
            self.effort = ""
            self.say(paint("dim", "  este modelo não usa esforço", enabled=self.color))
        self.say(paint("dim", f"  modelo: {self.model_spec()}  (/salvar grava no AGENT.md)", enabled=self.color))
        return True

    def _cmd_esforco(self, arg: str) -> bool:
        from .models.catalog import resolve

        card = resolve(self.model_spec().split(":")[-1].split("@")[0])
        if card.verified and not card.efforts:
            self.say(paint("yellow", f"  {card.id} não usa esforço", enabled=self.color))
            return True
        niveis = list(card.efforts) or ["low", "medium", "high", "xhigh", "max"]
        if not arg:
            self.say(f"  {', '.join(niveis)}  (agora: {self.effort_now()})")
            return True
        if arg not in niveis:
            self.say(paint("yellow", f"  esforço inválido: {arg} (use {', '.join(niveis)})", enabled=self.color))
            return True
        self.effort = arg
        self.say(paint("dim", f"  esforço: {arg}  (/salvar grava no AGENT.md)", enabled=self.color))
        return True

    def _cmd_agente(self, arg: str) -> bool:
        if not arg:
            for a in find_agents("."):
                marca = "→" if a.resolve() == self.path.resolve() else " "
                tipo = "equipe" if (a / "TEAM.md").is_file() else "agente"
                self.say(f" {marca} {paint('cyan', str(a), enabled=self.color)} {paint('dim', tipo, enabled=self.color)}")
            self.say(paint("dim", "  /agente <dir> troca; /novo cria", enabled=self.color))
            return True
        d = Path(arg)
        if not ((d / "AGENT.md").is_file() or (d / "TEAM.md").is_file()):
            self.say(paint("yellow", f"  {d}: sem AGENT.md nem TEAM.md (/novo {d} cria)", enabled=self.color))
            return True
        self.path, self._profile, self._provider, self.model, self.effort = d, None, None, "", ""
        self.say(self.header())
        return True

    def _cmd_novo(self, arg: str) -> bool:
        try:
            destino = _criar_aqui(self.prompter, arg or None)
        except (PromptAborted, KeyboardInterrupt):
            self.say(paint("dim", "  cancelado", enabled=self.color))
            return True
        except Exception as erro:
            self.say(paint("yellow", f"  {erro}", enabled=self.color))
            return True
        return self._cmd_agente(str(destino))

    def _cmd_sessao(self, arg: str) -> bool:
        if not arg:
            self.say(f"  sessão: {self.session}")
            return True
        self.session = arg
        self.say(paint("dim", f"  sessão: {arg}", enabled=self.color))
        return True

    def _cmd_custo(self, _: str = "") -> bool:
        if not self.turns:
            self.say(paint("dim", "  nada gasto ainda", enabled=self.color))
            return True
        for i, t in enumerate(self.turns, 1):
            self.say(f"  {i:2d}. {paint('dim', f'US$ {t.outcome.cost_usd:.4f} · {t.outcome.turns} voltas · {t.seconds:.1f}s', enabled=self.color)}  {t.text[:50]}")
        self.say(f"  {paint('bold', f'total US$ {self.cost():.4f}', enabled=self.color)}")
        return True

    def _cmd_memoria(self, arg: str) -> bool:
        from .memory.cli import open_memory
        from .memory.core.base import MemoryQuery

        p = self.profile()
        if self.is_team() or not getattr(p, "memory", ()):  # equipe: cada membro tem a sua
            self.say(paint("dim", "  este perfil não tem memória ligada", enabled=self.color))
            return True
        for kind in p.memory:
            m = open_memory(kind, db=str(p.memory_db))
            got = m.read(MemoryQuery(text=arg or "", top_k=3))
            tamanho = m.stats()["size"]
            self.say(f"  {paint('cyan', kind, enabled=self.color)} {paint('dim', f'({tamanho} registros)', enabled=self.color)}")
            for g in got:
                self.say(paint("dim", f"     {g.record.content[:90].replace(chr(10), ' ')}", enabled=self.color))
        return True

    def _cmd_salvar(self, _: str = "") -> bool:
        if self.is_team():
            self.say(paint("yellow", "  numa equipe, o modelo é de cada membro", enabled=self.color))
            return True
        md = self.path / "AGENT.md"
        texto = md.read_text(encoding="utf-8")
        for chave, valor in (("model", self.model_spec()), ("effort", self.effort_now())):
            if not valor:
                continue
            import re

            if re.search(rf"^{chave}: .*$", texto, re.M):
                texto = re.sub(rf"^{chave}: .*$", f"{chave}: {valor}", texto, count=1, flags=re.M)
            else:
                texto = texto.replace("---\n", f"---\n{chave}: {valor}\n", 1)
        md.write_text(texto, encoding="utf-8")
        self.model = self.effort = ""
        self._profile = self._provider = None
        self.say(paint("dim", f"  gravado em {md}", enabled=self.color))
        return True

    def _cmd_editar(self, _: str = "") -> bool:
        import subprocess

        editor = os.environ.get("EDITOR") or os.environ.get("VISUAL")
        alvo = self.path / ("TEAM.md" if self.is_team() else "AGENT.md")
        if not editor:
            self.say(paint("yellow", f"  defina $EDITOR, ou edite {alvo}", enabled=self.color))
            return True
        subprocess.run([editor, str(alvo)], check=False)
        self._profile = self._provider = None
        self.say(paint("dim", f"  recarregado {alvo}", enabled=self.color))
        return True


# ---------------------------------------------------------------- CLI


def _criar_aqui(p: Prompter, destino: str | None) -> Path:
    """O `init` de dentro da conversa: o diretório é o nome que a pessoa deu.

    Sem `--agent`, o nome escolhido vira o diretório (`./revisor`), em vez de
    um `meu-agente` que ninguém pediu; e não se pergunta a primeira tarefa —
    a próxima linha da conversa já é ela.
    """
    from .onboarding import Answers, collect, materialize

    a = collect(p, Answers(path=Path(destino) if destino else Path("."), first_task="-"))
    a.first_task = ""
    if not destino:
        a.path = Path(a.name)
    escritos = materialize(a)
    p.say(paint("dim", f"gravado {escritos[0]}", enabled=p.color))
    p.say()
    return a.path


def cmd_chat(args: argparse.Namespace) -> int:
    p = Prompter()
    try:
        alvo, candidatos = resolve_agent(getattr(args, "agent", None) or None)
    except FileNotFoundError as erro:
        print(f"{erro}", file=sys.stderr)
        return 2
    if alvo is None:
        if not p.interactive:
            print("nenhum agente aqui. Crie um: exovision-agent init ./meu-agente", file=sys.stderr)
            return 2
        p.say(paint("bold", f"exovision-agent {__version__}", enabled=p.color))
        p.say("Nenhum agente por aqui ainda. Vamos criar um — leva meia dúzia de perguntas.")
        p.say()
        try:
            alvo = _criar_aqui(p, getattr(args, "agent", None))
        except (PromptAborted, KeyboardInterrupt):
            p.say("\ncancelado")
            return 1
        except Exception as erro:
            print(f"init: {erro}", file=sys.stderr)
            return 2
    elif len(candidatos) > 1 and p.interactive:
        p.note(f"{len(candidatos)} agentes aqui; usando {alvo} (/agente troca)")
    chat = Chat(
        path=alvo,
        prompter=p,
        session=getattr(args, "session", "") or load_state().get("session") or "conversa",
        model=getattr(args, "model", "") or "",
        effort=getattr(args, "effort", "") or "",
        scripted=getattr(args, "scripted", "") or "",
    )
    primeira: Sequence[str] = getattr(args, "message", None) or ()
    if primeira:
        chat.greet()
        chat.ask_agent(" ".join(primeira))
        if not p.interactive or getattr(args, "once", False):
            chat.bye()
            return 0 if (not chat.turns or chat.turns[-1].outcome.ok) else 1
        return chat.loop(greet=False)
    if not p.interactive:
        print("sem terminal interativo: passe a mensagem (`exovision-agent chat \"tarefa\"`) ou use `agents run`", file=sys.stderr)
        return 2
    return chat.loop()


def add_parser(sub: Any) -> None:
    c = sub.add_parser("chat", help="conversa com o agente (o padrão quando não se passa subcomando)")
    c.add_argument("message", nargs="*", help="a primeira mensagem (sem ela, abre a conversa)")
    c.add_argument("--agent", "-a", help="diretório do agente ou da equipe")
    c.add_argument("--model", "-m", help="modelo só para esta conversa")
    c.add_argument("--effort")
    c.add_argument("--session", "-s")
    c.add_argument("--scripted", help="roteiro JSON em vez do modelo (sem rede)")
    c.add_argument("--once", action="store_true", help="responde a mensagem e sai")
    c.set_defaults(fn=cmd_chat)
