"""Ferramentas: o que o modelo pode pedir, e como o harness executa.

Duas superfícies, separadas de propósito:

- **`ToolResult`** — o que volta para o *runtime*: `ok`, `code`, `metadata`
  são controle; `text` é apresentação para o modelo. Inferir falha de um prefixo
  como ``[erro]`` no texto tornava a telemetria mentirosa para comandos que
  saem com código não zero e texto útil.
- **`Toolset`** — o que o *laço* exige de qualquer ferramentaria: declarar-se
  (`definitions()`) e executar (`__call__`). Uma bancada de bash/editor, um
  conjunto de funções decoradas e um servidor MCP implementam a mesma
  superfície; é isso que impede o laço de ganhar um `if` por tipo de agente.

Ferramentas definidas pela Anthropic (`bash_20250124`, `text_editor_20250728`)
entram **sem `input_schema`**: o modelo foi treinado nelas, e mandar um schema
nosso as transformaria em ferramentas customizadas homônimas — outra coisa.

`parallel_safe` é a razão de promover uma ação a ferramenta própria: pelo
comando opaco do bash o harness não distingue um `grep` de um `git push` e
teria de serializar tudo.
"""

from __future__ import annotations

import enum
import inspect
import json
import typing
from collections.abc import Callable
from dataclasses import dataclass, field
from typing import Any, Protocol, runtime_checkable

__all__ = [
    "RISK_LEVELS",
    "Composite",
    "Registry",
    "Tool",
    "ToolAssemblyError",
    "ToolCall",
    "ToolResult",
    "Toolset",
    "anthropic_defined",
    "schema_from_signature",
    "tool",
]

#: Níveis de risco, do mais brando ao mais grave. A política de governança
#: decide por nível: `read` é seguramente paralelizável e nunca pede
#: confirmação; `irreversible` é o candidato natural a um portão humano.
RISK_LEVELS: tuple[str, ...] = ("read", "write", "external", "irreversible")


class ToolAssemblyError(RuntimeError):
    """Falha ao montar a ferramentaria (colisão, definição inválida).

    Derruba a *montagem*, não a chamada: despacho ambíguo descoberto no meio
    de uma execução custa a execução.
    """


@dataclass(frozen=True, slots=True)
class ToolResult:
    """Estado para o runtime, texto para o modelo."""

    text: str
    ok: bool = True
    code: int = 0
    metadata: dict[str, Any] = field(default_factory=dict)
    #: blocos de conteúdo adicionais no formato de fio (ex.: imagens). Quando
    #: presente, substitui `text` como `content` do `tool_result`.
    blocks: tuple[dict[str, Any], ...] = ()

    @classmethod
    def error(cls, text: str, *, code: int = 1, **metadata: Any) -> ToolResult:
        return cls(text=text, ok=False, code=code, metadata=metadata)

    def to_block(self, tool_use_id: str) -> dict[str, Any]:
        """O bloco `tool_result` no formato da Messages API."""
        block: dict[str, Any] = {"type": "tool_result", "tool_use_id": tool_use_id}
        block["content"] = list(self.blocks) if self.blocks else self.text
        if not self.ok:
            block["is_error"] = True
        return block

    def __str__(self) -> str:
        return self.text


def normalize(value: Any) -> ToolResult:
    """Aceita a superfície legada (str) e dicts/listas (serializados em JSON)."""
    if isinstance(value, ToolResult):
        return value
    if value is None:
        return ToolResult(text="")
    if isinstance(value, str):
        return ToolResult(text=value)
    if isinstance(value, (dict, list, tuple, int, float, bool)):
        return ToolResult(text=json.dumps(value, ensure_ascii=False, default=str))
    return ToolResult(text=str(value))


@dataclass(frozen=True, slots=True)
class ToolCall:
    """Um pedido de ferramenta feito pelo modelo (bloco `tool_use`)."""

    id: str
    name: str
    arguments: dict[str, Any]

    @classmethod
    def from_block(cls, block: dict[str, Any]) -> ToolCall:
        raw = block.get("input") or {}
        # O modelo pode escapar JSON de formas diferentes; sempre decodificar,
        # nunca casar string.
        if isinstance(raw, str):
            try:
                raw = json.loads(raw)
            except json.JSONDecodeError:
                raw = {"_raw": raw}
        return cls(
            id=str(block.get("id", "")), name=str(block.get("name", "")), arguments=dict(raw)
        )


@runtime_checkable
class Toolset(Protocol):
    """O que o laço exige de uma ferramentaria: declarar-se e executar."""

    def definitions(self) -> list[dict[str, Any]]: ...

    def __call__(self, name: str, arguments: dict[str, Any]) -> Any: ...


# --------------------------------------------------------------------------
# Derivação de schema a partir de assinatura Python
# --------------------------------------------------------------------------

_PRIMITIVES: dict[Any, dict[str, Any]] = {
    str: {"type": "string"},
    int: {"type": "integer"},
    float: {"type": "number"},
    bool: {"type": "boolean"},
    dict: {"type": "object"},
    list: {"type": "array"},
    tuple: {"type": "array"},
    Any: {},
}


def _schema_for(annotation: Any) -> dict[str, Any]:
    if annotation is inspect.Parameter.empty:
        return {}
    if annotation in _PRIMITIVES:
        return dict(_PRIMITIVES[annotation])
    origin = typing.get_origin(annotation)
    args = typing.get_args(annotation)
    if origin is typing.Union or (origin is not None and origin.__name__ == "UnionType"):
        non_none = [a for a in args if a is not type(None)]
        if len(non_none) == 1:
            return _schema_for(non_none[0])
        return {"anyOf": [_schema_for(a) for a in non_none]}
    if origin in (list, tuple, set, frozenset):
        item = _schema_for(args[0]) if args else {}
        return {"type": "array", "items": item}
    if origin is dict:
        return {"type": "object"}
    if origin is typing.Literal:
        return {"enum": list(args)}
    if inspect.isclass(annotation) and issubclass(annotation, enum.Enum):
        return {"enum": [m.value for m in annotation]}
    return {}


def _param_docs(doc: str) -> dict[str, str]:
    """Extrai `nome: descrição` de seções `Args:`/`Parâmetros:` (Google style)."""
    out: dict[str, str] = {}
    lines = doc.splitlines()
    active = False
    for line in lines:
        stripped = line.strip()
        if stripped.lower().rstrip(":") in (
            "args",
            "arguments",
            "parameters",
            "parâmetros",
            "parametros",
        ):
            active = True
            continue
        if active:
            if not stripped:
                continue
            if stripped.endswith(":") and " " not in stripped.rstrip(":"):
                active = False  # nova seção (Returns:, Raises:)
                continue
            if ":" in stripped:
                name, _, desc = stripped.partition(":")
                name = name.split("(")[0].strip()
                out[name] = desc.strip()
    return out


def schema_from_signature(fn: Callable[..., Any]) -> dict[str, Any]:
    """JSON Schema (draft-07 subset) derivado dos type hints e da docstring."""
    sig = inspect.signature(fn)
    try:
        hints = typing.get_type_hints(fn)
    except Exception:
        hints = {}
    docs = _param_docs(inspect.getdoc(fn) or "")
    properties: dict[str, Any] = {}
    required: list[str] = []
    for name, param in sig.parameters.items():
        if name in ("self", "cls") or param.kind in (
            inspect.Parameter.VAR_POSITIONAL,
            inspect.Parameter.VAR_KEYWORD,
        ):
            continue
        schema = _schema_for(hints.get(name, param.annotation))
        if name in docs:
            schema["description"] = docs[name]
        if param.default is inspect.Parameter.empty:
            required.append(name)
        elif param.default is not None:
            schema["default"] = param.default
        properties[name] = schema
    out: dict[str, Any] = {"type": "object", "properties": properties}
    if required:
        out["required"] = required
    return out


# --------------------------------------------------------------------------
# Tool
# --------------------------------------------------------------------------


@dataclass(slots=True)
class Tool:
    """Uma ferramenta customizada: definição + função."""

    name: str
    description: str
    fn: Callable[..., Any]
    input_schema: dict[str, Any] = field(
        default_factory=lambda: {"type": "object", "properties": {}}
    )
    parallel_safe: bool = False
    risk: str = "write"
    strict: bool = False
    #: Para ferramentas definidas pela Anthropic: o `type` versionado. Quando
    #: presente, a definição vai sem `input_schema`.
    defined_type: str = ""

    def __post_init__(self) -> None:
        if not self.name or not self.name.replace("_", "").replace("-", "").isalnum():
            raise ToolAssemblyError(f"nome de ferramenta inválido: {self.name!r}")
        if self.risk not in RISK_LEVELS:
            raise ToolAssemblyError(f"risco {self.risk!r} fora de {RISK_LEVELS}")
        if not self.defined_type and not self.description:
            raise ToolAssemblyError(
                f"ferramenta {self.name!r} sem descrição: existe e nunca é escolhida"
            )

    def definition(self) -> dict[str, Any]:
        if self.defined_type:
            return {"type": self.defined_type, "name": self.name}
        d: dict[str, Any] = {
            "name": self.name,
            "description": self.description,
            "input_schema": self.input_schema,
        }
        if self.strict:
            d["strict"] = True
            d["input_schema"] = {**self.input_schema, "additionalProperties": False}
            d["input_schema"].setdefault("required", list(self.input_schema.get("properties", {})))
        return d

    def __call__(self, **arguments: Any) -> ToolResult:
        return normalize(self.fn(**arguments))


def tool(
    fn: Callable[..., Any] | None = None,
    *,
    name: str | None = None,
    description: str | None = None,
    parallel_safe: bool = False,
    risk: str = "write",
    strict: bool = False,
) -> Any:
    """Decorador: transforma uma função Python numa `Tool`.

    >>> @tool(parallel_safe=True, risk="read")
    ... def soma(a: int, b: int = 0) -> int:
    ...     '''Soma dois inteiros.
    ...
    ...     Args:
    ...         a: primeiro
    ...         b: segundo
    ...     '''
    ...     return a + b
    >>> soma.definition()["input_schema"]["required"]
    ['a']
    """

    def wrap(f: Callable[..., Any]) -> Tool:
        doc = inspect.getdoc(f) or ""
        desc = description if description is not None else doc.split("\n\n")[0].strip()
        return Tool(
            name=name or f.__name__,
            description=desc,
            fn=f,
            input_schema=schema_from_signature(f),
            parallel_safe=parallel_safe,
            risk=risk,
            strict=strict,
        )

    return wrap(fn) if fn is not None else wrap


def anthropic_defined(
    defined_type: str,
    name: str,
    fn: Callable[..., Any],
    *,
    risk: str = "write",
    parallel_safe: bool = False,
) -> Tool:
    """Uma ferramenta definida pela Anthropic (`bash_20250124`, `text_editor_20250728`)."""
    return Tool(
        name=name,
        description="",
        fn=fn,
        defined_type=defined_type,
        risk=risk,
        parallel_safe=parallel_safe,
    )


# --------------------------------------------------------------------------
# Registry / Composite
# --------------------------------------------------------------------------


class Registry:
    """Ferramentaria em processo: um dicionário de `Tool` com a superfície `Toolset`.

    Colisão de nome é erro na montagem. A ordem de `definitions()` é a de
    registro — determinística, para que o prefixo de cache não mude entre
    execuções do mesmo agente.
    """

    def __init__(self, tools: typing.Iterable[Tool] = ()) -> None:
        self._tools: dict[str, Tool] = {}
        for t in tools:
            self.register(t)

    def register(self, t: Tool) -> Tool:
        if t.name in self._tools:
            raise ToolAssemblyError(f"ferramenta {t.name!r} registrada duas vezes")
        self._tools[t.name] = t
        return t

    def tool(self, **kw: Any) -> Callable[[Callable[..., Any]], Tool]:
        """`@registry.tool(...)` — decora e registra."""

        def deco(f: Callable[..., Any]) -> Tool:
            return self.register(tool(f, **kw))

        return deco

    def get(self, name: str) -> Tool | None:
        return self._tools.get(name)

    def names(self) -> list[str]:
        return list(self._tools)

    def definitions(self) -> list[dict[str, Any]]:
        return [t.definition() for t in self._tools.values()]

    def parallel_safe(self, name: str) -> bool:
        t = self._tools.get(name)
        return bool(t and t.parallel_safe)

    def risk(self, name: str) -> str:
        t = self._tools.get(name)
        return t.risk if t else "irreversible"

    def __call__(self, name: str, arguments: dict[str, Any]) -> ToolResult:
        t = self._tools.get(name)
        if t is None:
            return ToolResult.error(
                f"ferramenta desconhecida: {name!r}. Disponíveis: {', '.join(self._tools)}",
                code=404,
            )
        try:
            inspect.signature(t.fn).bind(**arguments)
        except TypeError as erro:
            # argumento faltando/extra: informação para o modelo corrigir
            return ToolResult.error(f"argumentos inválidos para {name!r}: {erro}", code=422)
        try:
            return t(**arguments)
        except Exception as erro:
            return ToolResult.error(
                f"{type(erro).__name__}: {erro}", code=500, exception=type(erro).__name__
            )

    def __len__(self) -> int:
        return len(self._tools)

    def __contains__(self, name: str) -> bool:
        return name in self._tools


class Composite:
    """Várias ferramentarias, uma superfície. Colisão derruba a montagem."""

    def __init__(self, *toolsets: Toolset) -> None:
        self._sets: list[Toolset] = list(toolsets)
        self._owner: dict[str, Toolset] = {}
        for ts in self._sets:
            for d in ts.definitions():
                n = d["name"]
                if n in self._owner:
                    raise ToolAssemblyError(f"ferramenta {n!r} definida por duas ferramentarias")
                self._owner[n] = ts

    def definitions(self) -> list[dict[str, Any]]:
        out: list[dict[str, Any]] = []
        for ts in self._sets:
            out.extend(ts.definitions())
        return out

    def parallel_safe(self, name: str) -> bool:
        ts = self._owner.get(name)
        fn = getattr(ts, "parallel_safe", None)
        return bool(fn(name)) if callable(fn) else False

    def risk(self, name: str) -> str:
        ts = self._owner.get(name)
        fn = getattr(ts, "risk", None)
        return str(fn(name)) if callable(fn) else "irreversible"

    def __call__(self, name: str, arguments: dict[str, Any]) -> ToolResult:
        ts = self._owner.get(name)
        if ts is None:
            return ToolResult.error(f"ferramenta desconhecida: {name!r}", code=404)
        try:
            return normalize(ts(name, arguments))
        except Exception as erro:
            return ToolResult.error(f"{type(erro).__name__}: {erro}", code=500)

    def __len__(self) -> int:
        return len(self._owner)
