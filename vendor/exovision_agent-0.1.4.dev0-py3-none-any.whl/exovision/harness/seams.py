"""As costuras do harness — o conjunto fechado de pontos por onde tudo passa.

    startup · context.assemble · memory.recall · llm.request · llm.response
    policy.decision · tool.call · tool.result · memory.commit · turn.end · shutdown

Toda chamada ao modelo, toda chamada de ferramenta e toda decisão de governança
atravessa uma costura; não há caminho que as contorne. É isso que faz do traço
uma *medição* e não um log: duas execuções com alavancas diferentes (poda de
contexto, esforço, política, orçamento de memória) deixam traços com a mesma
forma e, portanto, comparáveis.

O conjunto é fechado de propósito. Uma costura que só existe num harness é
passagem, não abstração — e um observador que precisa "saber" quais costuras
existem em cada harness não consegue comparar harnesses.

Observador nunca derruba a execução: observar não é participar.
"""

from __future__ import annotations

import contextlib
import json
import time
from collections import Counter
from collections.abc import Callable, Iterable
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

__all__ = ["SEAMS", "Event", "SeamError", "Seams"]

SEAMS: tuple[str, ...] = (
    "startup",
    "context.assemble",
    "memory.recall",
    "llm.request",
    "llm.response",
    "policy.decision",
    "tool.call",
    "tool.result",
    "memory.commit",
    "turn.end",
    "shutdown",
)

_SEAM_SET = frozenset(SEAMS)
SEPARATOR = "."


class SeamError(ValueError):
    """Costura fora do conjunto fechado."""


@dataclass(frozen=True, slots=True)
class Event:
    """O que passou por uma costura, e quando."""

    seam: str
    session: str
    at: float
    turn: int = 0
    data: dict[str, Any] = field(default_factory=dict)

    @property
    def subject(self) -> str:
        """`llm.request` na sessão `codigo-1` -> `seam.codigo-1.llm.request`.

        Assunto hierárquico, compatível com barramentos (NATS) que casam por
        padrão (`seam.*.tool.>`).
        """
        session = str(self.session).replace(SEPARATOR, "-") or "-"
        return SEPARATOR.join(("seam", session, self.seam))

    def to_dict(self) -> dict[str, Any]:
        return {
            "seam": self.seam,
            "session": self.session,
            "turn": self.turn,
            "at": self.at,
            "subject": self.subject,
            **self.data,
        }


class Seams:
    """O despachante. Publica sempre; guarda o que passou; avisa quem assinou."""

    def __init__(
        self, session: str = "-", *, keep: int = 5000, clock: Callable[[], float] | None = None
    ) -> None:
        self.session = session
        self.keep = keep
        self.trace: list[Event] = []
        self.turn = 0
        self._clock = clock or time.time
        self._listeners: list[tuple[str, Callable[[Event], None]]] = []
        self._counts: Counter[str] = Counter()

    # ----------------------------------------------------------- assinar
    def on(self, seam: str, listener: Callable[[Event], None]) -> None:
        """Escutar uma costura, ou `*` para todas."""
        if seam != "*" and seam not in _SEAM_SET:
            raise SeamError(f"{seam!r} não é costura; use {list(SEAMS)} ou '*'")
        self._listeners.append((seam, listener))

    # ---------------------------------------------------------- publicar
    def emit(self, seam: str, **data: Any) -> Event:
        if seam not in _SEAM_SET:
            raise SeamError(f"{seam!r} não é costura. O conjunto é fechado: {list(SEAMS)}.")
        event = Event(seam=seam, session=self.session, at=self._clock(), turn=self.turn, data=data)
        self.trace.append(event)
        self._counts[seam] += 1
        if len(self.trace) > self.keep:
            del self.trace[: len(self.trace) - self.keep]
        for wanted, listener in self._listeners:
            if wanted in ("*", seam):
                with contextlib.suppress(Exception):  # observar não é participar
                    listener(event)
        return event

    # ----------------------------------------------------------- medir
    def count(self, seam: str) -> int:
        return self._counts.get(seam, 0)

    def counts(self) -> dict[str, int]:
        """O traço em uma linha: quantas vezes cada costura foi atravessada."""
        return {s: self._counts.get(s, 0) for s in SEAMS}

    def of(self, seam: str) -> Iterable[Event]:
        return (e for e in self.trace if e.seam == seam)

    def last(self, seam: str) -> Event | None:
        for e in reversed(self.trace):
            if e.seam == seam:
                return e
        return None

    # -------------------------------------------------------- persistir
    def dump(self, path: str | Path) -> int:
        """Escreve o traço como JSONL (uma linha por evento). Retorna o total."""
        p = Path(path)
        p.parent.mkdir(parents=True, exist_ok=True)
        with p.open("w", encoding="utf-8") as fh:
            for e in self.trace:
                fh.write(json.dumps(e.to_dict(), ensure_ascii=False, default=str) + "\n")
        return len(self.trace)

    def __len__(self) -> int:
        return len(self.trace)

    def __repr__(self) -> str:  # pragma: no cover
        return f"<Seams {self.session} {dict(self._counts)}>"
