"""`exovision-agent`: rodar um agente pela linha de comando.

    exovision-agent run "conserte o teste que falha" --instruction revisor.md \\
        --workspace . --skills ./skills --session pr-42 --trace trace.jsonl

    exovision-agent trace trace.jsonl          # contagem por costura
    exovision-agent sessions --state .exovision/state.db

    exovision-agent run "tarefa" --mcp "npx -y @exemplo/servidor" --mcp-expose index
    exovision-agent run "tarefa" --mcp ./servidor --mcp-resources --mcp-prompt revisar
    exovision-agent run "tarefa" --subagents time.json --ask-at external
    exovision-agent run "tarefa" --rollouts 16 --batch      # 16 amostras, metade do preço

    exovision-agent specialize show ./especialidade --system   # o que a especialidade põe no prompt
    exovision-agent specialize eval ./especialidade --split test
    exovision-agent specialize evolve ./especialidade --iterations 10 --save

    exovision-agent memory kinds                                # as 21 categorias (`mem` é atalho)
    exovision-agent memory write episodic "o deploy falhou às 3h" --db mem.db
    exovision-agent rag ingest ./docs --db corpus.db --embedder fastembed
    exovision-agent rag query "onde fica a Vortex?" --db corpus.db -k 5

    exovision-agent tasks add "revise o PR 42" --db fila.db --instruction revisor.md --workspace .
    exovision-agent tasks work --db fila.db --state journal.db --workers 4   # durável e retomável

    exovision-agent run "tarefa" --plugin ./geo --evolve                     # anexa; o agente pode criar tools
    exovision-agent plugins verify ./geo --trust-db .exovision/trust.db      # a suíte verde promove

    exovision-agent agents new-team ./equipe/lab --description "o lab" --members revisor,redator
    exovision-agent agents send ./equipe/lab --to revisor "revise o PR 42"; exovision-agent agents serve ./equipe/lab

Uma só entrada para o kernel e seus módulos: `run`, `trace` e `sessions` são
o laço; `init` e `doctor` são a entrada guiada (`onboarding.py`);
`specialize`, `memory`, `rag`, `tasks`, `plugins`, `agents` e `models` são os
módulos, cada um registrando o seu subcomando por `add_parser(sub)`.

Antes de qualquer subcomando a CLI carrega o ambiente (`config.load_env`):
`$XDG_CONFIG_HOME/exovision/env`, `./.env` e o `.env` do diretório de perfil
recebido — sem sobrescrever o que já está exportado; `--env-file` acrescenta
um; `EXOVISION_NO_ENV=1` desliga.

Sem `--scripted`, o provedor vem de `--provider`/`--model` (ou do ambiente:
`EXOVISION_PROVIDER`, `EXOVISION_MODEL`); o padrão é o `AnthropicProvider`.
`--scripted roteiro.json` reproduz uma lista de respostas (sem rede);
`--replay cassete.jsonl` reexecuta chamadas gravadas por `--record`. A pilha
do módulo `models` entra pela linha de comando: `--ledger`, `--limits`,
`--breaker`, `--window`.
"""

from __future__ import annotations

import argparse
import json
import sys
from collections import Counter
from collections.abc import Mapping
from pathlib import Path
from typing import Any

from .. import __version__
from . import chat as chat_cli
from . import onboarding
from .agents import cli as agents_cli
from .batch import AnthropicBatchBackend, BatchProvider, rollouts
from .budget import Budget
from .config import load_env, load_env_file
from .instruction import Instruction, load_instruction
from .loop import Agent, run
from .mcp import (
    CallbackElicitor,
    Elicitation,
    MCPToolset,
    PromptLibrary,
    ProviderSampler,
    ResourceToolset,
    SamplingBudget,
    StaticRoots,
)
from .memory import cli as memory_cli
from .memory.bridge import MemoryBridge, NullMemory
from .models import (
    Breaker,
    Cassette,
    Ledger,
    RateLimiter,
    Window,
    make_provider,
    resolve,
    stack,
)
from .models import cli as models_cli
from .models.provider import Provider, ProviderError, Reply, ScriptedProvider
from .plugins import cli as plugins_cli
from .policy import AllowAll, Ask, Chain, DenyRisk
from .rag import cli as rag_cli
from .seams import Event, Seams
from .session import SQLiteStateStore
from .skills import SkillLibrary, load_skills
from .specialize import cli as specialize_cli
from .subagents import Subagent, Subagents
from .tasks import cli as tasks_cli
from .tools import Composite, Registry, ToolCall, Toolset
from .workbench import Workbench


def _scripted(path: str) -> ScriptedProvider:
    data = json.loads(Path(path).read_text(encoding="utf-8"))
    replies = [
        Reply(
            content=item["content"],
            stop_reason=item.get("stop_reason", "end_turn"),
            usage=item.get("usage", {}),
        )
        for item in data
    ]
    return ScriptedProvider(replies, model="scripted")


def _memory(kind: str):
    if kind == "none":
        return NullMemory()
    from .memory.systems.buffer import ConversationBuffer
    from .memory.systems.episodic import EpisodicMemory
    from .memory.systems.semantic import SemanticMemory

    return MemoryBridge([EpisodicMemory(), SemanticMemory(), ConversationBuffer()])


def _ask_terminal(call: ToolCall, risk: str) -> bool:
    sys.stderr.write(
        f"\n[portão] {call.name} (risco {risk}) {json.dumps(call.arguments, ensure_ascii=False)[:300]}\n aprovar? [s/N] "
    )
    sys.stderr.flush()
    try:
        return sys.stdin.readline().strip().lower() in ("s", "sim", "y", "yes")
    except Exception:
        return False


def _elicita_formulario(pedido: Elicitation) -> tuple[str, dict[str, Any]]:
    """Formulário no terminal. Campo por campo, com o schema à vista."""
    sys.stderr.write(f"\n[{pedido.server}] {pedido.message}\n")
    conteudo: dict[str, Any] = {}
    props = pedido.requested_schema.get("properties") or {}
    obrigatorios = set(pedido.requested_schema.get("required") or [])
    for nome, sub in props.items():
        rotulo = sub.get("title") or nome
        tipo = sub.get("type", "string")
        marca = "*" if nome in obrigatorios else ""
        escolhas = f" {sub['enum']}" if sub.get("enum") else ""
        sys.stderr.write(f"  {rotulo}{marca} ({tipo}{escolhas}): ")
        sys.stderr.flush()
        bruto = sys.stdin.readline().strip()
        if not bruto:
            if nome in obrigatorios:
                return "cancel", {}
            continue
        if tipo == "integer":
            conteudo[nome] = int(bruto)
        elif tipo == "number":
            conteudo[nome] = float(bruto)
        elif tipo == "boolean":
            conteudo[nome] = bruto.lower() in ("s", "sim", "y", "yes", "true", "1")
        else:
            conteudo[nome] = bruto
    sys.stderr.write("  enviar? [s/N] ")
    sys.stderr.flush()
    if sys.stdin.readline().strip().lower() not in ("s", "sim", "y", "yes"):
        return "decline", {}
    return "accept", conteudo


def _elicita_url(pedido: Elicitation, host: str) -> str:
    """Modo URL: mostra a URL inteira e o host. Não abre nada."""
    sys.stderr.write(
        f"\n[{pedido.server}] {pedido.message}\n"
        f"  o servidor quer que você abra, por conta própria:\n"
        f"  {pedido.url}\n  host: {host}\n  consentir? [s/N] "
    )
    sys.stderr.flush()
    return (
        "accept" if sys.stdin.readline().strip().lower() in ("s", "sim", "y", "yes") else "decline"
    )


def _aprova_sampling(params: Mapping[str, Any], server: str) -> bool:
    quantas = len(params.get("messages") or [])
    sys.stderr.write(
        f"\n[sampling] {server} quer usar o seu modelo ({quantas} mensagem(ns), "
        f"maxTokens={params.get('maxTokens', '?')}). Autorizar? [s/N] "
    )
    sys.stderr.flush()
    return sys.stdin.readline().strip().lower() in ("s", "sim", "y", "yes")


def _mcp_toolsets(
    specs: list[str], args: argparse.Namespace, provider: Provider
) -> list[MCPToolset]:
    """`--mcp` aceita uma URL (Streamable HTTP) ou um comando (stdio).

    O piso de risco padrão é `external`: ferramenta de servidor de terceiro
    não passa por um portão só porque se declarou de leitura. As capacidades
    que o servidor *pede de volta* — sampling, elicitation, roots — só são
    declaradas quando a linha de comando as liga explicitamente.
    """
    out: list[MCPToolset] = []
    for i, spec in enumerate(specs or []):
        opts: dict[str, Any] = {
            "prefix": f"mcp{i}" if len(specs) > 1 else "",
            "risk_floor": args.mcp_risk_floor,
            "trust_annotations": args.mcp_trust_annotations,
            "expose": args.mcp_expose,
            "use_tasks": args.mcp_tasks,
        }
        if args.mcp_sampling:
            opts["sampler"] = ProviderSampler(
                provider,
                budget=SamplingBudget(
                    max_calls=args.mcp_sampling_max_calls,
                    max_cost_usd=args.mcp_sampling_max_cost,
                ),
                approve=_aprova_sampling if args.mcp_sampling_ask else None,
            )
        if args.mcp_elicit:
            opts["elicitor"] = CallbackElicitor(form=_elicita_formulario, url=_elicita_url)
        if args.mcp_roots and args.workspace:
            opts["roots"] = StaticRoots([args.workspace])
        if spec.startswith(("http://", "https://")):
            out.append(MCPToolset.http(spec, **opts))
        else:
            out.append(MCPToolset.stdio(spec, **opts))
    return out


def _subagents(path: str, provider: Any, args: argparse.Namespace) -> Subagents | None:
    """Um time declarado em JSON — instrução, descrição, workspace e teto por agente.

    [{"name": "revisor", "instruction": "rev.md", "description": "Revisa o diff.",
      "workspace": ".", "max_turns": 8, "deny_at": "external"}]
    """
    if not path:
        return None
    declarados = json.loads(Path(path).read_text(encoding="utf-8"))
    membros: list[Subagent] = []
    for d in declarados:
        ws = Path(d["workspace"]).resolve() if d.get("workspace") else None
        filho = Agent(
            provider=provider,
            instruction=(
                load_instruction(d["instruction"])
                if d.get("instruction")
                else Instruction.inline(d.get("system", "Você é um subagente preciso."))
            ),
            name=d["name"],
            toolset=Workbench(ws) if ws else Registry(),
            policy=DenyRisk(at_or_above=d["deny_at"]) if d.get("deny_at") else AllowAll(),
            budget=Budget(max_turns=int(d.get("max_turns", 12))),
            workspace=ws,
        )
        membros.append(
            Subagent(
                name=d["name"],
                agent=filho,
                description=d["description"],
                returns=d.get("returns", "um resumo do que fez, verificou e do que faltou"),
                risk=d.get("risk", ""),
            )
        )
    return Subagents(membros, budget=Budget(max_cost_usd=args.max_cost), session=args.session)


def with_plugins(
    agent: Agent,
    *,
    plugin_paths: list[str] | None,
    workspace: Path | None,
    trust_db: str | None,
    evolve: bool,
    expose: str = "all",
    mcp_factory: Any = None,
) -> Agent:
    """Anexa plugins ao agente: os de `--plugin`, mais `plugins/` do workspace se existir.

    `--evolve` acrescenta o meta-toolset que cria plugins e tools em
    `<workspace>/plugins` (em draft; a suíte promove). O estado de confiança
    vem de `--trust-db` (padrão: `<workspace>/.exovision/trust.db` quando há
    workspace); sem ele tudo é draft — piso `external`.
    """
    from .plugins import Evolve, SQLiteTrustStore, attach, load_plugins

    paths: list[str] = list(plugin_paths or [])
    auto = (workspace / "plugins") if workspace else None
    if auto is not None and auto.is_dir() and str(auto) not in paths:
        paths.append(str(auto))
    plugins = load_plugins(paths) if paths else []
    if not trust_db and workspace is not None:
        trust_db = str(workspace / ".exovision" / "trust.db")
    store = SQLiteTrustStore(trust_db) if trust_db else None
    ev = None
    if evolve:
        root = auto if auto is not None else Path("plugins")
        ev = Evolve(root, store=store)
    if not plugins and ev is None:
        return agent
    return attach(agent, plugins, store=store, expose=expose, mcp_factory=mcp_factory, evolve=ev)


def _compose(*partes: Toolset | None) -> Toolset:
    """Uma ferramentaria só, a partir do que o operador pediu.

    Ferramentaria vazia é descartada antes de compor: um `Composite` com um
    conjunto vazio dentro só acrescenta um nível de indireção ao despacho.
    """
    usadas = [p for p in partes if p is not None and p.definitions()]
    if not usadas:
        return Registry()
    return usadas[0] if len(usadas) == 1 else Composite(*usadas)


def _provider(args: argparse.Namespace) -> Provider:
    """O driver e a pilha do módulo `models`, na ordem fixa do `stack`."""
    if args.scripted:
        base: Provider = _scripted(args.scripted)
    elif args.replay:
        from .models import Replay

        base = Replay(args.replay, model=args.model or "", effort=args.effort or "")
    else:
        spec = f"{args.provider}:{args.model or ''}" if args.provider else (args.model or "")
        base = make_provider(spec, effort=args.effort or "", base_url=args.base_url or "")
    cassette = Cassette(args.record, mode="once") if (args.record and not args.replay) else None
    limiter = None
    if args.limits:
        limiter = RateLimiter(
            args.limits, model=getattr(base, "model", "") or "-",
            rpm=args.rpm, itpm=args.itpm, otpm=args.otpm,
        )
    breaker = Breaker() if args.breaker else None
    ledger = Ledger(args.ledger) if args.ledger else None
    return stack(base, limiter=limiter, breaker=breaker, cassette=cassette, ledger=ledger, agent=args.name)


def _window(args: argparse.Namespace, provider: Provider) -> Window | None:
    if not args.window:
        return None
    if args.window == "auto":
        card = resolve(getattr(provider, "model", ""))
        if not card.known:
            sys.stderr.write(f"--window auto: janela de {card.id!r} desconhecida no catálogo; use --window N\n")
            return None
        return Window(context=card.context)
    return Window(context=int(args.window))


def cmd_run(args: argparse.Namespace) -> int:
    try:
        provider = _provider(args)
    except ProviderError as erro:
        sys.stderr.write(f"provedor: {erro}\n")
        return 2
    instruction = (
        load_instruction(args.instruction)
        if args.instruction
        else Instruction.inline(args.system or "Você é um agente útil, preciso e direto.")
    )
    if args.batch:
        if args.scripted:
            sys.stderr.write(
                "--batch fala com a Message Batches API; não combina com --scripted "
                "(o roteiro já é offline e não tem preço de lote).\n"
            )
            return 2
        base = provider
        while hasattr(base, "inner"):  # a pilha do `models` embrulha o driver
            base = base.inner
        if not hasattr(base, "build_kwargs"):
            sys.stderr.write("--batch exige o driver Anthropic (a Message Batches API é dele).\n")
            return 2
        provider = BatchProvider(
            AnthropicBatchBackend(base), size=args.batch_size, model=base.model
        )
    workspace = Path(args.workspace).resolve() if args.workspace else None
    toolset = Workbench(workspace) if workspace else None
    servidores = _mcp_toolsets(args.mcp or [], args, provider)
    recursos = (
        [ResourceToolset(s.client, prefix=s.prefix) for s in servidores]
        if args.mcp_resources
        else []
    )
    bibliotecas = (
        [PromptLibrary(s.client) for s in servidores]
        if (args.mcp_prompt or args.mcp_prompt_skills)
        else []
    )
    time_ = _subagents(args.subagents, provider, args)
    skills_locais = load_skills(args.skills) if args.skills else []
    if args.mcp_prompt_skills:
        for lib in bibliotecas:
            skills_locais.extend(lib.skills())
    skills = SkillLibrary(skills_locais) if skills_locais else None
    if args.mcp_prompt:
        alvo = next((lib for lib in bibliotecas if args.mcp_prompt in lib), None)
        if alvo is None:
            sys.stderr.write(
                f"prompt {args.mcp_prompt!r} não existe em nenhum servidor MCP declarado\n"
            )
            for s_ in servidores:
                s_.close()
            return 2
        instruction = alvo.instruction(args.mcp_prompt)
    policies: list[Any] = []
    if args.deny_at:
        policies.append(DenyRisk(at_or_above=args.deny_at))
    if args.ask_at:
        policies.append(Ask(_ask_terminal, at_or_above=args.ask_at))
    policy = Chain(policies) if policies else AllowAll()
    agent = Agent(
        provider=provider,
        instruction=instruction,
        name=args.name,
        toolset=_compose(toolset, *servidores, *recursos, time_),
        policy=policy,
        memory=_memory(args.memory),
        skills=skills,
        budget=Budget(max_turns=args.max_turns, max_cost_usd=args.max_cost),
        workspace=workspace,
        window=_window(args, provider),
    )

    def mcp_from_plugin(spec: dict[str, Any]) -> MCPToolset:
        opts = {k: v for k, v in spec.items() if k in ("expose", "risk_floor", "prefix")}
        alvo = str(spec["spec"])
        srv = MCPToolset.http(alvo, **opts) if alvo.startswith(("http://", "https://")) else MCPToolset.stdio(alvo, **opts)
        servidores.append(srv)
        return srv

    agent = with_plugins(
        agent,
        plugin_paths=args.plugin,
        workspace=workspace,
        trust_db=args.trust_db,
        evolve=args.evolve,
        expose=args.plugins_expose,
        mcp_factory=mcp_from_plugin,
    )
    seams = Seams(args.session)
    if args.ledger:
        Ledger(args.ledger).attach(seams, agent=args.name)
    if args.verbose:

        def eco(e: Event) -> None:
            visivel = {
                k: v for k, v in e.data.items() if k not in ("arguments", "report", "budget")
            }
            corpo = json.dumps(visivel, ensure_ascii=False, default=str)[:200]
            sys.stderr.write(f"{e.seam:16s} t{e.turn:<3d} {corpo}\n")

        seams.on("*", eco)
    if time_ is not None:
        time_.attach(seams)
    store = SQLiteStateStore(args.state) if args.state else None
    try:
        if args.rollouts > 1:
            pop = rollouts(agent, args.task, k=args.rollouts, session=args.session, seams=seams)
            if args.trace:
                seams.dump(args.trace)
            relatorio = {
                **pop.to_dict(),
                "consenso": dict(zip(("texto", "votos", "total"), pop.consensus(), strict=True)),
            }
            print(json.dumps(relatorio, ensure_ascii=False, indent=2))
            return 0 if pop.solved else 1
        outcome = run(
            agent,
            args.task,
            session=args.session,
            state_store=store,
            resume=args.resume,
            seams=seams,
        )
    finally:
        for s_ in servidores:
            s_.close()
    if args.trace:
        seams.dump(args.trace)
    if args.json:
        saida = outcome.to_dict()
        if time_ is not None:
            saida["subagentes"] = time_.report()
        print(json.dumps(saida, ensure_ascii=False, indent=2))
    else:
        from .ui import color_for, format_outcome

        corpo, rodape = format_outcome(outcome, color=color_for(sys.stderr))
        if corpo:
            print(corpo)
        if time_ is not None:
            rodape += f" · {time_.ledger.runs} delegações"
        sys.stderr.write(rodape + "\n")
    return 0 if outcome.ok else 1


def cmd_trace(args: argparse.Namespace) -> int:
    counts: Counter[str] = Counter()
    for line in Path(args.path).read_text(encoding="utf-8").splitlines():
        if line.strip():
            counts[json.loads(line)["seam"]] += 1
    print(json.dumps(dict(counts), indent=2))
    return 0


def cmd_sessions(args: argparse.Namespace) -> int:
    store = SQLiteStateStore(args.state)
    for name in store.names():
        st = store.load(name)
        if st:
            print(f"{name}\t{st.status}\tturn={st.turn}\tpending={len(st.pending_calls)}")
    return 0


#: preenchido por `build_parser` — é quem registra que sabe o que existe.
SUBCOMMANDS: set[str] = set()


def build_parser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(
        prog="exovision-agent",
        description="EXOVISION-I — o kernel agêntico e seus módulos. Sem subcomando: conversa com o agente daqui.",
    )
    p.add_argument("--version", action="version", version=f"exovision-agent {__version__}")
    p.add_argument("--env-file", metavar="ARQUIVO", help="carrega este .env também (o ambiente já posto tem precedência)")
    # `required=False`: `exovision-agent` sozinho abre a conversa (`chat`).
    sub = p.add_subparsers(dest="cmd", required=False)

    chat_cli.add_parser(sub)
    onboarding.add_parser(sub)

    r = sub.add_parser("run", help="roda uma tarefa")
    r.add_argument("task")
    r.add_argument("--instruction", help="documento .md de instrução")
    r.add_argument("--system", help="instrução inline (alternativa a --instruction)")
    r.add_argument("--name", default="agent")
    r.add_argument("--workspace", help="diretório onde bash/editor/busca rodam")
    r.add_argument("--skills", nargs="*", help="diretórios de skills")
    r.add_argument("--session", default="-")
    r.add_argument("--state", help="arquivo SQLite de estado durável")
    r.add_argument("--resume", action="store_true")
    r.add_argument("--memory", choices=["none", "default"], default="default")
    r.add_argument("--model", help="modelo ou apelido (opus, sonnet, haiku, fable); aceita tipo:modelo[@url]")
    r.add_argument("--effort")
    r.add_argument("--provider", choices=["anthropic", "openai", "google", "local", "compatible"], help="driver (padrão: pelo modelo, ou EXOVISION_PROVIDER)")
    r.add_argument("--base-url", help="URL base para --provider compatible/local/openai")
    r.add_argument("--record", metavar="CASSETE", help="grava as chamadas num cassete JSONL (reexecuta o que já tem)")
    r.add_argument("--replay", metavar="CASSETE", help="só reexecuta o cassete; sem rede")
    r.add_argument("--ledger", metavar="DB", help="livro-razão SQLite: uma linha por chamada e o desfecho")
    r.add_argument("--limits", metavar="DB", help="balde de fichas compartilhado (SQLite) por modelo")
    r.add_argument("--rpm", type=float, default=1000, help="requisições/min do balde (padrão: nível Start)")
    r.add_argument("--itpm", type=float, default=2_000_000, help="tokens de entrada/min do balde")
    r.add_argument("--otpm", type=float, default=400_000, help="tokens de saída/min do balde")
    r.add_argument("--breaker", action="store_true", help="disjuntor: 5 falhas seguidas abrem por 30 s")
    r.add_argument("--window", metavar="N|auto", help="janela do cliente em tokens (compactação simples); auto = catálogo")
    r.add_argument("--max-turns", type=int, default=60)
    r.add_argument("--max-cost", type=float, default=None)
    r.add_argument(
        "--deny-at",
        choices=["read", "write", "external", "irreversible"],
        help="nega ferramentas a partir deste risco",
    )
    r.add_argument(
        "--ask-at",
        choices=["read", "write", "external", "irreversible"],
        help="pede confirmação no terminal a partir deste risco",
    )
    r.add_argument(
        "--mcp",
        action="append",
        metavar="SPEC",
        help="servidor MCP: URL (Streamable HTTP) ou comando (stdio). Repetível.",
    )
    r.add_argument(
        "--mcp-expose",
        choices=["all", "index"],
        default="all",
        help="'all' põe o catálogo no prompt; 'index' publica mcp_find/mcp_call",
    )
    r.add_argument(
        "--mcp-risk-floor",
        choices=["read", "write", "external", "irreversible"],
        default="external",
        help="piso de risco das ferramentas MCP (padrão external)",
    )
    r.add_argument(
        "--mcp-trust-annotations",
        action="store_true",
        help="deixa as anotações do servidor subirem o risco acima do piso",
    )
    r.add_argument(
        "--mcp-resources",
        action="store_true",
        help="publica resource_list/resource_read do servidor como ferramentas",
    )
    r.add_argument("--mcp-prompt", metavar="NOME", help="usa um prompt do servidor como instrução")
    r.add_argument(
        "--mcp-prompt-skills",
        action="store_true",
        help="expõe os prompts do servidor no índice de skills",
    )
    r.add_argument(
        "--mcp-sampling",
        action="store_true",
        help="deixa o servidor usar o SEU modelo (e a sua fatura) via sampling",
    )
    r.add_argument("--mcp-sampling-max-calls", type=int, default=4)
    r.add_argument("--mcp-sampling-max-cost", type=float, default=0.5)
    r.add_argument(
        "--mcp-sampling-ask",
        action="store_true",
        help="pede confirmação no terminal a cada pedido de sampling",
    )
    r.add_argument(
        "--mcp-elicit",
        action="store_true",
        help="deixa o servidor pedir informação ao operador (formulário e consentimento de URL)",
    )
    r.add_argument(
        "--mcp-roots",
        action="store_true",
        help="expõe o --workspace ao servidor como root",
    )
    r.add_argument(
        "--mcp-tasks",
        action="store_true",
        help="usa execução como tarefa quando servidor e ferramenta suportam",
    )
    r.add_argument("--plugin", action="append", metavar="DIR", help="anexa um plugin (repetível); plugins/ do workspace entra sozinho")
    r.add_argument("--evolve", action="store_true", help="o agente pode criar plugins e tools (em draft; a suíte promove)")
    r.add_argument("--trust-db", help="SQLite com o estado de confiança dos plugins (padrão: <workspace>/.exovision/trust.db)")
    r.add_argument("--plugins-expose", choices=["all", "index"], default="all", help="tools dos plugins no catálogo ou por índice (find/call)")
    r.add_argument("--subagents", help="JSON declarando o time de subagentes")
    r.add_argument(
        "--rollouts",
        type=int,
        default=1,
        metavar="K",
        help="K execuções independentes da mesma tarefa; imprime cobertura e consenso",
    )
    r.add_argument(
        "--batch",
        action="store_true",
        help="usa a Message Batches API (metade do preço; assíncrono)",
    )
    r.add_argument("--batch-size", type=int, default=32, help="itens por submissão de lote")
    r.add_argument("--scripted", help="JSON com respostas roteirizadas (sem rede)")
    r.add_argument("--trace", help="grava o traço em JSONL")
    r.add_argument("--json", action="store_true", help="imprime o Outcome em JSON")
    r.add_argument("-v", "--verbose", action="store_true")
    r.set_defaults(fn=cmd_run)

    t = sub.add_parser("trace", help="resume um traço JSONL")
    t.add_argument("path")
    t.set_defaults(fn=cmd_trace)

    s = sub.add_parser("sessions", help="lista sessões de um arquivo de estado")
    s.add_argument("--state", required=True)
    s.set_defaults(fn=cmd_sessions)

    specialize_cli.add_parser(sub)
    memory_cli.add_parser(sub)
    rag_cli.add_parser(sub)
    tasks_cli.add_parser(sub)
    plugins_cli.add_parser(sub)
    agents_cli.add_parser(sub)
    models_cli.add_parser(sub)
    SUBCOMMANDS.clear()
    SUBCOMMANDS.update(sub.choices)
    return p


#: flags do parser raiz que levam valor (não são o subcomando).
_ROOT_VALUE_FLAGS = ("--env-file",)
_ROOT_ACTIONS = ("-h", "--help", "--version")


def _dispatch(argv: list[str], subcomandos: list[str]) -> list[str]:
    """`exovision-agent <qualquer coisa que não seja subcomando>` é conversa.

    Sem isto, `exovision-agent` sozinho falhava por falta de subcomando e
    `exovision-agent --agent ./x` (ou uma frase) morria em "invalid choice".
    Um engano de digitação não vira mensagem para o agente: vira sugestão.
    """
    import difflib

    if not subcomandos:  # build_parser não rodou: preferir falhar a mandar tudo ao modelo
        raise RuntimeError("dispatch sem a lista de subcomandos")
    i = 0
    while i < len(argv):
        tok = argv[i]
        if tok in _ROOT_ACTIONS:
            return argv
        if tok in _ROOT_VALUE_FLAGS:
            i += 2
            continue
        if tok.startswith("-"):
            i += 1
            continue
        if tok in subcomandos:
            return argv
        if len(argv) == 1:
            # Um argumento só que começa com um subcomando ("doctor --help" entre
            # aspas, ou `$var` que o shell não dividiu) quase nunca é uma pergunta
            # para o modelo — e mandá-la custa dinheiro. Melhor recusar.
            primeira = tok.split()[0] if tok.split() else ""
            if " " in tok and primeira in subcomandos:
                raise SystemExit(f"exovision-agent: {tok!r} chegou como um argumento só. Quis dizer `exovision-agent {tok}` (sem aspas)?\n(para conversar mesmo assim: `exovision-agent chat {tok!r}`)")
            if (perto := difflib.get_close_matches(tok, subcomandos, n=1, cutoff=0.75)):
                raise SystemExit(f"exovision-agent: não existe o comando {tok!r}. Você quis dizer `{perto[0]}`?\n(uma frase solta vira mensagem para o agente: `exovision-agent \"{tok} …\"`)")
        break
    return ["chat", *argv]


def main(argv: list[str] | None = None) -> int:
    parser = build_parser()  # preenche SUBCOMMANDS
    bruto = list(sys.argv[1:] if argv is None else argv)
    args = parser.parse_args(_dispatch(bruto, sorted(SUBCOMMANDS)))
    perfil = getattr(args, "path", None) if args.cmd in ("agents", "init", "doctor") else None
    load_env(profile_dir=perfil if isinstance(perfil, str) and Path(perfil).is_dir() else None)
    if args.env_file:
        load_env_file(args.env_file)
    return int(args.fn(args))


if __name__ == "__main__":  # pragma: no cover
    sys.exit(main())
