"""HippoRAG 2 (Gutiérrez et al., 2025, arXiv:2502.14802) — "From RAG to Memory". Experimental.

O que muda em relação ao HippoRAG original (que a memória hipocampal do
SDK implementa):

1. **Passagens viram nós** do grafo, ligadas por arestas de *contexto* às
   frases (entidades) que contêm — a busca densa passa a semear também
   passagens, com peso `passage_weight` (0,05 no artigo), o que dá ao PPR
   um sinal quando a consulta não tem entidade reconhecível.
2. **Sementes vêm de triplas, não de entidades**: as triplas do índice são
   recuperadas por embedding (`s r o` como texto), filtradas por
   *memória de reconhecimento* (o artigo usa o LLM para dizer quais
   triplas são pertinentes; aqui, por padrão, o limiar é o piso de ruído
   do embedder e `recognition` aceita uma função para o filtro por modelo),
   e as frases das triplas sobreviventes viram sementes com o peso do score.
3. **Sinonímia** liga frases com cosseno acima de `synonym_threshold`.

A leitura é o PPR com `damping=0.5`; o score de uma passagem é a massa
que chega ao nó dela. Sem sementes, degrada para a busca densa — o
artigo faz o mesmo.
"""

from __future__ import annotations

from collections.abc import Callable, Iterable, Sequence
from typing import Any

from ...memory.core.embeddings import Embedder, noise_floor_of
from ...memory.core.similarity import cosine
from ..chunking import Chunk
from ..embed import encode_query
from ..index import FlatIndex
from ..types import ChunkStore, ScoredChunk
from .engine import GraphEngine, Node, Rel
from .extract import GraphExtractor, PatternGraphExtractor, link_mentions, recognized

__all__ = ["HippoRAG2"]

PSG = "psg:"
Recognition = Callable[[str, Sequence[tuple[str, float]]], Sequence[str]]


class HippoRAG2:
    name = "hipporag2"

    def __init__(
        self,
        embedder: Embedder,
        store: ChunkStore,
        *,
        extractor: GraphExtractor | None = None,
        damping: float = 0.5,
        passage_weight: float = 0.05,
        top_triples: int = 8,
        top_passages: int = 8,
        synonym_threshold: float | None = None,
        recognition: Recognition | None = None,
        recognition_ratio: float = 0.75,
    ) -> None:
        self.embedder = embedder
        self.store = store
        self.extractor = extractor or PatternGraphExtractor()
        self.damping = damping
        self.passage_weight = passage_weight
        self.top_triples = top_triples
        self.top_passages = top_passages
        floor = noise_floor_of(embedder, 0.1)
        self.synonym_threshold = synonym_threshold if synonym_threshold is not None else max(0.8, 3.0 * floor)
        self.recognition = recognition
        self.recognition_ratio = recognition_ratio
        self.engine = GraphEngine()
        self.triple_index = FlatIndex(embedder.dim)
        self.passage_index = FlatIndex(embedder.dim)
        self._triples: dict[str, tuple[str, str, str]] = {}
        self._phrase_vec: dict[str, tuple[float, ...]] = {}
        self.synonyms = 0

    # ------------------------------------------------------------ índice
    def _add_phrase(self, nid: str, name: str, source: str) -> None:
        if nid in self.engine:
            node = self.engine.nodes[nid]
            if source not in node.sources:
                node.sources.append(source)
            return
        self.engine.add_node(Node(nid, "phrase", name, sources=[source]))
        vec = self.embedder.encode(name)
        for other, ovec in self._phrase_vec.items():
            sim = cosine(vec, ovec)
            if sim >= self.synonym_threshold:
                self.engine.add_rel(Rel(nid, other, "synonym", sim))
                self.synonyms += 1
        self._phrase_vec[nid] = vec

    def index(self, chunks: Iterable[Chunk]) -> int:
        n = 0
        for c in chunks:
            self.index_chunk(c)
            n += 1
        return n

    def index_chunk(self, chunk: Chunk) -> None:
        pnode = PSG + chunk.id
        vec = chunk.embedding or self.embedder.encode(chunk.text_for_embedding)
        self.engine.add_node(Node(pnode, "passage", chunk.id, embedding=vec))
        self.passage_index.add([chunk.id], [vec])
        ex = self.extractor.extract(chunk.text)
        phrases: list[str] = []
        for e in ex.entities:
            self._add_phrase(e.id, e.name, chunk.id)
            phrases.append(e.id)
        for r in ex.relations:
            sid, tid = r.source_id, r.target_id
            if not sid or not tid or sid == tid:
                continue
            for nid, name in ((sid, r.source), (tid, r.target)):
                self._add_phrase(nid, name, chunk.id)
                if nid not in phrases:
                    phrases.append(nid)
            self.engine.add_rel(Rel(sid, tid, r.relation, r.weight, sources=[chunk.id]))
            tkey = f"{sid}|{r.relation}|{tid}"
            if tkey not in self._triples:
                self._triples[tkey] = (sid, r.relation, tid)
                text = f"{r.source} {r.relation.replace('_', ' ')} {r.target}"
                self.triple_index.add([tkey], [self.embedder.encode(text)])
        for nid in phrases:
            self.engine.add_rel(Rel(pnode, nid, "context", 1.0, sources=[chunk.id]))

    # ------------------------------------------------------------ leitura
    def seeds_for(self, query: str) -> tuple[dict[str, float], dict[str, float]]:
        qv = encode_query(self.embedder, query)
        floor = noise_floor_of(self.embedder, 0.0)
        triples = [(k, s) for k, s in self.triple_index.search(qv, self.top_triples) if s > floor]
        if self.recognition is not None and triples:
            keep = set(self.recognition(query, triples))
            triples = [(k, s) for k, s in triples if k in keep]
        elif triples:
            # memória de reconhecimento sem modelo: só triplas próximas da melhor, acima do piso
            kept = recognized(dict(triples), floor=floor, ratio=self.recognition_ratio)
            triples = [(k, s) for k, s in triples if k in kept]
        phrase_seeds: dict[str, float] = {}
        for key, s in triples:
            sid, _, tid = self._triples[key]
            for nid in (sid, tid):
                phrase_seeds[nid] = max(phrase_seeds.get(nid, 0.0), s)
        # frases mencionadas na consulta (extração + ligação de menções)
        phrase_ids = [n for n, node in self.engine.nodes.items() if node.type == "phrase"]
        for e in self.extractor.extract(query).entities:
            if e.id in self.engine:
                phrase_seeds[e.id] = max(phrase_seeds.get(e.id, 0.0), 1.0)
        for nid in link_mentions(query, phrase_ids):
            phrase_seeds[nid] = max(phrase_seeds.get(nid, 0.0), 1.0)
        passage_seeds = recognized(dict(self.passage_index.search(qv, self.top_passages)), floor=floor, ratio=self.recognition_ratio)
        return phrase_seeds, passage_seeds

    def retrieve(self, query: str, k: int = 10) -> list[ScoredChunk]:
        if len(self.passage_index) == 0:
            return []
        phrase_seeds, passage_seeds = self.seeds_for(query)
        qv = encode_query(self.embedder, query)
        if not phrase_seeds:
            dense_only: list[ScoredChunk] = []
            for cid, s in self.passage_index.search(qv, k):
                ch = self.store.get(cid)
                if ch is not None:
                    dense_only.append(ScoredChunk(ch, s, {"dense": s, "ppr": 0.0, "seeds": 0.0}, self.name))
            return dense_only
        seeds: dict[str, float] = dict(phrase_seeds)
        for cid, s in passage_seeds.items():
            seeds[PSG + cid] = seeds.get(PSG + cid, 0.0) + self.passage_weight * s
        rank = self.engine.ppr(seeds, damping=self.damping)
        scored: list[tuple[str, float]] = []
        for nid, mass in rank.items():
            if nid.startswith(PSG) and mass > 0:
                scored.append((nid[len(PSG) :], mass))
        if not scored:
            return []
        max_mass = max(m for _, m in scored) or 1.0
        out: list[ScoredChunk] = []
        for cid, mass in scored:
            ch = self.store.get(cid)
            if ch is None:
                continue
            dense = passage_seeds.get(cid, 0.0)
            # o denso já entrou como semente; aqui só desempata
            out.append(ScoredChunk(ch, mass / max_mass + 0.01 * dense, {"ppr": mass / max_mass, "dense": dense, "seeds": float(len(phrase_seeds))}, self.name))
        out.sort(key=lambda s: (-s.score, s.id))
        return out[:k]

    def stats(self) -> dict[str, Any]:
        return {**self.engine.stats(), "triples": len(self._triples), "synonym_edges": self.synonyms}
