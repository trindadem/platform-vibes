"""Extração de entidades, relações e temas para construir o grafo.

O GraphRAG (Edge et al., 2024) e o LightRAG (Guo et al., 2024) usam um
LLM para extrair, de cada trecho, entidades com tipo e descrição e
relações com descrição e força; o LightRAG pede também *palavras-chave de
alto nível* (temas). `LLMGraphExtractor` faz exatamente isso, com o
`Provider` do harness e saída em JSON.

`PatternGraphExtractor` é a versão **offline e determinística**: relações
do extrator de triplas por padrões da memória, entidades dos nomes
próprios e dos extremos das triplas, descrição = a sentença em que a
entidade aparece, temas = as palavras de conteúdo mais frequentes. É a
linha de base honesta que faz os testes e o benchmark sintético rodarem
sem rede; a limitação (sujeito-verbo-objeto simples) é a do extrator de
padrões, e está declarada lá.
"""

from __future__ import annotations

import json
import re
from collections import Counter
from collections.abc import Iterable, Sequence
from dataclasses import dataclass, field
from typing import Any, Protocol, runtime_checkable

from ...memory.core.extract import PatternTripleExtractor
from ...memory.core.summarize import split_sentences
from ...memory.core.text import content_words, fold
from ...models.provider import Provider
from ..llm import LLMUsage, ask

__all__ = ["Entity", "Extraction", "GraphExtractor", "LLMGraphExtractor", "PatternGraphExtractor", "Relation", "entity_id", "link_mentions", "merge_extractions", "named_spans", "recognized"]


def entity_id(name: str) -> str:
    return fold(name).strip().replace(" ", "_")


_SENT_START = re.compile(r"(?:^|[.!?;\n]\s+)(\w)", re.UNICODE)
_TOKEN = re.compile(r"\b\w+\b", re.UNICODE)


def named_spans(text: str) -> list[str]:
    """Sequências de tokens capitalizados ("Ana Souza", "Banco Central").

    Um token capitalizado no início da sentença só entra se o span tem mais
    de um token — "Lisboa é..." é ambíguo, "Ana Souza trabalha..." não.
    """
    starts = {m.start(1) for m in _SENT_START.finditer(text)}
    spans: list[str] = []
    cur: list[tuple[str, bool]] = []
    last_end = -1
    for m in _TOKEN.finditer(text):
        tok = m.group(0)
        is_cap = len(tok) >= 2 and tok[0].isupper() and not tok.isupper()
        contiguous = m.start() - last_end <= 1
        if is_cap and (contiguous or not cur):
            cur.append((tok, m.start() in starts))
        else:
            if cur and not (len(cur) == 1 and cur[0][1]):
                spans.append(" ".join(t for t, _ in cur))
            cur = [(tok, m.start() in starts)] if is_cap else []
        last_end = m.end()
    if cur and not (len(cur) == 1 and cur[0][1]):
        spans.append(" ".join(t for t, _ in cur))
    out: list[str] = []
    for sp in spans:
        if sp not in out:
            out.append(sp)
    return out


@dataclass(slots=True)
class Entity:
    name: str
    type: str = "entity"
    description: str = ""

    @property
    def id(self) -> str:
        return entity_id(self.name)


@dataclass(slots=True)
class Relation:
    source: str
    target: str
    relation: str = "related"
    description: str = ""
    weight: float = 1.0

    @property
    def source_id(self) -> str:
        return entity_id(self.source)

    @property
    def target_id(self) -> str:
        return entity_id(self.target)


@dataclass(slots=True)
class Extraction:
    entities: list[Entity] = field(default_factory=list)
    relations: list[Relation] = field(default_factory=list)
    keywords: list[str] = field(default_factory=list)


@runtime_checkable
class GraphExtractor(Protocol):
    def extract(self, text: str) -> Extraction: ...


class PatternGraphExtractor:
    def __init__(self, *, max_keywords: int = 8, triples: PatternTripleExtractor | None = None) -> None:
        self.max_keywords = max_keywords
        self.triples = triples or PatternTripleExtractor()

    def extract(self, text: str) -> Extraction:
        sentences = split_sentences(text)
        ents: dict[str, Entity] = {}

        def describe(name: str) -> str:
            probe = fold(name.replace("_", " "))
            for s in sentences:
                if probe in fold(s):
                    return s[:240]
            return ""

        rels: list[Relation] = []
        # por sentença: o extrator de padrões não conhece fronteira de sentença
        for sent in sentences:
            has_copula = "é" in sent or "É" in sent
            for t in self.triples.extract(sent):
                # "e" só é cópula quando a sentença tem "é"; senão é a conjunção
                if t.relation.split("_")[0] == "e" and not has_copula:
                    continue
                for n in (t.subject, t.object):
                    if n and n not in ents:
                        ents[n] = Entity(n.replace("_", " "), "entity", describe(n))
                rels.append(Relation(t.subject.replace("_", " "), t.object.replace("_", " "), t.relation, "", t.confidence))
        for span in named_spans(text):
            key = entity_id(span)
            if key not in ents:
                ents[key] = Entity(span, "named", describe(span))
        counts = Counter(w for w in content_words(text) if len(w) >= 4)
        keywords = [w for w, _ in counts.most_common(self.max_keywords)]
        return Extraction(list(ents.values()), rels, keywords)


_SYSTEM = (
    "Você extrai um grafo de conhecimento de um texto. Responda SOMENTE com JSON no formato "
    '{"entities":[{"name":"...","type":"...","description":"..."}],'
    '"relations":[{"source":"...","target":"...","relation":"...","description":"...","strength":1-10}],'
    '"keywords":["tema de alto nível", ...]}. Nomes de entidade em forma canônica; '
    "relações entre entidades listadas; keywords são temas gerais do texto, não entidades."
)


class LLMGraphExtractor:
    def __init__(self, provider: Provider, *, usage: LLMUsage | None = None, max_tokens: int = 2000) -> None:
        self.provider = provider
        self.usage = usage or LLMUsage()
        self.max_tokens = max_tokens

    @staticmethod
    def parse(text: str) -> Extraction:
        m = re.search(r"\{.*\}", text, re.S)
        if not m:
            return Extraction()
        try:
            data: dict[str, Any] = json.loads(m.group(0))
        except json.JSONDecodeError:
            return Extraction()
        ents = [
            Entity(str(e.get("name", "")).strip(), str(e.get("type", "entity")).strip() or "entity", str(e.get("description", "")).strip())
            for e in data.get("entities", [])
            if isinstance(e, dict) and str(e.get("name", "")).strip()
        ]
        rels = []
        for r in data.get("relations", []):
            if not isinstance(r, dict) or not r.get("source") or not r.get("target"):
                continue
            try:
                w = float(r.get("strength", 5)) / 10.0
            except (TypeError, ValueError):
                w = 0.5
            rels.append(Relation(str(r["source"]).strip(), str(r["target"]).strip(), str(r.get("relation", "related")).strip() or "related", str(r.get("description", "")).strip(), max(0.1, min(1.0, w))))
        kws = [str(k).strip() for k in data.get("keywords", []) if str(k).strip()]
        return Extraction(ents, rels, kws)

    def extract(self, text: str) -> Extraction:
        return self.parse(ask(self.provider, _SYSTEM, text, usage=self.usage, max_tokens=self.max_tokens))


def recognized(cands: dict[str, float], *, floor: float, ratio: float) -> dict[str, float]:
    """Memória de reconhecimento sem modelo: mantém os candidatos cujo excesso acima
    do piso de ruído é pelo menos `ratio` vezes o excesso do melhor.

    Em embedders anisotrópicos (bge: p99 do ruído ~0,76) os scores se comprimem
    perto de 1 e uma razão sobre o score cru deixa passar quase tudo; a razão
    sobre o excesso `(s - piso) / (melhor - piso)` é invariante a esse deslocamento.
    """
    if not cands:
        return {}
    best = max(cands.values())
    if best <= floor:
        return {}
    keep: dict[str, float] = {}
    for k, s in cands.items():
        if s >= 1.0 - 1e-9 or (s - floor) >= ratio * (best - floor):
            keep[k] = s
    return keep


def link_mentions(text: str, node_ids: Iterable[str], *, min_len: int = 4) -> list[str]:
    """Liga menções do texto a ids de nós: id inteiro, ou token único de um id composto.

    "Karina" liga a `karina_lopes` se nenhum outro nó tem o token `karina`
    — *entity linking* mínimo, sem modelo. Tokens curtos e ambíguos não ligam.
    """
    words = [w for w in content_words(text) if len(w) >= min_len]
    ids = list(node_ids)
    idset = set(ids)
    found: list[str] = []
    # id composto presente literalmente ("ana souza" -> ana_souza)
    folded = " " + " ".join(content_words(text)) + " "
    for nid in ids:
        if "_" in nid and " " + nid.replace("_", " ") + " " in folded and nid not in found:
            found.append(nid)
    by_token: dict[str, list[str]] = {}
    for nid in ids:
        for tok in nid.split("_"):
            by_token.setdefault(tok, []).append(nid)
    for w in words:
        if w in idset and w not in found:
            found.append(w)
            continue
        owners = by_token.get(w, [])
        if len(owners) == 1 and owners[0] not in found:
            found.append(owners[0])
    return found


def merge_extractions(items: Sequence[Extraction]) -> Extraction:
    out = Extraction()
    seen_e: set[str] = set()
    seen_r: set[tuple[str, str, str]] = set()
    for ex in items:
        for e in ex.entities:
            if e.id not in seen_e:
                seen_e.add(e.id)
                out.entities.append(e)
        for r in ex.relations:
            key = (r.source_id, r.relation, r.target_id)
            if key not in seen_r:
                seen_r.add(key)
                out.relations.append(r)
        for kw in ex.keywords:
            if kw not in out.keywords:
                out.keywords.append(kw)
    return out
