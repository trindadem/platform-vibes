"""RAG sobre grafo: motor (Louvain/Leiden/PPR/fluxo), extração e quatro métodos.

| método | regime | leitura |
|---|---|---|
| `GraphRAG` | indústria | comunidades Leiden + relatórios; busca local e global |
| `LightRAG` | experimental | dois níveis: entidades (baixo) e relações/temas (alto) |
| `HippoRAG2` | experimental | passagens como nós, sementes por triplas, PPR |
| `PathRAG` | experimental | caminhos entre sementes podados por fluxo |
"""

from .builder import EntityGraphBuilder
from .engine import GraphEngine, Node, Path, Rel, leiden, louvain, modularity
from .extract import (
    Entity,
    Extraction,
    GraphExtractor,
    LLMGraphExtractor,
    PatternGraphExtractor,
    Relation,
    named_spans,
)
from .graphrag import CommunityReport, GraphRAG
from .hipporag2 import HippoRAG2
from .lightrag import LightRAG
from .pathrag import PathRAG

__all__ = [
    "CommunityReport",
    "Entity",
    "EntityGraphBuilder",
    "Extraction",
    "GraphEngine",
    "GraphExtractor",
    "GraphRAG",
    "HippoRAG2",
    "LLMGraphExtractor",
    "LightRAG",
    "Node",
    "Path",
    "PathRAG",
    "PatternGraphExtractor",
    "Rel",
    "Relation",
    "leiden",
    "louvain",
    "modularity",
    "named_spans",
]
