"""PathRAG (Chen et al., 2025, arXiv:2502.14902) — caminhos relacionais podados por fluxo. Experimental.

O diagnóstico do PathRAG sobre GraphRAG/LightRAG: a vizinhança das
entidades-semente é redundante e cheia de ruído; o que responde à
pergunta são os **caminhos** que ligam as sementes. Recuperação em três
passos:

1. sementes = entidades da consulta (por embedding e por menção literal);
2. caminhos entre pares de sementes, podados por **propagação de recurso**
   com decaimento `alpha` (0,8 no artigo) e limiar de poda; confiabilidade
   de um caminho = recurso médio nos seus nós;
3. os `top_k` caminhos viram texto, em ordem **crescente** de
   confiabilidade (o artigo coloca o mais confiável por último, mais perto
   da pergunta — o mesmo efeito de recência que Liu et al., 2023 medem).

Os trechos são os que sustentam as relações dos caminhos, ranqueados pela
soma das confiabilidades dos caminhos que os usam.
"""

from __future__ import annotations

from collections import defaultdict
from collections.abc import Iterable
from typing import Any

from ...memory.core.embeddings import Embedder, noise_floor_of
from ...memory.core.similarity import cosine
from ..chunking import Chunk
from ..embed import encode_query
from ..types import ChunkStore, ScoredChunk
from .builder import EntityGraphBuilder
from .engine import Path
from .extract import GraphExtractor, recognized

__all__ = ["PathRAG"]


class PathRAG:
    name = "pathrag"

    def __init__(
        self,
        embedder: Embedder,
        store: ChunkStore,
        *,
        extractor: GraphExtractor | None = None,
        seed_entities: int = 6,
        max_hops: int = 3,
        alpha: float = 0.8,
        threshold: float = 0.01,
        top_paths: int = 10,
        recognition_ratio: float = 0.75,
    ) -> None:
        self.embedder = embedder
        self.store = store
        self.builder = EntityGraphBuilder(embedder, extractor=extractor)
        self.seed_entities = seed_entities
        self.max_hops = max_hops
        self.alpha = alpha
        self.threshold = threshold
        self.top_paths = top_paths
        self.recognition_ratio = recognition_ratio

    @property
    def engine(self):
        return self.builder.engine

    def index(self, chunks: Iterable[Chunk]) -> int:
        return self.builder.index(chunks)

    def seeds_for(self, query: str) -> list[str]:
        qv = encode_query(self.embedder, query)
        floor = noise_floor_of(self.embedder, 0.0)
        weighted: dict[str, float] = {nid: 1.0 for nid in self.builder.entities_in(query)}
        for nid, s in self.builder.entity_index.search(qv, self.seed_entities):
            if s > floor:
                weighted[nid] = max(weighted.get(nid, 0.0), s)
        kept = recognized(weighted, floor=floor, ratio=self.recognition_ratio)
        seeds = [n for n, _ in sorted(kept.items(), key=lambda kv: -kv[1])]
        return seeds[: self.seed_entities]

    def paths(self, query: str) -> list[Path]:
        seeds = self.seeds_for(query)
        return self.engine.flow_prune(seeds, max_hops=self.max_hops, alpha=self.alpha, threshold=self.threshold, top_k=self.top_paths)

    def retrieve(self, query: str, k: int = 10) -> list[ScoredChunk]:
        paths = self.paths(query)
        qv = encode_query(self.embedder, query)
        hits: dict[str, float] = defaultdict(float)
        n_paths: dict[str, int] = defaultdict(int)
        for p in paths:
            for r in p.rels:
                for cid in r.sources:
                    hits[cid] += p.reliability
                    n_paths[cid] += 1
        if not hits:
            # sem caminho (uma semente só, ou nenhuma): trechos das sementes
            for nid in self.seeds_for(query):
                for cid in self.builder.chunks_of_entity(nid):
                    hits[cid] += 0.1
        out: list[ScoredChunk] = []
        for cid, h in hits.items():
            ch = self.store.get(cid)
            if ch is None:
                continue
            dense = cosine(qv, ch.embedding) if ch.embedding is not None else cosine(qv, self.embedder.encode(ch.text_for_embedding))
            out.append(ScoredChunk(ch, h + 0.05 * max(dense, 0.0), {"path": h, "paths": float(n_paths.get(cid, 0)), "dense": dense}, self.name))
        out.sort(key=lambda s: (-s.score, s.id))
        return out[:k]

    def context(self, query: str, *, k: int = 6, max_chars: int = 3000) -> str:
        names = {nid: (n.name or nid) for nid, n in self.engine.nodes.items()}
        paths = self.paths(query)
        lines = [f"Caminho ({p.reliability:.3f}): {p.as_text(names)}" for p in sorted(paths, key=lambda p: p.reliability)]
        for sc in self.retrieve(query, k):
            lines.append(f"Trecho [{sc.id}]: {sc.text}")
        return "\n".join(lines)[:max_chars]

    def stats(self) -> dict[str, Any]:
        return self.builder.stats()
