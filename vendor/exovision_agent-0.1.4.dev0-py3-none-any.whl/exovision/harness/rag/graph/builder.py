"""Construção incremental do grafo de entidades a partir de trechos.

GraphRAG, LightRAG e PathRAG leem o mesmo grafo: entidades com descrição e
embedding, relações com descrição, evidência (ids de trecho) e temas. O
`EntityGraphBuilder` constrói e mantém esse grafo trecho a trecho — e os
dois índices vetoriais que os métodos consultam: um sobre entidades
(`nome: descrição`) e um sobre relações (`origem relação destino:
descrição temas`). Indexar é incremental: o LightRAG faz questão disso
(um trecho novo não reindexa o grafo), e o GraphRAG só precisa recomputar
comunidades, que é `communities()` sob demanda.
"""

from __future__ import annotations

from collections import defaultdict
from collections.abc import Iterable
from typing import Any

from ...memory.core.embeddings import Embedder
from ..chunking import Chunk
from ..index import FlatIndex
from .engine import GraphEngine, Node, Rel
from .extract import Extraction, GraphExtractor, PatternGraphExtractor, link_mentions

__all__ = ["EntityGraphBuilder", "rel_key"]


def rel_key(source_id: str, relation: str, target_id: str) -> str:
    return f"{source_id}|{relation}|{target_id}"


class EntityGraphBuilder:
    def __init__(
        self,
        embedder: Embedder,
        *,
        extractor: GraphExtractor | None = None,
        engine: GraphEngine | None = None,
    ) -> None:
        self.embedder = embedder
        self.extractor = extractor or PatternGraphExtractor()
        self.engine = engine or GraphEngine()
        self.entity_index = FlatIndex(embedder.dim)
        self.relation_index = FlatIndex(embedder.dim)
        self.chunk_entities: dict[str, list[str]] = {}
        self.chunk_keywords: dict[str, list[str]] = {}
        self.rel_keywords: dict[str, list[str]] = defaultdict(list)
        self.extractions: dict[str, Extraction] = {}

    # ------------------------------------------------------------ indexação
    def index(self, chunks: Iterable[Chunk]) -> int:
        n = 0
        for c in chunks:
            self.index_chunk(c)
            n += 1
        return n

    def index_chunk(self, chunk: Chunk) -> Extraction:
        ex = self.extractor.extract(chunk.text)
        self.extractions[chunk.id] = ex
        ents: list[str] = []
        for e in ex.entities:
            node = self.engine.add_node(Node(e.id, e.type, e.name, e.description, sources=[chunk.id]))
            if node.id not in ents:
                ents.append(node.id)
            self._reindex_entity(node)
        for r in ex.relations:
            sid, tid = r.source_id, r.target_id
            if not sid or not tid or sid == tid:
                continue
            for nid, name in ((sid, r.source), (tid, r.target)):
                if nid not in self.engine:
                    node = self.engine.add_node(Node(nid, "entity", name, sources=[chunk.id]))
                    self._reindex_entity(node)
                if nid not in ents:
                    ents.append(nid)
            rel = self.engine.add_rel(Rel(sid, tid, r.relation, r.weight, r.description, sources=[chunk.id]))
            key = rel_key(sid, rel.relation, tid)
            for kw in ex.keywords:
                if kw not in self.rel_keywords[key]:
                    self.rel_keywords[key].append(kw)
            self._reindex_relation(rel)
        self.chunk_entities[chunk.id] = ents
        self.chunk_keywords[chunk.id] = list(ex.keywords)
        return ex

    def _entity_text(self, node: Node) -> str:
        return f"{node.name}: {node.description}" if node.description else node.name

    def _reindex_entity(self, node: Node) -> None:
        vec = self.embedder.encode(self._entity_text(node))
        node.embedding = vec
        self.entity_index.add([node.id], [vec])

    def _relation_text(self, rel: Rel) -> str:
        s = self.engine.nodes[rel.source].name or rel.source
        t = self.engine.nodes[rel.target].name or rel.target
        kws = " ".join(self.rel_keywords.get(rel_key(rel.source, rel.relation, rel.target), []))
        base = f"{s} {rel.relation.replace('_', ' ')} {t}"
        extra = " ".join(x for x in (rel.description, kws) if x)
        return f"{base}: {extra}" if extra else base

    def _reindex_relation(self, rel: Rel) -> None:
        key = rel_key(rel.source, rel.relation, rel.target)
        self.relation_index.add([key], [self.embedder.encode(self._relation_text(rel))])

    # ------------------------------------------------------------ consultas
    def rel_by_key(self, key: str) -> Rel | None:
        s, r, t = key.split("|", 2)
        return self.engine.rels.get((s, r, t))

    def entities_in(self, text: str) -> list[str]:
        """Ids de entidades do grafo mencionadas literalmente no texto."""
        ex = self.extractor.extract(text)
        found: list[str] = []
        for e in ex.entities:
            if e.id in self.engine and e.id not in found:
                found.append(e.id)
        for r in ex.relations:
            for nid in (r.source_id, r.target_id):
                if nid in self.engine and nid not in found:
                    found.append(nid)
        for nid in link_mentions(text, self.engine.nodes):
            if nid not in found:
                found.append(nid)
        return found

    def chunks_of_entity(self, node_id: str) -> list[str]:
        node = self.engine.nodes.get(node_id)
        return list(node.sources) if node else []

    def stats(self) -> dict[str, Any]:
        return {**self.engine.stats(), "chunks": len(self.chunk_entities), "entity_index": len(self.entity_index), "relation_index": len(self.relation_index)}


