"""LightRAG (Guo et al., 2024, arXiv:2410.05779) — recuperação em dois níveis. Experimental.

A ideia: o grafo não substitui o índice vetorial, entra *nele*. Cada
entidade e cada relação viram um texto indexado (nome + descrição; origem
+ relação + destino + descrição + temas). A consulta é decomposta em
palavras-chave de dois níveis:

* **baixo nível** — entidades específicas ("Vortex", "Ana"): casam com o
  índice de entidades; entram as suas relações e trechos-fonte;
* **alto nível** — temas ("mercado de trabalho", "regulação"): casam com o
  índice de relações (que carrega os temas extraídos); entram os extremos
  e os trechos-fonte.

Os trechos recuperados pelos dois caminhos são unidos e ranqueados por
quantos casamentos os apontam (e pelo cosseno com a consulta, como
desempate). Indexação incremental por construção: um trecho novo só
acrescenta entradas nos dois índices. A extração de palavras-chave é
offline (entidades nomeadas e palavras de conteúdo) ou por modelo.
"""

from __future__ import annotations

from collections import defaultdict
from collections.abc import Iterable
from dataclasses import dataclass, field
from typing import Any

from ...memory.core.embeddings import Embedder, noise_floor_of
from ...memory.core.similarity import cosine
from ...memory.core.text import content_words
from ...models.provider import Provider
from ..chunking import Chunk
from ..embed import encode_query
from ..llm import LLMUsage, ask, parse_json_list
from ..types import ChunkStore, ScoredChunk
from .builder import EntityGraphBuilder
from .extract import GraphExtractor, named_spans, recognized

__all__ = ["LightRAG", "QueryKeywords"]


@dataclass(slots=True)
class QueryKeywords:
    low: list[str] = field(default_factory=list)
    high: list[str] = field(default_factory=list)


class LightRAG:
    name = "lightrag"

    def __init__(
        self,
        embedder: Embedder,
        store: ChunkStore,
        *,
        extractor: GraphExtractor | None = None,
        provider: Provider | None = None,
        top_entities: int = 6,
        top_relations: int = 6,
        recognition_ratio: float = 0.75,
        usage: LLMUsage | None = None,
    ) -> None:
        self.embedder = embedder
        self.store = store
        self.builder = EntityGraphBuilder(embedder, extractor=extractor)
        self.provider = provider
        self.top_entities = top_entities
        self.top_relations = top_relations
        self.recognition_ratio = recognition_ratio
        self.usage = usage or LLMUsage()

    @property
    def engine(self):
        return self.builder.engine

    def index(self, chunks: Iterable[Chunk]) -> int:
        return self.builder.index(chunks)

    # ------------------------------------------------------------ palavras-chave
    def keywords(self, query: str) -> QueryKeywords:
        if self.provider is not None:
            text = ask(
                self.provider,
                'Extraia palavras-chave da consulta em dois níveis. Responda com JSON: {"low": ["entidades específicas"], "high": ["temas gerais"]}.',
                query,
                usage=self.usage,
                max_tokens=200,
            )
            import json
            import re

            m = re.search(r"\{.*\}", text, re.S)
            if m:
                try:
                    d = json.loads(m.group(0))
                    return QueryKeywords([str(x) for x in d.get("low", [])], [str(x) for x in d.get("high", [])])
                except json.JSONDecodeError:
                    pass
            return QueryKeywords(parse_json_list(text), [])
        low = named_spans(query) + [n for n in self.builder.entities_in(query)]
        words = content_words(query)
        high = [w for w in words if len(w) >= 4 and w not in {x.lower() for x in low}]
        return QueryKeywords(list(dict.fromkeys(low)), high[:8])

    # ------------------------------------------------------------ recuperação
    def retrieve(self, query: str, k: int = 10, *, mode: str = "hybrid") -> list[ScoredChunk]:
        kws = self.keywords(query)
        floor = noise_floor_of(self.embedder, 0.0)
        hits: dict[str, float] = defaultdict(float)
        low_hits: dict[str, float] = defaultdict(float)
        high_hits: dict[str, float] = defaultdict(float)
        eng = self.engine
        if mode in ("local", "hybrid"):
            low_text = " ".join(kws.low) or query
            literal = set(self.builder.entities_in(query))
            cands = {nid: 1.0 for nid in literal}
            for nid, s in self.builder.entity_index.search(encode_query(self.embedder, low_text), self.top_entities):
                if s > floor:
                    cands[nid] = max(cands.get(nid, 0.0), s)
            for nid, w in recognized(cands, floor=floor, ratio=self.recognition_ratio).items():
                for cid in self.builder.chunks_of_entity(nid):
                    low_hits[cid] += w
                # relações da entidade e os vizinhos de um salto (o LightRAG junta ambos)
                for r in eng.rels_of(nid):
                    for cid in r.sources:
                        low_hits[cid] += 0.5 * w
                for nb in eng.neighbors(nid):
                    for cid in self.builder.chunks_of_entity(nb):
                        low_hits[cid] += 0.25 * w
        if mode in ("global", "hybrid"):
            high_text = " ".join(kws.high) or query
            for key, s in self.builder.relation_index.search(encode_query(self.embedder, high_text), self.top_relations):
                w = max(s - floor, 0.0)
                rel = self.builder.rel_by_key(key)
                if rel is None or w <= 0:
                    continue
                for cid in rel.sources:
                    high_hits[cid] += w
                for end in (rel.source, rel.target):
                    for cid in self.builder.chunks_of_entity(end):
                        high_hits[cid] += 0.25 * w
        for cid, w in low_hits.items():
            hits[cid] += w
        for cid, w in high_hits.items():
            hits[cid] += w
        if not hits:
            return []
        qv = encode_query(self.embedder, query)
        out: list[ScoredChunk] = []
        for cid, h in hits.items():
            ch = self.store.get(cid)
            if ch is None:
                continue
            dense = cosine(qv, ch.embedding) if ch.embedding is not None else cosine(qv, self.embedder.encode(ch.text_for_embedding))
            out.append(ScoredChunk(ch, h + 0.5 * max(dense, 0.0), {"low": low_hits.get(cid, 0.0), "high": high_hits.get(cid, 0.0), "dense": dense}, self.name))
        out.sort(key=lambda s: (-s.score, s.id))
        return out[:k]

    def context(self, query: str, *, k: int = 6, max_chars: int = 3000) -> str:
        kws = self.keywords(query)
        eng = self.engine
        parts = [f"Palavras-chave: baixo nível {kws.low}; alto nível {kws.high}"]
        for nid, _ in self.builder.entity_index.search(encode_query(self.embedder, " ".join(kws.low) or query), 4):
            node = eng.nodes[nid]
            parts.append(f"Entidade {node.name or nid}: {node.description}".strip())
        for key, _ in self.builder.relation_index.search(encode_query(self.embedder, " ".join(kws.high) or query), 4):
            rel = self.builder.rel_by_key(key)
            if rel:
                parts.append(f"Relação: {eng.nodes[rel.source].name} {rel.relation.replace('_', ' ')} {eng.nodes[rel.target].name} {rel.description}".strip())
        for sc in self.retrieve(query, k):
            parts.append(f"Trecho [{sc.id}]: {sc.text}")
        return "\n".join(parts)[:max_chars]

    def stats(self) -> dict[str, Any]:
        return self.builder.stats()
