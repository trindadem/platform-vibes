"""O motor de grafo: grafo de propriedades + Louvain/Leiden + PPR + poda por fluxo.

Os quatro métodos de GraphRAG deste pacote diferem na *construção* e na
*leitura* do grafo; os algoritmos são os mesmos, e moram aqui:

* **Personalized PageRank** — reutilizado de `memory.core.graph` (Haveliwala,
  2002): a leitura do HippoRAG.
* **Louvain** (Blondel et al., 2008): otimização gulosa de modularidade em
  dois passos (movimento local, agregação), repetidos até estabilizar. Cada
  repetição é um nível da hierarquia.
* **Leiden** (Traag, Waltman & van Eck, 2019): Louvain com uma fase de
  *refinamento* entre o movimento local e a agregação, que garante
  comunidades **conectadas** — o Louvain pode produzir comunidades
  desconexas (até 25% delas em grafos reais, no artigo). É o algoritmo do
  GraphRAG da Microsoft (Edge et al., 2024).
* **Poda por fluxo** (PathRAG, Chen et al., 2025): propaga um recurso a
  partir de cada nó-semente com decaimento `alpha`, mede a confiabilidade de
  um caminho como o recurso médio nos seus nós e mantém os `top_k` caminhos.

A modularidade com resolução `gamma` (Reichardt & Bornholdt, 2006):

    Q = (1/2m) * sum_ij [A_ij - gamma * k_i k_j / (2m)] * delta(c_i, c_j)

`gamma > 1` produz comunidades menores. Tudo é determinístico dado `seed`.
"""

from __future__ import annotations

import json
import math
import random
import sqlite3
from collections import defaultdict, deque
from collections.abc import Iterable, Mapping, Sequence
from dataclasses import dataclass, field
from itertools import pairwise
from typing import Any

from ...memory.core.graph import Edge, Graph

__all__ = ["GraphEngine", "Node", "Path", "Rel", "leiden", "louvain", "modularity"]

Adj = dict[str, dict[str, float]]


@dataclass(slots=True)
class Node:
    id: str
    type: str = "entity"
    name: str = ""
    description: str = ""
    attrs: dict[str, Any] = field(default_factory=dict)
    embedding: tuple[float, ...] | None = None
    sources: list[str] = field(default_factory=list)  # ids de trecho

    def to_dict(self) -> dict[str, Any]:
        return {
            "id": self.id,
            "type": self.type,
            "name": self.name,
            "description": self.description,
            "attrs": self.attrs,
            "sources": self.sources,
        }


@dataclass(slots=True)
class Rel:
    source: str
    target: str
    relation: str = "related"
    weight: float = 1.0
    description: str = ""
    sources: list[str] = field(default_factory=list)

    def key(self) -> tuple[str, str, str]:
        return (self.source, self.relation, self.target)

    def to_dict(self) -> dict[str, Any]:
        return {
            "source": self.source,
            "target": self.target,
            "relation": self.relation,
            "weight": self.weight,
            "description": self.description,
            "sources": self.sources,
        }


@dataclass(slots=True)
class Path:
    nodes: list[str]
    rels: list[Rel]
    reliability: float

    def as_text(self, names: Mapping[str, str] | None = None) -> str:
        def nm(n: str) -> str:
            return names.get(n, n) if names else n

        parts = [nm(self.nodes[0])]
        for prev, r, n in zip(self.nodes, self.rels, self.nodes[1:], strict=False):
            arrow = f"-[{r.relation}]->" if r.source == prev else f"<-[{r.relation}]-"
            parts.append(f"{arrow} {nm(n)}")
        return " ".join(parts)


# --------------------------------------------------------------------------
# Modularidade, Louvain e Leiden sobre adjacência simétrica
# --------------------------------------------------------------------------


def _symmetric(adj: Adj) -> Adj:
    out: Adj = defaultdict(dict)
    for u, nbrs in adj.items():
        out.setdefault(u, {})
        for v, w in nbrs.items():
            out[u][v] = out[u].get(v, 0.0) + w
            out[v][u] = out[v].get(u, 0.0) + w
    return out


def modularity(adj: Adj, partition: Mapping[str, str], *, gamma: float = 1.0) -> float:
    """Q de Newman com resolução, sobre adjacência simétrica (cada aresta em ambos os lados).

    Q = sum_c [ S_in(c)/2m - gamma * (S_tot(c)/2m)^2 ], com S_in a soma dos pesos
    internos (contados nos dois sentidos) e S_tot a soma dos graus da comunidade.
    """
    m2 = sum(w for nbrs in adj.values() for w in nbrs.values())  # = 2m
    if m2 <= 0:
        return 0.0
    s_in: dict[str, float] = defaultdict(float)
    s_tot: dict[str, float] = defaultdict(float)
    for u, nbrs in adj.items():
        cu = partition[u]
        for v, w in nbrs.items():
            s_tot[cu] += w
            if partition[v] == cu:
                s_in[cu] += w
    return sum(s_in[c] / m2 - gamma * (s_tot[c] / m2) ** 2 for c in s_tot)


def _local_moving(adj: Adj, partition: dict[str, str], gamma: float, rng: random.Random, *, queue_based: bool) -> bool:
    m2 = sum(w for nbrs in adj.values() for w in nbrs.values())
    if m2 <= 0:
        return False
    k = {u: sum(nbrs.values()) for u, nbrs in adj.items()}
    tot: dict[str, float] = defaultdict(float)
    for u, c in partition.items():
        tot[c] += k[u]
    order = list(adj)
    rng.shuffle(order)
    queue = deque(order)
    in_queue = set(order)
    moved_any = False
    while queue:
        u = queue.popleft()
        in_queue.discard(u)
        cu = partition[u]
        links: dict[str, float] = defaultdict(float)
        for v, w in adj[u].items():
            if v != u:
                links[partition[v]] += w
        tot[cu] -= k[u]
        best_c, best_gain = cu, links.get(cu, 0.0) - gamma * tot[cu] * k[u] / m2
        for c, w_in in links.items():
            gain = w_in - gamma * tot[c] * k[u] / m2
            if gain > best_gain + 1e-12 or (abs(gain - best_gain) <= 1e-12 and c < best_c and c != cu):
                best_c, best_gain = c, gain
        tot[best_c] += k[u]
        if best_c != cu:
            partition[u] = best_c
            moved_any = True
            if queue_based:
                for v in adj[u]:
                    if partition[v] != best_c and v not in in_queue:
                        queue.append(v)
                        in_queue.add(v)
    return moved_any


def _aggregate(adj: Adj, partition: Mapping[str, str]) -> Adj:
    out: Adj = defaultdict(dict)
    for u, nbrs in adj.items():
        cu = partition[u]
        out.setdefault(cu, {})
        for v, w in nbrs.items():
            cv = partition[v]
            out[cu][cv] = out[cu].get(cv, 0.0) + w
    return out


def _connected_components(adj: Adj, members: Sequence[str]) -> list[list[str]]:
    mem = set(members)
    seen: set[str] = set()
    comps: list[list[str]] = []
    for s in members:
        if s in seen:
            continue
        comp = []
        stack = [s]
        seen.add(s)
        while stack:
            u = stack.pop()
            comp.append(u)
            for v in adj[u]:
                if v in mem and v not in seen:
                    seen.add(v)
                    stack.append(v)
        comps.append(sorted(comp))
    return comps


def _refine(adj: Adj, partition: Mapping[str, str], gamma: float, theta: float, rng: random.Random) -> dict[str, str]:
    """Fase de refinamento do Leiden: dentro de cada comunidade, funde singletons
    bem conectados em subcomunidades, escolhendo com probabilidade ~ exp(dQ/theta)."""
    m2 = sum(w for nbrs in adj.values() for w in nbrs.values())
    k = {u: sum(nbrs.values()) for u, nbrs in adj.items()}
    refined = {u: u for u in adj}
    by_comm: dict[str, list[str]] = defaultdict(list)
    for u, c in partition.items():
        by_comm[c].append(u)
    for _c, members in by_comm.items():
        mem = set(members)
        tot_c = sum(k[u] for u in members)
        sub_tot: dict[str, float] = {u: k[u] for u in members}
        sub_members: dict[str, set[str]] = {u: {u} for u in members}
        order = list(members)
        rng.shuffle(order)
        for u in order:
            if len(sub_members[refined[u]]) != 1:
                continue  # só singletons se movem
            # bem conectado à comunidade?
            e_u_c = sum(w for v, w in adj[u].items() if v in mem and v != u)
            if e_u_c < gamma * k[u] * (tot_c - k[u]) / m2:
                continue
            links: dict[str, float] = defaultdict(float)
            for v, w in adj[u].items():
                if v in mem and v != u:
                    links[refined[v]] += w
            cands: list[tuple[str, float]] = []
            for s, w_in in links.items():
                # subcomunidade bem conectada à comunidade
                tot_s = sub_tot[s]
                e_s_c = sum(w for x in sub_members[s] for v, w in adj[x].items() if v in mem and v not in sub_members[s])
                if e_s_c < gamma * tot_s * (tot_c - tot_s) / m2:
                    continue
                gain = w_in - gamma * tot_s * k[u] / m2
                if gain >= 0:
                    cands.append((s, gain))
            if not cands:
                continue
            if theta <= 0:
                target = max(cands, key=lambda t: (t[1], t[0]))[0]
            else:
                weights = [math.exp(min(g / theta, 700.0)) for _, g in cands]
                r = rng.random() * sum(weights)
                acc = 0.0
                target = cands[-1][0]
                for (s, _), w in zip(cands, weights, strict=True):
                    acc += w
                    if acc >= r:
                        target = s
                        break
            old = refined[u]
            sub_members[old].discard(u)
            sub_tot[old] -= k[u]
            refined[u] = target
            sub_members[target].add(u)
            sub_tot[target] += k[u]
    return refined


def louvain(adj: Adj, *, gamma: float = 1.0, seed: int = 0, max_levels: int = 10) -> list[dict[str, str]]:
    """Níveis de partição, do mais fino ao mais grosso, sobre os nós originais."""
    rng = random.Random(seed)
    adj = _symmetric(adj)
    partition = {u: u for u in adj}
    levels: list[dict[str, str]] = []
    mapping = {u: u for u in adj}  # nó original -> nó agregado
    cur = adj
    for _ in range(max_levels):
        part = {u: u for u in cur}
        moved = _local_moving(cur, part, gamma, rng, queue_based=False)
        if not moved:
            break
        partition = {u: part[mapping[u]] for u in adj}
        levels.append(dict(partition))
        cur = _aggregate(cur, part)
        mapping = {u: part[mapping[u]] for u in adj}
    if not levels:
        levels.append({u: u for u in adj})
    return levels


def leiden(adj: Adj, *, gamma: float = 1.0, seed: int = 0, theta: float = 0.01, max_levels: int = 10) -> list[dict[str, str]]:
    """Leiden: movimento local rápido -> refinamento -> agregação da partição refinada.

    Garantia entregue: cada comunidade de cada nível é **conectada**
    (`test_leiden_nao_produz_comunidade_desconexa`).
    """
    rng = random.Random(seed)
    adj = _symmetric(adj)
    levels: list[dict[str, str]] = []
    mapping = {u: u for u in adj}
    cur = adj
    for _ in range(max_levels):
        part = {u: u for u in cur}
        moved = _local_moving(cur, part, gamma, rng, queue_based=True)
        if not moved:
            break
        refined = _refine(cur, part, gamma, theta, rng)
        # comunidades conectadas por construção: quebra as que não são
        by_c: dict[str, list[str]] = defaultdict(list)
        for u, c in refined.items():
            by_c[c].append(u)
        for members in list(by_c.values()):
            comps = _connected_components(cur, members)
            if len(comps) > 1:
                for comp in comps:
                    label = min(comp)
                    for u in comp:
                        refined[u] = label
        partition = {u: part[mapping[u]] for u in adj}
        levels.append(dict(partition))
        # agrega pela partição refinada; a partição inicial do agregado é `part`
        cur_next = _aggregate(cur, refined)
        mapping = {u: refined[mapping[u]] for u in adj}
        cur = cur_next
        if len(cur) == len(set(refined.values())) and all(len(v) == 1 for v in by_c.values()):
            break
    if not levels:
        levels.append({u: u for u in adj})
    # garantia de conectividade no grafo original, em todo nível
    for lvl in levels:
        by_c = defaultdict(list)
        for u, c in lvl.items():
            by_c[c].append(u)
        for members in list(by_c.values()):
            comps = _connected_components(adj, members)
            if len(comps) > 1:
                for comp in comps:
                    label = min(comp)
                    for u in comp:
                        lvl[u] = label
    return levels


# --------------------------------------------------------------------------
# O motor
# --------------------------------------------------------------------------


class GraphEngine:
    """Grafo de propriedades: nós tipados, relações com evidência, algoritmos."""

    def __init__(self) -> None:
        self.nodes: dict[str, Node] = {}
        self.rels: dict[tuple[str, str, str], Rel] = {}
        self._graph = Graph()

    # ------------------------------------------------------------ escrita
    def add_node(self, node: Node) -> Node:
        existing = self.nodes.get(node.id)
        if existing is None:
            self.nodes[node.id] = node
            self._graph.add_node(node.id)
            return node
        if node.description and node.description not in existing.description:
            existing.description = (existing.description + " " + node.description).strip()
        for s in node.sources:
            if s not in existing.sources:
                existing.sources.append(s)
        existing.attrs.update(node.attrs)
        if existing.embedding is None and node.embedding is not None:
            existing.embedding = node.embedding
        return existing

    def add_rel(self, rel: Rel) -> Rel:
        for n in (rel.source, rel.target):
            if n not in self.nodes:
                self.add_node(Node(n, name=n))
        key = rel.key()
        existing = self.rels.get(key)
        if existing is None:
            self.rels[key] = rel
            self._graph.add_edge(Edge(rel.source, rel.target, rel.relation, rel.weight))
            return rel
        existing.weight += rel.weight
        self._graph.add_edge(Edge(rel.source, rel.target, rel.relation, rel.weight))
        if rel.description and rel.description not in existing.description:
            existing.description = (existing.description + " " + rel.description).strip()
        for s in rel.sources:
            if s not in existing.sources:
                existing.sources.append(s)
        return existing

    # ------------------------------------------------------------ leitura
    def __len__(self) -> int:
        return len(self.nodes)

    def __contains__(self, node_id: str) -> bool:
        return node_id in self.nodes

    def neighbors(self, node_id: str) -> set[str]:
        return self._graph.neighbors(node_id)

    def degree(self, node_id: str) -> int:
        return self._graph.degree(node_id)

    def rels_of(self, node_id: str) -> list[Rel]:
        return [r for r in self.rels.values() if r.source == node_id or r.target == node_id]

    def nodes_of_type(self, type_: str) -> list[Node]:
        return [n for n in self.nodes.values() if n.type == type_]

    def adjacency(self, *, types: Iterable[str] | None = None) -> Adj:
        allow = set(types) if types else None
        adj: Adj = defaultdict(dict)
        for r in self.rels.values():
            if allow and (self.nodes[r.source].type not in allow or self.nodes[r.target].type not in allow):
                continue
            adj[r.source][r.target] = adj[r.source].get(r.target, 0.0) + r.weight
            adj.setdefault(r.target, {})
        if allow:
            for node in self.nodes.values():
                if node.type in allow:
                    adj.setdefault(node.id, {})
        else:
            for nid in self.nodes:
                adj.setdefault(nid, {})
        return adj

    def ppr(self, seeds: Mapping[str, float] | Sequence[str], *, damping: float = 0.5, iterations: int = 30) -> dict[str, float]:
        seed_arg: dict[str, float] | Sequence[str] = dict(seeds) if isinstance(seeds, Mapping) else seeds
        return self._graph.personalized_pagerank(seed_arg, damping=damping, iterations=iterations)

    def shortest_path(self, a: str, b: str, *, max_hops: int = 5) -> list[Rel]:
        edges = self._graph.shortest_path(a, b, max_hops=max_hops)
        return [self.rels[(e.source, e.relation, e.target)] for e in edges if (e.source, e.relation, e.target) in self.rels]

    def k_hop(self, node_id: str, k: int = 2) -> dict[str, int]:
        return self._graph.k_hop(node_id, k)

    # ------------------------------------------------------------ comunidades
    def communities(self, *, method: str = "leiden", gamma: float = 1.0, seed: int = 0, types: Iterable[str] | None = None) -> list[dict[str, str]]:
        adj = self.adjacency(types=types)
        if not adj:
            return []
        if method == "leiden":
            return leiden(adj, gamma=gamma, seed=seed)
        if method == "louvain":
            return louvain(adj, gamma=gamma, seed=seed)
        raise ValueError(f"método desconhecido: {method!r}")

    def modularity(self, partition: Mapping[str, str], *, gamma: float = 1.0, types: Iterable[str] | None = None) -> float:
        return modularity(_symmetric(self.adjacency(types=types)), partition, gamma=gamma)

    # ------------------------------------------------------------ PathRAG
    def flow_prune(
        self,
        seeds: Sequence[str],
        *,
        max_hops: int = 3,
        alpha: float = 0.8,
        threshold: float = 0.01,
        top_k: int = 10,
        types: Iterable[str] | None = None,
    ) -> list[Path]:
        """Caminhos entre pares de sementes, podados por recurso propagado.

        S(seed) = 1; S(v) = sum_{u -> v} alpha * S(u) / deg(u); a
        confiabilidade de um caminho é a média de S nos seus nós. Caminhos
        são enumerados por BFS limitado a `max_hops`, sem repetir nó.
        """
        adj = _symmetric(self.adjacency(types=types))
        seeds = [s for s in seeds if s in adj]
        if len(seeds) < 2:
            return []
        deg = {u: max(len(nbrs), 1) for u, nbrs in adj.items()}
        paths: list[Path] = []
        seen_keys: set[tuple[str, ...]] = set()
        for i, s in enumerate(seeds):
            # propagação de recurso a partir de s
            resource: dict[str, float] = {s: 1.0}
            frontier = {s}
            for _ in range(max_hops):
                nxt: dict[str, float] = defaultdict(float)
                for u in frontier:
                    share = alpha * resource[u] / deg[u]
                    if share < threshold:
                        continue
                    for v in adj[u]:
                        nxt[v] += share
                if not nxt:
                    break
                for v, r in nxt.items():
                    resource[v] = resource.get(v, 0.0) + r
                frontier = set(nxt)
            for t in seeds[i + 1 :]:
                for node_path in self._simple_paths(adj, s, t, max_hops):
                    key = tuple(node_path)
                    if key in seen_keys:
                        continue
                    seen_keys.add(key)
                    rels = [self._rel_between(a, b) for a, b in pairwise(node_path)]
                    if any(r is None for r in rels):
                        continue
                    rel_ok = [r for r in rels if r is not None]
                    reliability = sum(resource.get(n, 0.0) for n in node_path) / len(node_path)
                    paths.append(Path(list(node_path), rel_ok, reliability))
        paths.sort(key=lambda p: (-p.reliability, len(p.nodes), p.nodes))
        return paths[:top_k]

    def _rel_between(self, a: str, b: str) -> Rel | None:
        best: Rel | None = None
        for r in self.rels.values():
            matches = (r.source == a and r.target == b) or (r.source == b and r.target == a)
            if matches and (best is None or r.weight > best.weight):
                best = r
        return best

    @staticmethod
    def _simple_paths(adj: Adj, s: str, t: str, max_hops: int, *, limit: int = 200) -> list[list[str]]:
        out: list[list[str]] = []
        stack: list[list[str]] = [[s]]
        while stack and len(out) < limit:
            path = stack.pop()
            last = path[-1]
            if last == t and len(path) > 1:
                out.append(path)
                continue
            if len(path) - 1 >= max_hops:
                continue
            for v in sorted(adj[last]):
                if v not in path:
                    stack.append([*path, v])
        return out

    # ------------------------------------------------------------ persistência
    def stats(self) -> dict[str, Any]:
        types: dict[str, int] = defaultdict(int)
        for n in self.nodes.values():
            types[n.type] += 1
        return {"nodes": len(self.nodes), "rels": len(self.rels), "types": dict(types), **self._graph.stats()}

    def save(self, path: str) -> None:
        conn = sqlite3.connect(path)
        conn.executescript(
            "DROP TABLE IF EXISTS nodes; DROP TABLE IF EXISTS rels;"
            "CREATE TABLE nodes (id TEXT PRIMARY KEY, doc TEXT NOT NULL, embedding TEXT);"
            "CREATE TABLE rels (source TEXT, relation TEXT, target TEXT, doc TEXT NOT NULL, PRIMARY KEY (source, relation, target));"
        )
        conn.executemany(
            "INSERT INTO nodes VALUES (?,?,?)",
            [(n.id, json.dumps(n.to_dict(), ensure_ascii=False), json.dumps(list(n.embedding)) if n.embedding else None) for n in self.nodes.values()],
        )
        conn.executemany(
            "INSERT INTO rels VALUES (?,?,?,?)",
            [(r.source, r.relation, r.target, json.dumps(r.to_dict(), ensure_ascii=False)) for r in self.rels.values()],
        )
        conn.commit()
        conn.close()

    @classmethod
    def load(cls, path: str) -> GraphEngine:
        g = cls()
        conn = sqlite3.connect(path)
        for _id, doc, emb in conn.execute("SELECT id, doc, embedding FROM nodes"):
            d = json.loads(doc)
            g.add_node(Node(d["id"], d.get("type", "entity"), d.get("name", ""), d.get("description", ""), d.get("attrs", {}), tuple(json.loads(emb)) if emb else None, list(d.get("sources", []))))
        for _s, _r, _t, doc in conn.execute("SELECT source, relation, target, doc FROM rels"):
            d = json.loads(doc)
            g.add_rel(Rel(d["source"], d["target"], d.get("relation", "related"), float(d.get("weight", 1.0)), d.get("description", ""), list(d.get("sources", []))))
        conn.close()
        return g
