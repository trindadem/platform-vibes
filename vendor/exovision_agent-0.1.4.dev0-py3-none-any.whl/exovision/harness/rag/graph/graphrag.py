"""GraphRAG (Edge et al., 2024, Microsoft) — o padrão de indústria em RAG sobre grafo.

Indexar: extrair entidades e relações de cada trecho, construir o grafo,
detectar comunidades com Leiden em níveis hierárquicos e escrever um
**relatório** por comunidade. Consultar de duas formas:

* **Busca local** — para perguntas sobre entidades específicas: as
  entidades mais próximas da consulta (por embedding) são sementes; entram
  no contexto as suas descrições, relações, os relatórios das comunidades
  a que pertencem e os trechos que as mencionam.
* **Busca global** — para perguntas de *sensemaking* ("quais os temas
  principais?"): map-reduce sobre os relatórios de um nível — cada
  relatório é pontuado contra a consulta (embedding, ou o modelo dá uma
  nota), os melhores são reduzidos num contexto.

O GraphRAG-Bench (Xiang et al., 2025; ICLR 2026) mediu onde isso paga:
+4,5% em multi-hop no HotpotQA, mas -13,4% em perguntas factuais simples
e 2,3x a latência — o roteador adaptativo (`query.AdaptiveRouter`) existe
para não usar grafo onde ele atrapalha. Os relatórios usam o sumarizador
extrativo da memória por padrão (offline); injete um `Summarizer` com
modelo para relatórios abstrativos.
"""

from __future__ import annotations

from collections import defaultdict
from collections.abc import Iterable, Mapping
from dataclasses import dataclass, field
from typing import Any

from ...memory.core.embeddings import Embedder, noise_floor_of
from ...memory.core.similarity import cosine
from ...memory.core.summarize import ExtractiveSummarizer, Summarizer
from ..chunking import Chunk
from ..embed import encode_query
from ..index import FlatIndex
from ..types import ChunkStore, ScoredChunk
from .builder import EntityGraphBuilder
from .extract import GraphExtractor, recognized

__all__ = ["CommunityReport", "GraphRAG"]


@dataclass(slots=True)
class CommunityReport:
    id: str
    level: int
    members: list[str]
    text: str
    sources: list[str] = field(default_factory=list)
    embedding: tuple[float, ...] | None = None
    rank: float = 0.0  # tamanho relativo, para desempate

    def to_dict(self) -> dict[str, Any]:
        return {"id": self.id, "level": self.level, "members": self.members, "text": self.text, "sources": self.sources}


class GraphRAG:
    name = "graphrag"

    def __init__(
        self,
        embedder: Embedder,
        store: ChunkStore,
        *,
        extractor: GraphExtractor | None = None,
        summarizer: Summarizer | None = None,
        method: str = "leiden",
        gamma: float = 1.0,
        max_report_chars: int = 600,
        seed_entities: int = 6,
        hops: int = 1,
        recognition_ratio: float = 0.75,
        seed: int = 0,
    ) -> None:
        self.embedder = embedder
        self.store = store
        self.builder = EntityGraphBuilder(embedder, extractor=extractor)
        self.summarizer = summarizer or ExtractiveSummarizer(embedder)
        self.method = method
        self.gamma = gamma
        self.max_report_chars = max_report_chars
        self.seed_entities = seed_entities
        self.hops = hops
        self.recognition_ratio = recognition_ratio
        self.seed = seed
        self.levels: list[dict[str, str]] = []
        self.reports: dict[str, CommunityReport] = {}
        self._report_index = FlatIndex(embedder.dim)
        self._dirty = False

    @property
    def engine(self):
        return self.builder.engine

    # ------------------------------------------------------------ indexação
    def index(self, chunks: Iterable[Chunk]) -> int:
        n = self.builder.index(chunks)
        self._dirty = True
        return n

    def build_communities(self) -> list[dict[str, str]]:
        self.levels = self.engine.communities(method=self.method, gamma=self.gamma, seed=self.seed)
        self.reports = {}
        self._report_index = FlatIndex(self.embedder.dim)
        for lvl, partition in enumerate(self.levels):
            groups: dict[str, list[str]] = defaultdict(list)
            for node, comm in partition.items():
                groups[comm].append(node)
            for comm, members in groups.items():
                if len(members) < 2 and lvl > 0:
                    continue
                report = self._report(lvl, comm, sorted(members))
                self.reports[report.id] = report
                self._report_index.add([report.id], [report.embedding or self.embedder.encode(report.text)])
        self._dirty = False
        return self.levels

    def _report(self, level: int, comm: str, members: list[str]) -> CommunityReport:
        eng = self.engine
        lines: list[str] = []
        sources: list[str] = []
        mem = set(members)
        for m in members:
            node = eng.nodes[m]
            lines.append(f"{node.name or m}: {node.description}" if node.description else (node.name or m))
            for s in node.sources:
                if s not in sources:
                    sources.append(s)
        for r in eng.rels.values():
            if r.source in mem and r.target in mem:
                s = eng.nodes[r.source].name or r.source
                t = eng.nodes[r.target].name or r.target
                lines.append(f"{s} {r.relation.replace('_', ' ')} {t}" + (f" ({r.description})" if r.description else ""))
        text = self.summarizer.summarize(lines, max_chars=self.max_report_chars) if lines else ""
        rep = CommunityReport(f"L{level}:{comm}", level, members, text, sources, rank=len(members))
        rep.embedding = self.embedder.encode(text or " ".join(members))
        return rep

    def _ensure(self) -> None:
        if self._dirty or not self.levels:
            self.build_communities()

    # ------------------------------------------------------------ busca local
    def seed_entities_for(self, query: str) -> dict[str, float]:
        qv = encode_query(self.embedder, query)
        floor = noise_floor_of(self.embedder, 0.0)
        seeds: dict[str, float] = {}
        for nid in self.builder.entities_in(query):
            seeds[nid] = 1.0
        for nid, s in self.builder.entity_index.search(qv, self.seed_entities):
            if s > floor:
                seeds[nid] = max(seeds.get(nid, 0.0), s)
        # memória de reconhecimento: só sementes próximas da melhor, acima do piso
        return recognized(seeds, floor=floor, ratio=self.recognition_ratio)

    def local_search(self, query: str, k: int = 10) -> list[ScoredChunk]:
        self._ensure()
        seeds = self.seed_entities_for(query)
        if not seeds:
            return []
        eng = self.engine
        qv = encode_query(self.embedder, query)
        chunk_hits: dict[str, float] = defaultdict(float)
        chunk_entities: dict[str, set[str]] = defaultdict(set)
        for nid, w in seeds.items():
            for cid in self.builder.chunks_of_entity(nid):
                chunk_hits[cid] += w
                chunk_entities[cid].add(nid)
            # vizinhança: 1 salto no GraphRAG original; `hops` > 1 é calibração nossa
            for nb, dist in eng.k_hop(nid, self.hops).items():
                if dist == 0:
                    continue
                for cid in self.builder.chunks_of_entity(nb):
                    chunk_hits[cid] += (0.25**dist) * w
        out: list[ScoredChunk] = []
        for cid, hit in chunk_hits.items():
            ch = self.store.get(cid)
            if ch is None:
                continue
            dense = cosine(qv, ch.embedding) if ch.embedding is not None else cosine(qv, self.embedder.encode(ch.text_for_embedding))
            score = hit + 0.5 * max(dense, 0.0)
            out.append(ScoredChunk(ch, score, {"entity_hits": hit, "dense": dense, "entities": float(len(chunk_entities[cid]))}, self.name))
        out.sort(key=lambda s: (-s.score, s.id))
        return out[:k]

    def retrieve(self, query: str, k: int = 10) -> list[ScoredChunk]:
        return self.local_search(query, k)

    def local_context(self, query: str, *, k: int = 6, max_chars: int = 3000) -> str:
        self._ensure()
        seeds = self.seed_entities_for(query)
        eng = self.engine
        parts: list[str] = []
        for nid in list(seeds)[: self.seed_entities]:
            node = eng.nodes[nid]
            parts.append(f"Entidade {node.name or nid}: {node.description}".strip())
            for r in eng.rels_of(nid)[:6]:
                s = eng.nodes[r.source].name or r.source
                t = eng.nodes[r.target].name or r.target
                parts.append(f"Relação: {s} {r.relation.replace('_', ' ')} {t}")
            for rep in self.reports_of(nid)[:2]:
                parts.append(f"Comunidade {rep.id}: {rep.text}")
        for sc in self.local_search(query, k):
            parts.append(f"Trecho [{sc.id}]: {sc.text}")
        text = "\n".join(p for p in parts if p)
        return text[:max_chars]

    def reports_of(self, node_id: str) -> list[CommunityReport]:
        out = []
        for lvl, partition in enumerate(self.levels):
            comm = partition.get(node_id)
            if comm is not None:
                rep = self.reports.get(f"L{lvl}:{comm}")
                if rep is not None:
                    out.append(rep)
        return out

    # ------------------------------------------------------------ busca global
    def global_search(
        self, query: str, *, level: int | None = None, k: int = 5, scorer: Mapping[str, float] | None = None
    ) -> list[tuple[CommunityReport, float]]:
        """Map: pontua cada relatório do nível; reduce: os `k` melhores.

        `scorer` permite injetar notas dadas por um modelo (`{report_id:
        nota}`); sem ele, a nota é o cosseno com a consulta.
        """
        self._ensure()
        if not self.reports:
            return []
        lvl = (len(self.levels) - 1) if level is None else level
        qv = encode_query(self.embedder, query)
        scored: list[tuple[CommunityReport, float]] = []
        for rep in self.reports.values():
            if rep.level != lvl:
                continue
            s = scorer.get(rep.id, 0.0) if scorer is not None else cosine(qv, rep.embedding)
            scored.append((rep, s))
        scored.sort(key=lambda t: (-t[1], -t[0].rank, t[0].id))
        return scored[:k]

    def global_context(self, query: str, *, level: int | None = None, k: int = 5, max_chars: int = 3000) -> str:
        parts = [f"Comunidade {rep.id} ({len(rep.members)} entidades): {rep.text}" for rep, _ in self.global_search(query, level=level, k=k)]
        return "\n".join(parts)[:max_chars]

    def stats(self) -> dict[str, Any]:
        return {**self.builder.stats(), "levels": len(self.levels), "reports": len(self.reports)}
