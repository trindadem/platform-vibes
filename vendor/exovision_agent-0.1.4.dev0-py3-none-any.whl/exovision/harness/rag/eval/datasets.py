"""Conjuntos de dados: BEIR (formato oficial) e corpora sintéticos controlados.

**BEIR** (Thakur et al., 2021): `corpus.jsonl` (`_id`, `title`, `text`),
`queries.jsonl` (`_id`, `text`) e `qrels/test.tsv`. Os dois usados aqui
são pequenos o bastante para rodar em CPU e têm números publicados para
comparação:

| dataset | docs | consultas | BM25 nDCG@10 (Anserini) | BM25+CE |
|---|---|---|---|---|
| SciFact | 5.183 | 300 | 0,665 | 0,688 |
| NFCorpus | 3.633 | 323 | 0,325 | 0,350 |

Os arquivos vêm de `https://public.ukp.informatik.tu-darmstadt.de/thakur/BEIR/datasets/<nome>.zip`
e ficam em `~/.cache/exovision/rag/<nome>/` (`download_beir`).

**Sintéticos** — determinísticos por semente, com relevância conhecida
por construção, para medir o que os públicos não isolam:

* `multi_hop_corpus`: cadeias de fatos "A trabalha na B. B fica em C. C é
  a capital de D." em passagens separadas, distratores e perguntas de 1,
  2 e 3 saltos com as passagens de apoio marcadas — o experimento em que
  grafo *deveria* ganhar, e o em que não deveria;
* `needle_corpus`: documentos longos por concatenação de abstracts (ou
  parágrafos), em que a relevância de um trecho é conter o abstract
  relevante — para calibrar tamanho de trecho e recuperação contextual.
"""

from __future__ import annotations

import csv
import io
import json
import os
import random
import urllib.request
import zipfile
from collections.abc import Mapping
from dataclasses import dataclass, field

from ..types import Document

__all__ = ["BEIR_URL", "Dataset", "cache_dir", "download_beir", "load_beir", "multi_hop_corpus", "needle_corpus"]

BEIR_URL = "https://public.ukp.informatik.tu-darmstadt.de/thakur/BEIR/datasets/{name}.zip"


@dataclass(slots=True)
class Dataset:
    name: str
    docs: list[Document]
    queries: dict[str, str]
    qrels: dict[str, dict[str, int]]
    #: para o sintético multi-hop: saltos por consulta (`"3-pair"` = 3 saltos com as duas pontas nomeadas)
    hops: dict[str, int | str] = field(default_factory=dict)

    def __len__(self) -> int:
        return len(self.docs)


def cache_dir() -> str:
    return os.environ.get("EXOVISION_RAG_CACHE", os.path.join(os.path.expanduser("~"), ".cache", "exovision", "rag"))


def download_beir(name: str, *, dest: str | None = None) -> str:
    base = dest or cache_dir()
    target = os.path.join(base, name)
    if os.path.exists(os.path.join(target, "corpus.jsonl")):
        return target
    os.makedirs(base, exist_ok=True)
    with urllib.request.urlopen(BEIR_URL.format(name=name), timeout=600) as resp:
        data = resp.read()
    with zipfile.ZipFile(io.BytesIO(data)) as zf:
        zf.extractall(base)
    return target


def load_beir(name: str, *, split: str = "test", max_docs: int | None = None, dest: str | None = None) -> Dataset:
    path = os.path.join(dest or cache_dir(), name)
    if not os.path.exists(os.path.join(path, "corpus.jsonl")):
        raise FileNotFoundError(f"BEIR/{name} não está em {path}; rode download_beir({name!r})")
    qrels: dict[str, dict[str, int]] = {}
    with open(os.path.join(path, "qrels", f"{split}.tsv"), encoding="utf-8") as fh:
        reader = csv.reader(fh, delimiter="\t")
        next(reader, None)
        for row in reader:
            if len(row) < 3:
                continue
            qid, did, score = row[0], row[1], int(row[2])
            qrels.setdefault(qid, {})[did] = score
    docs: list[Document] = []
    needed = {d for rel in qrels.values() for d in rel}
    with open(os.path.join(path, "corpus.jsonl"), encoding="utf-8") as fh:
        for line in fh:
            d = json.loads(line)
            docs.append(Document(str(d["_id"]), str(d.get("text", "")), {"title": str(d.get("title", ""))}))
    if max_docs is not None and len(docs) > max_docs:
        # mantém os relevantes e amostra o resto, para benchmark rápido reprodutível
        rng = random.Random(0)
        rel = [d for d in docs if d.id in needed]
        rest = [d for d in docs if d.id not in needed]
        rng.shuffle(rest)
        docs = rel + rest[: max(0, max_docs - len(rel))]
    queries: dict[str, str] = {}
    with open(os.path.join(path, "queries.jsonl"), encoding="utf-8") as fh:
        for line in fh:
            q = json.loads(line)
            if str(q["_id"]) in qrels:
                queries[str(q["_id"])] = str(q.get("text", ""))
    return Dataset(name, docs, queries, qrels)


# --------------------------------------------------------------------------
# Sintéticos
# --------------------------------------------------------------------------

_PEOPLE = ["Ana Souza", "Bruno Lima", "Carla Dias", "Diego Rocha", "Elisa Prado", "Fábio Nunes", "Gabriela Melo", "Hugo Reis", "Iara Castro", "João Pires", "Karina Lopes", "Leonardo Cruz", "Marina Alves", "Nuno Faria", "Olívia Ramos", "Paulo Neves", "Renata Sales", "Sérgio Moura", "Tânia Braga", "Vítor Sá"]
_COMPANIES = ["Vortex", "Nimbus", "Quanta", "Helix", "Orbita", "Zenit", "Prisma", "Kairos", "Lumen", "Ícaro", "Trama", "Sigma", "Aurora", "Delta", "Fractal", "Nexo", "Vega", "Atlas", "Ômega", "Pulsar"]
_CITIES = [("Lisboa", "Portugal", "euro"), ("Madrid", "Espanha", "euro"), ("Paris", "França", "euro"), ("Berlim", "Alemanha", "euro"), ("Roma", "Itália", "euro"), ("Londres", "Reino Unido", "libra"), ("Tóquio", "Japão", "iene"), ("Brasília", "Brasil", "real"), ("Ottawa", "Canadá", "dólar canadense"), ("Camberra", "Austrália", "dólar australiano"), ("Berna", "Suíça", "franco suíço"), ("Oslo", "Noruega", "coroa norueguesa"), ("Estocolmo", "Suécia", "coroa sueca"), ("Copenhague", "Dinamarca", "coroa dinamarquesa"), ("Varsóvia", "Polônia", "zloty"), ("Praga", "Tchéquia", "coroa tcheca"), ("Budapeste", "Hungria", "forint"), ("Cidade do México", "México", "peso mexicano"), ("Santiago", "Chile", "peso chileno"), ("Buenos Aires", "Argentina", "peso argentino")]
_FILLER = [
    "O gato dorme no sofá da sala enquanto chove.",
    "A receita do bolo de cenoura leva três ovos e cobertura de chocolate.",
    "O trem das sete parte da estação central com dez minutos de atraso.",
    "A biblioteca municipal abre aos sábados pela manhã.",
    "O torneio de xadrez terminou empatado após cinco rodadas.",
    "A horta comunitária colheu tomates e manjericão esta semana.",
    "O museu inaugurou uma exposição de fotografia antiga.",
    "O ciclista completou a subida em quarenta minutos.",
]


def multi_hop_corpus(*, n_chains: int = 20, distractors: int = 40, seed: int = 0) -> Dataset:
    """Cadeias pessoa -> empresa -> cidade -> país (-> moeda), uma passagem por fato.

    Consultas: 1 salto ("onde trabalha X?"), 2 saltos ("em que cidade fica
    a empresa de X?"), 3 saltos ("em que país fica a empresa de X?") e
    3 saltos com as duas pontas nomeadas ("que ligação existe entre X e o
    país?"). Cada consulta marca como relevantes **todas** as passagens de
    apoio — o recall@k mede se o sistema traz a cadeia inteira.
    """
    rng = random.Random(seed)
    people = list(_PEOPLE)
    companies = list(_COMPANIES)
    cities = list(_CITIES)
    rng.shuffle(people)
    rng.shuffle(companies)
    rng.shuffle(cities)
    n = min(n_chains, len(people), len(companies), len(cities))
    docs: list[Document] = []
    queries: dict[str, str] = {}
    qrels: dict[str, dict[str, int]] = {}
    hops: dict[str, int | str] = {}
    for i in range(n):
        person, company, (city, country, currency) = people[i], companies[i], cities[i]
        p1, p2, p3, p4 = f"c{i}-p1", f"c{i}-p2", f"c{i}-p3", f"c{i}-p4"
        docs.append(Document(p1, f"{person} trabalha na {company}.", {"chain": i, "hop": 1}))
        docs.append(Document(p2, f"A {company} fica em {city}.", {"chain": i, "hop": 2}))
        docs.append(Document(p3, f"{city} é a capital de {country}.", {"chain": i, "hop": 3}))
        docs.append(Document(p4, f"{country} usa o {currency}.", {"chain": i, "hop": 4}))
        first = person.split()[0]
        queries[f"q{i}-h1"] = f"Onde trabalha {person}?"
        qrels[f"q{i}-h1"] = {p1: 1}
        hops[f"q{i}-h1"] = 1
        queries[f"q{i}-h2"] = f"Em que cidade fica a empresa onde {first} trabalha?"
        qrels[f"q{i}-h2"] = {p1: 1, p2: 1}
        hops[f"q{i}-h2"] = 2
        queries[f"q{i}-h3"] = f"Em que país fica a empresa onde {person} trabalha?"
        qrels[f"q{i}-h3"] = {p1: 1, p2: 1, p3: 1}
        hops[f"q{i}-h3"] = 3
        # duas pontas nomeadas: o caso para que o PathRAG foi desenhado
        queries[f"q{i}-pair"] = f"Que ligação existe entre {person} e {country}?"
        qrels[f"q{i}-pair"] = {p1: 1, p2: 1, p3: 1}
        hops[f"q{i}-pair"] = "3-pair"
    for j in range(distractors):
        docs.append(Document(f"d{j}", rng.choice(_FILLER) + f" Registro {j}.", {"chain": -1, "hop": 0}))
    rng.shuffle(docs)
    return Dataset("multi_hop", docs, queries, qrels, hops)


def needle_corpus(base: Dataset, *, per_doc: int = 8, seed: int = 0, max_queries: int | None = None) -> tuple[Dataset, Mapping[str, str]]:
    """Concatena `per_doc` documentos de `base` em documentos longos.

    Devolve o dataset longo e o mapa `doc_original -> doc_longo`. A
    relevância de um *trecho* recuperado é conter o texto do documento
    original relevante (`chunk_contains`); o avaliador de trechos em
    `bench.py` usa os offsets.
    """
    rng = random.Random(seed)
    docs = list(base.docs)
    rng.shuffle(docs)
    long_docs: list[Document] = []
    where: dict[str, str] = {}
    spans: dict[str, dict[str, tuple[int, int]]] = {}
    for i in range(0, len(docs), per_doc):
        group = docs[i : i + per_doc]
        lid = f"long{i // per_doc}"
        parts: list[str] = []
        pos = 0
        spans[lid] = {}
        for d in group:
            title = d.metadata.get("title", "")
            piece = (f"{title}. " if title else "") + d.text
            start = pos
            parts.append(piece)
            pos += len(piece) + 2
            spans[lid][d.id] = (start, start + len(piece))
            where[d.id] = lid
        long_docs.append(Document(lid, "\n\n".join(parts), {"spans": spans[lid]}))
    qids = list(base.queries)
    if max_queries is not None:
        qids = qids[:max_queries]
    queries = {q: base.queries[q] for q in qids}
    qrels = {q: dict(base.qrels[q]) for q in qids}
    return Dataset(f"{base.name}-needle", long_docs, queries, qrels), where


def qrels_to_docs(qrels: Mapping[str, Mapping[str, int]]) -> set[str]:
    return {d for rel in qrels.values() for d in rel}


