"""Os benchmarks: recuperação (BEIR e sintético), ANN, segmentação, grafo, fusão.

Cada função devolve um dicionário serializável com **o que foi medido e
como** (parâmetros, tamanhos, tempos, intervalos de confiança) e
`write_result` grava em `docs/rag/resultados/<nome>.json` — o estudo em
`docs/rag-estudo.md` e o documento `docs/rag.tex` citam esses arquivos, e
o teste `test_docs_rag` confere que os números citados existem.

Convenções:

* a unidade de avaliação no BEIR é o **documento**; trechos recuperados
  são agregados por documento (score máximo, ordem preservada);
* tempos são de parede, num único processo, na máquina que rodou — estão
  no JSON junto com a máquina, e não são comparáveis entre máquinas;
* toda semente é fixa; rodar de novo dá o mesmo número.
"""

from __future__ import annotations

import json
import os
import platform
import time
from collections.abc import Callable, Mapping, Sequence
from typing import Any

from ...memory.core.embeddings import Embedder
from ..embed import calibrate_noise_floor, encode_documents, encode_query
from ..index import FlatIndex
from ..types import Retriever, ScoredChunk
from .datasets import Dataset
from .metrics import Summary, bootstrap_ci, evaluate, paired_permutation_test

__all__ = [
    "ann_benchmark",
    "chunk_hits_benchmark",
    "doc_ranking",
    "environment",
    "graph_benchmark",
    "noise_floor_benchmark",
    "results_dir",
    "retrieval_benchmark",
    "write_result",
]


def results_dir() -> str:
    here = os.path.dirname(os.path.abspath(__file__))
    root = os.path.abspath(os.path.join(here, "..", "..", "..", ".."))
    return os.environ.get("EXOVISION_RAG_RESULTS", os.path.join(root, "docs", "rag", "resultados"))


def environment() -> dict[str, Any]:
    return {
        "machine": platform.machine(),
        "system": platform.system(),
        "python": platform.python_version(),
        "processor": platform.processor(),
        "timestamp": time.strftime("%Y-%m-%dT%H:%M:%S"),
    }


def write_result(name: str, payload: Mapping[str, Any], *, directory: str | None = None) -> str:
    d = directory or results_dir()
    os.makedirs(d, exist_ok=True)
    path = os.path.join(d, f"{name}.json")
    with open(path, "w", encoding="utf-8") as fh:
        json.dump({"environment": environment(), **payload}, fh, ensure_ascii=False, indent=2)
    return path


def doc_ranking(items: Sequence[ScoredChunk]) -> list[str]:
    """Trechos -> documentos, na ordem do primeiro trecho de cada documento."""
    out: list[str] = []
    for it in items:
        if it.doc_id not in out:
            out.append(it.doc_id)
    return out


def _ci(summary: Summary, key: str) -> dict[str, float]:
    mean, lo, hi = bootstrap_ci(list(summary.per_query.get(key, {}).values()))
    return {"mean": round(mean, 4), "lo": round(lo, 4), "hi": round(hi, 4)}


def retrieval_benchmark(
    dataset: Dataset,
    systems: Mapping[str, Callable[[], Retriever]],
    *,
    k: int = 100,
    k_values: Sequence[int] = (1, 3, 5, 10, 100),
    doc_level: bool = True,
    baseline: str | None = None,
    max_queries: int | None = None,
) -> dict[str, Any]:
    """Roda cada sistema nas consultas do dataset e mede; `systems` são fábricas
    (o índice é construído dentro do tempo medido)."""
    qids = list(dataset.queries)
    if max_queries is not None:
        qids = qids[:max_queries]
    qrels = {q: dataset.qrels[q] for q in qids}
    out: dict[str, Any] = {"dataset": dataset.name, "docs": len(dataset.docs), "queries": len(qids), "k": k, "systems": {}}
    summaries: dict[str, Summary] = {}
    for name, factory in systems.items():
        t0 = time.perf_counter()
        retriever = factory()
        build_s = time.perf_counter() - t0
        run: dict[str, list[str]] = {}
        t1 = time.perf_counter()
        for q in qids:
            items = retriever.retrieve(dataset.queries[q], k)
            run[q] = doc_ranking(items) if doc_level else [it.id for it in items]
        query_s = time.perf_counter() - t1
        summary = evaluate(run, qrels, k_values=k_values)
        summaries[name] = summary
        out["systems"][name] = {
            "metrics": summary.to_dict(),
            "ci": {key: _ci(summary, key) for key in ("ndcg@10", "recall@10", "recall@100", "mrr@10") if key in summary.means},
            "build_s": round(build_s, 3),
            "query_ms": round(query_s / max(len(qids), 1) * 1000, 3),
            "stats": getattr(retriever, "stats", lambda: {})(),
        }
    if baseline and baseline in summaries:
        base = summaries[baseline]
        for name, s in summaries.items():
            if name == baseline:
                continue
            key = "ndcg@10" if "ndcg@10" in s.per_query else next(iter(s.per_query))
            diff, p = paired_permutation_test(s.per_query[key], base.per_query[key])
            out["systems"][name]["vs_baseline"] = {"metric": key, "diff": round(diff, 4), "p_value": round(p, 4)}
    return out


def chunk_hits_benchmark(
    dataset: Dataset,
    where: Mapping[str, str],
    systems: Mapping[str, Callable[[], Retriever]],
    *,
    k_values: Sequence[int] = (1, 3, 5, 10),
    max_queries: int | None = None,
) -> dict[str, Any]:
    """Relevância no nível do trecho: o trecho recuperado cobre o documento original relevante?

    `where` mapeia doc original -> doc longo; os spans dos originais estão em
    `metadata["spans"]` do doc longo. Um trecho conta como relevante se a
    interseção com o span do original cobre pelo menos metade **do menor dos
    dois** — um trecho pequeno inteiro dentro do abstract conta; um trecho
    grande que cobre o abstract conta; um trecho que só encosta no título
    não. (Medir contra metade do *span* tornava impossível, por construção,
    qualquer trecho menor que meio abstract acertar — o primeiro
    `chunking_scifact_model2vec.json` deste repositório registrou R@5 = 0,007
    para 300 caracteres por isso, não por qualidade.)
    """
    qids = list(dataset.queries)
    if max_queries is not None:
        qids = qids[:max_queries]
    spans = {d.id: d.metadata.get("spans", {}) for d in dataset.docs}
    out: dict[str, Any] = {"dataset": dataset.name, "long_docs": len(dataset.docs), "queries": len(qids), "systems": {}}
    for name, factory in systems.items():
        t0 = time.perf_counter()
        r = factory()
        build_s = time.perf_counter() - t0
        run: dict[str, list[str]] = {}
        qrels: dict[str, dict[str, int]] = {}
        for q in qids:
            rel_docs = {d for d, s in dataset.qrels[q].items() if s > 0}
            targets: dict[str, tuple[str, int, int]] = {}
            for d in rel_docs:
                lid = where.get(d)
                if lid and d in spans.get(lid, {}):
                    a0, b0 = spans[lid][d]
                    targets[d] = (lid, int(a0), int(b0))
            qrels[q] = dict.fromkeys(targets, 1)
            items = r.retrieve(dataset.queries[q], max(k_values))
            ranked: list[str] = []
            for it in items:
                hit = ""
                for d, (lid, a, b) in targets.items():
                    if it.doc_id != lid:
                        continue
                    inter = min(it.chunk.end, b) - max(it.chunk.start, a)
                    if inter >= 0.5 * min(b - a, it.chunk.end - it.chunk.start):
                        hit = d
                        break
                ranked.append(hit or it.id)
            run[q] = ranked
        summary = evaluate(run, qrels, k_values=k_values, metrics=("recall", "hit", "mrr"))
        stats: dict[str, Any] = getattr(r, "stats", dict)()
        out["systems"][name] = {"metrics": summary.to_dict(), "ci": {key: _ci(summary, key) for key in ("recall@5", "hit@5") if key in summary.means}, "build_s": round(build_s, 3), "chunks": stats.get("chunks")}
    return out


def ann_benchmark(
    vectors: Sequence[Sequence[float]],
    queries: Sequence[Sequence[float]],
    systems: Mapping[str, Callable[[int], Any]],
    *,
    k: int = 10,
    search_kw: Mapping[str, Sequence[Mapping[str, Any]]] | None = None,
) -> dict[str, Any]:
    """Recall@k contra a varredura exata e latência por consulta, para cada índice.

    `systems[name](dim)` constrói o índice; `search_kw[name]` é a lista de
    variações de parâmetro de busca (ex.: `[{"ef": 16}, {"ef": 64}]`).
    """
    dim = len(vectors[0])
    ids = [f"v{i}" for i in range(len(vectors))]
    flat = FlatIndex(dim)
    flat.add(ids, vectors)
    truth = [{i for i, _ in flat.search(q, k)} for q in queries]
    t = time.perf_counter()
    for q in queries:
        flat.search(q, k)
    flat_ms = (time.perf_counter() - t) / len(queries) * 1000
    out: dict[str, Any] = {"n": len(vectors), "dim": dim, "queries": len(queries), "k": k, "flat_query_ms": round(flat_ms, 4), "systems": {}}
    for name, factory in systems.items():
        t0 = time.perf_counter()
        idx = factory(dim)
        idx.add(ids, vectors)
        build_s = time.perf_counter() - t0
        variants = list((search_kw or {}).get(name, [{}]))
        rows = []
        for kw in variants:
            evals_before = getattr(idx, "distance_evals", 0)
            t1 = time.perf_counter()
            rec = 0.0
            for q, tr in zip(queries, truth, strict=True):
                got = {i for i, _ in idx.search(q, k, **kw)}
                rec += len(got & tr) / k
            ms = (time.perf_counter() - t1) / len(queries) * 1000
            row = {"params": dict(kw), "recall": round(rec / len(queries), 4), "query_ms": round(ms, 4), "speedup_vs_flat": round(flat_ms / ms, 2) if ms > 0 else None}
            evals = getattr(idx, "distance_evals", None)
            if evals is not None:
                row["distance_evals_per_query"] = round((evals - evals_before) / len(queries), 1)
            rows.append(row)
        entry: dict[str, Any] = {"build_s": round(build_s, 3), "variants": rows}
        st = getattr(idx, "stats", None)
        if callable(st):
            entry["stats"] = st()
        mem = getattr(idx, "memory_bytes", None)
        if callable(mem):
            entry["memory_bytes"] = mem()
        out["systems"][name] = entry
    return out


def graph_benchmark(dataset: Dataset, systems: Mapping[str, Callable[[], Retriever]], *, k: int = 5, k_values: Sequence[int] = (1, 3, 5, 10)) -> dict[str, Any]:
    """Multi-hop sintético: métricas por número de saltos, por sistema."""
    out: dict[str, Any] = {"dataset": dataset.name, "docs": len(dataset.docs), "queries": len(dataset.queries), "k": k, "systems": {}}
    for name, factory in systems.items():
        t0 = time.perf_counter()
        r = factory()
        build_s = time.perf_counter() - t0
        run: dict[str, list[str]] = {}
        t1 = time.perf_counter()
        for q, text in dataset.queries.items():
            run[q] = doc_ranking(r.retrieve(text, max(k_values)))
        query_ms = (time.perf_counter() - t1) / max(len(dataset.queries), 1) * 1000
        summary = evaluate(run, dataset.qrels, k_values=k_values, metrics=("recall", "ndcg", "hit"))
        by_hop: dict[str, dict[str, float]] = {}
        for hop in sorted(set(dataset.hops.values()), key=str):
            qs = [q for q, h in dataset.hops.items() if h == hop]
            by_hop[str(hop)] = {key: round(sum(summary.per_query[key][q] for q in qs) / len(qs), 4) for key in (f"recall@{k}", f"hit@{k}", "ndcg@10") if key in summary.per_query}
        out["systems"][name] = {"metrics": summary.to_dict(), "by_hop": by_hop, "build_s": round(build_s, 3), "query_ms": round(query_ms, 3), "stats": getattr(r, "stats", lambda: {})()}
    return out


def noise_floor_benchmark(embedder: Embedder, texts: Sequence[str], *, name: str, pairs: int = 3000) -> dict[str, Any]:
    nf = calibrate_noise_floor(embedder, texts, pairs=pairs)
    # sanidade: consulta contra o próprio texto e contra paráfrase trivial
    sample = list(texts[:50])
    self_sim = sum(float(sum(a * b for a, b in zip(encode_query(embedder, t), v, strict=True))) for t, v in zip(sample, encode_documents(embedder, sample), strict=True)) / max(len(sample), 1)
    return {"embedder": name, "dim": embedder.dim, "noise_floor": nf.to_dict(), "self_similarity_mean": round(self_sim, 4), "texts": len(texts)}
