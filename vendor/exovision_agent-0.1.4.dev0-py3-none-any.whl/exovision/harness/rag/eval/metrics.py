"""Métricas de recuperação e a estatística que as torna comparáveis.

As métricas do BEIR (Thakur et al., 2021) e do TREC: nDCG@k (Järvelin &
Kekäläinen, 2002), Recall@k, Precision@k, MRR@k, MAP@k, e a taxa de
acerto. Sobre elas, o que um benchmark honesto precisa e a maioria omite:

* **intervalo de confiança por bootstrap** sobre as consultas (Efron,
  1979): um nDCG médio sem intervalo não diz se a diferença entre dois
  sistemas é sinal ou sorte;
* **teste de permutação pareado** (Smucker, Allan & Carterette, 2007 —
  o teste recomendado para IR): a probabilidade de a diferença média entre
  dois sistemas, nas *mesmas* consultas, ser tão grande por acaso.

Os *qrels* são `{query_id: {doc_id: relevância}}`; relevância 0 conta como
não relevante, como no BEIR.
"""

from __future__ import annotations

import math
import random
from collections.abc import Mapping, Sequence
from dataclasses import dataclass, field

__all__ = [
    "Qrels",
    "Run",
    "Summary",
    "bootstrap_ci",
    "evaluate",
    "hit_rate",
    "map_at_k",
    "mrr_at_k",
    "ndcg_at_k",
    "paired_permutation_test",
    "precision_at_k",
    "recall_at_k",
]

Qrels = Mapping[str, Mapping[str, int]]
Run = Mapping[str, Sequence[str]]  # query_id -> doc ids ranqueados


def _rel(qrels: Mapping[str, int], doc: str) -> int:
    return int(qrels.get(doc, 0))


def ndcg_at_k(ranked: Sequence[str], qrels: Mapping[str, int], k: int) -> float:
    dcg = 0.0
    for i, d in enumerate(ranked[:k]):
        r = _rel(qrels, d)
        if r > 0:
            dcg += (2**r - 1) / math.log2(i + 2)
    ideal = sorted((r for r in qrels.values() if r > 0), reverse=True)[:k]
    idcg = sum((2**r - 1) / math.log2(i + 2) for i, r in enumerate(ideal))
    return dcg / idcg if idcg > 0 else 0.0


def recall_at_k(ranked: Sequence[str], qrels: Mapping[str, int], k: int) -> float:
    relevant = {d for d, r in qrels.items() if r > 0}
    if not relevant:
        return 0.0
    return len(relevant & set(ranked[:k])) / len(relevant)


def precision_at_k(ranked: Sequence[str], qrels: Mapping[str, int], k: int) -> float:
    if k <= 0:
        return 0.0
    return sum(1 for d in ranked[:k] if _rel(qrels, d) > 0) / k


def mrr_at_k(ranked: Sequence[str], qrels: Mapping[str, int], k: int) -> float:
    for i, d in enumerate(ranked[:k]):
        if _rel(qrels, d) > 0:
            return 1.0 / (i + 1)
    return 0.0


def map_at_k(ranked: Sequence[str], qrels: Mapping[str, int], k: int) -> float:
    relevant = {d for d, r in qrels.items() if r > 0}
    if not relevant:
        return 0.0
    hits = 0
    acc = 0.0
    for i, d in enumerate(ranked[:k]):
        if d in relevant:
            hits += 1
            acc += hits / (i + 1)
    return acc / min(len(relevant), k)


def hit_rate(ranked: Sequence[str], qrels: Mapping[str, int], k: int) -> float:
    return 1.0 if any(_rel(qrels, d) > 0 for d in ranked[:k]) else 0.0


_METRICS = {
    "ndcg": ndcg_at_k,
    "recall": recall_at_k,
    "precision": precision_at_k,
    "mrr": mrr_at_k,
    "map": map_at_k,
    "hit": hit_rate,
}


@dataclass(slots=True)
class Summary:
    """Média por métrica, com os valores por consulta guardados para estatística."""

    means: dict[str, float] = field(default_factory=dict)
    per_query: dict[str, dict[str, float]] = field(default_factory=dict)  # métrica -> qid -> valor
    n_queries: int = 0

    def to_dict(self) -> dict[str, float]:
        return {k: round(v, 4) for k, v in self.means.items()}


def evaluate(run: Run, qrels: Qrels, *, k_values: Sequence[int] = (1, 3, 5, 10, 100), metrics: Sequence[str] = ("ndcg", "recall", "mrr", "precision", "map", "hit")) -> Summary:
    out = Summary()
    qids = [q for q in qrels if q in run]
    out.n_queries = len(qids)
    for m in metrics:
        fn = _METRICS[m]
        for k in k_values:
            key = f"{m}@{k}"
            vals = {q: fn(run[q], qrels[q], k) for q in qids}
            out.per_query[key] = vals
            out.means[key] = sum(vals.values()) / len(vals) if vals else 0.0
    return out


def bootstrap_ci(values: Sequence[float], *, iterations: int = 2000, alpha: float = 0.05, seed: int = 0) -> tuple[float, float, float]:
    """(média, limite inferior, limite superior) por bootstrap percentil."""
    if not values:
        return 0.0, 0.0, 0.0
    rng = random.Random(seed)
    n = len(values)
    mean = sum(values) / n
    means = []
    for _ in range(iterations):
        s = 0.0
        for _ in range(n):
            s += values[rng.randrange(n)]
        means.append(s / n)
    means.sort()
    lo = means[int(alpha / 2 * (iterations - 1))]
    hi = means[int((1 - alpha / 2) * (iterations - 1))]
    return mean, lo, hi


def paired_permutation_test(a: Mapping[str, float], b: Mapping[str, float], *, iterations: int = 5000, seed: int = 0) -> tuple[float, float]:
    """(diferença média a-b, valor-p bilateral) sobre as consultas em comum."""
    qids = [q for q in a if q in b]
    if not qids:
        return 0.0, 1.0
    diffs = [a[q] - b[q] for q in qids]
    observed = sum(diffs) / len(diffs)
    rng = random.Random(seed)
    extreme = 0
    for _ in range(iterations):
        s = 0.0
        for d in diffs:
            s += d if rng.random() < 0.5 else -d
        if abs(s / len(diffs)) >= abs(observed) - 1e-15:
            extreme += 1
    return observed, (extreme + 1) / (iterations + 1)
