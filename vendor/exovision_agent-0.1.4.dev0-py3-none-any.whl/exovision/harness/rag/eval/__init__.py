"""Avaliação: métricas com estatística, datasets (BEIR e sintéticos) e benchmarks."""

from .bench import (
    ann_benchmark,
    chunk_hits_benchmark,
    doc_ranking,
    graph_benchmark,
    noise_floor_benchmark,
    results_dir,
    retrieval_benchmark,
    write_result,
)
from .datasets import Dataset, download_beir, load_beir, multi_hop_corpus, needle_corpus
from .metrics import (
    Summary,
    bootstrap_ci,
    evaluate,
    map_at_k,
    mrr_at_k,
    ndcg_at_k,
    paired_permutation_test,
    precision_at_k,
    recall_at_k,
)

__all__ = [
    "Dataset",
    "Summary",
    "ann_benchmark",
    "bootstrap_ci",
    "chunk_hits_benchmark",
    "doc_ranking",
    "download_beir",
    "evaluate",
    "graph_benchmark",
    "load_beir",
    "map_at_k",
    "mrr_at_k",
    "multi_hop_corpus",
    "ndcg_at_k",
    "needle_corpus",
    "noise_floor_benchmark",
    "paired_permutation_test",
    "precision_at_k",
    "recall_at_k",
    "results_dir",
    "retrieval_benchmark",
    "write_result",
]
