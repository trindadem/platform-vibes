"""O pipeline: ingerir, recuperar, empacotar — e os laços adaptativos em volta dele.

`RAGPipeline` é a configuração de produção: segmentação, embedding real,
índice ANN + BM25 na mesma coleção, fusão, reranking opcional e
transformação de consulta opcional. Cada `ScoredChunk` sai com a
decomposição do score por sinal e o id do trecho, que o contexto cita.

Em volta dele, quatro padrões que decidem *se* e *como* recuperar:

| padrão | regime | origem |
|---|---|---|
| `CorrectiveRAG` | experimental | CRAG (Yan et al., 2024): um avaliador dá nota aos trechos; `correto` -> refina por sentenças, `incorreto` -> recuperador de contingência, `ambíguo` -> os dois |
| `SufficiencyGate` | experimental | "Sufficient Context" (Joren et al., 2025): decide se o contexto basta; se não, o sistema abstém em vez de alucinar |
| `IterativeRetriever` | experimental | IRCoT (Trivedi et al., 2023) / Search-R1 (Jin et al., 2025): entrelaça raciocínio e busca; o modelo (ou uma heurística de ponte por entidades) escreve a próxima consulta |
| `self_route` | experimental | Self-Route (Li et al., 2024): se o corpus cabe no orçamento, contexto longo; se não, RAG |

Todos os padrões funcionam sem modelo (heurísticas declaradas) e com o
`Provider` do harness — e são testados com `ScriptedProvider`.
"""

from __future__ import annotations

import json
from collections import defaultdict
from collections.abc import Callable, Iterable, Sequence
from dataclasses import dataclass, field
from typing import Any

from ..memory.core.budget import estimate_tokens
from ..memory.core.embeddings import Embedder
from ..memory.core.summarize import split_sentences
from ..memory.core.text import content_words
from ..models.provider import Provider
from .chunking import Chunk, Chunker, RecursiveChunker
from .embed import encode_documents, encode_query
from .fusion import convex, rrf
from .graph.extract import named_spans
from .llm import LLMUsage, ask
from .query import QueryTransform, run_transforms
from .rerank import Reranker, lost_in_the_middle
from .types import ChunkStore, Document, Retriever, ScoredChunk
from .vectordb import Collection

__all__ = [
    "Context",
    "CorrectiveRAG",
    "IterativeRetriever",
    "RAGPipeline",
    "Sufficiency",
    "SufficiencyGate",
    "self_route",
]


@dataclass(slots=True)
class Context:
    text: str
    items: list[ScoredChunk]
    tokens: int
    dropped: int
    order: str

    def ids(self) -> list[str]:
        return [i.id for i in self.items]


def _as_document(item: Any, i: int) -> Document:
    if isinstance(item, Document):
        return item
    if isinstance(item, str):
        return Document(f"doc{i}", item)
    if isinstance(item, dict):
        return Document(str(item.get("id", f"doc{i}")), str(item.get("text", "")), {k: v for k, v in item.items() if k not in ("id", "text")})
    if isinstance(item, tuple) and len(item) >= 2:
        return Document(str(item[0]), str(item[1]), dict(item[2]) if len(item) > 2 else {})
    raise TypeError(f"documento inválido: {type(item).__name__}")


class RAGPipeline:
    name = "hybrid"

    def __init__(
        self,
        embedder: Embedder,
        *,
        chunker: Chunker | None = None,
        index: str = "hnsw",
        sparse: bool = True,
        fusion: str = "rrf",
        alpha: float = 0.5,
        rrf_k: float = 60.0,
        reranker: Reranker | None = None,
        rerank_pool: int = 50,
        transforms: Sequence[QueryTransform] = (),
        pool: int | None = None,
        path: str | None = None,
        name: str = "corpus",
        **index_kw: Any,
    ) -> None:
        if fusion not in ("rrf", "convex", "dense", "sparse"):
            raise ValueError("fusion: rrf | convex | dense | sparse")
        if fusion == "sparse" and not sparse:
            raise ValueError("fusion='sparse' exige sparse=True")
        self.embedder = embedder
        self.chunker: Chunker = chunker or RecursiveChunker(800, 100)
        self.fusion = fusion
        self.alpha = alpha
        self.rrf_k = rrf_k
        self.reranker = reranker
        self.rerank_pool = rerank_pool
        self.transforms = list(transforms)
        self.pool = pool
        self.path = path
        self.store = ChunkStore()
        self.collection = Collection(name, embedder.dim, index=index, sparse=sparse, path=path, **index_kw)
        self.docs = 0
        self.usage = LLMUsage()
        if path:
            self._rehydrate()

    # ------------------------------------------------------------ disco
    def _rehydrate(self) -> None:
        docs: set[str] = set()
        chunks: list[Chunk] = []
        for item in self.collection._items.values():
            p = item.payload
            if "doc_id" not in p:
                continue
            c = Chunk(p["doc_id"], int(p.get("index", 0)), p.get("text", item.text), int(p.get("start", 0)), int(p.get("end", 0)), dict(p.get("metadata", {})), p.get("context", ""), item.vector)
            chunks.append(c)
            docs.add(c.doc_id)
        self.store.add(chunks)
        self.docs = len(docs)

    # ------------------------------------------------------------ ingestão
    def ingest(self, documents: Iterable[Any]) -> int:
        chunks: list[Chunk] = []
        n_docs = 0
        for i, item in enumerate(documents):
            doc = _as_document(item, i)
            if not doc.text.strip():
                continue
            replaced = self.store.remove_doc(doc.id)
            if not replaced:
                n_docs += 1
            if replaced:
                self.collection.delete(replaced)
            chunks.extend(self.chunker.chunk(doc.id, doc.text, doc.metadata))
        if not chunks:
            return 0
        todo = [c for c in chunks if c.embedding is None]
        if todo:
            vecs = encode_documents(self.embedder, [c.text_for_embedding for c in todo])
            for c, v in zip(todo, vecs, strict=True):
                c.embedding = v
        self.store.add(chunks)
        self.collection.upsert(
            [c.id for c in chunks],
            [c.embedding or () for c in chunks],
            [{"doc_id": c.doc_id, "index": c.index, "start": c.start, "end": c.end, "text": c.text, "context": c.context, "metadata": c.metadata} for c in chunks],
            [c.text_for_embedding for c in chunks],
        )
        self.docs += n_docs
        return len(chunks)

    # ------------------------------------------------------------ recuperação
    def _search_one(self, query: str, pool: int, filter: dict[str, Any] | None) -> tuple[list[tuple[str, float]], list[tuple[str, float]]]:
        dense: list[tuple[str, float]] = []
        sparse: list[tuple[str, float]] = []
        if self.fusion != "sparse":
            dense = self.collection.query(encode_query(self.embedder, query), pool, filter=filter)
        if self.fusion != "dense" and self.collection._inverted is not None:
            sparse = self.collection.query_text(query, pool, filter=filter)
        return dense, sparse

    def retrieve(self, query: str, k: int = 10, *, filter: dict[str, Any] | None = None) -> list[ScoredChunk]:
        if not query.strip() or len(self.collection) == 0:
            return []
        pool = self.pool or max(k * 4, self.rerank_pool if self.reranker else 0, 20)
        queries = run_transforms(self.transforms, query) if self.transforms else [query]
        rankings: list[list[str]] = []
        dense_scores: dict[str, float] = defaultdict(float)
        sparse_scores: dict[str, float] = defaultdict(float)
        for q in queries:
            d, s = self._search_one(q, pool, filter)
            if d:
                rankings.append([i for i, _ in d])
                for i, sc in d:
                    dense_scores[i] = max(dense_scores[i], sc)
            if s:
                rankings.append([i for i, _ in s])
                for i, sc in s:
                    sparse_scores[i] = max(sparse_scores[i], sc)
        if not rankings:
            return []
        if self.fusion == "convex" and len(queries) == 1:
            fused = convex(dense_scores, sparse_scores, alpha=self.alpha)
        elif self.fusion in ("dense", "sparse") and len(queries) == 1:
            fused = sorted((dense_scores if self.fusion == "dense" else sparse_scores).items(), key=lambda kv: (-kv[1], kv[0]))
        else:
            fused = rrf(rankings, k=self.rrf_k)
        fused = fused[:pool]
        signals: dict[str, dict[str, float]] = {i: {"fused": s, "dense": dense_scores.get(i, 0.0), "sparse": sparse_scores.get(i, 0.0)} for i, s in fused}
        order = [i for i, _ in fused]
        if self.reranker is not None and order:
            head = order[: self.rerank_pool]
            docs = [(c.text if c is not None else "") for c in (self.store.get(h) for h in head)]
            ranked = self.reranker.rerank(query, docs)
            for pos, sc in ranked:
                signals[head[pos]]["rerank"] = sc
            head = [head[pos] for pos, _ in ranked]
            order = head + order[self.rerank_pool :]
        out: list[ScoredChunk] = []
        for rank, cid in enumerate(order[:k]):
            ch = self.store.get(cid)
            if ch is None:
                continue
            sig = signals[cid]
            score = sig.get("rerank", sig["fused"]) if self.reranker is not None else sig["fused"]
            out.append(ScoredChunk(ch, float(score), {**sig, "rank": float(rank)}, self.name))
        return out

    # ------------------------------------------------------------ contexto
    def context(
        self,
        query: str,
        *,
        k: int = 8,
        budget_tokens: int = 2000,
        order: str = "relevance",
        filter: dict[str, Any] | None = None,
        cite: bool = True,
    ) -> Context:
        items = self.retrieve(query, k, filter=filter)
        chosen: list[ScoredChunk] = []
        used = 0
        dropped = 0
        for it in items:
            cost = estimate_tokens(it.text) + 8
            if used + cost > budget_tokens:
                dropped += 1
                continue
            chosen.append(it)
            used += cost
        ordered = lost_in_the_middle(chosen) if order == "lost_in_the_middle" else chosen
        lines = [f"[{it.id}] {it.text}" if cite else it.text for it in ordered]
        return Context("\n\n".join(lines), ordered, used, dropped, order)

    def stats(self) -> dict[str, Any]:
        return {"docs": self.docs, "chunks": len(self.store), "collection": self.collection.stats(), "reranker": type(self.reranker).__name__ if self.reranker else None, "fusion": self.fusion, "transforms": [type(t).__name__ for t in self.transforms]}

    def save_manifest(self, path: str | None = None) -> str:
        p = path or (self.path + ".manifest.json" if self.path else "rag.manifest.json")
        with open(p, "w", encoding="utf-8") as fh:
            json.dump({"stats": self.stats(), "chunker": type(self.chunker).__name__, "embedder": repr(self.embedder)}, fh, ensure_ascii=False, indent=2)
        return p


# --------------------------------------------------------------------------
# CRAG
# --------------------------------------------------------------------------

Grader = Callable[[str, ScoredChunk], float]


def lexical_grader(query: str, chunk: ScoredChunk) -> float:
    """Nota 0..1 sem modelo: cobertura dos termos da consulta pelo trecho."""
    q = set(content_words(query))
    if not q:
        return 0.0
    t = set(content_words(chunk.text))
    return len(q & t) / len(q)


def provider_grader(provider: Provider, *, usage: LLMUsage | None = None) -> Grader:
    def grade(query: str, chunk: ScoredChunk) -> float:
        text = ask(provider, "Responda com um número de 0 a 10: quanto a passagem ajuda a responder à pergunta.", f"Pergunta: {query}\n\nPassagem: {chunk.text[:800]}", usage=usage, max_tokens=6)
        digits = "".join(ch for ch in text if ch.isdigit() or ch == ".")
        try:
            return min(10.0, max(0.0, float(digits))) / 10.0
        except ValueError:
            return 0.0

    return grade


class CorrectiveRAG:
    name = "crag"

    def __init__(
        self,
        retriever: Retriever,
        *,
        grader: Grader | None = None,
        upper: float = 0.6,
        lower: float = 0.2,
        fallback: Retriever | None = None,
        refine: bool = True,
        embedder: Embedder | None = None,
    ) -> None:
        self.retriever = retriever
        self.grader = grader or lexical_grader
        self.upper = upper
        self.lower = lower
        self.fallback = fallback
        self.refine = refine
        self.embedder = embedder
        self.last_action = ""

    def _strip(self, query: str, chunk: ScoredChunk) -> str:
        """Decompõe em sentenças e mantém as que tocam a consulta (knowledge refinement)."""
        q = set(content_words(query))
        keep = [s for s in split_sentences(chunk.text) if q & set(content_words(s))]
        return " ".join(keep) if keep else chunk.text

    def retrieve(self, query: str, k: int = 10) -> list[ScoredChunk]:
        hits = self.retriever.retrieve(query, max(k * 2, 6))
        graded = [(h, self.grader(query, h)) for h in hits]
        best = max((g for _, g in graded), default=0.0)
        if best >= self.upper:
            action = "correct"
        elif best < self.lower:
            action = "incorrect"
        else:
            action = "ambiguous"
        self.last_action = action
        out: list[ScoredChunk] = []
        if action in ("correct", "ambiguous"):
            for h, g in graded:
                if g >= self.lower or action == "ambiguous":
                    ch = h.chunk
                    if self.refine:
                        text = self._strip(query, h)
                        ch = Chunk(ch.doc_id, ch.index, text, ch.start, ch.end, ch.metadata, ch.context, ch.embedding)
                    out.append(ScoredChunk(ch, g + 0.01 * h.score, {**h.signals, "grade": g}, f"{self.name}:{action}"))
        if action in ("incorrect", "ambiguous") and self.fallback is not None:
            seen = {o.id for o in out}
            for h in self.fallback.retrieve(query, k):
                if h.id not in seen:
                    out.append(ScoredChunk(h.chunk, h.score * 0.5, {**h.signals, "fallback": 1.0}, f"{self.name}:{action}"))
        out.sort(key=lambda s: (-s.score, s.id))
        return out[:k]


# --------------------------------------------------------------------------
# Suficiência
# --------------------------------------------------------------------------


@dataclass(slots=True)
class Sufficiency:
    sufficient: bool
    score: float
    reason: str
    missing: list[str] = field(default_factory=list)


class SufficiencyGate:
    """`assess(query, chunks)`: o contexto basta? Offline: cobertura de termos e entidades."""

    def __init__(self, *, provider: Provider | None = None, threshold: float = 0.6, usage: LLMUsage | None = None) -> None:
        self.provider = provider
        self.threshold = threshold
        self.usage = usage or LLMUsage()

    def assess(self, query: str, chunks: Sequence[ScoredChunk]) -> Sufficiency:
        if not chunks:
            return Sufficiency(False, 0.0, "sem contexto")
        if self.provider is not None:
            ctx = "\n\n".join(c.text[:800] for c in chunks[:8])
            text = ask(self.provider, "O contexto contém informação suficiente para responder à pergunta? Responda apenas 'sim' ou 'não'.", f"Pergunta: {query}\n\nContexto:\n{ctx}", usage=self.usage, max_tokens=4).strip().lower()
            ok = text.startswith("sim") or text.startswith("yes")
            return Sufficiency(ok, 1.0 if ok else 0.0, "modelo")
        q_terms = set(content_words(query))
        ents = {e.lower() for e in named_spans(query)}
        text = " ".join(c.text for c in chunks).lower()
        covered = {t for t in q_terms if t in set(content_words(text))}
        ents_ok = {e for e in ents if e in text}
        term_cov = len(covered) / len(q_terms) if q_terms else 1.0
        ent_cov = len(ents_ok) / len(ents) if ents else 1.0
        score = 0.6 * term_cov + 0.4 * ent_cov
        missing = sorted((q_terms - covered) | (ents - ents_ok))
        return Sufficiency(score >= self.threshold, score, "cobertura", missing)


# --------------------------------------------------------------------------
# Iterativo (IRCoT / Search-R1)
# --------------------------------------------------------------------------


class IterativeRetriever:
    name = "iterative"

    def __init__(
        self,
        retriever: Retriever,
        *,
        provider: Provider | None = None,
        max_rounds: int = 3,
        per_round: int = 5,
        usage: LLMUsage | None = None,
    ) -> None:
        self.retriever = retriever
        self.provider = provider
        self.max_rounds = max_rounds
        self.per_round = per_round
        self.usage = usage or LLMUsage()
        self.rounds: list[dict[str, Any]] = []

    def _next_query(self, query: str, evidence: Sequence[ScoredChunk], asked: Sequence[str]) -> str | None:
        if self.provider is not None:
            ctx = "\n".join(f"- {c.text[:300]}" for c in evidence[:8])
            text = ask(
                self.provider,
                'Você conduz uma busca em etapas. Dada a pergunta e a evidência já recuperada, responda com JSON: {"action":"search","query":"..."} para buscar mais (uma consulta focada no que falta) ou {"action":"answer"} se a evidência basta.',
                f"Pergunta: {query}\n\nEvidência:\n{ctx}\n\nConsultas já feitas: {list(asked)}",
                usage=self.usage,
                max_tokens=120,
            )
            try:
                start = text.index("{")
                data = json.loads(text[start : text.rindex("}") + 1])
            except (ValueError, json.JSONDecodeError):
                return None
            if data.get("action") == "search" and data.get("query"):
                q = str(data["query"]).strip()
                return q if q and q not in asked else None
            return None
        # heurística de ponte: entidades novas na evidência que a consulta não menciona
        known = {e.lower() for e in named_spans(query)} | set(content_words(query))
        cands: list[str] = []
        for c in evidence:
            for e in named_spans(c.text):
                if e.lower() not in known and e not in cands:
                    cands.append(e)
        for e in cands:
            q = f"{e} {query}"
            if q not in asked:
                return q
        return None

    def retrieve(self, query: str, k: int = 10) -> list[ScoredChunk]:
        self.rounds = []
        asked = [query]
        evidence: dict[str, ScoredChunk] = {}
        q: str | None = query
        for r in range(self.max_rounds):
            if q is None:
                break
            hits = self.retriever.retrieve(q, self.per_round)
            new = 0
            for h in hits:
                if h.id not in evidence:
                    evidence[h.id] = ScoredChunk(h.chunk, h.score / (1 + 0.5 * r), {**h.signals, "round": float(r)}, self.name)
                    new += 1
            self.rounds.append({"round": r, "query": q, "new": new})
            if new == 0 and r > 0:
                break
            q = self._next_query(query, list(evidence.values()), asked)
            if q is not None:
                asked.append(q)
        out = sorted(evidence.values(), key=lambda s: (-s.score, s.id))
        return out[:k]


def self_route(query: str, docs: Sequence[Document], *, budget_tokens: int, pipeline: RAGPipeline, k: int = 8) -> tuple[str, list[ScoredChunk]]:
    """Self-Route: contexto longo quando cabe, RAG quando não. Devolve (rota, trechos)."""
    total = sum(estimate_tokens(d.text) for d in docs)
    if total <= budget_tokens:
        chunks = [ScoredChunk(Chunk(d.id, 0, d.text, 0, len(d.text), dict(d.metadata)), 1.0, {"route": 0.0}, "long_context") for d in docs]
        return "long_context", chunks
    return "rag", pipeline.retrieve(query, k)




