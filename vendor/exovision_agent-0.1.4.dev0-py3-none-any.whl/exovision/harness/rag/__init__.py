"""exovision.harness.rag — recuperação aumentada: vetores, esparso, grafo, e os laços em volta.

Metade padrões de indústria, metade fronteira experimental, todos medidos:

| camada | indústria | experimental |
|---|---|---|
| embeddings | `FastEmbedEmbedder` (bge/e5 ONNX), `OpenAIEmbedder`, `VoyageEmbedder`, `SentenceTransformersEmbedder` | `Model2VecEmbedder` (estático destilado), embeddings por token |
| segmentação | `FixedChunker`, `RecursiveChunker`, `SentenceChunker`, `ContextualChunker` | `SemanticChunker`, `LateChunker` |
| índice | `FlatIndex`, `HNSWIndex`, `IVFIndex`, `ScalarQuantizer`, `BinaryQuantizer`, `ProductQuantizer` | `MatryoshkaIndex`, `MultiVectorIndex` (ColBERT) |
| esparso e fusão | BM25 (`BM25Encoder` + `InvertedIndex`), RRF, CombSUM, convexa, DBSF | SPLADE via `FastEmbedSparse`, doc2query (`DocExpander`) |
| reranking | `FastEmbedCrossEncoder`, `SentenceTransformersCrossEncoder`, `LLMReranker` | `lost_in_the_middle` |
| consulta | `HyDE`, `MultiQuery` | `StepBack`, `Decompose`, `AdaptiveRouter` |
| grafo | `GraphRAG` (Leiden + relatórios; local/global) | `LightRAG`, `HippoRAG2`, `PathRAG` |
| laços | `RAGPipeline` (híbrido + rerank) | `CorrectiveRAG`, `SufficiencyGate`, `IterativeRetriever`, `self_route` |
| harness | `RAGToolset`, `RAGMemoryPort` | — |

O estudo, a bibliografia e a tabela afirmação -> teste estão em
`docs/rag.tex`, `docs/rag.bib` e `docs/rag-estudo.md`; os números medidos
em `docs/rag/resultados/`.
"""

from .chunking import (
    Chunk,
    ContextualChunker,
    FixedChunker,
    LateChunker,
    RecursiveChunker,
    SemanticChunker,
    SentenceChunker,
)
from .embed import (
    CachedEmbedder,
    FastEmbedColBERT,
    FastEmbedEmbedder,
    HashingTokenEmbedder,
    Model2VecEmbedder,
    OllamaEmbedder,
    OpenAIEmbedder,
    SentenceTransformersEmbedder,
    VoyageEmbedder,
    calibrate_noise_floor,
    load_embedder,
)
from .fusion import combmnz, combsum, convex, dbsf, rrf, weighted_rrf
from .graph import GraphEngine, GraphRAG, HippoRAG2, LightRAG, PathRAG
from .index import (
    BinaryQuantizer,
    FlatIndex,
    HNSWIndex,
    IVFIndex,
    MatryoshkaIndex,
    MultiVectorIndex,
    ProductQuantizer,
    QuantizedIndex,
    ScalarQuantizer,
)
from .pipeline import (
    Context,
    CorrectiveRAG,
    IterativeRetriever,
    RAGPipeline,
    SufficiencyGate,
    self_route,
)
from .query import AdaptiveRouter, Decompose, HyDE, MultiQuery, StepBack
from .rerank import (
    FastEmbedCrossEncoder,
    LexicalReranker,
    LLMReranker,
    SentenceTransformersCrossEncoder,
    lost_in_the_middle,
)
from .sparse import BM25Encoder, DocExpander, FastEmbedSparse, InvertedIndex
from .tool import RAGMemoryPort, RAGToolset
from .types import ChunkStore, Document, Retriever, ScoredChunk
from .vectordb import Collection, Filter

__all__ = [
    "AdaptiveRouter",
    "BM25Encoder",
    "BinaryQuantizer",
    "CachedEmbedder",
    "Chunk",
    "ChunkStore",
    "Collection",
    "Context",
    "ContextualChunker",
    "CorrectiveRAG",
    "Decompose",
    "DocExpander",
    "Document",
    "FastEmbedColBERT",
    "FastEmbedCrossEncoder",
    "FastEmbedEmbedder",
    "FastEmbedSparse",
    "Filter",
    "FixedChunker",
    "FlatIndex",
    "GraphEngine",
    "GraphRAG",
    "HNSWIndex",
    "HashingTokenEmbedder",
    "HippoRAG2",
    "HyDE",
    "IVFIndex",
    "InvertedIndex",
    "IterativeRetriever",
    "LLMReranker",
    "LateChunker",
    "LexicalReranker",
    "LightRAG",
    "MatryoshkaIndex",
    "Model2VecEmbedder",
    "MultiQuery",
    "MultiVectorIndex",
    "OllamaEmbedder",
    "OpenAIEmbedder",
    "PathRAG",
    "ProductQuantizer",
    "QuantizedIndex",
    "RAGMemoryPort",
    "RAGPipeline",
    "RAGToolset",
    "RecursiveChunker",
    "Retriever",
    "ScalarQuantizer",
    "ScoredChunk",
    "SemanticChunker",
    "SentenceChunker",
    "SentenceTransformersCrossEncoder",
    "SentenceTransformersEmbedder",
    "StepBack",
    "SufficiencyGate",
    "VoyageEmbedder",
    "calibrate_noise_floor",
    "combmnz",
    "combsum",
    "convex",
    "dbsf",
    "load_embedder",
    "lost_in_the_middle",
    "rrf",
    "self_route",
    "weighted_rrf",
]
