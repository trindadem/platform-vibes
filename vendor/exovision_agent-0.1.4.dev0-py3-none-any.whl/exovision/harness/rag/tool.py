"""RAG dentro do harness: como ferramenta e como porta de memória.

Duas maneiras de um agente usar o corpus, e elas não competem:

* **`RAGToolset`** — o *modelo* decide quando e o que buscar. Três
  ferramentas com interfaces de granularidade crescente, como o A-RAG
  (Lin et al., 2026, arXiv:2602.03442) mostra ser o desenho que escala com
  a capacidade do modelo: `keyword_search` (BM25, exato), `semantic_search`
  (denso+esparso fundido) e `read_chunk` (o trecho inteiro e os vizinhos
  no documento). `graph_search` entra quando há um método de grafo.
  Todas são `read` e paralelizáveis; a política do harness não precisa
  de caso especial.
* **`RAGMemoryPort`** — o *harness* injeta contexto antes da primeira
  volta, pela mesma porta que a memória usa (`recall` -> `<memory>` na
  primeira mensagem). Os trechos chegam como `OBSERVED` com a URI do
  documento na proveniência: corpus ingerido pelo operador é mais confiável
  que resultado de ferramenta, e menos que o que o usuário afirma.
"""

from __future__ import annotations

from typing import Any

from ..memory.bridge import Recall
from ..memory.core.base import Retrieved
from ..memory.core.record import MemoryRecord, Provenance
from ..memory.core.types import MemoryKind, ProvenanceKind, TrustTier
from ..tools import Registry, ToolResult
from .pipeline import RAGPipeline
from .types import ScoredChunk

__all__ = ["RAGMemoryPort", "RAGToolset"]


def _render(items: list[ScoredChunk], *, snippet_chars: int) -> str:
    if not items:
        return "Nenhum trecho encontrado."
    lines = []
    for it in items:
        snippet = it.text if len(it.text) <= snippet_chars else it.text[:snippet_chars] + "…"
        lines.append(f"[{it.id}] (score {it.score:.3f}, doc {it.doc_id}) {snippet}")
    return "\n".join(lines)


class RAGToolset:
    """`Toolset` do harness sobre um `RAGPipeline` (e, opcionalmente, um método de grafo)."""

    def __init__(
        self,
        pipeline: RAGPipeline,
        *,
        graph: Any | None = None,
        k: int = 5,
        snippet_chars: int = 400,
        neighbors: int = 1,
    ) -> None:
        self.pipeline = pipeline
        self.graph = graph
        self.k = k
        self.snippet_chars = snippet_chars
        self.neighbors = neighbors
        self.calls: list[tuple[str, dict[str, Any]]] = []
        self._reg = Registry()
        default_k = k

        @self._reg.tool(parallel_safe=True, risk="read")
        def semantic_search(query: str, k: int = default_k) -> ToolResult:
            """Busca híbrida (semântica + palavras-chave) no corpus indexado.

            Args:
                query: a pergunta ou descrição do que procurar
                k: número de trechos
            """
            items = pipeline.retrieve(query, k)
            return ToolResult(_render(items, snippet_chars=snippet_chars), metadata={"ids": [i.id for i in items], "k": k})

        @self._reg.tool(parallel_safe=True, risk="read")
        def keyword_search(query: str, k: int = default_k) -> ToolResult:
            """Busca exata por palavras-chave (BM25): identificadores, nomes, códigos.

            Args:
                query: termos a casar literalmente
                k: número de trechos
            """
            if pipeline.collection._inverted is None:
                return ToolResult.error("coleção sem índice de palavras-chave", code=422)
            hits = pipeline.collection.query_text(query, k)
            items = []
            for i, s in hits:
                ch = pipeline.store.get(i)
                if ch is not None:
                    items.append(ScoredChunk(ch, s, {"sparse": s}, "keyword"))
            return ToolResult(_render(items, snippet_chars=snippet_chars), metadata={"ids": [i.id for i in items]})

        @self._reg.tool(parallel_safe=True, risk="read")
        def read_chunk(chunk_id: str) -> ToolResult:
            """Lê um trecho inteiro pelo id (como aparece nos resultados) e os trechos vizinhos no documento.

            Args:
                chunk_id: id no formato `doc#n`
            """
            ch = pipeline.store.get(chunk_id)
            if ch is None:
                return ToolResult.error(f"trecho desconhecido: {chunk_id!r}", code=404)
            siblings = pipeline.store.of_doc(ch.doc_id)
            lo, hi = ch.index - self.neighbors, ch.index + self.neighbors
            parts = [f"[{s.id}]{' <<' if s.id == ch.id else ''} {s.text}" for s in siblings if lo <= s.index <= hi]
            return ToolResult("\n\n".join(parts), metadata={"doc_id": ch.doc_id, "index": ch.index, "start": ch.start, "end": ch.end})

        if graph is not None:

            @self._reg.tool(parallel_safe=True, risk="read")
            def graph_search(query: str) -> ToolResult:
                """Consulta o grafo de conhecimento do corpus: entidades, relações e caminhos entre elas.

                Args:
                    query: a pergunta, idealmente nomeando as entidades envolvidas
                """
                fn = getattr(graph, "context", None) or getattr(graph, "local_context", None)
                if callable(fn):
                    return ToolResult(str(fn(query)))
                items = graph.retrieve(query, default_k)
                return ToolResult(_render(items, snippet_chars=snippet_chars))

    def definitions(self) -> list[dict[str, Any]]:
        return self._reg.definitions()

    def parallel_safe(self, name: str) -> bool:
        return self._reg.parallel_safe(name)

    def risk(self, name: str) -> str:
        return self._reg.risk(name)

    def __call__(self, name: str, arguments: dict[str, Any]) -> ToolResult:
        self.calls.append((name, dict(arguments)))
        return self._reg(name, arguments)

    def __len__(self) -> int:
        return len(self._reg)


class RAGMemoryPort:
    """`MemoryPort` que injeta trechos do corpus no contexto inicial."""

    def __init__(self, pipeline: RAGPipeline, *, k: int = 6, budget_tokens: int = 1500, order: str = "relevance") -> None:
        self.pipeline = pipeline
        self.k = k
        self.budget_tokens = budget_tokens
        self.order = order
        self.last: Recall = Recall()

    def recall(self, text: str, *, session: str = "", actor: str = "") -> Recall:
        ctx = self.pipeline.context(text, k=self.k, budget_tokens=self.budget_tokens, order=self.order)
        items = [
            Retrieved(
                record=MemoryRecord(
                    content=it.text,
                    kind=MemoryKind.VECTOR,
                    id=it.id,
                    trust=TrustTier.OBSERVED,
                    provenance=Provenance(kind=ProvenanceKind.ENVIRONMENT, source_id=it.id, uri=f"doc:{it.doc_id}"),
                    payload={"doc_id": it.doc_id, "signals": it.signals},
                ),
                score=it.score,
                subsystem="rag",
                rationale=dict(it.signals),
            )
            for it in ctx.items
        ]
        header = "Trechos do corpus (cite pelo id entre colchetes):\n" if items else ""
        self.last = Recall(text=(header + ctx.text) if items else "", items=items, tokens=ctx.tokens, dropped=ctx.dropped, per_subsystem={"rag": len(items)})
        return self.last

    def observe(self, kind: str, content: str, *, session: str = "", turn: int = 0, **detail: Any) -> None:
        return None

    def commit(self) -> dict[str, Any]:
        return {"rag": self.pipeline.stats()}


