"""Fusão de rankings e de scores.

Denso e esparso erram em lugares diferentes — o embedding pega paráfrase e
dilui identificadores; o BM25 pega o identificador exato e ignora a
paráfrase. A fusão dos dois é o padrão de produção (Elastic, Weaviate, Qdrant
e Pinecone expõem "hybrid search"), e há quatro maneiras de fazê-la:

* **RRF** (Cormack, Clarke & Buettcher, 2009): só usa a *posição*;
  `1/(k + rank)`. Indiferente à escala dos scores, por isso robusta; `k=60`
  é o valor do artigo e o padrão em todo lugar. `weighted_rrf` pondera as
  listas — Van Dongen (2025) mediu que a ponderação por validação cruzada é o
  que faz embeddings estáticos renderem em híbrido.
* **CombSUM / CombMNZ** (Fox & Shaw, 1994): soma scores *normalizados*
  (min-max ou z-score); MNZ multiplica pelo número de listas em que o item
  aparece. Usa a magnitude, e por isso ganha quando os scores são calibrados
  e perde quando não são.
* **Convexa** (`alpha * denso + (1-alpha) * esparso`): o "alpha" do Weaviate
  e do Pinecone; Bruch et al. (2023) mostraram que, com normalização
  adequada, a combinação convexa é competitiva com RRF e mais afinável.
* **DBSF** (*distribution-based score fusion*): normaliza cada lista por
  `media +- 3 sigma` em vez de min-max — imune a um único score extremo.

Todos devolvem `[(id, score)]` em ordem decrescente e determinística
(desempate por id).
"""

from __future__ import annotations

import math
from collections import defaultdict
from collections.abc import Mapping, Sequence

from ..memory.core.similarity import reciprocal_rank_fusion

__all__ = [
    "combmnz",
    "combsum",
    "convex",
    "dbsf",
    "normalize_scores",
    "rrf",
    "weighted_rrf",
]

Ranked = list[tuple[str, float]]


def rrf(rankings: Sequence[Sequence[str]], *, k: float = 60.0) -> Ranked:
    return reciprocal_rank_fusion(rankings, k=k)


def weighted_rrf(rankings: Sequence[Sequence[str]], weights: Sequence[float], *, k: float = 60.0) -> Ranked:
    return reciprocal_rank_fusion(rankings, k=k, weights=list(weights))


def normalize_scores(scores: Mapping[str, float], method: str = "minmax") -> dict[str, float]:
    """`minmax` -> [0,1]; `zscore` -> (x-mu)/sigma; `dbsf` -> [mu-3s, mu+3s] em [0,1]; `none`."""
    if not scores:
        return {}
    vals = list(scores.values())
    if method == "none":
        return dict(scores)
    if method == "minmax":
        lo, hi = min(vals), max(vals)
        if hi - lo < 1e-12:
            return {k: 1.0 for k in scores}
        return {k: (v - lo) / (hi - lo) for k, v in scores.items()}
    mu = sum(vals) / len(vals)
    var = sum((v - mu) ** 2 for v in vals) / len(vals)
    sd = math.sqrt(var)
    if method == "zscore":
        if sd < 1e-12:
            return {k: 0.0 for k in scores}
        return {k: (v - mu) / sd for k, v in scores.items()}
    if method == "dbsf":
        lo, hi = mu - 3 * sd, mu + 3 * sd
        if hi - lo < 1e-12:
            return {k: 1.0 for k in scores}
        return {k: min(1.0, max(0.0, (v - lo) / (hi - lo))) for k, v in scores.items()}
    raise ValueError(f"normalização desconhecida: {method!r}")


def _sorted(fused: Mapping[str, float]) -> Ranked:
    return sorted(fused.items(), key=lambda kv: (-kv[1], kv[0]))


def combsum(
    score_lists: Sequence[Mapping[str, float]],
    *,
    norm: str = "minmax",
    weights: Sequence[float] | None = None,
) -> Ranked:
    if weights is None:
        weights = [1.0] * len(score_lists)
    if len(weights) != len(score_lists):
        raise ValueError("weights e score_lists com tamanhos diferentes")
    fused: dict[str, float] = defaultdict(float)
    for scores, w in zip(score_lists, weights, strict=True):
        for k, v in normalize_scores(scores, norm).items():
            fused[k] += w * v
    return _sorted(fused)


def combmnz(score_lists: Sequence[Mapping[str, float]], *, norm: str = "minmax") -> Ranked:
    fused: dict[str, float] = defaultdict(float)
    hits: dict[str, int] = defaultdict(int)
    for scores in score_lists:
        for k, v in normalize_scores(scores, norm).items():
            fused[k] += v
            hits[k] += 1
    return _sorted({k: v * hits[k] for k, v in fused.items()})


def dbsf(score_lists: Sequence[Mapping[str, float]], *, weights: Sequence[float] | None = None) -> Ranked:
    return combsum(score_lists, norm="dbsf", weights=weights)


def convex(
    dense: Mapping[str, float], sparse: Mapping[str, float], *, alpha: float = 0.5, norm: str = "minmax"
) -> Ranked:
    """`alpha` em [0,1]: 1 é só denso, 0 é só esparso."""
    if not 0.0 <= alpha <= 1.0:
        raise ValueError("alpha em [0,1]")
    return combsum([dense, sparse], norm=norm, weights=[alpha, 1.0 - alpha])
