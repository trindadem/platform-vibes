"""Tipos comuns do RAG: documento, trecho pontuado, recuperador e o depósito de trechos."""

from __future__ import annotations

from collections.abc import Iterable, Sequence
from dataclasses import dataclass, field
from typing import Any, Protocol, runtime_checkable

from .chunking import Chunk

__all__ = ["ChunkStore", "Document", "Retriever", "ScoredChunk"]


@dataclass(slots=True)
class Document:
    id: str
    text: str
    metadata: dict[str, Any] = field(default_factory=dict)


@dataclass(slots=True)
class ScoredChunk:
    """Um trecho recuperado com o score final e a decomposição por sinal.

    `signals` é a justificativa (`{"dense": .., "sparse": .., "ppr": ..}`);
    `via` diz qual recuperador o produziu. Sem isso, a pergunta de auditoria
    "por que este trecho entrou no contexto?" não tem resposta.
    """

    chunk: Chunk
    score: float
    signals: dict[str, float] = field(default_factory=dict)
    via: str = ""

    @property
    def id(self) -> str:
        return self.chunk.id

    @property
    def text(self) -> str:
        return self.chunk.text

    @property
    def doc_id(self) -> str:
        return self.chunk.doc_id


@runtime_checkable
class Retriever(Protocol):
    name: str

    def retrieve(self, query: str, k: int = 10) -> list[ScoredChunk]: ...


class ChunkStore:
    """Trechos por id e por documento. Os recuperadores de grafo leem daqui."""

    def __init__(self, chunks: Iterable[Chunk] = ()) -> None:
        self._by_id: dict[str, Chunk] = {}
        self._by_doc: dict[str, list[str]] = {}
        self.add(chunks)

    def add(self, chunks: Iterable[Chunk]) -> None:
        for c in chunks:
            self._by_id[c.id] = c
            self._by_doc.setdefault(c.doc_id, [])
            if c.id not in self._by_doc[c.doc_id]:
                self._by_doc[c.doc_id].append(c.id)

    def remove_doc(self, doc_id: str) -> list[str]:
        ids = self._by_doc.pop(doc_id, [])
        for i in ids:
            self._by_id.pop(i, None)
        return ids

    def get(self, chunk_id: str) -> Chunk | None:
        return self._by_id.get(chunk_id)

    def get_many(self, ids: Sequence[str]) -> list[Chunk]:
        return [self._by_id[i] for i in ids if i in self._by_id]

    def of_doc(self, doc_id: str) -> list[Chunk]:
        return [self._by_id[i] for i in self._by_doc.get(doc_id, ())]

    def __len__(self) -> int:
        return len(self._by_id)

    def __contains__(self, chunk_id: str) -> bool:
        return chunk_id in self._by_id

    def __iter__(self):
        return iter(self._by_id.values())

    def ids(self) -> list[str]:
        return list(self._by_id)
