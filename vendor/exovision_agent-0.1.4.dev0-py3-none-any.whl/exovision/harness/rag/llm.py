"""Uma chamada de texto ao modelo, para os passos de RAG que precisam dele.

HyDE, multi-consulta, reranking listwise, avaliação corretiva e
contextualização de trecho são chamadas *de uma volta, sem ferramenta*. Elas
vivem hoje em `exovision.harness.models.engine` — as primitivas cognitivas do
kernel —; este módulo reexporta o que o RAG usa, para que `rag.*` continue
lendo como antes.
"""

from __future__ import annotations

from ..models.engine import LLMUsage, ask, parse_json_list, parse_ranking

__all__ = ["LLMUsage", "ask", "parse_json_list", "parse_ranking"]
