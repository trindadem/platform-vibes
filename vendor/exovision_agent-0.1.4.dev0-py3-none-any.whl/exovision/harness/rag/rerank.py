"""Reordenação: o segundo estágio.

Recuperar é barato e largo; reordenar é caro e estreito. O *two-stage
retrieval* (Nogueira & Cho, 2019, monoBERT) é o padrão de produção porque
um cross-encoder vê consulta e documento juntos e mede interação que o
bi-encoder não consegue — no BEIR, BM25 + cross-encoder é a melhor
configuração zero-shot (Thakur et al., 2021), e a Anthropic mediu -67% de
falhas de recuperação com reranking sobre a recuperação contextual.

| reranker | regime | o que é |
|---|---|---|
| `LexicalReranker` | linha de base | cobertura de termos e n-gramas; determinístico, sem modelo |
| `FastEmbedCrossEncoder` | indústria | `ms-marco-MiniLM-L-6-v2` em ONNX (o cross-encoder mais usado) |
| `SentenceTransformersCrossEncoder` | indústria | qualquer cross-encoder do Hub (bge-reranker, mxbai) |
| `LLMReranker` | indústria/experimental | listwise (RankGPT, Sun et al., 2023): o modelo devolve uma permutação; janela deslizante para listas longas |
| `lost_in_the_middle` | experimental | reordena o contexto final: os melhores nas pontas (Liu et al., 2023) |

Todo reranker devolve `[(índice, score)]` decrescente sobre a lista de
entrada — o pipeline não precisa saber qual é.
"""

from __future__ import annotations

from collections.abc import Sequence
from typing import Any, Protocol, runtime_checkable

from ..memory.core.text import char_ngrams, content_words
from ..models.provider import Provider
from .llm import LLMUsage, ask, parse_ranking

__all__ = [
    "FastEmbedCrossEncoder",
    "LLMReranker",
    "LexicalReranker",
    "Reranker",
    "SentenceTransformersCrossEncoder",
    "lost_in_the_middle",
]

Ranked = list[tuple[int, float]]


@runtime_checkable
class Reranker(Protocol):
    def rerank(self, query: str, docs: Sequence[str], *, top_k: int | None = None) -> Ranked: ...


def _sort(scores: Sequence[float], top_k: int | None) -> Ranked:
    order = sorted(range(len(scores)), key=lambda i: (-scores[i], i))
    if top_k is not None:
        order = order[:top_k]
    return [(i, float(scores[i])) for i in order]


class LexicalReranker:
    """Cobertura dos termos da consulta + sobreposição de trigramas de caractere."""

    def __init__(self, *, ngram_weight: float = 0.3) -> None:
        self.ngram_weight = ngram_weight

    def rerank(self, query: str, docs: Sequence[str], *, top_k: int | None = None) -> Ranked:
        q_terms = set(content_words(query))
        q_grams = set(char_ngrams(query, 3, 3))
        scores: list[float] = []
        for d in docs:
            terms = set(content_words(d))
            cov = len(q_terms & terms) / len(q_terms) if q_terms else 0.0
            grams = set(char_ngrams(d, 3, 3))
            ov = len(q_grams & grams) / len(q_grams) if q_grams else 0.0
            scores.append(cov + self.ngram_weight * ov)
        return _sort(scores, top_k)


class FastEmbedCrossEncoder:
    def __init__(self, model: str = "Xenova/ms-marco-MiniLM-L-6-v2") -> None:
        from fastembed.rerank.cross_encoder import (
            TextCrossEncoder,
        )

        self.model_name = model
        self._model = TextCrossEncoder(model)

    def rerank(self, query: str, docs: Sequence[str], *, top_k: int | None = None) -> Ranked:
        if not docs:
            return []
        scores = [float(s) for s in self._model.rerank(query, list(docs))]
        return _sort(scores, top_k)


class SentenceTransformersCrossEncoder:
    def __init__(self, model: str = "cross-encoder/ms-marco-MiniLM-L-6-v2", *, device: str | None = None) -> None:
        from sentence_transformers import CrossEncoder

        self.model_name = model
        self._model = CrossEncoder(model, device=device)

    def rerank(self, query: str, docs: Sequence[str], *, top_k: int | None = None) -> Ranked:
        if not docs:
            return []
        scores = [float(s) for s in self._model.predict([(query, d) for d in docs])]
        return _sort(scores, top_k)


_LISTWISE_SYSTEM = (
    "Você é um reordenador de passagens. Receberá uma consulta e passagens numeradas. "
    "Responda SOMENTE com a ordem de relevância, da mais para a menos relevante, no formato "
    "[3] > [1] > [2], incluindo todos os números."
)
_POINTWISE_SYSTEM = (
    "Você avalia se uma passagem responde a uma consulta. Responda com um número de 0 a 10 "
    "e nada mais: 10 se responde diretamente, 0 se é irrelevante."
)


class LLMReranker:
    """RankGPT listwise (janela deslizante) ou pointwise (nota 0-10 por passagem).

    Listwise custa uma chamada por janela e produz uma permutação; pointwise
    custa uma chamada por passagem e produz um score comparável entre
    consultas — útil para abstenção. `usage` acumula o gasto.
    """

    def __init__(
        self,
        provider: Provider,
        *,
        mode: str = "listwise",
        window: int = 20,
        step: int = 10,
        max_chars: int = 600,
        usage: LLMUsage | None = None,
    ) -> None:
        if mode not in ("listwise", "pointwise"):
            raise ValueError("mode: listwise | pointwise")
        self.provider = provider
        self.mode = mode
        self.window = window
        self.step = step
        self.max_chars = max_chars
        self.usage = usage or LLMUsage()

    def _listwise_window(self, query: str, docs: Sequence[str]) -> list[int]:
        body = "\n\n".join(f"[{i + 1}] {d[: self.max_chars]}" for i, d in enumerate(docs))
        text = ask(self.provider, _LISTWISE_SYSTEM, f"Consulta: {query}\n\nPassagens:\n{body}\n\nOrdem:", usage=self.usage, max_tokens=256)
        return parse_ranking(text, len(docs))

    def rerank(self, query: str, docs: Sequence[str], *, top_k: int | None = None) -> Ranked:
        n = len(docs)
        if n == 0:
            return []
        if self.mode == "pointwise":
            scores: list[float] = []
            for d in docs:
                text = ask(self.provider, _POINTWISE_SYSTEM, f"Consulta: {query}\n\nPassagem: {d[: self.max_chars]}\n\nNota:", usage=self.usage, max_tokens=8)
                digits = "".join(ch for ch in text if ch.isdigit() or ch == ".")
                try:
                    scores.append(min(10.0, max(0.0, float(digits))) / 10.0)
                except ValueError:
                    scores.append(0.0)
            return _sort(scores, top_k)
        # listwise com janela deslizante de trás para frente (RankGPT)
        order = list(range(n))
        if n <= self.window:
            perm = self._listwise_window(query, docs)
            order = perm
        else:
            end = n
            while end > 0:
                start = max(0, end - self.window)
                seg = order[start:end]
                perm = self._listwise_window(query, [docs[i] for i in seg])
                order[start:end] = [seg[p] for p in perm]
                if start == 0:
                    break
                end -= self.step
        scores_l = [0.0] * n
        for rank, i in enumerate(order):
            scores_l[i] = 1.0 - rank / max(n, 1)
        return _sort(scores_l, top_k)


def lost_in_the_middle(items: Sequence[Any]) -> list[Any]:
    """Melhores nas pontas, piores no meio (LongContextReorder).

    Liu et al. (2023) mediram uma curva em U: o modelo usa melhor o que está
    no início e no fim do contexto. `items` chega em ordem decrescente de
    relevância; sai como [1, 3, 5, ..., 6, 4, 2].
    """
    left: list[Any] = []
    right: list[Any] = []
    for i, it in enumerate(items):
        (left if i % 2 == 0 else right).append(it)
    return left + right[::-1]
