"""Transformação de consulta e roteamento adaptativo.

A consulta do usuário raramente é a melhor consulta para o índice. Quatro
transformações com modelo e um roteador:

| técnica | regime | o que faz |
|---|---|---|
| `HyDE` (Gao et al., 2022) | indústria | gera uma resposta hipotética e embute *ela*: documento casa com documento melhor que pergunta casa com documento |
| `MultiQuery` + RAG-Fusion (Rackauckas, 2024) | indústria | n reformulações; os rankings se fundem por RRF |
| `StepBack` (Zheng et al., 2023) | experimental | uma pergunta mais abstrata que a original, para trazer o princípio antes do detalhe |
| `Decompose` (least-to-most, Zhou et al., 2023) | experimental | sub-perguntas para consultas compostas |
| `AdaptiveRouter` (Adaptive-RAG, Jeong et al., 2024) | experimental | classifica a complexidade: sem recuperação / um passo / iterativo |

O roteador tem um classificador **offline** (comprimento, entidades,
conjunções, comparativos) e aceita um `Provider` para classificar com
modelo. O offline existe para que o roteamento seja testável e para que
consulta trivial não pague uma chamada só para descobrir que é trivial.
"""

from __future__ import annotations

import re
from collections.abc import Sequence
from dataclasses import dataclass, field
from typing import Protocol, runtime_checkable

from ..memory.core.embeddings import Embedder
from ..memory.core.text import content_words
from ..models.provider import Provider
from .embed import encode_query, l2_normalize
from .llm import LLMUsage, ask, parse_json_list

__all__ = [
    "AdaptiveRouter",
    "Decompose",
    "HyDE",
    "MultiQuery",
    "QueryTransform",
    "Route",
    "StepBack",
]


@runtime_checkable
class QueryTransform(Protocol):
    def transform(self, query: str) -> list[str]: ...


class HyDE:
    """Embedding = média normalizada de (consulta, passagem hipotética).

    A média mantém a consulta como âncora: uma alucinação do modelo não
    substitui a pergunta, só a desloca em direção ao vocabulário da resposta.
    """

    def __init__(self, provider: Provider, embedder: Embedder, *, usage: LLMUsage | None = None, max_tokens: int = 300) -> None:
        self.provider = provider
        self.embedder = embedder
        self.usage = usage or LLMUsage()
        self.max_tokens = max_tokens

    def hypothetical(self, query: str) -> str:
        return ask(
            self.provider,
            "Escreva uma passagem curta e plausível que responderia à pergunta, no estilo de um documento de referência. Sem preâmbulo.",
            query,
            usage=self.usage,
            max_tokens=self.max_tokens,
        ).strip()

    def transform(self, query: str) -> list[str]:
        h = self.hypothetical(query)
        return [query, h] if h else [query]

    def encode(self, query: str) -> tuple[float, ...]:
        qv = encode_query(self.embedder, query)
        h = self.hypothetical(query)
        if not h:
            return qv
        hv = self.embedder.encode(h)
        return l2_normalize([a + b for a, b in zip(qv, hv, strict=True)])


class MultiQuery:
    def __init__(self, provider: Provider, *, n: int = 3, usage: LLMUsage | None = None) -> None:
        self.provider = provider
        self.n = n
        self.usage = usage or LLMUsage()

    def transform(self, query: str) -> list[str]:
        text = ask(
            self.provider,
            f"Gere {self.n} reformulações diferentes da pergunta, cobrindo vocabulários alternativos. Responda com uma lista JSON de strings.",
            query,
            usage=self.usage,
            max_tokens=400,
        )
        alts = [q for q in parse_json_list(text) if q.lower() != query.lower()][: self.n]
        return [query, *alts]


class StepBack:
    def __init__(self, provider: Provider, *, usage: LLMUsage | None = None) -> None:
        self.provider = provider
        self.usage = usage or LLMUsage()

    def transform(self, query: str) -> list[str]:
        text = ask(
            self.provider,
            "Escreva uma pergunta mais geral (um passo atrás) cuja resposta ajude a responder à pergunta dada. Responda só com a pergunta.",
            query,
            usage=self.usage,
            max_tokens=120,
        ).strip()
        return [query, text] if text else [query]


class Decompose:
    def __init__(self, provider: Provider, *, max_parts: int = 4, usage: LLMUsage | None = None) -> None:
        self.provider = provider
        self.max_parts = max_parts
        self.usage = usage or LLMUsage()

    def transform(self, query: str) -> list[str]:
        text = ask(
            self.provider,
            f"Decomponha a pergunta em até {self.max_parts} sub-perguntas independentes e simples. Responda com uma lista JSON de strings. Se a pergunta já é simples, devolva uma lista com ela apenas.",
            query,
            usage=self.usage,
            max_tokens=400,
        )
        parts = parse_json_list(text, strict=True)[: self.max_parts]
        return parts or [query]


@dataclass(slots=True)
class Route:
    kind: str  # none | single | multi
    reason: str = ""
    features: dict[str, float] = field(default_factory=dict)


_MULTI_HINTS = re.compile(
    r"\b(e|and|ou|or|comparad[oa]|compare|versus|vs|diferença|difference|antes|depois|before|after|"
    r"ambos|both|qual dos|which of|entre|between|também|also|além|besides)\b",
    re.I,
)
_TRIVIAL = re.compile(r"^\s*(oi|olá|ola|obrigad[oa]|hello|hi|thanks|thank you|bom dia|boa tarde|boa noite)[\s!.?]*$", re.I)
_MATH = re.compile(r"^[\s\d+\-*/^().,%=]+$")


class AdaptiveRouter:
    """`none` (responder do próprio modelo), `single` (uma recuperação) ou `multi` (iterativa).

    Heurística offline: saudação/aritmética -> `none`; conjunções,
    comparativos, mais de uma entidade capitalizada ou pergunta longa ->
    `multi`; o resto -> `single`. Com `provider`, a heurística decide só os
    casos claros e o modelo os ambíguos.
    """

    def __init__(self, provider: Provider | None = None, *, usage: LLMUsage | None = None) -> None:
        self.provider = provider
        self.usage = usage or LLMUsage()

    def features(self, query: str) -> dict[str, float]:
        words = content_words(query)
        # a maiúscula inicial da frase não é entidade
        body = query[:1].lower() + query[1:]
        caps = re.findall(r"\b[A-ZÁÉÍÓÚÂÊÔÃÕÇ][\wáéíóúâêôãõç]+", body)
        return {
            "words": float(len(words)),
            "hints": float(len(_MULTI_HINTS.findall(query))),
            "entities": float(len(set(caps))),
            "questions": float(query.count("?")),
        }

    def route(self, query: str) -> Route:
        q = query.strip()
        f = self.features(q)
        if not q or _TRIVIAL.match(q) or _MATH.match(q):
            return Route("none", "trivial", f)
        score = f["hints"] + max(0.0, f["entities"] - 1) + max(0.0, f["questions"] - 1) + (1.0 if f["words"] > 18 else 0.0)
        if score >= 2:
            return Route("multi", "composta", f)
        if score == 0 and f["words"] <= 12:
            return Route("single", "simples", f)
        if self.provider is None:
            return Route("multi" if score >= 1 else "single", "heuristica", f)
        text = ask(
            self.provider,
            "Classifique a complexidade da pergunta para um sistema de busca. Responda com UMA palavra: none (o modelo responde sozinho), single (uma busca basta) ou multi (exige compor várias buscas).",
            q,
            usage=self.usage,
            max_tokens=5,
        ).strip().lower()
        kind = "multi" if "multi" in text else "none" if "none" in text else "single"
        return Route(kind, "modelo", f)


def run_transforms(transforms: Sequence[QueryTransform], query: str) -> list[str]:
    """Aplica as transformações em sequência e devolve as consultas únicas, a original primeiro."""
    out: list[str] = [query]
    for t in transforms:
        for q in t.transform(query):
            if q and q not in out:
                out.append(q)
    return out
