"""Embedders reais e o protocolo assimétrico de recuperação.

A memória do EXOVISION-I usa `HashingEmbedder` por padrão porque a avaliação
precisa ser reprodutível bit a bit. RAG de produção precisa de um modelo
treinado por contraste (Karpukhin et al., 2020, DPR; Reimers & Gurevych,
2019, Sentence-BERT): o hashing captura sobreposição lexical e morfológica,
nunca sinonímia — "faturamento" e "receita" caem em buckets distintos.

Este módulo traz **cinco famílias**, todas atrás do mesmo protocolo:

| adaptador | onde roda | dependência | quando |
|---|---|---|---|
| `Model2VecEmbedder` | CPU, numpy | `model2vec` (~10 MB) | linha de base *real* e offline: embeddings estáticos destilados de um sentence-transformer (Tulkens & van Dongen, 2024); 500x mais rápido, ~90% do desempenho |
| `FastEmbedEmbedder` | CPU, ONNX | `fastembed` | modelo transformer quantizado sem PyTorch (bge, e5, jina) |
| `SentenceTransformersEmbedder` | CPU/GPU, torch | `sentence-transformers` | qualquer modelo do Hub; expõe embeddings por token (late chunking, ColBERT) |
| `OpenAIEmbedder` / `VoyageEmbedder` | API | nenhuma (urllib) | modelos de fronteira; Matryoshka (`dimensions`) |
| `OllamaEmbedder` | HTTP local | nenhuma | modelo local servido pelo Ollama |

**Assimetria.** Modelos de recuperação distinguem consulta de documento: o
bge-en prefixa a consulta com uma instrução, o e5 usa `query:`/`passage:`, o
Voyage recebe `input_type`. O protocolo `RetrievalEmbedder` acrescenta
`encode_query`/`encode_documents` a `Embedder`; `encode_query(embedder, texto)`
(função) cai em `encode` para embedders simétricos, de modo que a memória e o
RAG continuam aceitando qualquer `Embedder`.

**Piso de ruído.** Todo embedder tem um cosseno típico entre textos sem
relação; abaixo dele, o sinal é indistinguível de acaso. O hashing tem fórmula
(`2.6/sqrt(dim)`); modelos neurais precisam ser **medidos** —
`calibrate_noise_floor` faz isso com pares aleatórios do próprio corpus, e o
valor alimenta a abstenção de recuperação (Joren et al., 2025).
"""

from __future__ import annotations

import contextlib
import json
import math
import os
import random
import urllib.request
from collections.abc import Callable, Sequence
from dataclasses import dataclass
from typing import Any, Protocol, runtime_checkable

from ..memory.core.embeddings import Embedder, HashingEmbedder
from ..memory.core.similarity import cosine
from ..memory.core.text import fold

__all__ = [
    "CachedEmbedder",
    "FastEmbedColBERT",
    "FastEmbedEmbedder",
    "HashingTokenEmbedder",
    "Model2VecEmbedder",
    "NoiseFloor",
    "OllamaEmbedder",
    "OpenAIEmbedder",
    "RetrievalEmbedder",
    "SentenceTransformersEmbedder",
    "TokenEmbedder",
    "TokenEmbeddings",
    "VoyageEmbedder",
    "calibrate_noise_floor",
    "encode_documents",
    "encode_query",
    "fastembed_cache_dir",
    "l2_normalize",
    "load_embedder",
]

try:  # pragma: no cover - caminho opcional
    import numpy as _np

    _HAS_NUMPY = True
except Exception:  # pragma: no cover
    _np = None
    _HAS_NUMPY = False


# --------------------------------------------------------------------------
# Protocolos
# --------------------------------------------------------------------------


@runtime_checkable
class RetrievalEmbedder(Protocol):
    """`Embedder` + assimetria consulta/documento."""

    dim: int

    def encode(self, text: str) -> tuple[float, ...]: ...

    def encode_batch(self, texts: Sequence[str]) -> list[tuple[float, ...]]: ...

    def encode_query(self, text: str) -> tuple[float, ...]: ...

    def encode_documents(self, texts: Sequence[str]) -> list[tuple[float, ...]]: ...


@dataclass(slots=True)
class TokenEmbeddings:
    """Vetores por token, com o intervalo de caracteres que cada token cobre.

    É a matéria-prima do *late chunking* (Günther et al., 2024) e do
    late interaction (Khattab & Zaharia, 2020): o documento inteiro passa pelo
    modelo, e só depois se decide o que agrupar.
    """

    tokens: list[str]
    offsets: list[tuple[int, int]]
    vectors: list[tuple[float, ...]]

    def __len__(self) -> int:
        return len(self.tokens)

    def pool(self, start: int, end: int) -> tuple[float, ...]:
        """Média (normalizada) dos vetores dos tokens contidos em [start, end) chars."""
        acc: list[float] | None = None
        n = 0
        for (a, b), v in zip(self.offsets, self.vectors, strict=True):
            if b <= start or a >= end:
                continue
            if acc is None:
                acc = list(v)
            else:
                for i, x in enumerate(v):
                    acc[i] += x
            n += 1
        if acc is None or n == 0:
            return tuple([0.0] * (len(self.vectors[0]) if self.vectors else 0))
        return l2_normalize(tuple(x / n for x in acc))


@runtime_checkable
class TokenEmbedder(Protocol):
    dim: int

    def encode_tokens(self, text: str) -> TokenEmbeddings: ...


# --------------------------------------------------------------------------
# Utilidades
# --------------------------------------------------------------------------


def l2_normalize(vec: Sequence[float]) -> tuple[float, ...]:
    n = math.sqrt(sum(x * x for x in vec))
    if n < 1e-12:
        return tuple(float(x) for x in vec)
    return tuple(float(x) / n for x in vec)


def encode_query(embedder: Embedder, text: str) -> tuple[float, ...]:
    """Usa o lado *consulta* do embedder quando ele é assimétrico."""
    fn = getattr(embedder, "encode_query", None)
    return fn(text) if callable(fn) else embedder.encode(text)


def encode_documents(embedder: Embedder, texts: Sequence[str]) -> list[tuple[float, ...]]:
    fn = getattr(embedder, "encode_documents", None)
    return fn(texts) if callable(fn) else embedder.encode_batch(texts)


def _rows_to_tuples(rows: Any, *, normalize: bool = True) -> list[tuple[float, ...]]:
    out: list[tuple[float, ...]] = []
    for row in rows:
        v = tuple(float(x) for x in row)
        out.append(l2_normalize(v) if normalize else v)
    return out


@dataclass(slots=True)
class NoiseFloor:
    """Distribuição do cosseno entre pares de textos sem relação."""

    pairs: int
    mean: float
    p50: float
    p90: float
    p99: float
    max: float

    def to_dict(self) -> dict[str, float]:
        return {
            "pairs": self.pairs,
            "mean": self.mean,
            "p50": self.p50,
            "p90": self.p90,
            "p99": self.p99,
            "max": self.max,
        }


def _quantile(sorted_vals: Sequence[float], q: float) -> float:
    if not sorted_vals:
        return 0.0
    pos = q * (len(sorted_vals) - 1)
    lo = math.floor(pos)
    hi = min(lo + 1, len(sorted_vals) - 1)
    frac = pos - lo
    return sorted_vals[lo] * (1 - frac) + sorted_vals[hi] * frac


def calibrate_noise_floor(
    embedder: Embedder, texts: Sequence[str], *, pairs: int = 2000, seed: int = 0
) -> NoiseFloor:
    """p99 do cosseno entre pares aleatórios de `texts`.

    Pares aleatórios de um corpus grande são, com probabilidade esmagadora,
    não relacionados; o p99 é o limiar acima do qual uma similaridade é
    evidência e não ruído. O valor é específico do (embedder, domínio): o
    bge-small mede ~0.5 em abstracts biomédicos porque o espaço é anisotrópico
    (Ethayarajh, 2019), e o hashing mede ~0.1. Comparar cossenos absolutos
    entre embedders é, por isso, um erro; comparar contra o piso de cada um não.
    """
    if len(texts) < 2:
        return NoiseFloor(0, 0.0, 0.0, 0.0, 0.0, 0.0)
    rng = random.Random(seed)
    sample_size = min(len(texts), max(64, int(math.sqrt(pairs) * 4)))
    sample = rng.sample(list(texts), sample_size)
    vecs = embedder.encode_batch(sample)
    sims: list[float] = []
    n = len(sample)
    for _ in range(pairs):
        i = rng.randrange(n)
        j = rng.randrange(n - 1)
        if j >= i:
            j += 1
        sims.append(cosine(vecs[i], vecs[j]))
    sims.sort()
    return NoiseFloor(
        pairs=len(sims),
        mean=sum(sims) / len(sims),
        p50=_quantile(sims, 0.5),
        p90=_quantile(sims, 0.9),
        p99=_quantile(sims, 0.99),
        max=sims[-1],
    )


def fastembed_cache_dir() -> str:
    """`FASTEMBED_CACHE_PATH` ou `~/.cache/fastembed` — o padrão do fastembed é o
    diretório temporário do sistema, que o macOS limpa; modelo baixado precisa ficar."""
    path = os.environ.get("FASTEMBED_CACHE_PATH") or os.path.join(os.path.expanduser("~"), ".cache", "fastembed")
    os.makedirs(path, exist_ok=True)
    return path


class _Cache:
    """Cache texto -> vetor com despejo do mais antigo (ordem de inserção do dict).

    É só um acelerador: `encode_batch` nunca depende do que sobrou aqui para
    montar a resposta — o lote que cruzou o teto voltava zerado quando dependia.
    """

    __slots__ = ("_cap", "_d")

    def __init__(self, cap: int) -> None:
        self._d: dict[str, tuple[float, ...]] = {}
        self._cap = max(0, cap)

    def get(self, k: str) -> tuple[float, ...] | None:
        return self._d.get(k)

    def put(self, k: str, v: tuple[float, ...]) -> None:
        if self._cap == 0:
            return
        if k not in self._d:
            while len(self._d) >= self._cap:
                del self._d[next(iter(self._d))]
        self._d[k] = v

    def __len__(self) -> int:
        return len(self._d)


class _BatchEmbedderBase:
    """Esqueleto: cache por texto, normalização L2, assimetria por prefixo."""

    dim: int
    noise_floor: float = 0.0
    query_prefix: str = ""
    document_prefix: str = ""

    def __init__(self, *, cache_size: int = 8192) -> None:
        self._cache = _Cache(cache_size)

    # subclasses implementam:
    def _embed(self, texts: Sequence[str]) -> list[tuple[float, ...]]:  # pragma: no cover
        raise NotImplementedError

    def encode_batch(self, texts: Sequence[str]) -> list[tuple[float, ...]]:
        # A resposta sai deste dicionário local, não do cache: o cache tem teto
        # e um lote maior que ele (SciFact: 8646 trechos) perdia os primeiros.
        have: dict[str, tuple[float, ...] | None] = {t: self._cache.get(t) for t in dict.fromkeys(texts)}
        missing = [t for t, v in have.items() if v is None]
        if missing:
            for t, v in zip(missing, self._embed(missing), strict=True):
                have[t] = v
                self._cache.put(t, v)
        return [have[t] or tuple([0.0] * self.dim) for t in texts]

    def encode(self, text: str) -> tuple[float, ...]:
        return self.encode_batch([text])[0]

    def encode_query(self, text: str) -> tuple[float, ...]:
        return self.encode(self.query_prefix + text if self.query_prefix else text)

    def encode_documents(self, texts: Sequence[str]) -> list[tuple[float, ...]]:
        if self.document_prefix:
            texts = [self.document_prefix + t for t in texts]
        return self.encode_batch(texts)


# --------------------------------------------------------------------------
# Model2Vec — estático, numpy, offline
# --------------------------------------------------------------------------


class Model2VecEmbedder(_BatchEmbedderBase):
    """Embeddings estáticos destilados (Model2Vec; Tulkens & van Dongen, 2024).

    `potion-multilingual-128M` cobre PT-BR (101 idiomas), tem 256 dimensões e
    codifica ~10 mil sentenças por segundo em CPU: é o modelo *real* que os
    testes e a calibração usam quando está no cache do Hub. Não é
    assimétrico. Medido neste repositório: piso de ruído p99 = ver
    `docs/rag/resultados/noise_floor_model2vec.json`.
    """

    def __init__(
        self,
        model: str = "minishlab/potion-multilingual-128M",
        *,
        noise_floor: float = 0.0,
        cache_size: int = 8192,
    ) -> None:
        super().__init__(cache_size=cache_size)
        from model2vec import StaticModel

        self.model_name = model
        self._model = StaticModel.from_pretrained(model)
        probe = self._model.encode(["probe"])
        self.dim = int(probe.shape[-1])
        self.noise_floor = noise_floor

    def _embed(self, texts: Sequence[str]) -> list[tuple[float, ...]]:
        return _rows_to_tuples(self._model.encode(list(texts)))

    def __repr__(self) -> str:  # pragma: no cover
        return f"Model2VecEmbedder({self.model_name!r}, dim={self.dim})"


# --------------------------------------------------------------------------
# FastEmbed — ONNX, sem torch
# --------------------------------------------------------------------------


class FastEmbedEmbedder(_BatchEmbedderBase):
    """Transformer quantizado em ONNX (Qdrant FastEmbed).

    O `bge-small-en-v1.5` (Xiao et al., 2023) é o padrão: 384 dimensões,
    33M parâmetros, nDCG@10 médio de 51,7 no BEIR. FastEmbed já aplica o
    prefixo de consulta do bge em `query_embed` e nada em `passage_embed`;
    `encode_query`/`encode_documents` usam esses dois caminhos.
    """

    def __init__(
        self,
        model: str = "BAAI/bge-small-en-v1.5",
        *,
        noise_floor: float = 0.0,
        cache_size: int = 8192,
        threads: int | None = None,
    ) -> None:
        super().__init__(cache_size=cache_size)
        from fastembed import TextEmbedding

        self.model_name = model
        self._model = TextEmbedding(model, threads=threads, cache_dir=fastembed_cache_dir())
        probe = next(iter(self._model.embed(["probe"])))
        self.dim = len(probe)
        self.noise_floor = noise_floor
        self._qcache = _Cache(cache_size)

    def _embed(self, texts: Sequence[str]) -> list[tuple[float, ...]]:
        return _rows_to_tuples(self._model.passage_embed(list(texts)))

    def encode_query(self, text: str) -> tuple[float, ...]:
        cached = self._qcache.get(text)
        if cached is not None:
            return cached
        v = _rows_to_tuples(self._model.query_embed([text]))[0]
        self._qcache.put(text, v)
        return v

    def __repr__(self) -> str:  # pragma: no cover
        return f"FastEmbedEmbedder({self.model_name!r}, dim={self.dim})"


class FastEmbedColBERT:
    """ColBERTv2 em ONNX (Santhanam et al., 2022) como `TokenEmbedder`.

    Um vetor de 128 dimensões por token; a relevância é o MaxSim somado
    (`index/multivector.py`). Os offsets de caractere não vêm do FastEmbed,
    então são reconstruídos por casamento dos tokens no texto — suficiente para
    agrupar por trecho, não para alinhamento exato.
    """

    def __init__(self, model: str = "colbert-ir/colbertv2.0") -> None:
        from fastembed import LateInteractionTextEmbedding

        self.model_name = model
        self._model = LateInteractionTextEmbedding(model, cache_dir=fastembed_cache_dir())
        probe = next(iter(self._model.embed(["probe"])))
        self.dim = int(probe.shape[-1])

    def _tokens(self, text: str, n: int) -> tuple[list[str], list[tuple[int, int]]]:
        toks = text.split()
        offs: list[tuple[int, int]] = []
        pos = 0
        for t in toks:
            i = text.find(t, pos)
            offs.append((i, i + len(t)))
            pos = i + len(t)
        # ColBERT produz um vetor por *subtoken*; o casamento é aproximado
        if len(toks) >= n:
            return toks[:n], offs[:n]
        while len(toks) < n:
            toks.append("")
            offs.append((len(text), len(text)))
        return toks, offs

    def encode_tokens(self, text: str) -> TokenEmbeddings:
        mat = next(iter(self._model.embed([text])))
        vecs = _rows_to_tuples(mat)
        toks, offs = self._tokens(text, len(vecs))
        return TokenEmbeddings(toks, offs, vecs)

    def encode_query_tokens(self, text: str) -> TokenEmbeddings:
        mat = next(iter(self._model.query_embed([text])))
        vecs = _rows_to_tuples(mat)
        toks, offs = self._tokens(text, len(vecs))
        return TokenEmbeddings(toks, offs, vecs)


# --------------------------------------------------------------------------
# sentence-transformers — torch
# --------------------------------------------------------------------------


class SentenceTransformersEmbedder(_BatchEmbedderBase):
    """Qualquer modelo do Hub via sentence-transformers (Reimers & Gurevych, 2019).

    Expõe `encode_tokens` (vetores contextuais por token, com offsets do
    tokenizador) — é o único adaptador aqui que torna o *late chunking*
    de fato contextual.
    """

    def __init__(
        self,
        model: str = "intfloat/multilingual-e5-small",
        *,
        query_prefix: str | None = None,
        document_prefix: str | None = None,
        noise_floor: float = 0.0,
        cache_size: int = 8192,
        device: str | None = None,
    ) -> None:
        super().__init__(cache_size=cache_size)
        from sentence_transformers import SentenceTransformer

        self.model_name = model
        self._model = SentenceTransformer(model, device=device)
        self.dim = int(self._model.get_sentence_embedding_dimension() or 0)
        self.noise_floor = noise_floor
        if query_prefix is None and "e5" in model:
            query_prefix, document_prefix = "query: ", "passage: "
        self.query_prefix = query_prefix or ""
        self.document_prefix = document_prefix or ""

    def _embed(self, texts: Sequence[str]) -> list[tuple[float, ...]]:
        arr = self._model.encode(list(texts), normalize_embeddings=True, convert_to_numpy=True)
        return _rows_to_tuples(arr, normalize=False)

    def encode_tokens(self, text: str) -> TokenEmbeddings:
        tok = self._model.tokenizer
        enc = tok(text, return_offsets_mapping=True, truncation=True)
        offsets = [tuple(o) for o in enc["offset_mapping"]]
        tokens = tok.convert_ids_to_tokens(enc["input_ids"])
        mat = self._model.encode(text, output_value="token_embeddings", convert_to_numpy=True)
        vecs = _rows_to_tuples(mat)
        n = min(len(vecs), len(tokens))
        keep = [i for i in range(n) if offsets[i][1] > offsets[i][0]]  # sem especiais
        return TokenEmbeddings(
            [tokens[i] for i in keep], [offsets[i] for i in keep], [vecs[i] for i in keep]
        )


# --------------------------------------------------------------------------
# APIs remotas — urllib, sem SDK
# --------------------------------------------------------------------------

Transport = Callable[[str, dict[str, str], dict[str, Any]], dict[str, Any]]


def _http_json(url: str, headers: dict[str, str], payload: dict[str, Any]) -> dict[str, Any]:
    data = json.dumps(payload).encode("utf-8")
    req = urllib.request.Request(url, data=data, method="POST")
    req.add_header("Content-Type", "application/json")
    for k, v in headers.items():
        req.add_header(k, v)
    with urllib.request.urlopen(req, timeout=120) as resp:
        return json.loads(resp.read().decode("utf-8"))


class _RemoteEmbedder(_BatchEmbedderBase):
    url: str = ""
    max_batch: int = 256

    def __init__(
        self,
        *,
        transport: Transport | None = None,
        cache_size: int = 8192,
    ) -> None:
        super().__init__(cache_size=cache_size)
        self._transport: Transport = transport or _http_json

    def _headers(self) -> dict[str, str]:  # pragma: no cover
        return {}

    def _payload(self, texts: Sequence[str], *, kind: str) -> dict[str, Any]:  # pragma: no cover
        raise NotImplementedError

    def _rows(self, response: dict[str, Any]) -> list[Sequence[float]]:
        data = response.get("data", [])
        data = sorted(data, key=lambda d: d.get("index", 0))
        return [d["embedding"] for d in data]

    def _call(self, texts: Sequence[str], *, kind: str) -> list[tuple[float, ...]]:
        out: list[tuple[float, ...]] = []
        for i in range(0, len(texts), self.max_batch):
            chunk = list(texts[i : i + self.max_batch])
            resp = self._transport(self.url, self._headers(), self._payload(chunk, kind=kind))
            rows = self._rows(resp)
            if len(rows) != len(chunk):
                raise RuntimeError(f"{self.__class__.__name__}: {len(rows)} vetores para {len(chunk)} textos")
            out.extend(_rows_to_tuples(rows))
        return out

    def _embed(self, texts: Sequence[str]) -> list[tuple[float, ...]]:
        return self._call(texts, kind="document")


class OpenAIEmbedder(_RemoteEmbedder):
    """`text-embedding-3-*` (OpenAI, 2024): Matryoshka nativo via `dimensions`.

    A chave vem de `OPENAI_API_KEY`; nunca de argumento. `dimensions` trunca
    no servidor — o modelo foi treinado com MRL (Kusupati et al., 2022), de
    modo que os primeiros `d` componentes são um embedding válido, não um corte.
    """

    url = "https://api.openai.com/v1/embeddings"
    max_batch = 512

    def __init__(
        self,
        model: str = "text-embedding-3-small",
        *,
        dimensions: int | None = None,
        transport: Transport | None = None,
        cache_size: int = 8192,
        api_key: str | None = None,
    ) -> None:
        super().__init__(transport=transport, cache_size=cache_size)
        self.model_name = model
        self.dimensions = dimensions
        self._key = api_key if api_key is not None else os.environ.get("OPENAI_API_KEY", "")
        base = os.environ.get("OPENAI_BASE_URL")
        if base:
            self.url = base.rstrip("/") + "/embeddings"
        self.dim = dimensions or {"text-embedding-3-small": 1536, "text-embedding-3-large": 3072}.get(model, 1536)

    def _headers(self) -> dict[str, str]:
        if not self._key:
            raise RuntimeError("OPENAI_API_KEY ausente no ambiente")
        return {"Authorization": f"Bearer {self._key}"}

    def _payload(self, texts: Sequence[str], *, kind: str) -> dict[str, Any]:
        p: dict[str, Any] = {"model": self.model_name, "input": list(texts)}
        if self.dimensions:
            p["dimensions"] = self.dimensions
        return p


class VoyageEmbedder(_RemoteEmbedder):
    """Voyage AI — o provedor de embeddings recomendado na documentação da Anthropic.

    Assimétrico por `input_type` (`query`/`document`), o que muda o prefixo no
    servidor. `VOYAGE_API_KEY` no ambiente.
    """

    url = "https://api.voyageai.com/v1/embeddings"
    max_batch = 128

    def __init__(
        self,
        model: str = "voyage-3.5",
        *,
        output_dimension: int | None = None,
        transport: Transport | None = None,
        cache_size: int = 8192,
        api_key: str | None = None,
    ) -> None:
        super().__init__(transport=transport, cache_size=cache_size)
        self.model_name = model
        self.output_dimension = output_dimension
        self._key = api_key if api_key is not None else os.environ.get("VOYAGE_API_KEY", "")
        self.dim = output_dimension or 1024
        self._qcache = _Cache(cache_size)

    def _headers(self) -> dict[str, str]:
        if not self._key:
            raise RuntimeError("VOYAGE_API_KEY ausente no ambiente")
        return {"Authorization": f"Bearer {self._key}"}

    def _payload(self, texts: Sequence[str], *, kind: str) -> dict[str, Any]:
        p: dict[str, Any] = {"model": self.model_name, "input": list(texts), "input_type": kind}
        if self.output_dimension:
            p["output_dimension"] = self.output_dimension
        return p

    def encode_query(self, text: str) -> tuple[float, ...]:
        cached = self._qcache.get(text)
        if cached is not None:
            return cached
        v = self._call([text], kind="query")[0]
        self._qcache.put(text, v)
        return v


class OllamaEmbedder(_RemoteEmbedder):
    """Modelo local servido pelo Ollama (`/api/embed`)."""

    max_batch = 64

    def __init__(
        self,
        model: str = "nomic-embed-text",
        *,
        host: str | None = None,
        dim: int = 768,
        transport: Transport | None = None,
        cache_size: int = 8192,
    ) -> None:
        super().__init__(transport=transport, cache_size=cache_size)
        self.model_name = model
        self.url = (host or os.environ.get("OLLAMA_HOST", "http://localhost:11434")).rstrip("/") + "/api/embed"
        self.dim = dim

    def _payload(self, texts: Sequence[str], *, kind: str) -> dict[str, Any]:
        return {"model": self.model_name, "input": list(texts)}

    def _rows(self, response: dict[str, Any]) -> list[Sequence[float]]:
        return list(response.get("embeddings", []))


# --------------------------------------------------------------------------
# Embedder por token, determinístico (fallback dos testes)
# --------------------------------------------------------------------------


class HashingTokenEmbedder:
    """Um vetor por token, por hashing, com mistura de janela.

    Não é contextual no sentido de um transformer — cada token só vê os
    `window` vizinhos, por média ponderada — e é dito assim no nome. Existe
    para que os índices multi-vetor e o late chunking tenham um `TokenEmbedder`
    reprodutível e sem rede nos testes. O ganho de *late chunking* de verdade
    exige um `SentenceTransformersEmbedder` (ou outro modelo contextual).
    """

    def __init__(self, dim: int = 128, *, window: int = 1, mix: float = 0.3) -> None:
        self.dim = dim
        self.window = window
        self.mix = mix
        self._word = HashingEmbedder(dim, word_ngrams_range=(1, 1), char_ngrams_range=(3, 4))

    def encode_tokens(self, text: str) -> TokenEmbeddings:
        import re

        tokens: list[str] = []
        offsets: list[tuple[int, int]] = []
        for m in re.finditer(r"[0-9]+(?:[.,][0-9]+)*|[^\W_]+", text):
            tokens.append(fold(m.group(0)))
            offsets.append((m.start(), m.end()))
        base = [self._word.encode(t) for t in tokens]
        vecs: list[tuple[float, ...]] = []
        for i, v in enumerate(base):
            acc = list(v)
            for d in range(1, self.window + 1):
                for j in (i - d, i + d):
                    if 0 <= j < len(base):
                        w = self.mix / d
                        for k, x in enumerate(base[j]):
                            acc[k] += w * x
            vecs.append(l2_normalize(acc))
        return TokenEmbeddings(tokens, offsets, vecs)

    def encode_query_tokens(self, text: str) -> TokenEmbeddings:
        return self.encode_tokens(text)

    # também serve como Embedder simétrico (média dos tokens)
    def encode(self, text: str) -> tuple[float, ...]:
        te = self.encode_tokens(text)
        if not te.vectors:
            return tuple([0.0] * self.dim)
        return te.pool(0, len(text) + 1)

    def encode_batch(self, texts: Sequence[str]) -> list[tuple[float, ...]]:
        return [self.encode(t) for t in texts]


class CachedEmbedder:
    """Cache persistente (JSON) em volta de qualquer embedder — recalibrar não recodifica."""

    def __init__(self, inner: Embedder, path: str) -> None:
        self.inner = inner
        self.path = path
        self.dim = inner.dim
        self.noise_floor = float(getattr(inner, "noise_floor", 0.0))
        self._d: dict[str, tuple[float, ...]] = {}
        if os.path.exists(path):
            with open(path, encoding="utf-8") as fh:
                for line in fh:
                    try:
                        k, v = json.loads(line)
                    except Exception:
                        continue
                    self._d[k] = tuple(v)
        self._fh = open(path, "a", encoding="utf-8")  # noqa: SIM115 - fechado em close()

    def _key(self, prefix: str, text: str) -> str:
        return prefix + "\x00" + text

    def _fill(self, prefix: str, texts: Sequence[str], fn: Callable[[Sequence[str]], list[tuple[float, ...]]]) -> list[tuple[float, ...]]:
        missing = [t for t in dict.fromkeys(texts) if self._key(prefix, t) not in self._d]
        if missing:
            for t, v in zip(missing, fn(missing), strict=True):
                self._d[self._key(prefix, t)] = v
                self._fh.write(json.dumps([self._key(prefix, t), list(v)]) + "\n")
            self._fh.flush()
        return [self._d[self._key(prefix, t)] for t in texts]

    def encode_batch(self, texts: Sequence[str]) -> list[tuple[float, ...]]:
        return self._fill("", texts, self.inner.encode_batch)

    def encode(self, text: str) -> tuple[float, ...]:
        return self.encode_batch([text])[0]

    def encode_query(self, text: str) -> tuple[float, ...]:
        return self._fill("q", [text], lambda ts: [encode_query(self.inner, t) for t in ts])[0]

    def encode_documents(self, texts: Sequence[str]) -> list[tuple[float, ...]]:
        return self._fill("d", texts, lambda ts: encode_documents(self.inner, ts))

    def close(self) -> None:
        self._fh.close()

    def __setattr__(self, name: str, value: Any) -> None:
        object.__setattr__(self, name, value)
        if name == "noise_floor" and hasattr(self, "inner"):
            with contextlib.suppress(AttributeError):
                self.inner.noise_floor = value  # type: ignore[attr-defined]


def load_embedder(spec: str = "hashing") -> Embedder:
    """`hashing`, `hashing:256`, `model2vec[:nome]`, `fastembed[:nome]`, `st:nome`, `openai[:nome]`, `voyage[:nome]`, `ollama[:nome]`."""
    kind, _, arg = spec.partition(":")
    if kind == "hashing":
        return HashingEmbedder(int(arg) if arg else 512)
    if kind == "model2vec":
        return Model2VecEmbedder(arg) if arg else Model2VecEmbedder()
    if kind == "fastembed":
        return FastEmbedEmbedder(arg) if arg else FastEmbedEmbedder()
    if kind in ("st", "sentence-transformers"):
        return SentenceTransformersEmbedder(arg) if arg else SentenceTransformersEmbedder()
    if kind == "openai":
        return OpenAIEmbedder(arg) if arg else OpenAIEmbedder()
    if kind == "voyage":
        return VoyageEmbedder(arg) if arg else VoyageEmbedder()
    if kind == "ollama":
        return OllamaEmbedder(arg) if arg else OllamaEmbedder()
    raise ValueError(f"embedder desconhecido: {spec!r}")

