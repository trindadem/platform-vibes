"""Um banco vetorial pequeno e honesto: coleção, metadados, filtro, híbrido, disco.

O que um banco vetorial de produção oferece além do índice: `upsert` por id,
*payload* consultável, filtro por metadado que não destrói o recall,
esparso e denso no mesmo lugar, e persistência. `Collection` entrega os
cinco sobre os índices de `index/` e o `InvertedIndex` de `sparse.py`.

**Filtro.** A pergunta clássica é pré-filtrar (varrer só os permitidos:
exato, caro quando são muitos) ou pós-filtrar (buscar mais e descartar:
barato, e falha quando a seletividade é alta — os `k` melhores permitidos
podem não estar entre os `ef` visitados). A coleção resolve o predicado
sobre os payloads primeiro, conta os permitidos, e entrega ao índice o
conjunto **e** a contagem: o HNSW escolhe varredura exata quando o
subconjunto é pequeno e pós-filtro com `ef` inflado quando é grande. É a
regra do Qdrant; o ACORN (Patel et al., 2024) generaliza para predicados
arbitrários com um grafo mais denso, o que fica fora daqui.

O DSL do filtro é o do MongoDB/Qdrant em miniatura: igualdade,
`$in`, `$nin`, `$gt/$gte/$lt/$lte`, `$exists`, `$and`, `$or`, `$not`.

**Disco.** SQLite (WAL) guarda id, vetor (float32 cru), payload (JSON) e
texto; o índice é reconstruído na abertura, como `SQLiteStore` faz na
memória. Para não reconstruir o HNSW a cada abertura, `snapshot()` grava o
grafo ao lado (`<path>.hnsw`), e `open` o usa se bater com o conteúdo.
"""

from __future__ import annotations

import json
import sqlite3
import struct
import threading
from collections.abc import Callable, Mapping, Sequence
from dataclasses import dataclass, field
from typing import Any

from .fusion import convex, rrf
from .index import FlatIndex, HNSWIndex, IVFIndex, VectorIndex
from .index.base import Hit
from .sparse import BM25Encoder, InvertedIndex, SparseEncoder

__all__ = ["Collection", "Filter", "Item", "compile_filter"]

Predicate = Callable[[Mapping[str, Any]], bool]

_OPS = {
    "$gt": lambda a, b: a is not None and a > b,
    "$gte": lambda a, b: a is not None and a >= b,
    "$lt": lambda a, b: a is not None and a < b,
    "$lte": lambda a, b: a is not None and a <= b,
    "$ne": lambda a, b: a != b,
    "$in": lambda a, b: a in b,
    "$nin": lambda a, b: a not in b,
}


def _get(payload: Mapping[str, Any], dotted: str) -> Any:
    cur: Any = payload
    for part in dotted.split("."):
        if not isinstance(cur, Mapping) or part not in cur:
            return None
        cur = cur[part]
    return cur


def compile_filter(spec: Mapping[str, Any] | None) -> Predicate:
    """Compila o DSL num predicado sobre payload. `None`/`{}` -> tudo passa."""
    if not spec:
        return lambda _p: True
    clauses: list[Predicate] = []
    for key, val in spec.items():
        if key == "$and":
            clauses.append(_all_of([compile_filter(s) for s in val]))
        elif key == "$or":
            clauses.append(_any_of([compile_filter(s) for s in val]))
        elif key == "$not":
            clauses.append(_negate(compile_filter(val)))
        elif isinstance(val, Mapping) and any(k.startswith("$") for k in val):
            for op, arg in val.items():
                if op == "$exists":
                    clauses.append(_exists(key, bool(arg)))
                elif op in _OPS:
                    clauses.append(_compare(key, _OPS[op], arg))
                else:
                    raise ValueError(f"operador desconhecido no filtro: {op!r}")
        else:
            clauses.append(_compare(key, lambda a, b: a == b, val))
    return _all_of(clauses)


def _all_of(subs: list[Predicate]) -> Predicate:
    def pred(p: Mapping[str, Any]) -> bool:
        return all(s(p) for s in subs)

    return pred


def _any_of(subs: list[Predicate]) -> Predicate:
    def pred(p: Mapping[str, Any]) -> bool:
        return any(s(p) for s in subs)

    return pred


def _negate(sub: Predicate) -> Predicate:
    def pred(p: Mapping[str, Any]) -> bool:
        return not sub(p)

    return pred


def _exists(key: str, expected: bool) -> Predicate:
    def pred(p: Mapping[str, Any]) -> bool:
        return (_get(p, key) is not None) == expected

    return pred


def _compare(key: str, fn: Callable[[Any, Any], bool], arg: Any) -> Predicate:
    def pred(p: Mapping[str, Any]) -> bool:
        return bool(fn(_get(p, key), arg))

    return pred


@dataclass(slots=True)
class Filter:
    spec: dict[str, Any] = field(default_factory=dict)

    def predicate(self) -> Predicate:
        return compile_filter(self.spec)


@dataclass(slots=True)
class Item:
    id: str
    payload: dict[str, Any]
    text: str = ""
    vector: tuple[float, ...] | None = None


_SCHEMA = """
CREATE TABLE IF NOT EXISTS items (
    id      TEXT PRIMARY KEY,
    vector  BLOB NOT NULL,
    payload TEXT NOT NULL,
    text    TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS meta (key TEXT PRIMARY KEY, value TEXT NOT NULL);
"""


class Collection:
    def __init__(
        self,
        name: str,
        dim: int,
        *,
        index: str | VectorIndex = "hnsw",
        metric: str = "cosine",
        sparse: bool | SparseEncoder = True,
        path: str | None = None,
        **index_kw: Any,
    ) -> None:
        self.name = name
        self.dim = dim
        self.metric = metric
        self.index: VectorIndex = self._make_index(index, dim, metric, index_kw)
        self._sparse_enc: SparseEncoder | None
        if sparse is True:
            self._sparse_enc = BM25Encoder()
        elif sparse is False:
            self._sparse_enc = None
        else:
            self._sparse_enc = sparse
        self._inverted = InvertedIndex() if self._sparse_enc is not None else None
        self._items: dict[str, Item] = {}
        self._lock = threading.RLock()
        self.path = path
        self._conn: sqlite3.Connection | None = None
        if path:
            self._conn = sqlite3.connect(path, check_same_thread=False)
            self._conn.execute("PRAGMA journal_mode=WAL")
            self._conn.executescript(_SCHEMA)
            self._conn.commit()
            self._hydrate()

    @staticmethod
    def _make_index(index: str | VectorIndex, dim: int, metric: str, kw: dict[str, Any]) -> VectorIndex:
        if not isinstance(index, str):
            return index
        if index == "hnsw":
            return HNSWIndex(dim, metric=metric, **kw)
        if index == "flat":
            return FlatIndex(dim, metric=metric, **kw)
        if index == "ivf":
            return IVFIndex(dim, metric=metric, **kw)
        raise ValueError(f"índice desconhecido: {index!r}")

    # ------------------------------------------------------------ disco
    def _hydrate(self) -> None:
        assert self._conn is not None
        rows = self._conn.execute("SELECT id, vector, payload, text FROM items").fetchall()
        if not rows:
            return
        ids, vecs, payloads, texts = [], [], [], []
        for id_, blob, payload, text in rows:
            ids.append(id_)
            vecs.append(struct.unpack(f"<{self.dim}f", blob))
            payloads.append(json.loads(payload))
            texts.append(text)
        self._upsert_memory(ids, vecs, payloads, texts)

    def _persist(self, ids: Sequence[str], vectors: Sequence[Sequence[float]], payloads: Sequence[dict[str, Any]], texts: Sequence[str]) -> None:
        if self._conn is None:
            return
        rows = [
            (i, struct.pack(f"<{self.dim}f", *[float(x) for x in v]), json.dumps(p, ensure_ascii=False), t)
            for i, v, p, t in zip(ids, vectors, payloads, texts, strict=True)
        ]
        self._conn.executemany("INSERT OR REPLACE INTO items (id, vector, payload, text) VALUES (?,?,?,?)", rows)
        self._conn.commit()

    def close(self) -> None:
        if self._conn is not None:
            self._conn.commit()
            self._conn.close()
            self._conn = None

    # ------------------------------------------------------------ escrita
    def _upsert_memory(self, ids, vectors, payloads, texts) -> None:
        with self._lock:
            if self._sparse_enc is not None and isinstance(self._sparse_enc, BM25Encoder):
                for t in texts:
                    if t:
                        self._sparse_enc.add(t)
            self.index.add(list(ids), [tuple(float(x) for x in v) for v in vectors])
            for i, v, p, t in zip(ids, vectors, payloads, texts, strict=True):
                self._items[i] = Item(i, dict(p), t, tuple(float(x) for x in v))
                if self._inverted is not None and self._sparse_enc is not None and t:
                    self._inverted.add(i, self._sparse_enc.encode_document(t))

    def upsert(
        self,
        ids: Sequence[str],
        vectors: Sequence[Sequence[float]],
        payloads: Sequence[dict[str, Any]] | None = None,
        texts: Sequence[str] | None = None,
    ) -> int:
        n = len(ids)
        if len(vectors) != n:
            raise ValueError("ids e vectors com tamanhos diferentes")
        payloads = list(payloads) if payloads is not None else [{} for _ in range(n)]
        texts = list(texts) if texts is not None else ["" for _ in range(n)]
        if len(payloads) != n or len(texts) != n:
            raise ValueError("payloads/texts com tamanho diferente de ids")
        self._upsert_memory(ids, vectors, payloads, texts)
        self._persist(ids, vectors, payloads, texts)
        return n

    def delete(self, ids: Sequence[str]) -> int:
        n = 0
        with self._lock:
            for i in ids:
                if self._items.pop(i, None) is None:
                    continue
                self.index.remove(i)
                if self._inverted is not None:
                    self._inverted.remove(i)
                n += 1
            if self._conn is not None and n:
                self._conn.executemany("DELETE FROM items WHERE id = ?", [(i,) for i in ids])
                self._conn.commit()
        return n

    # ------------------------------------------------------------ leitura
    def get(self, id: str) -> Item | None:
        return self._items.get(id)

    def count(self) -> int:
        return len(self._items)

    def __len__(self) -> int:
        return len(self._items)

    def _allowed(self, filter: Mapping[str, Any] | Filter | None) -> tuple[Callable[[str], bool] | None, int | None]:
        if filter is None:
            return None, None
        spec = filter.spec if isinstance(filter, Filter) else filter
        if not spec:
            return None, None
        pred = compile_filter(spec)
        ok = {i for i, it in self._items.items() if pred(it.payload)}
        return (lambda i: i in ok), len(ok)

    def query(
        self,
        vector: Sequence[float],
        k: int = 10,
        *,
        filter: Mapping[str, Any] | Filter | None = None,
        **kw: Any,
    ) -> list[Hit]:
        allowed, count = self._allowed(filter)
        if count == 0:
            return []
        if isinstance(self.index, HNSWIndex):
            return self.index.search(vector, k, allowed=allowed, allowed_count=count, **kw)
        return self.index.search(vector, k, allowed=allowed, **kw)

    def query_text(self, text: str, k: int = 10, *, filter: Mapping[str, Any] | Filter | None = None) -> list[Hit]:
        if self._inverted is None or self._sparse_enc is None:
            raise RuntimeError("coleção sem índice esparso")
        allowed, count = self._allowed(filter)
        if count == 0:
            return []
        return self._inverted.search(self._sparse_enc.encode_query(text), k, allowed=allowed)

    def query_hybrid(
        self,
        vector: Sequence[float],
        text: str,
        k: int = 10,
        *,
        filter: Mapping[str, Any] | Filter | None = None,
        fusion: str = "rrf",
        alpha: float = 0.5,
        rrf_k: float = 60.0,
        pool: int | None = None,
    ) -> list[Hit]:
        """`fusion='rrf'` (posições) ou `'convex'` (scores min-max, peso `alpha` no denso)."""
        pool = pool or max(k * 4, 20)
        dense = self.query(vector, pool, filter=filter)
        sparse = self.query_text(text, pool, filter=filter) if text else []
        if fusion == "rrf":
            fused = rrf([[i for i, _ in dense], [i for i, _ in sparse]], k=rrf_k)
        elif fusion == "convex":
            fused = convex(dict(dense), dict(sparse), alpha=alpha)
        else:
            raise ValueError(f"fusão desconhecida: {fusion!r}")
        return fused[:k]

    def stats(self) -> dict[str, Any]:
        s: dict[str, Any] = {"name": self.name, "dim": self.dim, "count": len(self._items), "metric": self.metric}
        st = getattr(self.index, "stats", None)
        if callable(st):
            s["index"] = st()
        s["sparse"] = self._inverted is not None and len(self._inverted)
        return s

    # ------------------------------------------------------------ snapshot
    def snapshot(self) -> str | None:
        """Grava o HNSW ao lado do banco para não reconstruir na abertura."""
        if self.path and isinstance(self.index, HNSWIndex):
            p = self.path + ".hnsw"
            self.index.save(p)
            return p
        return None

    @classmethod
    def open(cls, name: str, dim: int, path: str, **kw: Any) -> Collection:
        """Abre do disco; usa o snapshot do HNSW se ele cobre exatamente os ids gravados."""
        import os

        snap = path + ".hnsw"
        if kw.get("index", "hnsw") == "hnsw" and os.path.exists(snap) and os.path.exists(snap + ".vec"):
            try:
                idx = HNSWIndex.load(snap)
            except Exception:
                idx = None
            if idx is not None:
                col = cls(name, dim, index=idx, path=None, **{k: v for k, v in kw.items() if k != "index"})
                col.path = path
                col._conn = sqlite3.connect(path, check_same_thread=False)
                col._conn.execute("PRAGMA journal_mode=WAL")
                col._conn.executescript(_SCHEMA)
                rows = col._conn.execute("SELECT id, vector, payload, text FROM items").fetchall()
                ids = {r[0] for r in rows}
                if ids == set(idx._row):
                    # índice bate: só hidrata itens e esparso
                    for id_, blob, payload, text in rows:
                        vec = struct.unpack(f"<{dim}f", blob)
                        col._items[id_] = Item(id_, json.loads(payload), text, vec)
                        if col._sparse_enc is not None and isinstance(col._sparse_enc, BM25Encoder) and text:
                            col._sparse_enc.add(text)
                    if col._inverted is not None and col._sparse_enc is not None:
                        for it in col._items.values():
                            if it.text:
                                col._inverted.add(it.id, col._sparse_enc.encode_document(it.text))
                    return col
                col.close()
        return cls(name, dim, path=path, **kw)
