"""`exovision-agent rag`: ingerir, consultar e medir pela linha de comando.

    exovision-agent rag ingest ./docs --db corpus.db --embedder fastembed
    exovision-agent rag query "onde fica a Vortex?" --db corpus.db --embedder fastembed -k 5
    exovision-agent rag bench beir --dataset scifact --embedder fastembed --reranker fastembed
    exovision-agent rag bench ann --embedder fastembed --dataset scifact
    exovision-agent rag bench chunking --embedder model2vec
    exovision-agent rag bench graph
    exovision-agent rag bench noise --embedder model2vec --dataset scifact
    exovision-agent rag bench all --embedder fastembed

`--embedder` aceita `hashing[:dim]`, `model2vec[:modelo]`, `fastembed[:modelo]`,
`st:modelo`, `openai[:modelo]`, `voyage[:modelo]`, `ollama[:modelo]`. Os
benchmarks gravam JSON em `docs/rag/resultados/` (ou `--out`).

Este módulo não tem `main`: ele registra o subcomando no parser de
`exovision.harness.cli` por `add_parser(sub)`, como `specialize` e `memory`.
"""

from __future__ import annotations

import argparse
import contextlib
import json
import time
from collections.abc import Callable
from pathlib import Path
from typing import Any

from ..memory.core.embeddings import Embedder
from .chunking import (
    ContextualChunker,
    FixedChunker,
    RecursiveChunker,
    SemanticChunker,
    SentenceChunker,
)
from .embed import CachedEmbedder, encode_documents, load_embedder
from .eval.bench import (
    ann_benchmark,
    chunk_hits_benchmark,
    graph_benchmark,
    noise_floor_benchmark,
    retrieval_benchmark,
    write_result,
)
from .eval.datasets import Dataset, download_beir, load_beir, multi_hop_corpus, needle_corpus
from .graph import GraphRAG, HippoRAG2, LightRAG, PathRAG
from .index import (
    BinaryQuantizer,
    HNSWIndex,
    IVFIndex,
    MatryoshkaIndex,
    ProductQuantizer,
    QuantizedIndex,
    ScalarQuantizer,
)
from .pipeline import IterativeRetriever, RAGPipeline
from .rerank import FastEmbedCrossEncoder, LexicalReranker, Reranker
from .types import Document

__all__ = ["add_parser"]


def _embedder(spec: str, *, cache: str | None = None) -> Embedder:
    emb = load_embedder(spec)
    if cache:
        return CachedEmbedder(emb, cache)
    return emb


def _calibrate_floor(emb: Embedder, texts: list[str]) -> float:
    """Mede o p99 do cosseno entre pares aleatórios do corpus e grava no embedder.

    Todo método que abstém ou filtra por "acima do ruído" lê `embedder.noise_floor`;
    sem esta medição o valor é 0 e o filtro não filtra nada.
    """
    from .embed import calibrate_noise_floor

    nf = calibrate_noise_floor(emb, texts, pairs=min(2000, max(200, len(texts) * 4)))
    with contextlib.suppress(AttributeError):
        emb.noise_floor = nf.p99  # type: ignore[attr-defined]
    return nf.p99


def _reranker(spec: str | None) -> Reranker | None:
    if not spec or spec == "none":
        return None
    if spec == "lexical":
        return LexicalReranker()
    if spec.startswith("fastembed"):
        _, _, model = spec.partition(":")
        return FastEmbedCrossEncoder(model) if model else FastEmbedCrossEncoder()
    raise SystemExit(f"reranker desconhecido: {spec}")


def _chunker(spec: str, embedder: Embedder):
    kind, _, arg = spec.partition(":")
    size = int(arg) if arg else 800
    if kind == "fixed":
        return FixedChunker(size, size // 8)
    if kind == "recursive":
        return RecursiveChunker(size, size // 8)
    if kind == "sentence":
        return SentenceChunker(size)
    if kind == "semantic":
        return SemanticChunker(embedder, max_chars=size)
    if kind == "contextual":
        return ContextualChunker(RecursiveChunker(size, size // 8))
    raise SystemExit(f"segmentador desconhecido: {spec}")


def _read_docs(path: str) -> list[Document]:
    p = Path(path)
    docs: list[Document] = []
    if p.is_file() and p.suffix == ".jsonl":
        for line in p.read_text(encoding="utf-8").splitlines():
            if line.strip():
                d = json.loads(line)
                docs.append(Document(str(d.get("id") or d.get("_id")), str(d.get("text", "")), {k: v for k, v in d.items() if k not in ("id", "_id", "text")}))
        return docs
    files = [p] if p.is_file() else sorted(x for x in p.rglob("*") if x.suffix in (".md", ".txt", ".rst", ".py", ".json"))
    for f in files:
        try:
            docs.append(Document(str(f.relative_to(p) if p.is_dir() else f.name), f.read_text(encoding="utf-8"), {"path": str(f)}))
        except UnicodeDecodeError:
            continue
    return docs


def _dataset(name: str, max_docs: int | None) -> Dataset:
    if name == "multi_hop":
        return multi_hop_corpus()
    download_beir(name)
    return load_beir(name, max_docs=max_docs)


# --------------------------------------------------------------------------
# comandos
# --------------------------------------------------------------------------


def cmd_ingest(a: argparse.Namespace) -> int:
    emb = _embedder(a.embedder, cache=a.embed_cache)
    pipe = RAGPipeline(emb, chunker=_chunker(a.chunker, emb), index=a.index, path=a.db)
    docs = _read_docs(a.path)
    t = time.perf_counter()
    n = pipe.ingest(docs)
    pipe.collection.snapshot()
    print(json.dumps({"docs": len(docs), "chunks": n, "seconds": round(time.perf_counter() - t, 2), **pipe.stats()}, ensure_ascii=False, indent=2))
    return 0


def cmd_query(a: argparse.Namespace) -> int:
    emb = _embedder(a.embedder, cache=a.embed_cache)
    pipe = RAGPipeline(emb, index=a.index, path=a.db, reranker=_reranker(a.reranker), fusion=a.fusion)
    if a.iterative:
        items = IterativeRetriever(pipe).retrieve(a.query, a.k)
    else:
        items = pipe.retrieve(a.query, a.k)
    if a.json:
        print(json.dumps([{"id": i.id, "score": i.score, "signals": i.signals, "text": i.text} for i in items], ensure_ascii=False, indent=2))
    else:
        for i in items:
            print(f"[{i.id}] {i.score:.4f}  {i.text[:200].replace(chr(10), ' ')}")
    return 0


def _systems_for_beir(ds: Dataset, emb: Embedder, a: argparse.Namespace) -> dict[str, Callable[[], Any]]:
    def make(fusion: str, reranker: Reranker | None = None, chunker: str = "recursive:1200") -> Callable[[], Any]:
        def f() -> Any:
            p = RAGPipeline(emb, chunker=_chunker(chunker, emb), index="flat", fusion=fusion, reranker=reranker, rerank_pool=a.rerank_pool)
            p.ingest(ds.docs)
            return p

        return f

    systems: dict[str, Callable[[], Any]] = {"bm25": make("sparse"), "dense": make("dense"), "hybrid_rrf": make("rrf"), "hybrid_convex": make("convex")}
    rr = _reranker(a.reranker)
    if rr is not None:
        systems["hybrid_rrf+rerank"] = make("rrf", rr)
    return systems


def cmd_bench(a: argparse.Namespace) -> int:
    out_dir = a.out
    which = a.which
    if which in ("beir", "all"):
        emb = _embedder(a.embedder, cache=a.embed_cache)
        for name in a.dataset.split(","):
            ds = _dataset(name, a.max_docs)
            floor = _calibrate_floor(emb, [d.text for d in ds.docs])
            res = retrieval_benchmark(ds, _systems_for_beir(ds, emb, a), baseline="bm25", max_queries=a.max_queries)
            res["embedder"] = a.embedder
            res["noise_floor_p99"] = round(floor, 4)
            path = write_result(f"beir_{name}_{a.embedder.split(':')[0]}", res, directory=out_dir)
            print(path)
            for s, v in res["systems"].items():
                print(f"  {s:20s} nDCG@10={v['metrics'].get('ndcg@10')}  R@100={v['metrics'].get('recall@100')}  ms/q={v['query_ms']}")
    if which in ("noise", "all"):
        emb = _embedder(a.embedder, cache=a.embed_cache)
        ds = _dataset(a.dataset.split(",")[0], a.max_docs)
        res = noise_floor_benchmark(emb, [d.text for d in ds.docs], name=a.embedder)
        print(write_result(f"noise_floor_{a.embedder.split(':')[0]}", res, directory=out_dir), res["noise_floor"])
    if which in ("ann", "all"):
        emb = _embedder(a.embedder, cache=a.embed_cache)
        ds = _dataset(a.dataset.split(",")[0], a.max_docs)
        texts = [(d.metadata.get("title", "") + " " + d.text).strip() for d in ds.docs]
        vectors = encode_documents(emb, texts)
        qtexts = list(ds.queries.values())[: a.max_queries or 200]
        from .embed import encode_query

        queries = [encode_query(emb, q) for q in qtexts]
        ann_systems: dict[str, Callable[[int], Any]] = {
            "hnsw": lambda d: HNSWIndex(d, M=16, ef_construction=200),
            "ivf": lambda d: IVFIndex(d, nprobe=8),
            "int8": lambda d: QuantizedIndex(ScalarQuantizer(d), rescore=0),
            "int8+rescore": lambda d: QuantizedIndex(ScalarQuantizer(d), rescore=4),
            "binary": lambda d: QuantizedIndex(BinaryQuantizer(d), rescore=0),
            "binary+rescore": lambda d: QuantizedIndex(BinaryQuantizer(d), rescore=8),
            "pq": lambda d: QuantizedIndex(ProductQuantizer(d, m=max(1, d // 8)), rescore=0),
            "pq+rescore": lambda d: QuantizedIndex(ProductQuantizer(d, m=max(1, d // 8)), rescore=8),
            "matryoshka64": lambda d: MatryoshkaIndex(d, dims=min(64, d), rescore=8),
            "matryoshka128": lambda d: MatryoshkaIndex(d, dims=min(128, d), rescore=8),
        }
        search_kw = {"hnsw": [{"ef": e} for e in (16, 32, 64, 128, 256)], "ivf": [{"nprobe": n} for n in (1, 2, 4, 8, 16, 32)]}
        res = ann_benchmark(vectors, queries, ann_systems, k=10, search_kw=search_kw)
        res["embedder"] = a.embedder
        res["dataset"] = ds.name
        path = write_result(f"ann_{ds.name}_{a.embedder.split(':')[0]}", res, directory=out_dir)
        print(path)
        for s, v in res["systems"].items():
            print(f"  {s:16s} build={v['build_s']}s " + " ".join(f"{r['params']}:R={r['recall']}/{r['query_ms']}ms" for r in v["variants"]))
    if which in ("chunking", "all"):
        emb = _embedder(a.embedder, cache=a.embed_cache)
        base = _dataset(a.dataset.split(",")[0], a.max_docs)
        ds, where = needle_corpus(base, per_doc=8, max_queries=a.max_queries or 150)
        floor = _calibrate_floor(emb, [d.text for d in base.docs])
        chunk_systems: dict[str, Callable[[], Any]] = {}
        for spec in ("fixed:300", "fixed:600", "fixed:1200", "recursive:300", "recursive:600", "recursive:1200", "sentence:600", "semantic:600", "contextual:600"):

            def make(spec: str = spec) -> Any:
                p = RAGPipeline(emb, chunker=_chunker(spec, emb), index="flat", fusion="rrf")
                p.ingest(ds.docs)
                return p

            chunk_systems[spec] = make
        res = chunk_hits_benchmark(ds, where, chunk_systems, max_queries=a.max_queries)
        res["embedder"] = a.embedder
        res["noise_floor_p99"] = round(floor, 4)
        path = write_result(f"chunking_{base.name}_{a.embedder.split(':')[0]}", res, directory=out_dir)
        print(path)
        for s, v in res["systems"].items():
            print(f"  {s:16s} R@5={v['metrics'].get('recall@5')} hit@5={v['metrics'].get('hit@5')} chunks={v['chunks']}")
    if which in ("graph", "all"):
        emb = _embedder(a.embedder, cache=a.embed_cache)
        ds = multi_hop_corpus()
        floor = _calibrate_floor(emb, [d.text for d in ds.docs])

        def pipe(fusion: str) -> Callable[[], Any]:
            def f() -> Any:
                p = RAGPipeline(emb, chunker=SentenceChunker(400), index="flat", fusion=fusion)
                p.ingest(ds.docs)
                return p

            return f

        def graph(cls: type, **kw: Any) -> Callable[[], Any]:
            def f() -> Any:
                p = RAGPipeline(emb, chunker=SentenceChunker(400), index="flat")
                p.ingest(ds.docs)
                g = cls(emb, p.store, **kw)
                g.index(list(p.store))
                return g

            return f

        def iterative() -> Any:
            p = RAGPipeline(emb, chunker=SentenceChunker(400), index="flat")
            p.ingest(ds.docs)
            return IterativeRetriever(p, max_rounds=3, per_round=3)

        graph_systems: dict[str, Callable[[], Any]] = {"dense": pipe("dense"), "bm25": pipe("sparse"), "hybrid": pipe("rrf"), "iterative": iterative, "graphrag": graph(GraphRAG), "graphrag_2hop": graph(GraphRAG, hops=2), "lightrag": graph(LightRAG), "hipporag2": graph(HippoRAG2), "pathrag": graph(PathRAG)}
        res = graph_benchmark(ds, graph_systems, k=5)
        res["embedder"] = a.embedder
        res["noise_floor_p99"] = round(floor, 4)
        path = write_result(f"graph_multi_hop_{a.embedder.split(':')[0]}", res, directory=out_dir)
        print(path)
        for s, v in res["systems"].items():
            print(f"  {s:14s} " + " ".join(f"{h}:R@5={m.get('recall@5')}" for h, m in v["by_hop"].items()) + f"  ms/q={v['query_ms']}")
    return 0


def add_parser(sub: Any) -> None:
    sp = sub.add_parser(
        "rag",
        help="recuperação aumentada: ingerir, consultar, medir",
        description=__doc__,
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )
    ss = sp.add_subparsers(dest="rcmd", required=True)

    def common(sp: argparse.ArgumentParser) -> None:
        sp.add_argument("--embedder", default="hashing", help="hashing | model2vec | fastembed | st:m | openai | voyage | ollama")
        sp.add_argument("--embed-cache", default=None, help="arquivo JSONL de cache de embeddings")

    i = ss.add_parser("ingest", help="indexa um diretório ou JSONL")
    i.add_argument("path")
    i.add_argument("--db", required=True)
    i.add_argument("--index", default="hnsw", choices=("hnsw", "flat", "ivf"))
    i.add_argument("--chunker", default="recursive:800")
    common(i)
    i.set_defaults(fn=cmd_ingest)

    q = ss.add_parser("query", help="consulta uma base indexada")
    q.add_argument("query")
    q.add_argument("--db", required=True)
    q.add_argument("--index", default="hnsw", choices=("hnsw", "flat", "ivf"))
    q.add_argument("-k", type=int, default=5)
    q.add_argument("--fusion", default="rrf", choices=("rrf", "convex", "dense", "sparse"))
    q.add_argument("--reranker", default=None, help="none | lexical | fastembed[:modelo]")
    q.add_argument("--iterative", action="store_true")
    q.add_argument("--json", action="store_true")
    common(q)
    q.set_defaults(fn=cmd_query)

    b = ss.add_parser("bench", help="roda um benchmark e grava o JSON")
    b.add_argument("which", choices=("beir", "ann", "chunking", "graph", "noise", "all"))
    b.add_argument("--dataset", default="scifact", help="scifact | nfcorpus | multi_hop (lista separada por vírgula no beir)")
    b.add_argument("--max-docs", type=int, default=None)
    b.add_argument("--max-queries", type=int, default=None)
    b.add_argument("--reranker", default=None)
    b.add_argument("--rerank-pool", type=int, default=100)
    b.add_argument("--out", default=None, help="diretório dos resultados (padrão docs/rag/resultados)")
    common(b)
    b.set_defaults(fn=cmd_bench)
