"""Recuperação esparsa: BM25 como vetor esparso, índice invertido e esparso aprendido.

O BM25 (Robertson & Zaragoza, 2009) continua sendo a linha de base que os
modelos densos precisam vencer — no BEIR (Thakur et al., 2021) ele bate
DPR e ANCE em média zero-shot. Aqui ele aparece de duas formas que dão o
mesmo score:

* `exovision.harness.memory.core.similarity.BM25Index` — o índice incremental que a
  memória já usa;
* `BM25Encoder` + `InvertedIndex` — o **mesmo** BM25 como *vetor esparso*
  `{termo: peso}` e produto interno. É a forma que os bancos vetoriais
  (Pinecone, Qdrant, Milvus) usam para servir esparso e denso no mesmo motor,
  e a forma que aceita um esparso *aprendido* (SPLADE, Formal et al., 2021)
  sem mudar o índice: só troca o encoder.

`DocExpander` implementa a expansão de documento (doc2query, Nogueira et
al., 2019): perguntas geradas para o documento entram no texto indexado, e
assim o vocabulário da consulta encontra o do documento. Experimental por
custo (um modelo por documento), não por eficácia.
"""

from __future__ import annotations

import heapq
import math
from collections import defaultdict
from collections.abc import Callable, Iterable, Sequence
from typing import Protocol, runtime_checkable

from ..memory.core.text import tokenize

__all__ = [
    "BM25Encoder",
    "DocExpander",
    "FastEmbedSparse",
    "InvertedIndex",
    "SparseEncoder",
    "SparseVector",
]

SparseVector = dict[str, float]


@runtime_checkable
class SparseEncoder(Protocol):
    def encode_query(self, text: str) -> SparseVector: ...

    def encode_document(self, text: str) -> SparseVector: ...


class BM25Encoder:
    """BM25 Okapi como encoder esparso.

    peso(t, D) = IDF(t) * f(t,D)*(k1+1) / (f(t,D) + k1*(1-b+b*|D|/avgdl))

    A consulta vira `{t: 1.0}` (termos únicos), de modo que o produto interno
    é exatamente o BM25 clássico. `fit` fixa `df` e `avgdl`; `add` mantém
    ambos incrementais para corpus que cresce.
    """

    def __init__(self, k1: float = 1.5, b: float = 0.75, *, tokenizer: Callable[[str], list[str]] | None = None) -> None:
        self.k1 = k1
        self.b = b
        self.tokenize = tokenizer or tokenize
        self._df: dict[str, int] = defaultdict(int)
        self._n = 0
        self._total_len = 0

    @property
    def avgdl(self) -> float:
        return self._total_len / self._n if self._n else 0.0

    def fit(self, texts: Iterable[str]) -> BM25Encoder:
        for t in texts:
            self.add(t)
        return self

    def add(self, text: str) -> None:
        toks = self.tokenize(text)
        self._n += 1
        self._total_len += len(toks)
        for t in set(toks):
            self._df[t] += 1

    def idf(self, term: str) -> float:
        df = self._df.get(term, 0)
        return math.log(1.0 + (self._n - df + 0.5) / (df + 0.5))

    def encode_document(self, text: str) -> SparseVector:
        toks = self.tokenize(text)
        if not toks:
            return {}
        tf: dict[str, int] = defaultdict(int)
        for t in toks:
            tf[t] += 1
        avgdl = self.avgdl or 1.0
        norm = self.k1 * (1.0 - self.b + self.b * len(toks) / avgdl)
        return {t: self.idf(t) * f * (self.k1 + 1.0) / (f + norm) for t, f in tf.items()}

    def encode_query(self, text: str) -> SparseVector:
        return dict.fromkeys(set(self.tokenize(text)), 1.0)


class InvertedIndex:
    """Índice invertido para vetores esparsos, com produto interno e top-k por heap."""

    def __init__(self) -> None:
        self._postings: dict[str, dict[str, float]] = defaultdict(dict)
        self._docs: dict[str, SparseVector] = {}

    def __len__(self) -> int:
        return len(self._docs)

    def __contains__(self, doc_id: str) -> bool:
        return doc_id in self._docs

    def add(self, doc_id: str, vector: SparseVector) -> None:
        if doc_id in self._docs:
            self.remove(doc_id)
        self._docs[doc_id] = dict(vector)
        for term, w in vector.items():
            if w != 0.0:
                self._postings[term][doc_id] = w

    def remove(self, doc_id: str) -> bool:
        vec = self._docs.pop(doc_id, None)
        if vec is None:
            return False
        for term in vec:
            p = self._postings.get(term)
            if p is not None:
                p.pop(doc_id, None)
                if not p:
                    self._postings.pop(term, None)
        return True

    def search(
        self, query: SparseVector, top_k: int = 10, *, allowed: Callable[[str], bool] | None = None
    ) -> list[tuple[str, float]]:
        if not query or not self._docs or top_k <= 0:
            return []
        scores: dict[str, float] = defaultdict(float)
        for term, qw in query.items():
            if qw == 0.0:
                continue
            for doc_id, dw in self._postings.get(term, {}).items():
                scores[doc_id] += qw * dw
        items = ((-s, d) for d, s in scores.items() if allowed is None or allowed(d))
        return [(d, -ns) for ns, d in heapq.nsmallest(top_k, items)]

    def vector(self, doc_id: str) -> SparseVector | None:
        return self._docs.get(doc_id)


class DocExpander:
    """doc2query: anexa ao texto perguntas que ele responde, antes de indexar.

    `generate(text) -> list[str]` é normalmente um modelo (T5 doc2query ou um
    LLM via `Provider`); nos testes é uma função. `keep_original` mantém o
    texto para a leitura — a expansão só existe para o índice.
    """

    def __init__(self, generate: Callable[[str], Sequence[str]], *, max_queries: int = 5) -> None:
        self.generate = generate
        self.max_queries = max_queries

    def expand(self, text: str) -> str:
        qs = [q.strip() for q in self.generate(text) if q and q.strip()][: self.max_queries]
        return text + ("\n" + "\n".join(qs) if qs else "")


class FastEmbedSparse:
    """SPLADE++ (ou BM42) em ONNX via FastEmbed, como `SparseEncoder`.

    `prithivida/Splade_PP_en_v1` é o esparso aprendido; `Qdrant/bm42` é a
    variante por atenção. Ambos produzem `{token_id: peso}` — o índice não
    sabe que os termos são ids, e não precisa saber.
    """

    def __init__(self, model: str = "prithivida/Splade_PP_en_v1") -> None:
        from fastembed import SparseTextEmbedding

        from .embed import fastembed_cache_dir

        self.model_name = model
        self._model = SparseTextEmbedding(model, cache_dir=fastembed_cache_dir())

    @staticmethod
    def _to_dict(emb) -> SparseVector:
        return {str(int(i)): float(v) for i, v in zip(emb.indices, emb.values, strict=True)}

    def encode_query(self, text: str) -> SparseVector:
        return self._to_dict(next(iter(self._model.query_embed([text]))))

    def encode_document(self, text: str) -> SparseVector:
        return self._to_dict(next(iter(self._model.embed([text]))))

    def encode_documents(self, texts: Sequence[str]) -> list[SparseVector]:
        return [self._to_dict(e) for e in self._model.embed(list(texts))]
