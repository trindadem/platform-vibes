"""Segmentação de documentos: do padrão de produção ao experimental.

O que se recupera é o *trecho*, não o documento; a unidade de segmentação
decide o que o embedding consegue representar e o que o modelo consegue ler.
Há cinco estratégias aqui, marcadas pelo regime:

| estratégia | regime | origem |
|---|---|---|
| `FixedChunker` | indústria | janela fixa com sobreposição — a linha de base de todo benchmark |
| `RecursiveChunker` | indústria | separadores hierárquicos (parágrafo > linha > sentença > palavra); o `RecursiveCharacterTextSplitter` do LangChain |
| `SentenceChunker` | indústria | janelas que respeitam fronteira de sentença |
| `SemanticChunker` | experimental | corte onde o embedding "vira" (Kamradt, 2024); Qu et al. (2024, arXiv:2410.13070) mediram que o custo não se paga de forma consistente — por isso está aqui *e* está medido |
| `ContextualChunker` | indústria | *Contextual Retrieval* (Anthropic, 2024): um prefixo de contexto do documento por trecho; -49% de falhas de recuperação com BM25 contextual, -67% com reranking |
| `LateChunker` | experimental | *late chunking* (Günther et al., 2024, arXiv:2409.04701): embutir o documento inteiro e agrupar os vetores de token depois — o trecho carrega o contexto dos vizinhos |

Todo `Chunk` guarda `start`/`end` em caracteres do documento original: um
trecho recuperado precisa apontar para onde veio (auditoria) e o late
chunking precisa dos intervalos para agrupar tokens.
"""

from __future__ import annotations

from collections.abc import Callable, Sequence
from dataclasses import dataclass, field
from typing import Any, Protocol, runtime_checkable

from ..memory.core.budget import CHARS_PER_TOKEN
from ..memory.core.embeddings import Embedder
from ..memory.core.similarity import cosine
from ..memory.core.summarize import split_sentences
from .embed import TokenEmbedder

__all__ = [
    "Chunk",
    "Chunker",
    "ContextualChunker",
    "FixedChunker",
    "LateChunker",
    "RecursiveChunker",
    "SemanticChunker",
    "SentenceChunker",
    "chunk_id",
]


def chunk_id(doc_id: str, index: int) -> str:
    return f"{doc_id}#{index}"


@dataclass(slots=True)
class Chunk:
    doc_id: str
    index: int
    text: str
    start: int
    end: int
    metadata: dict[str, Any] = field(default_factory=dict)
    #: prefixo de contexto (Contextual Retrieval); entra no embedding e no BM25,
    #: mas não substitui `text`, que é o que o modelo lê com a citação
    context: str = ""
    #: vetor pré-computado (late chunking); `None` -> o pipeline codifica `text_for_embedding`
    embedding: tuple[float, ...] | None = None

    @property
    def id(self) -> str:
        return chunk_id(self.doc_id, self.index)

    @property
    def text_for_embedding(self) -> str:
        return f"{self.context}\n\n{self.text}" if self.context else self.text

    def to_dict(self) -> dict[str, Any]:
        return {
            "id": self.id,
            "doc_id": self.doc_id,
            "index": self.index,
            "text": self.text,
            "start": self.start,
            "end": self.end,
            "metadata": self.metadata,
            "context": self.context,
        }


@runtime_checkable
class Chunker(Protocol):
    def chunk(self, doc_id: str, text: str, metadata: dict[str, Any] | None = None) -> list[Chunk]: ...


def _unit_size(size: int, unit: str) -> int:
    if unit == "tokens":
        return int(size * CHARS_PER_TOKEN)
    if unit != "chars":
        raise ValueError("unit deve ser 'chars' ou 'tokens'")
    return size


def _make(doc_id: str, pieces: Sequence[tuple[int, int]], text: str, metadata: dict[str, Any] | None) -> list[Chunk]:
    out: list[Chunk] = []
    for a, b in pieces:
        seg = text[a:b]
        if not seg.strip():
            continue
        # apara espaço nas bordas mantendo offsets corretos
        lead = len(seg) - len(seg.lstrip())
        trail = len(seg) - len(seg.rstrip())
        out.append(
            Chunk(
                doc_id=doc_id,
                index=len(out),
                text=seg.strip(),
                start=a + lead,
                end=b - trail,
                metadata=dict(metadata or {}),
            )
        )
    return out


class FixedChunker:
    """Janela fixa com sobreposição. `unit='tokens'` usa a razão chars/token calibrada."""

    def __init__(self, size: int = 800, overlap: int = 100, *, unit: str = "chars") -> None:
        if overlap >= size:
            raise ValueError("overlap deve ser menor que size")
        self.size = _unit_size(size, unit)
        self.overlap = _unit_size(overlap, unit)

    def chunk(self, doc_id: str, text: str, metadata: dict[str, Any] | None = None) -> list[Chunk]:
        if not text:
            return []
        step = self.size - self.overlap
        pieces = [(a, min(a + self.size, len(text))) for a in range(0, max(len(text) - self.overlap, 1), step)]
        return _make(doc_id, pieces, text, metadata)


class RecursiveChunker:
    """Separadores hierárquicos: tenta parágrafo, depois linha, sentença, palavra.

    Um pedaço maior que `size` é re-dividido pelo separador seguinte; pedaços
    consecutivos são fundidos até `size`, e a sobreposição reaproveita os
    últimos pedaços do trecho anterior (nunca corta no meio de um pedaço).
    """

    def __init__(
        self,
        size: int = 800,
        overlap: int = 100,
        *,
        unit: str = "chars",
        separators: Sequence[str] = ("\n\n", "\n", ". ", "; ", ", ", " ", ""),
    ) -> None:
        if overlap >= size:
            raise ValueError("overlap deve ser menor que size")
        self.size = _unit_size(size, unit)
        self.overlap = _unit_size(overlap, unit)
        self.separators = tuple(separators)

    def _split(self, text: str, base: int, level: int) -> list[tuple[int, int]]:
        if len(text) <= self.size or level >= len(self.separators):
            return [(base, base + len(text))]
        sep = self.separators[level]
        if sep == "":
            return [(base + i, base + min(i + self.size, len(text))) for i in range(0, len(text), self.size)]
        parts: list[tuple[int, int]] = []
        pos = 0
        while pos <= len(text):
            nxt = text.find(sep, pos)
            end = len(text) if nxt < 0 else nxt + len(sep)
            if end > pos:
                parts.append((pos, end))
            if nxt < 0:
                break
            pos = end
        if len(parts) <= 1:
            return self._split(text, base, level + 1)
        out: list[tuple[int, int]] = []
        for a, b in parts:
            piece = text[a:b]
            if len(piece) > self.size:
                out.extend(self._split(piece, base + a, level + 1))
            else:
                out.append((base + a, base + b))
        return out

    def chunk(self, doc_id: str, text: str, metadata: dict[str, Any] | None = None) -> list[Chunk]:
        if not text:
            return []
        atoms = self._split(text, 0, 0)
        windows: list[tuple[int, int]] = []
        cur: list[tuple[int, int]] = []
        cur_len = 0
        for a, b in atoms:
            ln = b - a
            if cur and cur_len + ln > self.size:
                windows.append((cur[0][0], cur[-1][1]))
                # sobreposição: mantém os últimos átomos que cabem em `overlap`
                keep: list[tuple[int, int]] = []
                acc = 0
                for x in reversed(cur):
                    if acc + (x[1] - x[0]) > self.overlap:
                        break
                    keep.insert(0, x)
                    acc += x[1] - x[0]
                cur = keep
                cur_len = acc
            cur.append((a, b))
            cur_len += ln
        if cur:
            windows.append((cur[0][0], cur[-1][1]))
        return _make(doc_id, windows, text, metadata)


class SentenceChunker:
    """Janelas de sentenças inteiras, com sobreposição em sentenças."""

    def __init__(self, max_chars: int = 600, overlap_sentences: int = 1) -> None:
        self.max_chars = max_chars
        self.overlap_sentences = overlap_sentences

    def _sentences(self, text: str) -> list[tuple[int, int]]:
        spans: list[tuple[int, int]] = []
        pos = 0
        for s in split_sentences(text):
            i = text.find(s, pos)
            if i < 0:
                continue
            spans.append((i, i + len(s)))
            pos = i + len(s)
        return spans

    def chunk(self, doc_id: str, text: str, metadata: dict[str, Any] | None = None) -> list[Chunk]:
        spans = self._sentences(text)
        if not spans:
            return []
        windows: list[tuple[int, int]] = []
        cur: list[tuple[int, int]] = []
        size = 0
        for a, b in spans:
            if cur and size + (b - a) > self.max_chars:
                windows.append((cur[0][0], cur[-1][1]))
                cur = cur[-self.overlap_sentences :] if self.overlap_sentences > 0 else []
                size = sum(y - x for x, y in cur)
            cur.append((a, b))
            size += b - a + 1
        if cur:
            windows.append((cur[0][0], cur[-1][1]))
        return _make(doc_id, windows, text, metadata)


class SemanticChunker:
    """Corta onde a similaridade entre sentenças vizinhas cai abaixo do percentil.

    Cada sentença é embutida com `buffer` vizinhas de cada lado (suaviza o
    sinal); a distância `1 - cos` entre janelas consecutivas acima do percentil
    `breakpoint_percentile` é um ponto de corte. `max_chars` e `min_chars`
    domam os extremos: grupos enormes são re-divididos por sentença, grupos
    minúsculos são fundidos ao vizinho.
    """

    def __init__(
        self,
        embedder: Embedder,
        *,
        breakpoint_percentile: float = 90.0,
        buffer: int = 1,
        max_chars: int = 1500,
        min_chars: int = 120,
    ) -> None:
        self.embedder = embedder
        self.breakpoint_percentile = breakpoint_percentile
        self.buffer = buffer
        self.max_chars = max_chars
        self.min_chars = min_chars
        self._sent = SentenceChunker(max_chars=max_chars, overlap_sentences=0)

    def chunk(self, doc_id: str, text: str, metadata: dict[str, Any] | None = None) -> list[Chunk]:
        spans = self._sent._sentences(text)
        if not spans:
            return []
        if len(spans) == 1:
            return _make(doc_id, spans, text, metadata)
        sents = [text[a:b] for a, b in spans]
        windows = [
            " ".join(sents[max(0, i - self.buffer) : i + self.buffer + 1]) for i in range(len(sents))
        ]
        vecs = self.embedder.encode_batch(windows)
        dists = [1.0 - cosine(vecs[i], vecs[i + 1]) for i in range(len(vecs) - 1)]
        ordered = sorted(dists)
        pos = self.breakpoint_percentile / 100.0 * (len(ordered) - 1)
        lo = int(pos)
        hi = min(lo + 1, len(ordered) - 1)
        threshold = ordered[lo] + (ordered[hi] - ordered[lo]) * (pos - lo)
        groups: list[list[tuple[int, int]]] = [[spans[0]]]
        for i, d in enumerate(dists):
            if d > threshold and len(ordered) > 1:
                groups.append([spans[i + 1]])
            else:
                groups[-1].append(spans[i + 1])
        # min_chars: funde grupos pequenos ao anterior
        merged: list[list[tuple[int, int]]] = []
        for g in groups:
            size = g[-1][1] - g[0][0]
            if merged and size < self.min_chars:
                merged[-1].extend(g)
            else:
                merged.append(g)
        pieces: list[tuple[int, int]] = []
        for g in merged:
            a, b = g[0][0], g[-1][1]
            if b - a > self.max_chars:
                sub = self._sent.chunk(doc_id, text[a:b])
                pieces.extend((a + c.start, a + c.end) for c in sub)
            else:
                pieces.append((a, b))
        return _make(doc_id, pieces, text, metadata)


Contextualizer = Callable[[str, dict[str, Any], "Chunk", int], str]


def default_contextualizer(doc_text: str, metadata: dict[str, Any], chunk: Chunk, total: int) -> str:
    """Contexto barato e offline: título (ou primeira sentença) e posição no documento.

    O contexto do artigo da Anthropic é gerado por um modelo com o documento
    inteiro no cache de prompt; `ContextualChunker(provider_contextualizer(...))`
    faz isso. Este padrão é o que dá para ter sem modelo: já recupera a
    ancoragem ao documento que o corte destrói.
    """
    title = str(metadata.get("title") or "").strip()
    if not title:
        first = split_sentences(doc_text[:400])
        title = first[0][:160] if first else ""
    return f"Documento: {title}. Trecho {chunk.index + 1} de {total}." if title else f"Trecho {chunk.index + 1} de {total}."


class ContextualChunker:
    """Aplica um contextualizador a cada trecho de um segmentador base."""

    def __init__(self, base: Chunker, contextualizer: Contextualizer | None = None) -> None:
        self.base = base
        self.contextualizer = contextualizer or default_contextualizer

    def chunk(self, doc_id: str, text: str, metadata: dict[str, Any] | None = None) -> list[Chunk]:
        chunks = self.base.chunk(doc_id, text, metadata)
        meta = dict(metadata or {})
        for c in chunks:
            c.context = self.contextualizer(text, meta, c, len(chunks)).strip()
        return chunks


class LateChunker:
    """Late chunking: embute o documento inteiro, agrupa os vetores por trecho.

    Só é *contextual* se o `TokenEmbedder` for (um transformer de contexto
    longo). Com `HashingTokenEmbedder` a mecânica é a mesma e o ganho é nulo
    por construção — é isso que o teste verifica e o estudo diz.
    `max_doc_chars` protege contra a janela do modelo: documentos maiores são
    embutidos por segmentos macro e agrupados dentro de cada segmento.
    """

    def __init__(self, token_embedder: TokenEmbedder, base: Chunker, *, max_doc_chars: int = 8000) -> None:
        self.token_embedder = token_embedder
        self.base = base
        self.max_doc_chars = max_doc_chars
        self.dim = token_embedder.dim

    def chunk(self, doc_id: str, text: str, metadata: dict[str, Any] | None = None) -> list[Chunk]:
        chunks = self.base.chunk(doc_id, text, metadata)
        if not chunks:
            return []
        # macro-segmentos que cabem na janela do modelo, cortados em fronteira de trecho
        segments: list[tuple[int, int, list[Chunk]]] = []
        cur: list[Chunk] = []
        for c in chunks:
            if cur and c.end - cur[0].start > self.max_doc_chars:
                segments.append((cur[0].start, cur[-1].end, cur))
                cur = []
            cur.append(c)
        if cur:
            segments.append((cur[0].start, cur[-1].end, cur))
        for a, b, group in segments:
            te = self.token_embedder.encode_tokens(text[a:b])
            for c in group:
                c.embedding = te.pool(c.start - a, c.end - a)
        return chunks


