"""Quantização de vetores: escalar (int8), binária e por produto (PQ).

O custo de um índice vetorial é memória: 10^6 vetores de 1024 floats são
4 GB. Três reduções, em ordem de agressividade e de idade:

* **Escalar int8** (4x): `x -> round((x - lo) / (hi - lo) * 255)` por
  dimensão; o produto interno sai da forma afim `q.(s*c + o) = (q*s).c + q.o`
  sem decodificar. Perda de recall quase nula; é o padrão "int8" do Qdrant,
  Elastic e do sentence-transformers.
* **Binária** (32x): o sinal de cada dimensão. Hamming gera candidatos;
  o *rescoring assimétrico* (consulta em float contra documento em ±1)
  recupera a maior parte da qualidade — Shakir, Aarsen & Lee (2024) medem
  ~96% do desempenho com rescoring em embeddings de 1024d. Em dimensões
  baixas (256-384) a perda é maior, e é medida aqui.
* **PQ** (Jégou, Douze & Schmid, 2011; 8x-64x): divide o vetor em `m`
  sub-vetores, cada um quantizado por um codebook de 256 centróides
  (k-means); a distância é somada de tabelas de lookup (ADC — *asymmetric
  distance computation*). É o segundo estágio do IVF-PQ do FAISS e do
  DiskANN.

RaBitQ (Gao & Long, 2024) dá à quantização binária um limite de erro com
garantia teórica via rotação aleatória; a rotação está implementada
(`BinaryQuantizer(rotate=True)`) — ela descorrelaciona as dimensões antes do
sinal, que é a parte que importa para a distribuição de erro; o estimador
não enviesado completo do RaBitQ fica como trabalho futuro declarado.

`QuantizedIndex` embrulha um quantizador: varre códigos, pega `rescore * k`
candidatos e reordena com os floats originais (mantidos por padrão; em
produção ficam em disco). Sem rescoring, o índice devolve o score do código.
"""

from __future__ import annotations

import heapq
import math
from collections.abc import Sequence
from typing import Any, Protocol, runtime_checkable

from ._matrix import HAS_NUMPY, Matrix, kmeans, np
from .base import Allowed, Hit

__all__ = ["BinaryQuantizer", "ProductQuantizer", "QuantizedIndex", "Quantizer", "ScalarQuantizer"]


@runtime_checkable
class Quantizer(Protocol):
    dim: int

    def fit(self, vectors: Sequence[Sequence[float]]) -> None: ...

    def encode(self, vector: Sequence[float]) -> Any: ...

    def scores(self, query: Sequence[float], codes: Sequence[Any]) -> list[float]: ...

    @property
    def bytes_per_vector(self) -> int: ...


def _norm(v: Sequence[float]) -> list[float]:
    n = math.sqrt(sum(x * x for x in v))
    return [float(x) / n for x in v] if n > 1e-12 else [float(x) for x in v]


class ScalarQuantizer:
    """uint8 por dimensão, com limites por dimensão (ou globais) ajustados em `fit`."""

    def __init__(self, dim: int, *, per_dimension: bool = True, clip_quantile: float = 0.999) -> None:
        self.dim = dim
        self.per_dimension = per_dimension
        self.clip_quantile = clip_quantile
        self._lo: Any = None
        self._scale: Any = None

    @property
    def bytes_per_vector(self) -> int:
        return self.dim

    def fit(self, vectors: Sequence[Sequence[float]]) -> None:
        if not vectors:
            raise ValueError("fit sem vetores")
        if HAS_NUMPY:
            X = np.asarray(vectors, dtype=np.float32)
            q = self.clip_quantile
            if self.per_dimension:
                lo = np.quantile(X, 1 - q, axis=0)
                hi = np.quantile(X, q, axis=0)
            else:
                lo = np.full(self.dim, float(np.quantile(X, 1 - q)), dtype=np.float32)
                hi = np.full(self.dim, float(np.quantile(X, q)), dtype=np.float32)
            scale = (hi - lo) / 255.0
            scale[scale < 1e-9] = 1e-9
            self._lo, self._scale = lo.astype(np.float32), scale.astype(np.float32)
            return
        cols = list(zip(*[list(map(float, v)) for v in vectors], strict=True))
        lo_l, hi_l = [], []
        for col in cols:
            s = sorted(col)
            lo_l.append(s[int((1 - self.clip_quantile) * (len(s) - 1))])
            hi_l.append(s[int(self.clip_quantile * (len(s) - 1))])
        if not self.per_dimension:
            lo_l = [min(lo_l)] * self.dim
            hi_l = [max(hi_l)] * self.dim
        self._lo = lo_l
        self._scale = [max((h - lo) / 255.0, 1e-9) for lo, h in zip(lo_l, hi_l, strict=True)]

    def encode(self, vector: Sequence[float]) -> Any:
        if self._lo is None:
            raise RuntimeError("fit antes de encode")
        if HAS_NUMPY:
            x = np.asarray(vector, dtype=np.float32)
            return np.clip(np.rint((x - self._lo) / self._scale), 0, 255).astype(np.uint8)
        return bytes(
            min(255, max(0, round((float(x) - lo) / s))) for x, lo, s in zip(vector, self._lo, self._scale, strict=True)
        )

    def decode(self, code: Any) -> list[float]:
        if HAS_NUMPY:
            return (np.asarray(code, dtype=np.float32) * self._scale + self._lo).tolist()
        return [c * s + lo for c, s, lo in zip(code, self._scale, self._lo, strict=True)]

    def scores(self, query: Sequence[float], codes: Sequence[Any]) -> list[float]:
        """Produto interno q.(s*c + lo) = (q*s).c + q.lo, sem decodificar."""
        if not codes:
            return []
        if HAS_NUMPY:
            q = np.asarray(query, dtype=np.float32)
            qs = q * self._scale
            const = float(q @ self._lo)
            C = np.stack([np.asarray(c, dtype=np.float32) for c in codes])
            return [float(x) for x in C @ qs + const]
        qs = [float(a) * s for a, s in zip(query, self._scale, strict=True)]
        const = sum(float(a) * lo for a, lo in zip(query, self._lo, strict=True))
        return [sum(w * c for w, c in zip(qs, code, strict=True)) + const for code in codes]


class BinaryQuantizer:
    """Sinal por dimensão, empacotado em bits. `rotate=True` aplica uma rotação
    aleatória ortogonal (RaBitQ) antes do sinal.

    `scores` é o *assimétrico*: consulta em float contra documento em ±1 —
    `sum(q_i * sign(x_i))`. `hamming` é o simétrico (popcount), mais barato e
    pior; serve para gerar candidatos. Com numpy os códigos são `uint8`
    empacotados (`np.packbits`) e o score desempacota por consulta; sem numpy
    o código é um `int` e o laço é em Python.
    """

    def __init__(self, dim: int, *, rotate: bool = False, seed: int = 0) -> None:
        self.dim = dim
        self.rotate = rotate
        self.seed = seed
        self._R: Any = None

    @property
    def bytes_per_vector(self) -> int:
        return (self.dim + 7) // 8

    def fit(self, vectors: Sequence[Sequence[float]]) -> None:
        if self.rotate and HAS_NUMPY:
            rng = np.random.default_rng(self.seed)
            A = rng.normal(size=(self.dim, self.dim)).astype(np.float32)
            Q, _ = np.linalg.qr(A)
            self._R = Q.astype(np.float32)

    def _rot(self, v: Sequence[float]) -> Any:
        if self._R is not None:
            return np.asarray(v, dtype=np.float32) @ self._R
        return np.asarray(v, dtype=np.float32) if HAS_NUMPY else [float(x) for x in v]

    def encode(self, vector: Sequence[float]) -> Any:
        x = self._rot(vector)
        if HAS_NUMPY:
            return np.packbits((x > 0).astype(np.uint8), bitorder="little")
        bits = 0
        for i, val in enumerate(x):
            if float(val) > 0:
                bits |= 1 << i
        return bits

    def hamming(self, a: Any, b: Any) -> int:
        if HAS_NUMPY:
            return int(np.unpackbits(np.bitwise_xor(a, b)).sum())
        return (a ^ b).bit_count()

    def scores(self, query: Sequence[float], codes: Sequence[Any]) -> list[float]:
        if not codes:
            return []
        q = self._rot(query)
        if HAS_NUMPY:
            qf = np.asarray(q, dtype=np.float32)
            packed = np.stack(codes)
            bits = np.unpackbits(packed, axis=1, bitorder="little")[:, : self.dim].astype(np.float32)
            # sum(q_i * sign_i) = 2*sum_{bit=1} q_i - sum(q_i)
            return [float(x) for x in 2.0 * (bits @ qf) - float(qf.sum())]
        qf_l = [float(x) for x in q]
        total = sum(qf_l)
        out: list[float] = []
        for code in codes:
            pos = 0.0
            c = code
            i = 0
            while c:
                if c & 1:
                    pos += qf_l[i]
                c >>= 1
                i += 1
            out.append(2.0 * pos - total)
        return out


class ProductQuantizer:
    """PQ com `m` sub-espaços e 2^nbits centróides cada (padrão: 8 bits = 256)."""

    def __init__(self, dim: int, *, m: int = 8, nbits: int = 8, seed: int = 0, iterations: int = 12) -> None:
        if dim % m != 0:
            raise ValueError(f"dim {dim} não é divisível por m={m}")
        self.dim = dim
        self.m = m
        self.k = 1 << nbits
        self.sub = dim // m
        self.seed = seed
        self.iterations = iterations
        self._codebooks: list[Any] = []

    @property
    def bytes_per_vector(self) -> int:
        return self.m * (1 if self.k <= 256 else 2)

    def fit(self, vectors: Sequence[Sequence[float]]) -> None:
        if not vectors:
            raise ValueError("fit sem vetores")
        k = min(self.k, len(vectors))
        self._codebooks = []
        if HAS_NUMPY:
            X = np.asarray(vectors, dtype=np.float32)
            for j in range(self.m):
                C, _ = kmeans(X[:, j * self.sub : (j + 1) * self.sub], k, seed=self.seed + j, iterations=self.iterations)
                self._codebooks.append(C)
            return
        rows = [list(map(float, v)) for v in vectors]
        for j in range(self.m):
            part = [r[j * self.sub : (j + 1) * self.sub] for r in rows]
            C, _ = kmeans(part, k, seed=self.seed + j, iterations=self.iterations)
            self._codebooks.append(C)

    def encode(self, vector: Sequence[float]) -> Any:
        if not self._codebooks:
            raise RuntimeError("fit antes de encode")
        if HAS_NUMPY:
            x = np.asarray(vector, dtype=np.float32)
            codes = []
            for j, C in enumerate(self._codebooks):
                s = x[j * self.sub : (j + 1) * self.sub]
                d = ((C - s) ** 2).sum(axis=1)
                codes.append(int(d.argmin()))
            return np.asarray(codes, dtype=np.uint16 if self.k > 256 else np.uint8)
        codes_l: list[int] = []
        for j, C in enumerate(self._codebooks):
            sub_l: list[float] = [float(v) for v in vector[j * self.sub : (j + 1) * self.sub]]
            best = min(range(len(C)), key=lambda c: sum((a - b) ** 2 for a, b in zip(C[c], sub_l, strict=True)))
            codes_l.append(best)
        return codes_l

    def decode(self, code: Any) -> list[float]:
        out: list[float] = []
        for j, c in enumerate(code):
            cb = self._codebooks[j][int(c)]
            out.extend(float(x) for x in cb)
        return out

    def scores(self, query: Sequence[float], codes: Sequence[Any]) -> list[float]:
        """ADC: tabela m x k de produtos internos consulta-centróide, somada por código."""
        if not codes:
            return []
        if HAS_NUMPY:
            q = np.asarray(query, dtype=np.float32)
            table = np.stack([C @ q[j * self.sub : (j + 1) * self.sub] for j, C in enumerate(self._codebooks)])
            Cd = np.stack([np.asarray(c, dtype=np.int64) for c in codes])
            cols = np.arange(self.m)
            return [float(x) for x in table[cols, Cd].sum(axis=1)]
        table_l: list[list[float]] = []
        for j, C in enumerate(self._codebooks):
            qs = [float(v) for v in query[j * self.sub : (j + 1) * self.sub]]
            table_l.append([sum(a * b for a, b in zip(c, qs, strict=True)) for c in C])
        return [sum(table_l[j][int(c)] for j, c in enumerate(code)) for code in codes]


class QuantizedIndex:
    """Varredura sobre códigos + rescoring com floats.

    `rescore=0` desliga o rescoring (score do código). `keep_full=False`
    descarta os floats — aí `rescore` precisa ser 0.
    """

    def __init__(
        self,
        quantizer: Quantizer,
        *,
        rescore: int = 4,
        keep_full: bool = True,
        metric: str = "cosine",
        train_on_first: int = 4096,
    ) -> None:
        self.q = quantizer
        self.dim = quantizer.dim
        self.rescore = rescore
        self.keep_full = keep_full
        self.metric = metric
        self.train_on_first = train_on_first
        if rescore and not keep_full:
            raise ValueError("rescore exige keep_full=True")
        self._full = Matrix(self.dim, metric=metric) if keep_full else None
        self._codes: list[Any] = []
        self._ids: list[str] = []
        self._row: dict[str, int] = {}
        self._deleted: set[int] = set()
        self._fitted = False
        self._pending: list[tuple[str, list[float]]] = []

    def __len__(self) -> int:
        return len(self._row)

    def __contains__(self, id: str) -> bool:
        return id in self._row

    def _prep(self, v: Sequence[float]) -> list[float]:
        return _norm(v) if self.metric == "cosine" else [float(x) for x in v]

    def fit(self, vectors: Sequence[Sequence[float]]) -> None:
        self.q.fit([self._prep(v) for v in vectors])
        self._fitted = True

    def add(self, ids: Sequence[str], vectors: Sequence[Sequence[float]]) -> None:
        if len(ids) != len(vectors):
            raise ValueError("ids e vectors com tamanhos diferentes")
        if not self._fitted:
            sample = [self._prep(v) for v in vectors[: self.train_on_first]]
            if len(sample) < 2:
                sample = sample * 2
            self.q.fit(sample)
            self._fitted = True
        for id_, v in zip(ids, vectors, strict=True):
            if id_ in self._row:
                self.remove(id_)
            p = self._prep(v)
            row = len(self._ids)
            self._ids.append(id_)
            self._row[id_] = row
            self._codes.append(self.q.encode(p))
            if self._full is not None:
                self._full.append_raw(p)

    def remove(self, id: str) -> bool:
        row = self._row.pop(id, None)
        if row is None:
            return False
        self._deleted.add(row)
        return True

    def search(self, vector: Sequence[float], k: int, *, allowed: Allowed | None = None) -> list[Hit]:
        if k <= 0 or not self._row:
            return []
        qv = self._prep(vector)
        rows = [r for r in range(len(self._ids)) if r not in self._deleted and (allowed is None or allowed(self._ids[r]))]
        if not rows:
            return []
        approx = self.q.scores(qv, [self._codes[r] for r in rows])
        n_cand = k * self.rescore if self.rescore else k
        cands = heapq.nsmallest(n_cand, ((-s, r) for s, r in zip(approx, rows, strict=True)))
        if self.rescore and self._full is not None:
            crow = [r for _, r in cands]
            exact = self._full.scores(self._full.prepare(qv), crow)
            best = heapq.nsmallest(k, ((-s, self._ids[r]) for s, r in zip(exact, crow, strict=True)))
            return [(i, -s) for s, i in best]
        return [(self._ids[r], -s) for s, r in cands[:k]]

    def memory_bytes(self) -> int:
        return self.q.bytes_per_vector * (len(self._ids) - len(self._deleted))


