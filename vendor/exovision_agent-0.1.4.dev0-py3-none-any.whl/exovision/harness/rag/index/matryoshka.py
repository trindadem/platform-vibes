"""Recuperação adaptativa Matryoshka (Kusupati et al., 2022) — experimental.

Um embedding treinado com MRL (*Matryoshka Representation Learning*) tem a
propriedade de que os primeiros `d'` componentes já são um embedding válido:
a informação está ordenada por importância. Isso permite o **funil**
(*adaptive retrieval*): pré-selecionar com `d' << d` (barato) e reordenar
os `rescore * k` melhores com o vetor inteiro. O OpenAI `text-embedding-3`,
o nomic-embed e o jina-v3 são MRL; o bge-small e o potion **não** são — e o
funil ainda funciona neles, com perda maior, o que é medido aqui
(`docs/rag/resultados/ann_scifact_{model2vec,fastembed}.json`, sistemas `matryoshka64`/`matryoshka128`): é a evidência de que o
truque exige o treino, não só a truncagem.

O índice interno é injetável (`FlatIndex` por padrão, `HNSWIndex` para
escala); ele vê apenas os `dims` primeiros componentes, renormalizados.
"""

from __future__ import annotations

import heapq
from collections.abc import Callable, Sequence

from ._matrix import Matrix
from .base import Allowed, Hit, VectorIndex
from .flat import FlatIndex

__all__ = ["MatryoshkaIndex"]


class MatryoshkaIndex:
    def __init__(
        self,
        dim: int,
        *,
        dims: int = 64,
        rescore: int = 8,
        metric: str = "cosine",
        inner: Callable[[int], VectorIndex] | None = None,
    ) -> None:
        if not 0 < dims <= dim:
            raise ValueError("dims deve estar em (0, dim]")
        self.dim = dim
        self.dims = dims
        self.rescore = rescore
        self.metric = metric
        self._inner: VectorIndex = (inner or (lambda d: FlatIndex(d, metric=metric)))(dims)
        self._full = Matrix(dim, metric=metric)
        self._ids: list[str] = []
        self._row: dict[str, int] = {}
        self._deleted: set[int] = set()

    def __len__(self) -> int:
        return len(self._row)

    def __contains__(self, id: str) -> bool:
        return id in self._row

    def _prefix(self, v: Sequence[float]) -> list[float]:
        return [float(x) for x in v[: self.dims]]

    def add(self, ids: Sequence[str], vectors: Sequence[Sequence[float]]) -> None:
        if len(ids) != len(vectors):
            raise ValueError("ids e vectors com tamanhos diferentes")
        for id_, v in zip(ids, vectors, strict=True):
            if id_ in self._row:
                self.remove(id_)
            row = self._full.append(v)
            self._ids.append(id_)
            self._row[id_] = row
        self._inner.add(list(ids), [self._prefix(v) for v in vectors])

    def remove(self, id: str) -> bool:
        row = self._row.pop(id, None)
        if row is None:
            return False
        self._deleted.add(row)
        self._inner.remove(id)
        return True

    def search(self, vector: Sequence[float], k: int, *, allowed: Allowed | None = None) -> list[Hit]:
        if k <= 0 or not self._row:
            return []
        n_cand = max(k, k * self.rescore)
        cands = self._inner.search(self._prefix(vector), n_cand, allowed=allowed)
        rows = [self._row[i] for i, _ in cands if i in self._row]
        if not rows:
            return []
        exact = self._full.scores(self._full.prepare(vector), rows)
        best = heapq.nsmallest(k, ((-s, self._ids[r]) for s, r in zip(exact, rows, strict=True)))
        return [(i, -s) for s, i in best]
