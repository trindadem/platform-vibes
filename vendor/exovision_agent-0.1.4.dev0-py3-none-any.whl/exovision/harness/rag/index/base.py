"""O contrato dos índices vetoriais."""

from __future__ import annotations

from collections.abc import Callable, Sequence
from typing import Protocol, runtime_checkable

__all__ = ["Allowed", "Hit", "VectorIndex"]

Hit = tuple[str, float]
Allowed = Callable[[str], bool]


@runtime_checkable
class VectorIndex(Protocol):
    """`add`, `remove`, `search`; scores com "maior é melhor".

    `allowed` é o filtro por metadado: o índice decide *como* honrá-lo
    (pós-filtro com `ef` inflado, pré-filtro por varredura) — o chamador só
    diz o que pode entrar.
    """

    dim: int

    def add(self, ids: Sequence[str], vectors: Sequence[Sequence[float]]) -> None: ...

    def remove(self, id: str) -> bool: ...

    def search(self, vector: Sequence[float], k: int, *, allowed: Allowed | None = None) -> list[Hit]: ...

    def __len__(self) -> int: ...
