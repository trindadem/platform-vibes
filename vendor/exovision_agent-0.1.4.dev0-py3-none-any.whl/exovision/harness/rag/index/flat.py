"""Índice plano: varredura exata. A verdade contra a qual todo ANN é medido."""

from __future__ import annotations

import heapq
import json
from collections.abc import Sequence
from typing import Any

from ._matrix import HAS_NUMPY, Matrix, np
from .base import Allowed, Hit

__all__ = ["FlatIndex"]


class FlatIndex:
    """Busca exata por produto interno / L2 sobre todas as linhas.

    O(N·d) por consulta. Em 10^4 vetores de 384 dimensões custa ~1 ms com
    numpy — muitas vezes é *o* índice certo; HNSW só compensa quando N
    passa das dezenas de milhares (Aumüller et al., 2020, ann-benchmarks).
    """

    def __init__(self, dim: int, *, metric: str = "cosine", use_numpy: bool | None = None) -> None:
        self.dim = dim
        self.metric = metric
        self._m = Matrix(dim, metric=metric, use_numpy=use_numpy)
        self._ids: list[str] = []
        self._row: dict[str, int] = {}
        self._deleted: set[int] = set()

    def __len__(self) -> int:
        return len(self._row)

    def __contains__(self, id: str) -> bool:
        return id in self._row

    def add(self, ids: Sequence[str], vectors: Sequence[Sequence[float]]) -> None:
        if len(ids) != len(vectors):
            raise ValueError("ids e vectors com tamanhos diferentes")
        for id_, v in zip(ids, vectors, strict=True):
            if id_ in self._row:
                self.remove(id_)
            row = self._m.append(v)
            self._ids.append(id_)
            self._row[id_] = row

    def remove(self, id: str) -> bool:
        row = self._row.pop(id, None)
        if row is None:
            return False
        self._deleted.add(row)
        return True

    def vector(self, id: str) -> Any:
        row = self._row.get(id)
        return None if row is None else self._m.get(row)

    def search(self, vector: Sequence[float], k: int, *, allowed: Allowed | None = None) -> list[Hit]:
        if k <= 0 or not self._row:
            return []
        q = self._m.prepare(vector)
        scores = self._m.scores_all(q)
        n = len(self._m)
        if HAS_NUMPY and self._m.numpy:
            if not self._deleted and allowed is None:
                kk = min(k, n)
                idx = np.argpartition(-scores, kk - 1)[:kk]
                order = sorted(((float(scores[i]), self._ids[i]) for i in idx), key=lambda t: (-t[0], t[1]))
                return [(i, s) for s, i in order]
            cands = ((-float(scores[r]), self._ids[r]) for r in range(n) if r not in self._deleted and (allowed is None or allowed(self._ids[r])))
            return [(i, -s) for s, i in heapq.nsmallest(k, cands)]
        cands = ((-float(scores[r]), self._ids[r]) for r in range(n) if r not in self._deleted and (allowed is None or allowed(self._ids[r])))
        return [(i, -s) for s, i in heapq.nsmallest(k, cands)]

    # ---------------------------------------------------------- persistência
    def to_dict(self) -> dict[str, Any]:
        live = [r for r in range(len(self._m)) if r not in self._deleted]
        return {
            "kind": "flat",
            "dim": self.dim,
            "metric": self.metric,
            "ids": [self._ids[r] for r in live],
            "vectors": [self._m.to_lists()[r] for r in live],
        }

    @classmethod
    def from_dict(cls, d: dict[str, Any]) -> FlatIndex:
        idx = cls(int(d["dim"]), metric=str(d.get("metric", "cosine")))
        idx.add(list(d["ids"]), list(d["vectors"]))
        return idx

    def save(self, path: str) -> None:
        with open(path, "w", encoding="utf-8") as fh:
            json.dump(self.to_dict(), fh)

    @classmethod
    def load(cls, path: str) -> FlatIndex:
        with open(path, encoding="utf-8") as fh:
            return cls.from_dict(json.load(fh))
