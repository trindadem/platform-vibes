"""HNSW — Hierarchical Navigable Small World (Malkov & Yashunin, 2016/2018).

O índice padrão dos bancos vetoriais (pgvector, Pinecone, Qdrant, Weaviate,
Elasticsearch). Uma pilha de grafos de proximidade: a camada de cima é
esparsa e serve para *navegar* (poucos saltos longos), a camada 0 contém
todos os pontos e serve para *refinar*. Cada nó recebe a camada máxima
`l = floor(-ln(U) * mL)`, `mL = 1/ln(M)` — geometria que dá busca em
`O(log N)` esperado.

Os quatro algoritmos do artigo estão aqui com os nomes do artigo:

* **INSERT** (Alg. 1): desce da entrada até a camada do nó com `ef=1`, e
  daí para baixo busca com `ef_construction` e conecta;
* **SEARCH-LAYER** (Alg. 2): beam search com dois heaps — candidatos
  (mínimo) e resultados (máximo, tamanho `ef`);
* **SELECT-NEIGHBORS-HEURISTIC** (Alg. 4): um candidato só entra se está
  mais perto do nó que de qualquer vizinho já escolhido — é o que mantém a
  navegabilidade em dados agrupados e o que distingue HNSW de um kNN-graph;
  `keep_pruned` completa até `M` com os descartados;
* **K-NN-SEARCH** (Alg. 5): desce com `ef=1` até a camada 1 e faz
  SEARCH-LAYER com `ef_search` na camada 0.

`M0 = 2M` na camada 0, como no artigo. `ef_search` é o botão que troca
recall por latência: medido neste repositório em
`docs/rag/resultados/ann_scifact_{model2vec,fastembed}.json`.

**Filtro.** `allowed` é honrado em *pós-filtro com ef inflado*: a travessia
visita todos os nós (o grafo precisa deles para navegar), mas só os
permitidos entram no resultado, e `ef` cresce com `1/seletividade`. Quando
o chamador informa que o subconjunto permitido é pequeno
(`allowed_count`), a busca degrada para varredura exata do subconjunto — a
estratégia do Qdrant, e a resposta ao problema que o ACORN (Patel et al.,
2024) formaliza: filtros muito seletivos desconectam o grafo.

**Remoção** é lápide: o nó continua navegável e some dos resultados;
`compact()` reconstrói. Exclusão física em grafo de proximidade quebra
caminhos, e o hnswlib faz o mesmo.
"""

from __future__ import annotations

import heapq
import json
import math
import random
import struct
from collections.abc import Sequence
from typing import Any

from ._matrix import Matrix
from .base import Allowed, Hit

__all__ = ["HNSWIndex"]


class HNSWIndex:
    def __init__(
        self,
        dim: int,
        *,
        M: int = 16,
        ef_construction: int = 200,
        ef_search: int = 64,
        metric: str = "cosine",
        seed: int = 0,
        keep_pruned: bool = True,
        extend_candidates: bool = False,
        use_numpy: bool | None = None,
    ) -> None:
        if M < 2:
            raise ValueError("M >= 2")
        self.dim = dim
        self.metric = metric
        self.M = M
        self.M0 = 2 * M
        self.ef_construction = max(ef_construction, M)
        self.ef_search = ef_search
        self.keep_pruned = keep_pruned
        self.extend_candidates = extend_candidates
        self._mL = 1.0 / math.log(M)
        self._rng = random.Random(seed)
        self._m = Matrix(dim, metric=metric, use_numpy=use_numpy)
        self._ids: list[str] = []
        self._row: dict[str, int] = {}
        self._level: list[int] = []
        self._nb: list[list[list[int]]] = []  # nó -> camada -> vizinhos
        self._entry: int = -1
        self._max_level: int = -1
        self._deleted: set[int] = set()
        self.distance_evals = 0  # instrumentação para os benchmarks

    # ------------------------------------------------------------ básico
    def __len__(self) -> int:
        return len(self._row)

    def __contains__(self, id: str) -> bool:
        return id in self._row

    def _dist(self, q: Any, rows: Sequence[int]) -> list[float]:
        """Distância = -score (menor é melhor)."""
        self.distance_evals += len(rows)
        return [-s for s in self._m.scores(q, rows)]

    # ------------------------------------------------------------ Alg. 2
    def _search_layer(self, q: Any, entry: Sequence[int], ef: int, layer: int) -> list[tuple[float, int]]:
        """Devolve até `ef` pares (dist, nó) ordenados por dist."""
        visited = set(entry)
        d0 = self._dist(q, list(entry))
        cand: list[tuple[float, int]] = list(zip(d0, entry, strict=True))
        heapq.heapify(cand)
        res: list[tuple[float, int]] = [(-d, n) for d, n in zip(d0, entry, strict=True)]
        heapq.heapify(res)
        while cand:
            d, c = heapq.heappop(cand)
            if d > -res[0][0] and len(res) >= ef:
                break
            fresh = [e for e in self._nb[c][layer] if e not in visited]
            if not fresh:
                continue
            visited.update(fresh)
            for de, e in zip(self._dist(q, fresh), fresh, strict=True):
                if len(res) < ef or de < -res[0][0]:
                    heapq.heappush(cand, (de, e))
                    heapq.heappush(res, (-de, e))
                    if len(res) > ef:
                        heapq.heappop(res)
        return sorted((-nd, n) for nd, n in res)

    # ------------------------------------------------------------ Alg. 4
    def _select(self, q: Any, cands: list[tuple[float, int]], M: int, layer: int) -> list[int]:
        if self.extend_candidates:
            seen = {n for _, n in cands}
            extra: list[int] = []
            for _, n in cands:
                for e in self._nb[n][layer]:
                    if e not in seen:
                        seen.add(e)
                        extra.append(e)
            if extra:
                cands = cands + list(zip(self._dist(q, extra), extra, strict=True))
        cands = sorted(cands)
        if len(cands) <= M:
            return [n for _, n in cands]
        chosen: list[int] = []
        discarded: list[tuple[float, int]] = []
        for d, e in cands:
            if len(chosen) >= M:
                break
            if not chosen:
                chosen.append(e)
                continue
            closer_to_chosen = min(self._dist(self._m.get(e), chosen))
            if d < closer_to_chosen:
                chosen.append(e)
            else:
                discarded.append((d, e))
        if self.keep_pruned:
            for _, e in discarded:
                if len(chosen) >= M:
                    break
                chosen.append(e)
        return chosen

    # ------------------------------------------------------------ Alg. 1
    def _insert(self, id_: str, vector: Sequence[float]) -> None:
        row = self._m.append(vector)
        q = self._m.get(row)
        level = math.floor(-math.log(max(self._rng.random(), 1e-12)) * self._mL)
        self._ids.append(id_)
        self._row[id_] = row
        self._level.append(level)
        self._nb.append([[] for _ in range(level + 1)])
        if self._entry < 0:
            self._entry, self._max_level = row, level
            return
        ep = [self._entry]
        for lc in range(self._max_level, level, -1):
            ep = [self._search_layer(q, ep, 1, lc)[0][1]]
        for lc in range(min(self._max_level, level), -1, -1):
            W = self._search_layer(q, ep, self.ef_construction, lc)
            Mmax = self.M0 if lc == 0 else self.M
            neigh = self._select(q, W, self.M, lc)
            self._nb[row][lc] = list(neigh)
            for e in neigh:
                conn = self._nb[e][lc]
                conn.append(row)
                if len(conn) > Mmax:
                    ev = self._m.get(e)
                    pairs = list(zip(self._dist(ev, conn), conn, strict=True))
                    self._nb[e][lc] = self._select(ev, pairs, Mmax, lc)
            ep = [n for _, n in W]
        if level > self._max_level:
            self._entry, self._max_level = row, level

    def add(self, ids: Sequence[str], vectors: Sequence[Sequence[float]]) -> None:
        if len(ids) != len(vectors):
            raise ValueError("ids e vectors com tamanhos diferentes")
        for id_, v in zip(ids, vectors, strict=True):
            if id_ in self._row:
                self.remove(id_)
            self._insert(id_, v)

    def remove(self, id: str) -> bool:
        row = self._row.pop(id, None)
        if row is None:
            return False
        self._deleted.add(row)
        return True

    # ------------------------------------------------------------ Alg. 5
    def search(
        self,
        vector: Sequence[float],
        k: int,
        *,
        allowed: Allowed | None = None,
        ef: int | None = None,
        allowed_count: int | None = None,
    ) -> list[Hit]:
        if k <= 0 or self._entry < 0 or not self._row:
            return []
        q = self._m.prepare(vector)
        n_live = len(self._row)
        # subconjunto permitido pequeno: varredura exata do subconjunto vence o grafo
        if allowed is not None and allowed_count is not None and allowed_count <= max(4 * k, int(0.05 * n_live)):
            rows = [r for r, i in enumerate(self._ids) if r not in self._deleted and allowed(i)]
            pairs = sorted(zip(self._dist(q, rows), rows, strict=True))[:k]
            return [(self._ids[r], -d) for d, r in pairs]
        ef_eff = max(ef or self.ef_search, k)
        if allowed is not None:
            sel = (allowed_count / n_live) if allowed_count else 0.25
            ef_eff = int(min(n_live, max(ef_eff, ef_eff / max(sel, 1e-3))))
        ep = [self._entry]
        for lc in range(self._max_level, 0, -1):
            ep = [self._search_layer(q, ep, 1, lc)[0][1]]
        W = self._search_layer(q, ep, ef_eff, 0)
        out: list[Hit] = []
        for d, r in W:
            if r in self._deleted:
                continue
            id_ = self._ids[r]
            if allowed is not None and not allowed(id_):
                continue
            out.append((id_, -d))
            if len(out) >= k:
                break
        return out

    # ------------------------------------------------------------ manutenção
    def compact(self) -> HNSWIndex:
        """Reconstrói sem as lápides (nova instância com os mesmos parâmetros)."""
        fresh = HNSWIndex(
            self.dim,
            M=self.M,
            ef_construction=self.ef_construction,
            ef_search=self.ef_search,
            metric=self.metric,
            keep_pruned=self.keep_pruned,
            extend_candidates=self.extend_candidates,
        )
        live = [r for r in range(len(self._ids)) if r not in self._deleted]
        fresh.add([self._ids[r] for r in live], [self._m.get(r) for r in live])
        return fresh

    def stats(self) -> dict[str, Any]:
        live = [r for r in range(len(self._ids)) if r not in self._deleted]
        deg0 = [len(self._nb[r][0]) for r in live] or [0]
        return {
            "size": len(live),
            "deleted": len(self._deleted),
            "max_level": self._max_level,
            "levels": {str(lv): sum(1 for r in live if self._level[r] == lv) for lv in range(self._max_level + 1)},
            "mean_degree_l0": sum(deg0) / len(deg0),
            "M": self.M,
            "ef_construction": self.ef_construction,
            "ef_search": self.ef_search,
        }

    # ---------------------------------------------------------- persistência
    def save(self, path: str) -> None:
        """`path` (JSON: grafo, ids, parâmetros) + `path.vec` (float32 cru)."""
        meta = {
            "kind": "hnsw",
            "dim": self.dim,
            "metric": self.metric,
            "M": self.M,
            "ef_construction": self.ef_construction,
            "ef_search": self.ef_search,
            "keep_pruned": self.keep_pruned,
            "extend_candidates": self.extend_candidates,
            "ids": self._ids,
            "level": self._level,
            "nb": self._nb,
            "entry": self._entry,
            "max_level": self._max_level,
            "deleted": sorted(self._deleted),
        }
        with open(path, "w", encoding="utf-8") as fh:
            json.dump(meta, fh)
        with open(path + ".vec", "wb") as fb:
            for row in self._m.to_lists():
                fb.write(struct.pack(f"<{self.dim}f", *row))

    @classmethod
    def load(cls, path: str) -> HNSWIndex:
        with open(path, encoding="utf-8") as fh:
            meta = json.load(fh)
        idx = cls(
            int(meta["dim"]),
            M=int(meta["M"]),
            ef_construction=int(meta["ef_construction"]),
            ef_search=int(meta["ef_search"]),
            metric=str(meta["metric"]),
            keep_pruned=bool(meta["keep_pruned"]),
            extend_candidates=bool(meta["extend_candidates"]),
        )
        n = len(meta["ids"])
        size = struct.calcsize(f"<{idx.dim}f")
        with open(path + ".vec", "rb") as fb:
            for _ in range(n):
                idx._m.append_raw(struct.unpack(f"<{idx.dim}f", fb.read(size)))
        idx._ids = list(meta["ids"])
        idx._row = {i: r for r, i in enumerate(idx._ids)}
        idx._level = [int(x) for x in meta["level"]]
        idx._nb = [[[int(x) for x in layer] for layer in node] for node in meta["nb"]]
        idx._entry = int(meta["entry"])
        idx._max_level = int(meta["max_level"])
        for r in meta.get("deleted", []):
            idx._deleted.add(int(r))
            idx._row.pop(idx._ids[int(r)], None)
        return idx
