"""Armazenamento de vetores e k-means — o chão comum dos índices.

`Matrix` guarda vetores por linha (numpy float32 quando disponível, tuplas
quando não) e responde a uma pergunta só: o score de uma consulta contra um
conjunto de linhas. Os índices (plano, HNSW, IVF, quantizado) diferem em
*quais* linhas pedem; a álgebra é a mesma.

Métricas, todas como "maior é melhor":

* `cosine` — vetores normalizados na entrada; score = produto interno;
* `dot` — produto interno cru;
* `l2` — `-||q - x||^2` (o negativo da distância euclidiana ao quadrado).

`kmeans` é Lloyd (1982) com semeadura k-means++ (Arthur & Vassilvitskii,
2007): a semeadura evita os mínimos locais ruins que o Lloyd puro cai com
inicialização uniforme, e é o que o FAISS usa no treino do IVF e do PQ.
"""

from __future__ import annotations

import math
import random
from collections.abc import Sequence
from typing import Any

__all__ = ["HAS_NUMPY", "Matrix", "kmeans", "np"]

try:  # pragma: no cover - caminho opcional
    import numpy as np

    HAS_NUMPY = True
except Exception:  # pragma: no cover
    np = None
    HAS_NUMPY = False

METRICS = ("cosine", "dot", "l2")


def _normalize_list(v: Sequence[float]) -> list[float]:
    n = math.sqrt(sum(x * x for x in v))
    return [float(x) / n for x in v] if n > 1e-12 else [float(x) for x in v]


class Matrix:
    """Vetores por linha; capacidade dobra sob demanda."""

    def __init__(self, dim: int, *, metric: str = "cosine", use_numpy: bool | None = None) -> None:
        if dim <= 0:
            raise ValueError("dim deve ser positivo")
        if metric not in METRICS:
            raise ValueError(f"métrica desconhecida: {metric!r}")
        self.dim = dim
        self.metric = metric
        self.numpy = HAS_NUMPY if use_numpy is None else (use_numpy and HAS_NUMPY)
        self._n = 0
        if self.numpy:
            self._mat = np.zeros((64, dim), dtype=np.float32)
        else:
            self._rows: list[list[float]] = []

    def __len__(self) -> int:
        return self._n

    # ------------------------------------------------------------ escrita
    def prepare(self, vec: Sequence[float]) -> Any:
        """Converte para a forma interna e normaliza se a métrica é cosseno."""
        if len(vec) != self.dim:
            raise ValueError(f"vetor de dimensão {len(vec)}, índice de {self.dim}")
        if self.numpy:
            arr = np.asarray(vec, dtype=np.float32)
            if self.metric == "cosine":
                n = float(np.linalg.norm(arr))
                if n > 1e-12:
                    arr = arr / n
            return arr
        lst = [float(x) for x in vec]
        return _normalize_list(lst) if self.metric == "cosine" else lst

    def append(self, vec: Sequence[float]) -> int:
        row = self._n
        v = self.prepare(vec)
        if self.numpy:
            if row >= self._mat.shape[0]:
                grown = np.zeros((self._mat.shape[0] * 2, self.dim), dtype=np.float32)
                grown[: self._n] = self._mat[: self._n]
                self._mat = grown
            self._mat[row] = v
        else:
            self._rows.append(v)
        self._n += 1
        return row

    def append_raw(self, vec: Sequence[float]) -> int:
        """Anexa sem normalizar — para recarregar vetores já preparados."""
        row = self._n
        if self.numpy:
            if row >= self._mat.shape[0]:
                grown = np.zeros((self._mat.shape[0] * 2, self.dim), dtype=np.float32)
                grown[: self._n] = self._mat[: self._n]
                self._mat = grown
            self._mat[row] = np.asarray(vec, dtype=np.float32)
        else:
            self._rows.append([float(x) for x in vec])
        self._n += 1
        return row

    def extend(self, vecs: Sequence[Sequence[float]]) -> list[int]:
        return [self.append(v) for v in vecs]

    # ------------------------------------------------------------ leitura
    def get(self, row: int) -> Any:
        return self._mat[row] if self.numpy else self._rows[row]

    def rows(self, idx: Sequence[int]) -> Any:
        if self.numpy:
            return self._mat[np.asarray(idx, dtype=np.int64)]
        return [self._rows[i] for i in idx]

    def all(self) -> Any:
        return self._mat[: self._n] if self.numpy else self._rows

    def scores(self, q: Any, idx: Sequence[int]) -> list[float]:
        """Score de `q` (já preparado) contra as linhas `idx`."""
        if not idx:
            return []
        if self.numpy:
            sub = self._mat[np.asarray(idx, dtype=np.int64)]
            if self.metric == "l2":
                d = sub - q
                return [float(x) for x in -(d * d).sum(axis=1)]
            return [float(x) for x in sub @ q]
        out: list[float] = []
        for i in idx:
            r = self._rows[i]
            if self.metric == "l2":
                out.append(-sum((a - b) ** 2 for a, b in zip(q, r, strict=True)))
            else:
                out.append(sum(a * b for a, b in zip(q, r, strict=True)))
        return out

    def scores_all(self, q: Any) -> Any:
        """Scores contra todas as linhas (array numpy ou lista)."""
        if self.numpy:
            sub = self._mat[: self._n]
            if self.metric == "l2":
                d = sub - q
                return -(d * d).sum(axis=1)
            return sub @ q
        return self.scores(q, range(self._n))

    def score_pair(self, a: int, b: int) -> float:
        return self.scores(self.get(a), [b])[0]

    def to_lists(self) -> list[list[float]]:
        if self.numpy:
            return self._mat[: self._n].tolist()
        return [list(r) for r in self._rows]


def kmeans(
    vectors: Any,
    k: int,
    *,
    iterations: int = 15,
    seed: int = 0,
    tolerance: float = 1e-4,
) -> tuple[Any, list[int]]:
    """Lloyd com k-means++ sobre `vectors` (numpy 2D ou lista de listas).

    Devolve `(centróides, atribuição)`; centróides na mesma forma da entrada.
    Clusters vazios são re-semeados com o ponto mais distante do seu centróide
    mais próximo — evita centróides mortos em `k` grande.
    """
    rng = random.Random(seed)
    n = len(vectors)
    if n == 0:
        raise ValueError("kmeans sem vetores")
    k = max(1, min(k, n))
    if HAS_NUMPY and isinstance(vectors, np.ndarray):
        X = vectors.astype(np.float32)
        # k-means++
        centers = [X[rng.randrange(n)]]
        d2 = ((X - centers[0]) ** 2).sum(axis=1)
        for _ in range(1, k):
            total = float(d2.sum())
            if total <= 0:
                centers.append(X[rng.randrange(n)])
                continue
            r = rng.random() * total
            acc = np.cumsum(d2)
            j = int(np.searchsorted(acc, r))
            j = min(j, n - 1)
            centers.append(X[j])
            d2 = np.minimum(d2, ((X - X[j]) ** 2).sum(axis=1))
        C = np.stack(centers)
        assign = np.zeros(n, dtype=np.int64)
        for _ in range(iterations):
            # distâncias por expansão: ||x||^2 - 2 x.c + ||c||^2
            xx = (X * X).sum(axis=1, keepdims=True)
            cc = (C * C).sum(axis=1)[None, :]
            dist = xx - 2.0 * (X @ C.T) + cc
            new_assign = dist.argmin(axis=1)
            newC = C.copy()
            for j in range(k):
                members = X[new_assign == j]
                if len(members) == 0:
                    far = int(dist.min(axis=1).argmax())
                    newC[j] = X[far]
                    new_assign[far] = j
                else:
                    newC[j] = members.mean(axis=0)
            shift = float(np.abs(newC - C).max())
            C = newC
            assign = new_assign
            if shift < tolerance:
                break
        return C, [int(a) for a in assign]

    # ---------------------------------------------------------- puro
    P: list[list[float]] = [list(map(float, v)) for v in vectors]
    dim = len(P[0])

    def d2f(a: Sequence[float], b: Sequence[float]) -> float:
        return sum((x - y) ** 2 for x, y in zip(a, b, strict=True))

    centers_l = [list(P[rng.randrange(n)])]
    dmin = [d2f(x, centers_l[0]) for x in P]
    for _ in range(1, k):
        total = sum(dmin)
        if total <= 0:
            centers_l.append(list(P[rng.randrange(n)]))
            continue
        r = rng.random() * total
        running = 0.0
        j = n - 1
        for i, d in enumerate(dmin):
            running += d
            if running >= r:
                j = i
                break
        centers_l.append(list(P[j]))
        dmin = [min(dm, d2f(x, P[j])) for dm, x in zip(dmin, P, strict=True)]
    assign_l = [0] * n
    for _ in range(iterations):
        dists = [[d2f(x, c) for c in centers_l] for x in P]
        assign_p = [min(range(k), key=lambda j, row=row: row[j]) for row in dists]  # type: ignore[misc]
        newC_p: list[list[float]] = [[0.0] * dim for _ in range(k)]
        counts = [0] * k
        for x, a in zip(P, assign_p, strict=True):
            counts[a] += 1
            for i, val in enumerate(x):
                newC_p[a][i] += val
        shift = 0.0
        for j in range(k):
            if counts[j] == 0:
                far = max(range(n), key=lambda i: min(dists[i]))
                newC_p[j] = list(P[far])
                assign_p[far] = j
            else:
                newC_p[j] = [v / counts[j] for v in newC_p[j]]
            shift = max(shift, max(abs(a - b) for a, b in zip(newC_p[j], centers_l[j], strict=True)))
        centers_l = newC_p
        assign_l = list(assign_p)
        if shift < tolerance:
            break
    return centers_l, assign_l
