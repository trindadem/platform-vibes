"""IVF — inverted file index (Sivic & Zisserman, 2003; Jégou et al., 2011; FAISS).

Particiona o espaço em `nlist` células de Voronoi por k-means; cada vetor
mora na lista da célula mais próxima. A consulta visita as `nprobe` células
mais próximas e varre só essas listas. Custo `O(nlist·d + nprobe·N/nlist·d)`;
com `nlist = sqrt(N)` e `nprobe` pequeno, ~`sqrt(N)` vezes menos trabalho
que a varredura plana. É o índice padrão do FAISS para escala média e a
base do IVF-PQ (`quant.py` fornece o PQ).

`nprobe` é o botão recall/latência, medido em `docs/rag/resultados/ann_scifact_{model2vec,fastembed}.json`.
O treino precisa de vetores representativos: `add` treina na primeira
leva quando `auto_train=True` (padrão); leva menor que `nlist` cai em
`nlist = len/4`, e uma leva de 1 vetor vira índice plano de uma lista.
"""

from __future__ import annotations

import heapq
import math
from collections.abc import Sequence
from typing import Any

from ._matrix import HAS_NUMPY, Matrix, kmeans, np
from .base import Allowed, Hit

__all__ = ["IVFIndex"]


class IVFIndex:
    def __init__(
        self,
        dim: int,
        *,
        nlist: int | None = None,
        nprobe: int = 8,
        metric: str = "cosine",
        seed: int = 0,
        auto_train: bool = True,
        use_numpy: bool | None = None,
    ) -> None:
        self.dim = dim
        self.metric = metric
        self.nlist = nlist
        self.nprobe = nprobe
        self.seed = seed
        self.auto_train = auto_train
        self._m = Matrix(dim, metric=metric, use_numpy=use_numpy)
        self._centroids: Matrix | None = None
        self._lists: list[list[int]] = []
        self._ids: list[str] = []
        self._row: dict[str, int] = {}
        self._cell: list[int] = []
        self._deleted: set[int] = set()

    def __len__(self) -> int:
        return len(self._row)

    def __contains__(self, id: str) -> bool:
        return id in self._row

    @property
    def trained(self) -> bool:
        return self._centroids is not None

    # ------------------------------------------------------------ treino
    def train(self, vectors: Sequence[Sequence[float]]) -> None:
        n = len(vectors)
        if n == 0:
            raise ValueError("train sem vetores")
        k = self.nlist or max(1, int(math.sqrt(n)))
        k = max(1, min(k, max(1, n // 4) if n >= 4 else 1))
        prepared = [self._m.prepare(v) for v in vectors]
        if HAS_NUMPY and self._m.numpy:
            C, _ = kmeans(np.stack(prepared), k, seed=self.seed)
            rows = C.tolist()
        else:
            C, _ = kmeans([list(p) for p in prepared], k, seed=self.seed)
            rows = C
        self._centroids = Matrix(self.dim, metric=self.metric, use_numpy=self._m.numpy)
        for c in rows:
            self._centroids.append(c)  # cosseno: centróide renormalizado
        self.nlist = len(rows)
        self._lists = [[] for _ in range(self.nlist)]

    def _nearest_cells(self, q: Any, n: int) -> list[int]:
        assert self._centroids is not None
        scores = self._centroids.scores_all(q)
        idx = range(len(self._centroids))
        return [c for _, c in heapq.nsmallest(n, ((-float(scores[c]), c) for c in idx))]

    # ------------------------------------------------------------ escrita
    def add(self, ids: Sequence[str], vectors: Sequence[Sequence[float]]) -> None:
        if len(ids) != len(vectors):
            raise ValueError("ids e vectors com tamanhos diferentes")
        if not self.trained:
            if not self.auto_train:
                raise RuntimeError("IVFIndex não treinado: chame train() ou use auto_train=True")
            self.train(vectors)
        for id_, v in zip(ids, vectors, strict=True):
            if id_ in self._row:
                self.remove(id_)
            row = self._m.append(v)
            cell = self._nearest_cells(self._m.get(row), 1)[0]
            self._ids.append(id_)
            self._row[id_] = row
            self._cell.append(cell)
            self._lists[cell].append(row)

    def remove(self, id: str) -> bool:
        row = self._row.pop(id, None)
        if row is None:
            return False
        self._deleted.add(row)
        cell = self._cell[row]
        self._lists[cell] = [r for r in self._lists[cell] if r != row]
        return True

    # ------------------------------------------------------------ leitura
    def search(
        self, vector: Sequence[float], k: int, *, allowed: Allowed | None = None, nprobe: int | None = None
    ) -> list[Hit]:
        if k <= 0 or not self._row or not self.trained:
            return []
        q = self._m.prepare(vector)
        cells = self._nearest_cells(q, min(nprobe or self.nprobe, self.nlist or 1))
        rows = [r for c in cells for r in self._lists[c] if r not in self._deleted]
        if allowed is not None:
            rows = [r for r in rows if allowed(self._ids[r])]
        if not rows:
            return []
        scores = self._m.scores(q, rows)
        best = heapq.nsmallest(k, ((-s, self._ids[r]) for s, r in zip(scores, rows, strict=True)))
        return [(i, -s) for s, i in best]

    def stats(self) -> dict[str, Any]:
        sizes = [len(lst) for lst in self._lists] or [0]
        return {
            "size": len(self._row),
            "nlist": self.nlist,
            "nprobe": self.nprobe,
            "list_mean": sum(sizes) / len(sizes),
            "list_max": max(sizes),
            "list_empty": sum(1 for s in sizes if s == 0),
        }
