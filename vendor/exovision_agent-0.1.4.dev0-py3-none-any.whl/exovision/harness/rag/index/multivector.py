"""Índice multi-vetor com *late interaction* (ColBERT) — experimental.

Um documento é uma matriz (um vetor por token); a relevância é o **MaxSim**
(Khattab & Zaharia, 2020):

    S(q, d) = sum_{i in q} max_{j in d} q_i . d_j

Cada token da consulta procura o token do documento que melhor o casa, e
os casamentos se somam. Isso preserva a interação fina que o bi-encoder
(um vetor por texto) perde na média — e explica por que o ColBERTv2
(Santhanam et al., 2022) generaliza melhor zero-shot no BEIR que os
bi-encoders do mesmo tamanho. O custo: `|d|` vetores por documento.

A busca segue o PLAID (Santhanam et al., 2022b) em miniatura: geração de
candidatos por vizinhos mais próximos *de token* (um índice plano sobre
todos os tokens de todos os documentos), depois MaxSim exato só nos
candidatos. `candidates_per_token` é o botão recall/latência.
"""

from __future__ import annotations

import heapq
from collections.abc import Sequence
from typing import Any

from ._matrix import HAS_NUMPY, Matrix, np
from .base import Allowed, Hit

__all__ = ["MultiVectorIndex"]


class MultiVectorIndex:
    def __init__(self, dim: int, *, candidates_per_token: int = 32, metric: str = "cosine") -> None:
        self.dim = dim
        self.candidates_per_token = candidates_per_token
        self.metric = metric
        self._tokens = Matrix(dim, metric=metric)
        self._owner: list[int] = []  # linha de token -> índice do documento
        self._doc_rows: list[list[int]] = []
        self._ids: list[str] = []
        self._row: dict[str, int] = {}
        self._deleted: set[int] = set()

    def __len__(self) -> int:
        return len(self._row)

    def __contains__(self, id: str) -> bool:
        return id in self._row

    def add(self, ids: Sequence[str], vectors: Sequence[Sequence[Sequence[float]]]) -> None:
        """`vectors[i]` é a matriz de tokens do documento `ids[i]`."""
        if len(ids) != len(vectors):
            raise ValueError("ids e vectors com tamanhos diferentes")
        for id_, mat in zip(ids, vectors, strict=True):
            if id_ in self._row:
                self.remove(id_)
            doc = len(self._ids)
            rows = []
            for v in mat:
                r = self._tokens.append(v)
                self._owner.append(doc)
                rows.append(r)
            self._ids.append(id_)
            self._row[id_] = doc
            self._doc_rows.append(rows)

    def remove(self, id: str) -> bool:
        doc = self._row.pop(id, None)
        if doc is None:
            return False
        self._deleted.add(doc)
        return True

    def maxsim(self, query: Sequence[Any], doc: int) -> float:
        rows = self._doc_rows[doc]
        if not rows:
            return 0.0
        total = 0.0
        for q in query:
            total += max(self._tokens.scores(q, rows))
        return total

    def search(
        self, vectors: Sequence[Sequence[float]], k: int, *, allowed: Allowed | None = None
    ) -> list[Hit]:
        """`vectors` é a matriz de tokens da consulta."""
        if k <= 0 or not self._row or not vectors:
            return []
        qs = [self._tokens.prepare(v) for v in vectors]
        cands: set[int] = set()
        n_tok = len(self._tokens)
        for q in qs:
            scores = self._tokens.scores_all(q)
            top = min(self.candidates_per_token, n_tok)
            if HAS_NUMPY and self._tokens.numpy:
                idx = np.argpartition(-scores, top - 1)[:top]
                cands.update(self._owner[int(i)] for i in idx)
            else:
                best = heapq.nlargest(top, range(n_tok), key=lambda i: scores[i])
                cands.update(self._owner[i] for i in best)
        cands = {d for d in cands if d not in self._deleted and (allowed is None or allowed(self._ids[d]))}
        scored = [(-self.maxsim(qs, d), self._ids[d]) for d in cands]
        return [(i, -s) for s, i in heapq.nsmallest(k, scored)]
