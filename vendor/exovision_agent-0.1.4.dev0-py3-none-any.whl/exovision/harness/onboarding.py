"""Entrada guiada: `exovision-agent init` e `exovision-agent doctor`.

O primeiro contato de quem instalou o pacote e não sabe (nem precisa saber)
o que é `AGENT.md`. O assistente faz as perguntas na ordem em que as decisões
dependem umas das outras — **provedor → credencial → modelo → agente ou
equipe → instrução** — e grava só o que o kernel já lê: `AGENT.md`/`TEAM.md`
(`agents.profile`, `agents.team`) e o arquivo de ambiente (`config`). Não
inventa formato, não instala nada, não abre navegador, não chama o modelo
(ratificado: a primeira chamada real é a primeira tarefa do usuário).

As regras são as de uma CLI (clig.dev):

- só pergunta se há terminal interativo; com `--no-input` (ou sem TTY) usa
  os padrões e falha com código 2 quando falta algo que teria perguntado;
- toda pergunta tem uma flag: a sessão interativa é açúcar sobre a
  não-interativa — é o que torna o `init` testável na suíte;
- idempotente: num diretório já configurado mostra o que há e pede
  confirmação para regravar (`--force` no modo não-interativo);
- segredo nunca aparece: `getpass` na digitação, nome da variável no resumo,
  `--key-file` no lugar de `--key` (argumento fica no histórico do shell);
- termina com o próximo comando na tela.

A lógica `Answers → arquivos` (`materialize`) é separada da interação
(`collect`, `Prompter`) para a suíte testar a geração com respostas dadas e a
interação com um `input` injetado. `doctor` diz o que falta antes de a
primeira tarefa falhar — cada item é `ok | aviso | falha` com a ação — e prova
o kernel sem rede rodando um laço roteirizado em memória.
"""

from __future__ import annotations

import argparse
import importlib
import json
import os
import platform
import shutil
import sys
from collections.abc import Callable, Mapping, MutableMapping, Sequence
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

from .. import __version__
from .config import env_file, env_file_mode_ok, load_env, parse_env, write_env_file
from .ui import PromptAborted, Prompter

__all__ = [
    "MEMORY_DEFAULT",
    "PROVIDERS",
    "Answers",
    "Check",
    "OnboardingError",
    "PromptAborted",
    "Prompter",
    "add_parser",
    "collect",
    "doctor",
    "materialize",
    "render_agent_md",
    "render_team_md",
]


class OnboardingError(ValueError):
    """Falta uma resposta que só o usuário pode dar (código de saída 2)."""


# ---------------------------------------------------------------- provedores


@dataclass(frozen=True, slots=True)
class ProviderInfo:
    kind: str
    label: str
    key_var: str  # variável da credencial ("" = não precisa)
    key_alt: tuple[str, ...] = ()  # nomes alternativos aceitos pelo driver
    default_model: str = ""
    model_hint: str = ""
    url_var: str = ""  # variável da URL base ("" = fixa)
    default_url: str = ""
    key_url: str = ""  # onde se obtém a chave


PROVIDERS: dict[str, ProviderInfo] = {
    "anthropic": ProviderInfo("anthropic", "Anthropic (Claude)", "ANTHROPIC_API_KEY", (), "claude-sonnet-5", "claude-opus-5, claude-sonnet-5, claude-haiku-4-5 (ver `models catalog`)", "", "", "https://console.anthropic.com/"),
    "openai": ProviderInfo("openai", "OpenAI", "OPENAI_API_KEY", (), "gpt-5.4-mini", "gpt-5.4-mini, gpt-5.4", "OPENAI_BASE_URL", "https://api.openai.com/v1", "https://platform.openai.com/api-keys"),
    "google": ProviderInfo("google", "Google (Gemini)", "GEMINI_API_KEY", ("GOOGLE_API_KEY",), "", "o id do modelo no Google AI Studio", "GEMINI_BASE_URL", "https://generativelanguage.googleapis.com/v1beta", "https://aistudio.google.com/apikey"),
    "local": ProviderInfo("local", "Servidor local (Ollama, LM Studio, llama.cpp, vLLM…)", "", (), "", "o nome do modelo que o servidor carregou (ex.: qwen2.5:1.5b)", "EXOVISION_LOCAL_URL", "http://localhost:11434/v1", ""),
    "compatible": ProviderInfo("compatible", "Compatível com OpenAI (URL + token)", "EXOVISION_API_KEY", (), "", "o nome do modelo no serviço", "EXOVISION_BASE_URL", "", ""),
}
MEMORY_DEFAULT: tuple[str, ...] = ("episodic", "semantic", "buffer")
_AUTONOMY = ("auto", "ask", "never")
_EFFORTS = ("low", "medium", "high", "xhigh", "max")


def key_present(info: ProviderInfo, environ: Mapping[str, str] | None = None) -> str:
    """O nome da variável de credencial que está no ambiente, ou ""."""
    env = os.environ if environ is None else environ
    for var in (info.key_var, *info.key_alt):
        if var and env.get(var):
            return var
    return ""


# ---------------------------------------------------------------- as respostas


@dataclass
class Answers:
    """Tudo o que o `init` precisa saber. Campos vazios são perguntados (ou falham em `--no-input`)."""

    path: Path = field(default_factory=lambda: Path("."))
    kind: str = ""  # agent | team
    provider: str = ""
    model: str = ""
    effort: str = ""
    base_url: str = ""
    key: str = field(default="", repr=False)  # transitório; nunca gravado em Answers, só no arquivo de ambiente
    key_scope: str = ""  # env (já estava) | global | local | skip
    name: str = ""
    description: str = ""
    autonomy: str = ""
    memory: tuple[str, ...] | None = None
    workspace: str = ""
    instruction: str = ""
    members: tuple[tuple[str, str], ...] = ()  # (nome, descrição)
    first_task: str = ""

    def model_spec(self) -> str:
        """`[tipo:]modelo[@url]` — o que `make_provider` lê do `model:` do perfil."""
        spec = f"{self.provider}:{self.model}" if self.provider else self.model
        if self.provider in ("compatible", "local") and self.base_url and self.base_url != PROVIDERS[self.provider].default_url:
            spec += f"@{self.base_url}"
        return spec


# ---------------------------------------------------------------- a interação


def _slug_ok(name: str) -> bool:
    from .agents.profile import _NAME

    return bool(_NAME.match(name))


def collect(p: Prompter, a: Answers, *, environ: Mapping[str, str] | None = None, key_file: str = "") -> Answers:
    """Preenche o que falta em `a` perguntando (ou usando os padrões).

    A ordem é a das dependências. Resposta inválida **pergunta de novo**: antes,
    um nome com espaço no fim do questionário descartava tudo o que já tinha
    sido respondido.
    """
    from .models import parse_spec
    from .models.catalog import cards, resolve

    env = os.environ if environ is None else environ

    # 1. provedor
    if not a.provider:
        p.title("Provedor do modelo")
        kinds = list(PROVIDERS)
        a.provider = p.ask("Provedor", default="anthropic", choices=kinds, labels={k: PROVIDERS[k].label for k in kinds}, flag="--provider", error=OnboardingError)
    if a.provider not in PROVIDERS:
        raise OnboardingError(f"provedor desconhecido: {a.provider!r} (um de {', '.join(PROVIDERS)})")
    info = PROVIDERS[a.provider]

    # 2. URL base (só quem tem)
    if info.url_var and not a.base_url:
        if a.provider == "compatible":
            a.base_url = p.ask("URL base do serviço (…/v1)", required=True, flag="--base-url", error=OnboardingError,
                               validate=lambda v: None if v.startswith(("http://", "https://")) else "comece com http:// ou https://")
        else:
            a.base_url = env.get(info.url_var) or info.default_url

    # 3. credencial
    if info.key_var and not a.key_scope:
        presente = key_present(info, env)
        if key_file:
            a.key = Path(key_file).expanduser().read_text(encoding="utf-8").strip().splitlines()[0].strip()
            a.key_scope = a.key_scope or "global"
        elif presente:
            a.key_scope = "env"
            p.note(f"   credencial: {presente} já está no ambiente — não vou pedir")
        elif p.interactive:
            p.title(f"Credencial ({info.key_var})")
            if info.key_url:
                p.note(f"   obtenha uma em {info.key_url}")
            a.key = p.secret(f"{info.key_var} (não aparece ao digitar; Enter para pular)")
            if a.key:
                a.key_scope = a.key_scope or "global"
                destino = env_file() if a.key_scope == "global" else a.path / ".env"
                p.note(f"   → {destino}" + ("  (só o dono lê; `--local` grava no diretório do agente)" if a.key_scope == "global" else "  (+ .gitignore)"))
            else:
                a.key_scope = "skip"
                p.note(f"   sem credencial por ora: exporte {info.key_var} antes de rodar, ou rode `exovision-agent init` de novo")
        else:
            a.key_scope = "skip"
    elif not info.key_var:
        a.key_scope = a.key_scope or "none"

    # 4. modelo e esforço — o catálogo decide o que faz sentido perguntar
    if not a.model:
        p.title("Modelo")
        if a.provider == "anthropic":
            for c in cards("anthropic"):
                p.note(f"     {c.id:20s} US$ {c.price_in}/{c.price_out} por Mtok" + (f" · esforço {'/'.join(c.efforts)}" if c.efforts else " · sem esforço"))
        else:
            p.note(f"   {info.model_hint}")
        a.model = p.ask("Modelo", default=info.default_model, required=True, flag="--model", error=OnboardingError)
    card = resolve(parse_spec(a.model)[1] or a.model)
    aceita_esforco = bool(card.efforts) or not card.verified
    if not aceita_esforco:
        # Haiku 4.5 não faz pensamento adaptativo: perguntar esforço aqui produzia
        # um AGENT.md que o servidor recusa com 400 na primeira tarefa.
        if a.effort:
            p.note(f"   {card.id} não usa esforço; ignorando --effort {a.effort}")
        a.effort = ""
    elif not a.effort:
        niveis = list(card.efforts) or list(_EFFORTS)
        a.effort = p.ask("Esforço", default="high" if "high" in niveis else niveis[-1], choices=niveis, flag="--effort", error=OnboardingError) if p.interactive else ("high" if "high" in niveis else niveis[-1])
    elif card.efforts and a.effort not in card.efforts:
        raise OnboardingError(f"esforço {a.effort!r} não existe em {card.id} (tem {', '.join(card.efforts)})")
    if a.effort and a.effort not in _EFFORTS:
        raise OnboardingError(f"esforço {a.effort!r} fora de {_EFFORTS}")

    # 5. agente ou equipe
    if not a.kind:
        p.title("Um agente ou uma equipe?")
        p.note("   agente: um perfil (AGENT.md) que roda tarefas.  equipe: perfis que conversam por canais (TEAM.md + members/).")
        a.kind = p.ask("Tipo", default="agent", choices=["agent", "team"], flag="--team", error=OnboardingError)
    if a.kind not in ("agent", "team"):
        raise OnboardingError(f"tipo {a.kind!r} fora de (agent, team)")
    if not a.name:
        padrao = a.path.resolve().name if _slug_ok(a.path.resolve().name) else ("meu-agente" if a.kind == "agent" else "minha-equipe")
        a.name = p.ask("Nome (minúsculas, sem espaço)", default=padrao, flag="--name", error=OnboardingError, validate=_queixa_nome)
    if (queixa := _queixa_nome(a.name)) is not None:
        raise OnboardingError(f"nome inválido: {a.name!r} ({queixa})")
    if not a.description:
        a.description = p.ask("Para que serve, numa frase", default=f"{'agente' if a.kind == 'agent' else 'equipe'} {a.name}", flag="--description", error=OnboardingError)
    if not a.autonomy:
        if a.kind == "team":
            p.note("   ao receber uma mensagem: auto = age; ask = espera aprovação; never = só guarda")
            a.autonomy = p.ask("Autonomia dos membros", default="ask", choices=list(_AUTONOMY), flag="--autonomy", error=OnboardingError)
        else:
            a.autonomy = "ask"
    if a.autonomy not in _AUTONOMY:
        raise OnboardingError(f"autonomia {a.autonomy!r} fora de {_AUTONOMY}")
    if a.memory is None:
        a.memory = MEMORY_DEFAULT  # `--memory` muda; a pergunta não vale o que custa a quem está começando
    if a.memory:
        from .memory.systems import SYSTEMS

        conhecidas = {k.value for k in SYSTEMS}
        if desconhecidas := [m for m in a.memory if m not in conhecidas]:
            raise OnboardingError(f"categoria de memória desconhecida: {', '.join(desconhecidas)} (veja `exovision-agent memory kinds`)")

    # 6. bancada
    if a.workspace.strip().lower() == "none":
        a.workspace, ws_definido = "", True
    else:
        ws_definido = bool(a.workspace)
    if a.kind == "agent" and not ws_definido:
        p.note("   a bancada: a pasta onde o agente pode ler, editar e rodar comandos (`none` = sem ferramentas de arquivo)")
        a.workspace = p.ask("Bancada", default=str(Path.cwd()), flag="--workspace", error=OnboardingError)
        if a.workspace.strip().lower() == "none":
            a.workspace = ""
    if a.workspace:
        ws = Path(a.workspace).expanduser()
        if not ws.is_dir():
            if p.interactive and p.confirm(f"   {ws} não existe. Criar?", default=True):
                ws.mkdir(parents=True, exist_ok=True)
            else:
                p.warn(f"   atenção: {ws} não existe — o agente não vai conseguir usar bash/editor/busca até ela existir")
        a.workspace = str(ws)

    # 7. membros (equipe)
    if a.kind == "team" and not a.members:
        raw = p.ask("Membros (nomes separados por vírgula)", default="revisor,redator", flag="--members", error=OnboardingError,
                    validate=lambda v: None if all(_slug_ok(x.strip()) for x in v.split(",") if x.strip()) else "minúsculas, dígitos, `-` e `_`; começa com letra")
        nomes = [x.strip() for x in raw.split(",") if x.strip()]
        a.members = tuple((n, p.ask(f"  {n}: para que serve", default=f"membro {n}", flag="--members", error=OnboardingError)) for n in nomes)

    # 8. instrução
    if not a.instruction:
        if p.interactive:
            p.title("Instrução")
            p.note("   o corpo do AGENT.md — o que fazer, como decidir, o que devolver. Um molde curto vai ser gravado; edite depois (`/editar`).")
        a.instruction = _default_instruction(a)

    # 9. primeira tarefa (só interativo; a flag --run cobre o resto)
    if a.kind == "agent" and not a.first_task and p.interactive:
        p.title("Primeira tarefa")
        a.first_task = p.ask("Rodar uma tarefa agora? (Enter para não)", default="")
    return a


def _queixa_nome(nome: str) -> str | None:
    return None if _slug_ok(nome) else "minúsculas, dígitos, `-` e `_`; começa com letra"


def _default_instruction(a: Answers) -> str:
    if a.kind == "team":
        return (
            "Quem faz o quê, e como o trabalho passa de um para outro. O front-matter acima é o que o harness lê:\n"
            "- `channels`: quem assina o quê (mensagens num canal acordam quem assina)\n"
            "- `roles`: quem pode pedir a quem (vazio = todos)\n"
            '- `workflows`: JSON de [{"on": "done:<perfil>", "to": "<perfil>", "task": "... {{outcome}} ..."}]\n'
            "- `autonomy`: auto | ask | never (padrão dos membros)\n"
        )
    return (
        f"Você é {a.name}: {a.description}\n\n"
        "Trabalhe em passos pequenos e verificáveis: leia antes de editar, rode o que\n"
        "editou, e nunca afirme que algo funciona sem ter executado. Quando a tarefa\n"
        "for ambígua, escolha a interpretação mais conservadora e diga qual escolheu.\n"
        "Prefira a menor mudança que resolve o problema.\n\n"
        "Quando terminar, responda com texto — sem chamar ferramenta. Se não conseguiu\n"
        "terminar, diga o que faltou em vez de afirmar que está pronto.\n"
    )


# ---------------------------------------------------------------- Answers -> arquivos


def render_agent_md(
    *,
    name: str,
    description: str,
    model: str = "",
    effort: str = "",
    autonomy: str = "ask",
    memory: Sequence[str] = MEMORY_DEFAULT,
    workspace: str = "",
    capabilities: Sequence[str] = (),
    channels: Sequence[str] = (),
    body: str = "",
) -> str:
    """O `AGENT.md` que `agents.profile.load_profile` lê — front-matter plano, listas inline."""
    linhas = [f"name: {name}", "version: 0.1.0", f"description: {_fm(description)}"]
    if model:
        linhas.append(f"model: {model}")
    if effort:
        linhas.append(f"effort: {effort}")
    linhas.append(f"autonomy: {autonomy}")
    linhas.append(f"memory: [{', '.join(memory)}]")
    if workspace:
        linhas.append(f"workspace: {_fm(workspace)}")
    if capabilities:
        linhas.append(f"capabilities: [{', '.join(capabilities)}]")
    if channels:
        linhas.append(f"channels: [{', '.join(channels)}]")
    linhas.append("policy: {deny_at: irreversible, taint: true}")
    corpo = body.rstrip("\n") + "\n" if body else f"Você é {name}: {description}\n"
    return "---\n" + "\n".join(linhas) + "\n---\n" + corpo


def render_team_md(*, name: str, description: str, members: Sequence[str], autonomy: str = "ask", body: str = "") -> str:
    canais = "{geral: [" + ", ".join(members) + "]}" if members else "{}"
    fm = f"---\nname: {name}\nversion: 0.1.0\ndescription: {_fm(description)}\nchannels: {canais}\nautonomy: {autonomy}\nworkflows: []\n---\n"
    return fm + ("\n" + body.rstrip("\n") + "\n" if body else "")


def _fm(v: str) -> str:
    """Valor de front-matter: aspas quando o parser plano confundiria (`[`, `{`, `:`, aspas, número, booleano)."""
    s = v.strip().replace("\n", " ")
    if not s:
        return '""'
    if s[0] in "[{'\"" or ":" in s or "#" in s or s.lower() in ("true", "false", "yes", "no", "on", "off") or _looks_number(s):
        return '"' + s.replace('"', "'") + '"'
    return s


def _looks_number(s: str) -> bool:
    try:
        float(s)
    except ValueError:
        return False
    return True


def materialize(a: Answers, *, environ: Mapping[str, str] | None = None, force: bool = False) -> list[Path]:
    """Grava os arquivos que `a` descreve e devolve os caminhos. Não sobrescreve sem `force`."""
    d = a.path
    alvo = d / ("AGENT.md" if a.kind == "agent" else "TEAM.md")
    if alvo.exists() and not force:
        raise OnboardingError(f"já existe: {alvo} (use --force para regravar)")
    escritos: list[Path] = []
    d.mkdir(parents=True, exist_ok=True)
    spec = a.model_spec()
    if a.kind == "agent":
        (d / "notas").mkdir(exist_ok=True)
        alvo.write_text(
            render_agent_md(name=a.name, description=a.description, model=spec, effort=a.effort, autonomy=a.autonomy, memory=a.memory if a.memory is not None else MEMORY_DEFAULT, workspace=a.workspace, body=a.instruction),
            encoding="utf-8",
        )
        escritos.append(alvo)
    else:
        (d / "members").mkdir(exist_ok=True)
        (d / "shared").mkdir(exist_ok=True)
        nomes = [n for n, _ in a.members]
        for n, desc in a.members:
            sub = d / "members" / n
            md = sub / "AGENT.md"
            if md.exists() and not force:
                continue
            sub.mkdir(parents=True, exist_ok=True)
            (sub / "notas").mkdir(exist_ok=True)
            md.write_text(
                render_agent_md(name=n, description=desc, model=spec, effort=a.effort, autonomy=a.autonomy, memory=a.memory if a.memory is not None else MEMORY_DEFAULT, channels=["geral"], body=f"Você é {n}: {desc}\n\nPara falar com a equipe: team_send, team_ask, team_cfp; para o quadro-negro: team_artifact_read/write.\n"),
                encoding="utf-8",
            )
            escritos.append(md)
        alvo.write_text(render_team_md(name=a.name, description=a.description, members=nomes, autonomy=a.autonomy, body=a.instruction), encoding="utf-8")
        escritos.append(alvo)

    # credencial
    info = PROVIDERS[a.provider]
    pares: dict[str, str] = {}
    if a.key and info.key_var and a.key_scope in ("global", "local"):
        pares[info.key_var] = a.key
    if a.provider == "compatible" and a.base_url:
        pares[info.url_var] = a.base_url
    if pares:
        if a.key_scope == "local" or (a.key_scope == "env" and a.provider == "compatible"):
            escritos.append(write_env_file(d / ".env", pares))
            gi = d / ".gitignore"
            if not gi.exists():
                gi.write_text(".env\n*.db\n*.db-wal\n*.db-shm\n", encoding="utf-8")
                escritos.append(gi)
        else:
            escritos.append(write_env_file(env_file() if environ is None else _env_path(environ), pares))
    a.key = ""  # o segredo não fica em memória depois de gravado
    return escritos


def _env_path(environ: Mapping[str, str]) -> Path:
    from .config import _env_file_from

    return _env_file_from(environ)


# ---------------------------------------------------------------- init


def _summary(a: Answers, escritos: Sequence[Path]) -> list[str]:
    info = PROVIDERS[a.provider]
    linhas = [f"{'agente' if a.kind == 'agent' else 'equipe'} {a.name!r} em {a.path}", f"modelo {a.model_spec()} (esforço {a.effort})"]
    if info.key_var:
        onde = {"env": "já no ambiente", "global": f"em {env_file()}", "local": f"em {a.path / '.env'}", "skip": "NÃO configurada", "": "NÃO configurada"}[a.key_scope]
        linhas.append(f"credencial {info.key_var}: {onde}")
    for p in escritos:
        linhas.append(f"  gravado {p}")
    return linhas


def cmd_init(args: argparse.Namespace) -> int:
    p = Prompter(interactive=False if (args.no_input or args.yes) else None)
    a = Answers(
        path=Path(args.path),
        kind="team" if args.team else ("agent" if args.agent else ""),
        provider=args.provider or "",
        model=args.model or "",
        effort=args.effort or "",
        base_url=args.base_url or "",
        key_scope="local" if args.local else "",
        name=args.name or "",
        description=args.description or "",
        autonomy=args.autonomy or "",
        memory=None if args.memory is None else (() if args.memory.strip().lower() in ("none", "") else tuple(x.strip() for x in args.memory.split(",") if x.strip())),
        workspace=args.workspace or "",
        instruction=Path(args.instruction).read_text(encoding="utf-8") if args.instruction else "",
        members=tuple((m.strip(), f"membro {m.strip()}") for m in (args.members or "").split(",") if m.strip()),
        first_task=args.run or "",
    )
    if a.kind == "" and a.members:
        a.kind = "team"
    alvo_existente = next((a.path / f for f in ("AGENT.md", "TEAM.md") if (a.path / f).exists()), None)
    if alvo_existente and not args.force:
        if not p.interactive:
            print(f"já configurado: {alvo_existente} (use --force para regravar)", file=sys.stderr)
            return 2
        p.say(f"{alvo_existente} já existe:")
        for line in alvo_existente.read_text(encoding="utf-8").splitlines()[:12]:
            p.say(f"   {line}")
        if not p.confirm("Regravar?", default=False):
            p.say("nada alterado")
            return 0
    if p.interactive:
        p.title(f"exovision-agent {__version__} — configurar {'uma equipe' if a.kind == 'team' else 'um agente'} em {a.path}")
        p.say("Enter aceita o padrão entre colchetes. Nada é enviado a lugar nenhum.")
        p.say()
    try:
        collect(p, a, key_file=args.key_file or "")
        escritos = materialize(a, force=True)
    except OnboardingError as erro:
        print(f"init: {erro}", file=sys.stderr)
        return 2
    # prova grátis: o que foi gravado carrega
    try:
        if a.kind == "agent":
            from .agents.profile import load_profile

            load_profile(a.path)
        else:
            from .agents.team import load_team

            load_team(a.path)
    except Exception as erro:
        print(f"init: o que gravei não carrega — {erro}", file=sys.stderr)
        return 1
    proximo = f'exovision-agent agents run {a.path} "descreva o que você faz"' if a.kind == "agent" else f"exovision-agent agents show {a.path}\n  exovision-agent agents serve {a.path}"
    if args.json:
        print(json.dumps({"kind": a.kind, "name": a.name, "path": str(a.path), "model": a.model_spec(), "effort": a.effort, "key_scope": a.key_scope, "written": [str(x) for x in escritos], "next": proximo}, ensure_ascii=False, indent=2))
    else:
        p.say()
        for line in _summary(a, escritos):
            p.say(line)
        p.say()
        p.say("Pronto. O próximo passo:")
        p.say(f"  {proximo}")
        if a.key_scope in ("skip", "") and PROVIDERS[a.provider].key_var:
            p.say(f"  (antes, exporte {PROVIDERS[a.provider].key_var} ou rode `exovision-agent init {a.path} --force` para guardá-la)")
        p.say("  exovision-agent doctor " + str(a.path) + "   # confere o que falta")
    if a.first_task and a.kind == "agent":
        from .agents.cli import cmd_run as agents_run

        ns = argparse.Namespace(path=str(a.path), task=a.first_task, scripted=None, session=None, evolve=False, json=args.json)
        return int(agents_run(ns))
    return 0


# ---------------------------------------------------------------- doctor


@dataclass(frozen=True, slots=True)
class Check:
    status: str  # ok | aviso | falha
    label: str
    detail: str = ""
    action: str = ""

    def as_dict(self) -> dict[str, str]:
        return {"status": self.status, "label": self.label, "detail": self.detail, "action": self.action}


def _kernel_check() -> Check:
    """Um laço roteirizado em memória: prova que loop, provedor, instrução e traço funcionam sem rede."""
    try:
        from .loop import Agent, run
        from .models.provider import Reply, ScriptedProvider

        prov = ScriptedProvider([Reply(content=[{"type": "text", "text": "ok"}], stop_reason="end_turn", usage={"input_tokens": 1, "output_tokens": 1})])
        out = run(Agent(provider=prov, instruction="Responda ok.", name="doctor"), "ok?")
        if out.text.strip() == "ok" and out.stop_reason == "end_turn":
            return Check("ok", "kernel", f"laço roteirizado em memória: 1 volta, {out.stop_reason}")
        return Check("falha", "kernel", f"laço devolveu {out.stop_reason!r} / {out.text!r}")
    except Exception as erro:
        return Check("falha", "kernel", f"{type(erro).__name__}: {erro}", "reinstale: pip install --force-reinstall exovision-agent")


def doctor(path: str | Path | None = None, *, environ: MutableMapping[str, str] | None = None, release: bool = False, runner: Callable[[list[str]], tuple[int, str]] | None = None) -> list[Check]:
    env: MutableMapping[str, str] = os.environ if environ is None else environ
    checks: list[Check] = []

    # Python e pacote
    v = sys.version_info
    checks.append(Check("ok" if v >= (3, 10) else "falha", "python", f"{platform.python_version()} ({platform.system()} {platform.machine()})", "" if v >= (3, 10) else "exovision-agent exige Python >= 3.10"))
    frozen = bool(getattr(sys, "frozen", False))
    origem = "binário" if frozen else str(Path(__file__).resolve().parent.parent)
    checks.append(Check("ok", "exovision-agent", f"{__version__} — {origem}"))

    # SDK anthropic
    try:
        mod = importlib.import_module("anthropic")
        checks.append(Check("ok", "sdk anthropic", f"{getattr(mod, '__version__', '?')}"))
        sdk = True
    except Exception:
        sdk = False
        checks.append(Check("aviso", "sdk anthropic", "ausente — só faz falta para o provedor anthropic", "pip install exovision-agent[anthropic]"))

    # arquivos de ambiente
    carregados = load_env(profile_dir=path, environ=dict(env) if environ is not None else None) if not env.get("EXOVISION_NO_ENV") else {}
    gf = env_file() if environ is None else _env_path(env)
    if gf.exists():
        modo = env_file_mode_ok(gf)
        chaves = sorted(parse_env(gf.read_text(encoding="utf-8")))
        checks.append(Check("ok" if modo else "aviso", "arquivo global", f"{gf}: {', '.join(chaves) or 'vazio'}" + ("" if modo else " — legível por outros"), "" if modo else f"chmod 600 {gf}"))
    else:
        checks.append(Check("aviso", "arquivo global", f"{gf} não existe", "exovision-agent init grava a credencial lá"))
    for arq, ks in carregados.items():
        if Path(arq) != gf:
            checks.append(Check("ok", ".env", f"{arq}: {', '.join(ks)}"))

    # credenciais presentes (nunca o valor)
    presentes = []
    for info in PROVIDERS.values():
        if not info.key_var:
            continue
        var = key_present(info, env)
        if var:
            presentes.append(info.kind)
            checks.append(Check("ok", f"credencial {info.kind}", f"{var} presente"))
    if not presentes:
        checks.append(Check("aviso", "credenciais", "nenhuma variável de credencial no ambiente", "exovision-agent init, ou exporte ANTHROPIC_API_KEY / OPENAI_API_KEY / GEMINI_API_KEY"))

    # o perfil ou a equipe
    if path:
        d = Path(path)
        try:
            if (d / "TEAM.md").is_file():
                from .agents.team import load_team

                t = load_team(d)
                checks.append(Check("ok", "equipe", f"{t.name}: {len(t.members)} membros, canais {', '.join(t.channels) or '-'}"))
                modelos = {(m.model, m.effort) for m in t.members.values() if m.model}
            elif (d / "AGENT.md").is_file():
                from .agents.profile import load_profile

                pr = load_profile(d)
                checks.append(Check("ok", "perfil", f"{pr.name} v{pr.version}: modelo {pr.model or '(padrão)'}, autonomia {pr.autonomy}, memória {', '.join(pr.memory) or '-'}"))
                modelos = {(pr.model, pr.effort)} if pr.model else set()
                if pr.workspace and not Path(pr.workspace).is_dir():
                    checks.append(Check("aviso", "bancada", f"{pr.workspace} não existe", "crie a pasta ou edite `workspace:` no AGENT.md"))
            else:
                checks.append(Check("falha", "perfil", f"{d}: sem AGENT.md nem TEAM.md", f"exovision-agent init {d}"))
                modelos = set()
        except Exception as erro:
            checks.append(Check("falha", "perfil", f"{type(erro).__name__}: {erro}", "corrija o front-matter"))
            modelos = set()
        from .models import parse_spec
        from .models.catalog import resolve

        for spec, esforco in sorted(modelos):
            kind, model, _url = parse_spec(spec)
            card = resolve(model)
            kind = kind or card.provider or env.get("EXOVISION_PROVIDER", "anthropic")
            pinfo = PROVIDERS.get(kind)
            if pinfo is None:
                checks.append(Check("falha", f"modelo {spec}", f"provedor {kind!r} desconhecido"))
                continue
            info = pinfo
            if info.key_var and not key_present(info, env):
                checks.append(Check("falha", f"modelo {spec}", f"sem {info.key_var} no ambiente", f"exovision-agent init {d} --force, ou exporte {info.key_var}"))
            if kind == "anthropic":
                if not sdk:
                    checks.append(Check("falha", f"modelo {spec}", "o provedor anthropic precisa do SDK", "pip install exovision-agent[anthropic]"))
                if not card.verified:  # fora do catálogo: cartão com zeros
                    checks.append(Check("aviso", f"modelo {spec}", "fora do catálogo: preço desconhecido, não grátis", "exovision-agent models catalog"))
            # O provedor omite o esforço para quem não o aceita (senão é 400 do
            # servidor). O perfil pedir o que o modelo não tem é inconsistência
            # a corrigir, não impedimento: aviso.
            if esforco and card.verified and not card.efforts:
                checks.append(Check("aviso", f"modelo {spec}", f"{card.id} não usa esforço; o `effort: {esforco}` do perfil é ignorado", "remova `effort:` do AGENT.md, ou troque por um modelo com esforço (`exovision-agent models catalog`)"))
            elif esforco and card.efforts and esforco not in card.efforts:
                checks.append(Check("falha", f"modelo {spec}", f"esforço {esforco!r} não existe em {card.id}", f"use um de: {', '.join(card.efforts)}"))
        try:
            livre = shutil.disk_usage(d if d.exists() else Path.cwd()).free
            checks.append(Check("ok" if livre > 100 * 2**20 else "aviso", "disco", f"{livre / 2**30:.1f} GiB livres em {d}", "" if livre > 100 * 2**20 else "os .db do perfil precisam de espaço"))
        except OSError:
            pass

    checks.append(_kernel_check())

    if release:
        checks.extend(_release_checks(runner))
    return checks


def _release_checks(runner: Callable[[list[str]], tuple[int, str]] | None) -> list[Check]:
    """O que `docs/release.md` exige, conferido na máquina de quem publica."""
    import re
    import subprocess

    out: list[Check] = []
    ok_ver = bool(re.fullmatch(r"\d+\.\d+\.\d+", __version__))
    out.append(Check("ok" if ok_ver else "falha", "versão", __version__, "" if ok_ver else "sem sufixo (a1, rc1, dev) para publicar"))
    raiz = _source_root()
    if raiz is None:
        out.append(Check("aviso", "árvore de fontes", "não encontrada a partir do diretório atual — os testes e a licença não foram conferidos", "rode na raiz do SDK"))
        return out
    for nome in ("LICENSE", "NOTICE", "README.md", "pyproject.toml"):
        out.append(Check("ok" if (raiz / nome).is_file() else "falha", nome, str(raiz / nome), "" if (raiz / nome).is_file() else f"falta {nome} na raiz"))

    def _run(cmd: list[str]) -> tuple[int, str]:
        if runner is not None:
            return runner(cmd)
        try:
            r = subprocess.run(cmd, cwd=raiz, capture_output=True, text=True, timeout=1800)
            return r.returncode, (r.stdout + r.stderr)[-2000:]
        except (OSError, subprocess.TimeoutExpired) as erro:
            return 1, str(erro)

    for label, cmd in (("ruff", [sys.executable, "-m", "ruff", "check", "src", "tests"]), ("mypy", [sys.executable, "-m", "mypy", "src"]), ("pytest", [sys.executable, "-m", "pytest", "-q", "-p", "no:cacheprovider"])):
        code, texto = _run(cmd)
        ultima = texto.strip().splitlines()[-1] if texto.strip() else ""
        out.append(Check("ok" if code == 0 else "falha", label, ultima[:160], "" if code == 0 else f"{' '.join(cmd[2:])} falhou"))
    return out


def _source_root() -> Path | None:
    for base in (Path.cwd(), *Path.cwd().parents):
        if (base / "pyproject.toml").is_file() and (base / "src" / "exovision").is_dir():
            return base
    return None


def cmd_doctor(args: argparse.Namespace) -> int:
    checks = doctor(args.path, release=args.release)
    if args.json:
        print(json.dumps([c.as_dict() for c in checks], ensure_ascii=False, indent=2))
    else:
        cor = sys.stdout.isatty() and not os.environ.get("NO_COLOR")
        tint = {"ok": "32", "aviso": "33", "falha": "31"}
        print(f"exovision-agent doctor {__version__}")
        for c in checks:
            st = f"\033[{tint[c.status]}m{c.status:6s}\033[0m" if cor else f"{c.status:6s}"
            print(f"  {st} {c.label}: {c.detail}" + (f"\n         → {c.action}" if c.action else ""))
        n_av = sum(c.status == "aviso" for c in checks)
        n_fa = sum(c.status == "falha" for c in checks)
        print(f"{len(checks)} verificações: {n_av} avisos, {n_fa} falhas")
    return 1 if any(c.status == "falha" for c in checks) else 0


# ---------------------------------------------------------------- CLI


def add_parser(sub: Any) -> None:
    i = sub.add_parser("init", help="configura um agente ou uma equipe, com perguntas (ou flags)")
    i.add_argument("path", nargs="?", default=".", help="diretório do agente/equipe (padrão: o atual)")
    tipo = i.add_mutually_exclusive_group()
    tipo.add_argument("--agent", action="store_true", help="um perfil (AGENT.md)")
    tipo.add_argument("--team", action="store_true", help="uma equipe (TEAM.md + members/)")
    i.add_argument("--provider", choices=list(PROVIDERS))
    i.add_argument("--model")
    i.add_argument("--effort", choices=list(_EFFORTS))
    i.add_argument("--base-url", help="URL base (provedores compatible/local)")
    i.add_argument("--key-file", help="arquivo com a credencial (uma linha); nunca passe a chave como argumento")
    i.add_argument("--local", action="store_true", help="guarda a credencial em ./.env (+ .gitignore) em vez do arquivo global")
    i.add_argument("--name")
    i.add_argument("--description")
    i.add_argument("--autonomy", choices=list(_AUTONOMY))
    i.add_argument("--memory", help="categorias separadas por vírgula, ou `none`")
    i.add_argument("--workspace", help="a bancada (bash/editor/busca confinados ali); `none` = sem")
    i.add_argument("--instruction", help="arquivo .md com o corpo da instrução")
    i.add_argument("--members", help="equipe: nomes separados por vírgula")
    i.add_argument("--run", metavar="TAREFA", help="roda esta tarefa ao terminar")
    i.add_argument("--no-input", action="store_true", help="não pergunta: padrões ou erro (código 2)")
    i.add_argument("--yes", "-y", action="store_true", help="o mesmo que --no-input")
    i.add_argument("--force", action="store_true", help="regrava um diretório já configurado")
    i.add_argument("--json", action="store_true")
    i.set_defaults(fn=cmd_init)

    d = sub.add_parser("doctor", help="confere Python, SDK, credenciais, arquivo de ambiente, perfil e o kernel")
    d.add_argument("path", nargs="?", default=None, help="diretório de um agente/equipe para conferir também")
    d.add_argument("--release", action="store_true", help="acrescenta o que o roteiro de publicação exige (suíte, ruff, mypy, licença, versão)")
    d.add_argument("--json", action="store_true")
    d.set_defaults(fn=cmd_doctor)
