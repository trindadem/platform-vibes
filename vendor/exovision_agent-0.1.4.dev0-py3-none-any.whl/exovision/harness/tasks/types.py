"""Os tipos das tarefas duráveis: o que fica no disco e o que o handler lança.

Uma `Task` é **dados** — `kind`, `payload` JSON, prioridade, dependências,
política de repetição — e nada mais. Quem sabe executá-la é o handler
registrado para o `kind` no processo. É essa separação que torna a fila
durável: o processo pode morrer e renascer com o mesmo registro de handlers,
e a tarefa continua a mesma.

O handler diz ao scheduler o que aconteceu pela exceção que lança:

    return valor            -> `succeeded` (valor JSON, ou um `Outcome`)
    raise Transient(...)    -> repetir com backoff (qualquer outra exceção também)
    raise Permanent(...)    -> `failed`, repetir não cura
    raise Cancelled(...)    -> `cancelled`
    raise StateConflict     -> `blocked`: efeito ambíguo no journal do laço; exige gente
"""

from __future__ import annotations

import enum
import hashlib
import json
import re
from collections.abc import Mapping
from dataclasses import dataclass, field
from typing import Any

__all__ = [
    "TERMINAL",
    "Attempt",
    "Cancelled",
    "LeaseLost",
    "Permanent",
    "RetryPolicy",
    "Schedule",
    "Task",
    "TaskStatus",
    "Transient",
    "Trigger",
    "render",
    "unit",
]


def unit(seed: str) -> float:
    """Um número em [0, 1) determinístico pela semente (SHA-256) — o jitter reprodutível."""
    h = hashlib.sha256(seed.encode()).digest()
    return int.from_bytes(h[:8], "big") / float(1 << 64)


class TaskStatus(str, enum.Enum):
    PENDING = "pending"  # na fila (inclui a espera por dependências e por `not_before`)
    RUNNING = "running"  # reivindicada por um worker, com lease
    SUCCEEDED = "succeeded"
    FAILED = "failed"  # permanente, ou tentativas esgotadas
    CANCELLED = "cancelled"  # pelo operador, ou em cascata por upstream que falhou
    BLOCKED = "blocked"  # `StateConflict`: só um humano destrava (`retry`)


#: Estados de onde a tarefa não sai sozinha.
TERMINAL: frozenset[str] = frozenset(
    {TaskStatus.SUCCEEDED.value, TaskStatus.FAILED.value, TaskStatus.CANCELLED.value}
)


class Transient(Exception):
    """Falha que vale repetir: rede, provedor, recurso ocupado."""


class Permanent(Exception):
    """Falha que repetir não cura: entrada inválida, recusa, orçamento fechado."""


class Cancelled(Exception):
    """A tarefa parou porque o operador pediu."""


class LeaseLost(RuntimeError):
    """O worker perdeu a lease; o que ele produziu não vale mais."""


@dataclass(frozen=True, slots=True)
class RetryPolicy:
    """Backoff exponencial com teto e jitter **determinístico**.

    `delay(n)` é a espera depois da n-ésima tentativa falhar. O jitter é uma
    fração do intervalo, sorteada de um hash de `(seed, n)`: duas execuções da
    mesma tarefa esperam o mesmo tempo (reprodutível), e tarefas diferentes se
    dispersam (não batem no provedor no mesmo instante).
    """

    max_attempts: int = 3
    base_s: float = 1.0
    factor: float = 2.0
    max_s: float = 300.0
    jitter: float = 0.0

    def delay(self, attempt: int, *, seed: str = "") -> float:
        raw = min(self.max_s, self.base_s * (self.factor ** max(0, attempt - 1)))
        if self.jitter <= 0:
            return raw
        u = unit(f"{seed}:{attempt}")
        return raw * (1.0 - self.jitter + 2.0 * self.jitter * u)

    def to_dict(self) -> dict[str, Any]:
        return {
            "max_attempts": self.max_attempts,
            "base_s": self.base_s,
            "factor": self.factor,
            "max_s": self.max_s,
            "jitter": self.jitter,
        }

    @classmethod
    def from_dict(cls, d: dict[str, Any] | None) -> RetryPolicy:
        d = d or {}
        return cls(
            max_attempts=int(d.get("max_attempts", 3)),
            base_s=float(d.get("base_s", 1.0)),
            factor=float(d.get("factor", 2.0)),
            max_s=float(d.get("max_s", 300.0)),
            jitter=float(d.get("jitter", 0.0)),
        )


@dataclass(slots=True)
class Task:
    """Uma linha da fila. Tudo aqui é serializável; nada aqui executa."""

    id: str
    kind: str
    payload: dict[str, Any] = field(default_factory=dict)
    status: str = TaskStatus.PENDING.value
    key: str | None = None
    priority: int = 0
    not_before: float = 0.0
    attempts: int = 0  # monotônico: nunca volta atrás (é o fencing token)
    reopened_at_attempt: int = 0  # valor de `attempts` na última reabertura pelo operador
    retry: RetryPolicy = field(default_factory=RetryPolicy)
    timeout_s: float | None = None
    lease_until: float | None = None
    worker: str | None = None
    cancel_requested: bool = False
    result: Any = None
    error: str = ""
    after: tuple[str, ...] = ()
    origin: str = ""  # "" (manual) | "schedule:<nome>" | "trigger:<nome>"
    created_at: float = 0.0
    updated_at: float = 0.0
    started_at: float | None = None
    finished_at: float | None = None
    meta: dict[str, Any] = field(default_factory=dict)

    @property
    def tries(self) -> int:
        """Tentativas desde a última reabertura — o que a política de repetição conta."""
        return self.attempts - self.reopened_at_attempt

    @property
    def terminal(self) -> bool:
        return self.status in TERMINAL

    @property
    def ok(self) -> bool:
        return self.status == TaskStatus.SUCCEEDED.value

    def to_dict(self) -> dict[str, Any]:
        return {
            "id": self.id,
            "kind": self.kind,
            "payload": self.payload,
            "status": self.status,
            "key": self.key,
            "priority": self.priority,
            "not_before": self.not_before,
            "attempts": self.attempts,
            "reopened_at_attempt": self.reopened_at_attempt,
            "retry": self.retry.to_dict(),
            "timeout_s": self.timeout_s,
            "lease_until": self.lease_until,
            "worker": self.worker,
            "cancel_requested": self.cancel_requested,
            "result": self.result,
            "error": self.error,
            "after": list(self.after),
            "origin": self.origin,
            "created_at": self.created_at,
            "updated_at": self.updated_at,
            "started_at": self.started_at,
            "finished_at": self.finished_at,
            "meta": self.meta,
        }

    @classmethod
    def from_dict(cls, d: dict[str, Any]) -> Task:
        return cls(
            id=str(d["id"]),
            kind=str(d["kind"]),
            payload=dict(d.get("payload") or {}),
            status=str(d.get("status", TaskStatus.PENDING.value)),
            key=d.get("key"),
            priority=int(d.get("priority", 0)),
            not_before=float(d.get("not_before", 0.0)),
            attempts=int(d.get("attempts", 0)),
            reopened_at_attempt=int(d.get("reopened_at_attempt", 0)),
            retry=RetryPolicy.from_dict(d.get("retry")),
            timeout_s=(float(d["timeout_s"]) if d.get("timeout_s") is not None else None),
            lease_until=(float(d["lease_until"]) if d.get("lease_until") is not None else None),
            worker=d.get("worker"),
            cancel_requested=bool(d.get("cancel_requested", False)),
            result=d.get("result"),
            error=str(d.get("error") or ""),
            after=tuple(d.get("after") or ()),
            origin=str(d.get("origin") or ""),
            created_at=float(d.get("created_at", 0.0)),
            updated_at=float(d.get("updated_at", 0.0)),
            started_at=(float(d["started_at"]) if d.get("started_at") is not None else None),
            finished_at=(float(d["finished_at"]) if d.get("finished_at") is not None else None),
            meta=dict(d.get("meta") or {}),
        )


@dataclass(frozen=True, slots=True)
class Attempt:
    """Uma execução (ou uma perda de lease) — a linha do histórico da tarefa."""

    task_id: str
    attempt: int
    worker: str
    started_at: float
    finished_at: float | None = None
    status: str = "running"  # running | succeeded | failed | retry | cancelled | blocked | lost | stale
    error: str = ""

    def to_dict(self) -> dict[str, Any]:
        return {
            "task_id": self.task_id,
            "attempt": self.attempt,
            "worker": self.worker,
            "started_at": self.started_at,
            "finished_at": self.finished_at,
            "status": self.status,
            "error": self.error,
        }


def dumps(value: Any) -> str:
    """JSON estável (chaves ordenadas) — o que vai para o disco."""
    return json.dumps(value, ensure_ascii=False, sort_keys=True, default=str)


# --------------------------------------------------------------------------
# recorrência e gatilhos
# --------------------------------------------------------------------------


@dataclass(slots=True)
class Schedule:
    """Uma agenda: a mesma tarefa, de novo — por intervalo ou por cron.

    `overlap`: `skip` não dispara enquanto a instância anterior está pendente
    ou rodando; `queue` enfileira mesmo assim. `catch_up`: o que fazer com
    disparos perdidos (o worker estava fora): `one` dispara uma vez, `all`
    dispara uma por disparo perdido, `none` só dispara se o atraso for menor
    que a tolerância (`CATCH_UP_GRACE_S`, 60 s — "a agenda estava viva").
    `jitter_s` dispersa o `not_before` de forma determinística por (agenda,
    disparo).
    """

    name: str
    kind: str
    payload: dict[str, Any] = field(default_factory=dict)
    every_s: float | None = None
    cron: str | None = None
    tz: str = "UTC"
    next_at: float = 0.0
    overlap: str = "skip"
    catch_up: str = "one"
    jitter_s: float = 0.0
    ends_at: float | None = None
    max_runs: int | None = None
    runs: int = 0
    last_fired_at: float | None = None
    paused: bool = False
    priority: int = 0
    retry: RetryPolicy = field(default_factory=RetryPolicy)
    timeout_s: float | None = None
    created_at: float = 0.0
    updated_at: float = 0.0

    def to_dict(self) -> dict[str, Any]:
        return {
            "name": self.name,
            "kind": self.kind,
            "payload": self.payload,
            "every_s": self.every_s,
            "cron": self.cron,
            "tz": self.tz,
            "next_at": self.next_at,
            "overlap": self.overlap,
            "catch_up": self.catch_up,
            "jitter_s": self.jitter_s,
            "ends_at": self.ends_at,
            "max_runs": self.max_runs,
            "runs": self.runs,
            "last_fired_at": self.last_fired_at,
            "paused": self.paused,
            "priority": self.priority,
            "retry": self.retry.to_dict(),
            "timeout_s": self.timeout_s,
            "created_at": self.created_at,
            "updated_at": self.updated_at,
        }


@dataclass(slots=True)
class Trigger:
    """Um gatilho: mensagem que casa `pattern` no barramento vira uma tarefa.

    O `payload` é um molde: strings com `{{subject}}`, `{{seq}}`, `{{at}}` e
    `{{data.caminho}}` são preenchidas com a mensagem (`render`). A tarefa
    entra com `key = trigger:<nome>:<seq>` — a mesma mensagem nunca vira duas
    tarefas, mesmo com dois processos puxando ao mesmo tempo.
    """

    name: str
    pattern: str
    kind: str
    payload: dict[str, Any] = field(default_factory=dict)
    priority: int = 0
    retry: RetryPolicy = field(default_factory=RetryPolicy)
    timeout_s: float | None = None
    paused: bool = False
    fired: int = 0
    hold: bool = False  # a tarefa nasce em espera de aprovação (portão humano)
    created_at: float = 0.0
    updated_at: float = 0.0

    def to_dict(self) -> dict[str, Any]:
        return {
            "name": self.name,
            "pattern": self.pattern,
            "kind": self.kind,
            "payload": self.payload,
            "priority": self.priority,
            "retry": self.retry.to_dict(),
            "timeout_s": self.timeout_s,
            "paused": self.paused,
            "fired": self.fired,
            "hold": self.hold,
            "created_at": self.created_at,
            "updated_at": self.updated_at,
        }


_PLACEHOLDER = re.compile(r"\{\{\s*([A-Za-z0-9_.\-]+)\s*\}\}")


def _lookup(ctx: Mapping[str, Any], path: str) -> Any:
    cur: Any = ctx
    for part in path.split("."):
        if isinstance(cur, Mapping) and part in cur:
            cur = cur[part]
        elif isinstance(cur, (list, tuple)) and part.isdigit() and int(part) < len(cur):
            cur = cur[int(part)]
        else:
            return ""
    return cur


def render(template: Any, ctx: Mapping[str, Any]) -> Any:
    """Preenche `{{caminho}}` em toda string do molde (recursivo em dict/list).

    Uma string que é **só** um placeholder devolve o valor com o tipo original
    (`"{{data.n}}"` -> 3); com texto em volta, vira texto. Caminho ausente -> "".
    """
    if isinstance(template, str):
        m = _PLACEHOLDER.fullmatch(template.strip())
        if m:
            return _lookup(ctx, m.group(1))
        return _PLACEHOLDER.sub(lambda mm: str(_lookup(ctx, mm.group(1))), template)
    if isinstance(template, Mapping):
        return {k: render(v, ctx) for k, v in template.items()}
    if isinstance(template, list):
        return [render(v, ctx) for v in template]
    return template
