"""Expressões cron em stdlib: cinco campos, nomes, listas, intervalos, passos, apelidos.

    minuto hora dia-do-mês mês dia-da-semana
    0 9 * * mon-fri        # 09:00 em dia útil
    */15 * * * *           # a cada 15 min
    0 0 1 */3 *            # meia-noite do dia 1, a cada 3 meses
    @daily  @hourly  @weekly  @monthly  @yearly

Semântica de `crontab(5)`: quando dia-do-mês **e** dia-da-semana são ambos
restritos, basta um casar (OU); quando um deles é `*`, só o outro decide.
Domingo é 0 ou 7. O fuso é o da agenda (`zoneinfo`); a aritmética é de
relógio de parede, como no cron — uma hora que não existe na mudança de
horário é pulada, uma que existe duas vezes dispara uma vez.

`next_fire(expr, after, tz)` avança por saltos — mês, dia, hora, minuto —
em vez de minuto a minuto: `0 0 29 2 *` (só em bissexto) resolve em
milissegundos, não em milhões de iterações.
"""

from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime, timedelta
from zoneinfo import ZoneInfo

__all__ = ["Cron", "next_fire", "parse"]

_ALIASES = {
    "@yearly": "0 0 1 1 *",
    "@annually": "0 0 1 1 *",
    "@monthly": "0 0 1 * *",
    "@weekly": "0 0 * * 0",
    "@daily": "0 0 * * *",
    "@midnight": "0 0 * * *",
    "@hourly": "0 * * * *",
}
_MONTHS = {m: i + 1 for i, m in enumerate(["jan", "feb", "mar", "apr", "may", "jun", "jul", "aug", "sep", "oct", "nov", "dec"])}
_DAYS = {d: i for i, d in enumerate(["sun", "mon", "tue", "wed", "thu", "fri", "sat"])}
_RANGES = ((0, 59), (0, 23), (1, 31), (1, 12), (0, 7))
_NAMES: tuple[dict[str, int], ...] = ({}, {}, {}, _MONTHS, _DAYS)


def _atom(tok: str, lo: int, hi: int, names: dict[str, int]) -> int:
    t = tok.strip().lower()
    if t in names:
        return names[t]
    try:
        v = int(t)
    except ValueError:
        raise ValueError(f"valor inválido no cron: {tok!r}") from None
    if not lo <= v <= hi:
        raise ValueError(f"{v} fora de [{lo}, {hi}] no cron")
    return v


def _field(spec: str, lo: int, hi: int, names: dict[str, int]) -> frozenset[int]:
    out: set[int] = set()
    for part in spec.split(","):
        part = part.strip()
        if not part:
            raise ValueError(f"campo vazio no cron: {spec!r}")
        step = 1
        stepped = "/" in part
        if stepped:
            part, s = part.split("/", 1)
            try:
                step = int(s)
            except ValueError:
                raise ValueError(f"passo inválido no cron: {s!r}") from None
            if step < 1:
                raise ValueError(f"passo inválido no cron: {s!r}")
        if part == "*":
            a, b = lo, hi
        elif "-" in part:
            x, y = part.split("-", 1)
            a, b = _atom(x, lo, hi, names), _atom(y, lo, hi, names)
            if a > b:
                raise ValueError(f"intervalo invertido no cron: {part!r}")
        else:
            a = _atom(part, lo, hi, names)
            b = hi if stepped else a  # `5/10` = 5, 15, 25, ... (como no cron)
        out.update(range(a, b + 1, step))
    return frozenset(out)


@dataclass(frozen=True, slots=True)
class Cron:
    expr: str
    minutes: frozenset[int]
    hours: frozenset[int]
    days: frozenset[int]
    months: frozenset[int]
    weekdays: frozenset[int]  # 0..6, domingo = 0
    day_restricted: bool
    weekday_restricted: bool

    def matches_day(self, d: datetime) -> bool:
        wd = (d.weekday() + 1) % 7  # Python: segunda=0; cron: domingo=0
        by_dom = d.day in self.days
        by_dow = wd in self.weekdays
        if self.day_restricted and self.weekday_restricted:
            return by_dom or by_dow
        if self.day_restricted:
            return by_dom
        if self.weekday_restricted:
            return by_dow
        return True


def parse(expr: str) -> Cron:
    e = expr.strip().lower()
    e = _ALIASES.get(e, e)
    fields = e.split()
    if len(fields) != 5:
        raise ValueError(f"cron precisa de 5 campos (min hora dia mês dia-da-semana): {expr!r}")
    sets = [_field(f, lo, hi, names) for f, (lo, hi), names in zip(fields, _RANGES, _NAMES, strict=True)]
    weekdays = frozenset(v % 7 for v in sets[4])  # 7 -> 0
    return Cron(
        expr=expr.strip(),
        minutes=sets[0],
        hours=sets[1],
        days=sets[2],
        months=sets[3],
        weekdays=weekdays,
        day_restricted=fields[2] != "*",
        weekday_restricted=fields[4] != "*",
    )


def next_fire(expr: str | Cron, after: float, tz: str = "UTC", *, horizon_days: int = 366 * 5) -> float:
    """O primeiro instante estritamente depois de `after` (timestamp Unix) que casa a expressão."""
    cron = parse(expr) if isinstance(expr, str) else expr
    zone = ZoneInfo(tz)
    start = datetime.fromtimestamp(after, zone).replace(second=0, microsecond=0) + timedelta(minutes=1)
    limit = start + timedelta(days=horizon_days)
    d = start
    while d < limit:
        if d.month not in cron.months:
            y, m = (d.year + 1, 1) if d.month == 12 else (d.year, d.month + 1)
            d = d.replace(year=y, month=m, day=1, hour=0, minute=0)
            continue
        if not cron.matches_day(d):
            d = (d + timedelta(days=1)).replace(hour=0, minute=0)
            continue
        if d.hour not in cron.hours:
            d = (d + timedelta(hours=1)).replace(minute=0)
            continue
        if d.minute not in cron.minutes:
            d = d + timedelta(minutes=1)
            continue
        if d.utcoffset() != datetime.fromtimestamp(d.timestamp(), zone).utcoffset():
            # hora de parede que não existe (salto de horário de verão): pula
            d = d + timedelta(minutes=1)
            continue
        return d.timestamp()
    raise ValueError(f"cron {cron.expr!r} não dispara nos próximos {horizon_days} dias")
