"""exovision.harness.tasks — tarefas paralelas, simultâneas, duráveis e resilientes.

Módulo do kernel. A fila é dados em SQLite (`store`); o scheduler reivindica
com lease, executa em workers, repete com backoff, bloqueia o que é ambíguo
e cancela em cascata o que ficou sem upstream (`scheduler`); a tarefa de
agente retoma o journal do laço em vez de repetir (`runners`).

    from exovision.harness.tasks import Scheduler, SQLiteTaskStore, AgentRunner
    sched = Scheduler(SQLiteTaskStore("tasks.db"), {"agent": AgentRunner({"revisor": agent})})
    t = sched.enqueue("agent", {"agent": "revisor", "task": "revise o PR 42"}, key="pr-42")
    sched.run_until_idle(); sched.outcome(t.id)

    types      — Task, TaskStatus, RetryPolicy, Attempt, Schedule, Trigger, render;
                 Transient/Permanent/Cancelled
    store      — TaskStore (protocolo) e SQLiteTaskStore: claim atômico, lease, fencing,
                 DAG, agendas e gatilhos — tudo no mesmo arquivo
    cron       — expressões cron em stdlib (5 campos, nomes, apelidos, fuso)
    scheduler  — Scheduler e TaskContext: step/drain (síncrono), start/stop/serve_forever
                 (threads); schedule/on (recorrência e gatilhos); tick
    runners    — AgentRunner: a tarefa carrega o nome do agente; o agente é código
    cli        — `exovision-agent tasks add|work|ls|show|cancel|retry|schedule|on|publish|messages`

Tudo embarcado: a fila, as agendas, os gatilhos e o barramento (`exovision.harness.bus`)
são tabelas em SQLite (WAL). Não há serviço a instalar; um nó, N processos.
"""

from __future__ import annotations

from .cron import Cron, next_fire, parse
from .runners import AgentRunner
from .scheduler import HOLD, Handler, Scheduler, TaskContext
from .store import SQLiteTaskStore, TaskStore, new_id
from .types import (
    TERMINAL,
    Attempt,
    Cancelled,
    LeaseLost,
    Permanent,
    RetryPolicy,
    Schedule,
    Task,
    TaskStatus,
    Transient,
    Trigger,
    render,
    unit,
)

__all__ = [
    "HOLD",
    "TERMINAL",
    "AgentRunner",
    "Attempt",
    "Cancelled",
    "Cron",
    "Handler",
    "LeaseLost",
    "Permanent",
    "RetryPolicy",
    "SQLiteTaskStore",
    "Schedule",
    "Scheduler",
    "Task",
    "TaskContext",
    "TaskStatus",
    "TaskStore",
    "Transient",
    "Trigger",
    "new_id",
    "next_fire",
    "parse",
    "render",
    "unit",
]
