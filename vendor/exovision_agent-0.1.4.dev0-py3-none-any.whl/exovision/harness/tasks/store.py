"""A fila durável: SQLite, uma transação por decisão, lease com *fencing*.

Três propriedades, e o mecanismo de cada uma:

1. **Durável.** `add` só retorna depois do `COMMIT`. Um processo que morre
   um instante depois já deixou a tarefa no disco. WAL para leitura
   concorrente; `busy_timeout` para dois processos no mesmo arquivo.
2. **Uma execução por vez.** `claim` roda em `BEGIN IMMEDIATE`: dois workers
   — threads ou processos — nunca reivindicam a mesma tarefa. A lease
   (Gray & Cheriton, 1989) tem prazo; quem não a renova perde a tarefa
   para outro worker (`reap`).
3. **O worker que perdeu a lease não escreve.** `complete`, `release` e
   `heartbeat` só valem para `(worker, attempt)` iguais aos da linha — o
   número da tentativa é o *fencing token* (Kleppmann, 2017): um worker que
   ficou preso, acordou tarde e terminou, descobre que o seu resultado não
   vale mais, em vez de sobrescrever o do worker que o substituiu.

A fila não sabe executar nada; ela guarda, entrega, e registra o histórico
(`attempts`). Processos e threads compartilham o arquivo; a classe é segura
para threads por um lock e para processos pelo lock do próprio SQLite.
"""

from __future__ import annotations

import contextlib
import json
import sqlite3
import threading
import uuid
from collections.abc import Iterator, Sequence
from pathlib import Path
from typing import Any, Protocol, runtime_checkable

from ..session import enable_wal
from .types import TERMINAL, Attempt, RetryPolicy, Schedule, Task, TaskStatus, Trigger, dumps

__all__ = ["SQLiteTaskStore", "TaskStore", "new_id"]


def new_id() -> str:
    return uuid.uuid4().hex[:16]


@runtime_checkable
class TaskStore(Protocol):
    """O que o scheduler exige de uma fila. Um backend NATS/Temporal entra por aqui."""

    def add(self, task: Task) -> Task: ...

    def get(self, task_id: str) -> Task | None: ...

    def claim(self, worker: str, *, now: float, lease_s: float) -> Task | None: ...

    def heartbeat(self, task_id: str, worker: str, attempt: int, *, lease_until: float) -> bool: ...

    def complete(
        self,
        task_id: str,
        worker: str,
        attempt: int,
        *,
        status: str,
        result: Any = None,
        error: str = "",
        now: float,
    ) -> bool: ...

    def release(
        self, task_id: str, worker: str, attempt: int, *, not_before: float, error: str, now: float
    ) -> bool: ...

    def reap(self, *, now: float) -> list[str]: ...

    def cancel(self, task_id: str, *, now: float, reason: str = "") -> str | None: ...

    def cancel_requested(self, task_id: str) -> bool: ...

    def retry(self, task_id: str, *, now: float) -> bool: ...

    def wake(self, task_id: str, *, now: float) -> bool: ...

    def tasks(self, status: str | None = None) -> list[Task]: ...

    def attempts(self, task_id: str) -> list[Attempt]: ...

    def counts(self) -> dict[str, int]: ...

    def active_from(self, origin: str) -> int: ...

    def put_schedule(self, sch: Schedule) -> Schedule: ...

    def get_schedule(self, name: str) -> Schedule | None: ...

    def schedules(self) -> list[Schedule]: ...

    def due_schedules(self, *, now: float) -> list[Schedule]: ...

    def advance_schedule(
        self, name: str, *, expected_next: float, next_at: float, fired: int, now: float
    ) -> bool: ...

    def set_schedule_paused(self, name: str, paused: bool, *, now: float) -> bool: ...

    def delete_schedule(self, name: str) -> bool: ...

    def put_trigger(self, trg: Trigger) -> Trigger: ...

    def get_trigger(self, name: str) -> Trigger | None: ...

    def triggers(self, *, active_only: bool = False) -> list[Trigger]: ...

    def count_trigger(self, name: str, fired: int, *, now: float) -> None: ...

    def set_trigger_paused(self, name: str, paused: bool, *, now: float) -> bool: ...

    def delete_trigger(self, name: str) -> bool: ...


_SCHEMA = """
CREATE TABLE IF NOT EXISTS tasks (
    id TEXT PRIMARY KEY,
    key TEXT,
    kind TEXT NOT NULL,
    payload TEXT NOT NULL,
    status TEXT NOT NULL,
    priority INTEGER NOT NULL DEFAULT 0,
    not_before REAL NOT NULL DEFAULT 0,
    attempts INTEGER NOT NULL DEFAULT 0,
    reopened_at_attempt INTEGER NOT NULL DEFAULT 0,
    retry TEXT NOT NULL,
    timeout_s REAL,
    lease_until REAL,
    worker TEXT,
    cancel_requested INTEGER NOT NULL DEFAULT 0,
    result TEXT,
    error TEXT NOT NULL DEFAULT '',
    created_at REAL NOT NULL,
    updated_at REAL NOT NULL,
    started_at REAL,
    finished_at REAL,
    meta TEXT NOT NULL DEFAULT '{}',
    origin TEXT NOT NULL DEFAULT ''
);
CREATE UNIQUE INDEX IF NOT EXISTS tasks_key ON tasks(key) WHERE key IS NOT NULL;
CREATE INDEX IF NOT EXISTS tasks_origin ON tasks(origin, status);
CREATE INDEX IF NOT EXISTS tasks_claim ON tasks(status, priority, not_before);
CREATE TABLE IF NOT EXISTS deps (
    task_id TEXT NOT NULL,
    depends_on TEXT NOT NULL,
    pos INTEGER NOT NULL DEFAULT 0,
    PRIMARY KEY (task_id, depends_on)
);
CREATE INDEX IF NOT EXISTS deps_up ON deps(depends_on);
CREATE TABLE IF NOT EXISTS schedules (
    name TEXT PRIMARY KEY,
    kind TEXT NOT NULL,
    payload TEXT NOT NULL,
    every_s REAL,
    cron TEXT,
    tz TEXT NOT NULL DEFAULT 'UTC',
    next_at REAL NOT NULL,
    overlap TEXT NOT NULL DEFAULT 'skip',
    catch_up TEXT NOT NULL DEFAULT 'one',
    jitter_s REAL NOT NULL DEFAULT 0,
    ends_at REAL,
    max_runs INTEGER,
    runs INTEGER NOT NULL DEFAULT 0,
    last_fired_at REAL,
    paused INTEGER NOT NULL DEFAULT 0,
    priority INTEGER NOT NULL DEFAULT 0,
    retry TEXT NOT NULL,
    timeout_s REAL,
    created_at REAL NOT NULL,
    updated_at REAL NOT NULL
);
CREATE TABLE IF NOT EXISTS triggers (
    name TEXT PRIMARY KEY,
    pattern TEXT NOT NULL,
    kind TEXT NOT NULL,
    payload TEXT NOT NULL,
    priority INTEGER NOT NULL DEFAULT 0,
    retry TEXT NOT NULL,
    timeout_s REAL,
    paused INTEGER NOT NULL DEFAULT 0,
    fired INTEGER NOT NULL DEFAULT 0,
    hold INTEGER NOT NULL DEFAULT 0,
    created_at REAL NOT NULL,
    updated_at REAL NOT NULL
);
CREATE TABLE IF NOT EXISTS attempts (
    task_id TEXT NOT NULL,
    attempt INTEGER NOT NULL,
    worker TEXT NOT NULL,
    started_at REAL NOT NULL,
    finished_at REAL,
    status TEXT NOT NULL,
    error TEXT NOT NULL DEFAULT '',
    PRIMARY KEY (task_id, attempt)
);
"""

_COLS = (
    "id, key, kind, payload, status, priority, not_before, attempts, reopened_at_attempt, retry, "
    "timeout_s, lease_until, worker, cancel_requested, result, error, created_at, updated_at, "
    "started_at, finished_at, meta, origin"
)
_SCHED_COLS = (
    "name, kind, payload, every_s, cron, tz, next_at, overlap, catch_up, jitter_s, ends_at, "
    "max_runs, runs, last_fired_at, paused, priority, retry, timeout_s, created_at, updated_at"
)
_TRIG_COLS = "name, pattern, kind, payload, priority, retry, timeout_s, paused, fired, hold, created_at, updated_at"

# Uma tarefa pode ser reivindicada quando está pendente, chegou a hora, e
# toda dependência já terminou bem.
_CLAIMABLE = """
    status = 'pending' AND not_before <= :now
    AND NOT EXISTS (
        SELECT 1 FROM deps d JOIN tasks u ON u.id = d.depends_on
        WHERE d.task_id = tasks.id AND u.status != 'succeeded'
    )
"""


class SQLiteTaskStore:
    """Um arquivo (ou `:memory:`), três tabelas, uma transação por decisão."""

    def __init__(self, path: str | Path = ":memory:", *, busy_timeout_s: float = 30.0) -> None:
        self.path = str(path)
        if self.path != ":memory:":
            Path(self.path).parent.mkdir(parents=True, exist_ok=True)
        self._lock = threading.RLock()
        # isolation_level=None: nós dizemos onde a transação começa (BEGIN IMMEDIATE).
        self._conn = sqlite3.connect(
            self.path, isolation_level=None, check_same_thread=False, timeout=busy_timeout_s
        )
        self._conn.row_factory = sqlite3.Row
        with self._lock:
            self._conn.execute(f"PRAGMA busy_timeout={int(busy_timeout_s * 1000)}")
            if self.path != ":memory:":
                enable_wal(self._conn, timeout_s=busy_timeout_s)
            self._conn.executescript(_SCHEMA)

    # ----------------------------------------------------------- infra
    @contextlib.contextmanager
    def _tx(self) -> Iterator[sqlite3.Connection]:
        with self._lock:
            self._conn.execute("BEGIN IMMEDIATE")
            try:
                yield self._conn
            except BaseException:
                self._conn.execute("ROLLBACK")
                raise
            else:
                self._conn.execute("COMMIT")

    def _row_to_task(self, row: sqlite3.Row, after: Sequence[str] = ()) -> Task:
        return Task(
            id=row["id"],
            kind=row["kind"],
            payload=json.loads(row["payload"]),
            status=row["status"],
            key=row["key"],
            priority=int(row["priority"]),
            not_before=float(row["not_before"]),
            attempts=int(row["attempts"]),
            reopened_at_attempt=int(row["reopened_at_attempt"]),
            retry=RetryPolicy.from_dict(json.loads(row["retry"])),
            timeout_s=row["timeout_s"],
            lease_until=row["lease_until"],
            worker=row["worker"],
            cancel_requested=bool(row["cancel_requested"]),
            result=json.loads(row["result"]) if row["result"] is not None else None,
            error=row["error"] or "",
            after=tuple(after),
            created_at=float(row["created_at"]),
            updated_at=float(row["updated_at"]),
            started_at=row["started_at"],
            finished_at=row["finished_at"],
            meta=json.loads(row["meta"] or "{}"),
            origin=row["origin"] or "",
        )

    @staticmethod
    def _row_to_schedule(row: sqlite3.Row) -> Schedule:
        return Schedule(
            name=row["name"],
            kind=row["kind"],
            payload=json.loads(row["payload"]),
            every_s=row["every_s"],
            cron=row["cron"],
            tz=row["tz"],
            next_at=float(row["next_at"]),
            overlap=row["overlap"],
            catch_up=row["catch_up"],
            jitter_s=float(row["jitter_s"]),
            ends_at=row["ends_at"],
            max_runs=row["max_runs"],
            runs=int(row["runs"]),
            last_fired_at=row["last_fired_at"],
            paused=bool(row["paused"]),
            priority=int(row["priority"]),
            retry=RetryPolicy.from_dict(json.loads(row["retry"])),
            timeout_s=row["timeout_s"],
            created_at=float(row["created_at"]),
            updated_at=float(row["updated_at"]),
        )

    @staticmethod
    def _row_to_trigger(row: sqlite3.Row) -> Trigger:
        return Trigger(
            name=row["name"],
            pattern=row["pattern"],
            kind=row["kind"],
            payload=json.loads(row["payload"]),
            priority=int(row["priority"]),
            retry=RetryPolicy.from_dict(json.loads(row["retry"])),
            timeout_s=row["timeout_s"],
            paused=bool(row["paused"]),
            fired=int(row["fired"]),
            hold=bool(row["hold"]),
            created_at=float(row["created_at"]),
            updated_at=float(row["updated_at"]),
        )

    def _after(self, conn: sqlite3.Connection, task_id: str) -> list[str]:
        rows = conn.execute(
            "SELECT depends_on FROM deps WHERE task_id = ? ORDER BY pos", (task_id,)
        ).fetchall()
        return [r[0] for r in rows]

    def _get(self, conn: sqlite3.Connection, task_id: str) -> Task | None:
        row = conn.execute(f"SELECT {_COLS} FROM tasks WHERE id = ?", (task_id,)).fetchone()
        return self._row_to_task(row, self._after(conn, task_id)) if row else None

    # ------------------------------------------------------- produzir
    def add(self, task: Task) -> Task:
        """Grava e devolve a tarefa. Com `key` repetida, devolve a existente (idempotência)."""
        with self._tx() as conn:
            if task.key is not None:
                row = conn.execute("SELECT id FROM tasks WHERE key = ?", (task.key,)).fetchone()
                if row:
                    existing = self._get(conn, row[0])
                    assert existing is not None
                    return existing
            for dep in task.after:
                if conn.execute("SELECT 1 FROM tasks WHERE id = ?", (dep,)).fetchone() is None:
                    raise KeyError(f"dependência desconhecida: {dep!r}")
            conn.execute(
                f"INSERT INTO tasks({_COLS}) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)",
                (
                    task.id,
                    task.key,
                    task.kind,
                    dumps(task.payload),
                    task.status,
                    task.priority,
                    task.not_before,
                    task.attempts,
                    task.reopened_at_attempt,
                    dumps(task.retry.to_dict()),
                    task.timeout_s,
                    task.lease_until,
                    task.worker,
                    int(task.cancel_requested),
                    dumps(task.result) if task.result is not None else None,
                    task.error,
                    task.created_at,
                    task.updated_at,
                    task.started_at,
                    task.finished_at,
                    dumps(task.meta),
                    task.origin,
                ),
            )
            conn.executemany(
                "INSERT OR IGNORE INTO deps(task_id, depends_on, pos) VALUES (?, ?, ?)",
                [(task.id, dep, i) for i, dep in enumerate(task.after)],
            )
            return task

    def get(self, task_id: str) -> Task | None:
        with self._lock:
            return self._get(self._conn, task_id)

    # ------------------------------------------------------- executar
    def claim(self, worker: str, *, now: float, lease_s: float) -> Task | None:
        """Reivindica a próxima tarefa: prioridade maior, depois a mais antiga. Atômico.

        O desempate é o `rowid` — ordem de inserção —, não `created_at`: dois
        `enqueue` no mesmo tick do relógio ainda saem na ordem em que entraram.
        """
        with self._tx() as conn:
            row = conn.execute(
                f"SELECT id FROM tasks WHERE {_CLAIMABLE} "
                "ORDER BY priority DESC, not_before ASC, rowid ASC LIMIT 1",
                {"now": now},
            ).fetchone()
            if row is None:
                return None
            task_id = row[0]
            conn.execute(
                "UPDATE tasks SET status = 'running', worker = ?, attempts = attempts + 1, "
                "lease_until = ?, started_at = COALESCE(started_at, ?), updated_at = ? WHERE id = ?",
                (worker, now + lease_s, now, now, task_id),
            )
            task = self._get(conn, task_id)
            assert task is not None
            conn.execute(
                "INSERT INTO attempts(task_id, attempt, worker, started_at, status) VALUES (?,?,?,?,?)",
                (task_id, task.attempts, worker, now, "running"),
            )
            return task

    def heartbeat(self, task_id: str, worker: str, attempt: int, *, lease_until: float) -> bool:
        """Renova a lease. `False` = a tarefa já não é deste worker."""
        with self._tx() as conn:
            cur = conn.execute(
                "UPDATE tasks SET lease_until = ? WHERE id = ? AND worker = ? AND attempts = ? "
                "AND status = 'running'",
                (lease_until, task_id, worker, attempt),
            )
            return cur.rowcount == 1

    def _finish_attempt(
        self, conn: sqlite3.Connection, task_id: str, attempt: int, status: str, error: str, now: float
    ) -> None:
        conn.execute(
            "UPDATE attempts SET finished_at = ?, status = ?, error = ? WHERE task_id = ? AND attempt = ?",
            (now, status, error, task_id, attempt),
        )

    def _cascade_cancel(self, conn: sqlite3.Connection, task_id: str, now: float) -> None:
        """Quem dependia de uma tarefa que falhou nunca vai rodar: cancela em cascata."""
        rows = conn.execute(
            """
            WITH RECURSIVE down(id) AS (
                SELECT task_id FROM deps WHERE depends_on = :root
                UNION
                SELECT d.task_id FROM deps d JOIN down ON d.depends_on = down.id
            )
            SELECT id FROM down
            """,
            {"root": task_id},
        ).fetchall()
        for (dep_id,) in rows:
            conn.execute(
                "UPDATE tasks SET status = 'cancelled', error = ?, finished_at = ?, updated_at = ? "
                "WHERE id = ? AND status = 'pending'",
                (f"upstream:{task_id}", now, now, dep_id),
            )

    def complete(
        self,
        task_id: str,
        worker: str,
        attempt: int,
        *,
        status: str,
        result: Any = None,
        error: str = "",
        now: float,
    ) -> bool:
        """Fecha a tentativa num estado final (ou `blocked`). Só vale com a lease (fencing)."""
        if status not in TERMINAL and status != TaskStatus.BLOCKED.value:
            raise ValueError(f"complete() não aceita status {status!r}")
        with self._tx() as conn:
            cur = conn.execute(
                "UPDATE tasks SET status = ?, result = ?, error = ?, lease_until = NULL, "
                "finished_at = ?, updated_at = ? "
                "WHERE id = ? AND worker = ? AND attempts = ? AND status = 'running'",
                (
                    status,
                    dumps(result) if result is not None else None,
                    error,
                    now,
                    now,
                    task_id,
                    worker,
                    attempt,
                ),
            )
            if cur.rowcount != 1:
                self._finish_attempt(conn, task_id, attempt, "stale", "lease perdida", now)
                return False
            self._finish_attempt(conn, task_id, attempt, status, error, now)
            if status in (TaskStatus.FAILED.value, TaskStatus.CANCELLED.value):
                self._cascade_cancel(conn, task_id, now)
            return True

    def release(
        self, task_id: str, worker: str, attempt: int, *, not_before: float, error: str, now: float
    ) -> bool:
        """Devolve à fila para nova tentativa em `not_before`. Só vale com a lease."""
        with self._tx() as conn:
            cur = conn.execute(
                "UPDATE tasks SET status = 'pending', worker = NULL, lease_until = NULL, "
                "not_before = ?, error = ?, updated_at = ? "
                "WHERE id = ? AND worker = ? AND attempts = ? AND status = 'running'",
                (not_before, error, now, task_id, worker, attempt),
            )
            if cur.rowcount != 1:
                self._finish_attempt(conn, task_id, attempt, "stale", "lease perdida", now)
                return False
            self._finish_attempt(conn, task_id, attempt, "retry", error, now)
            return True

    def reap(self, *, now: float) -> list[str]:
        """Lease vencida = worker morto. Volta à fila, ou falha se as tentativas acabaram."""
        with self._tx() as conn:
            rows = conn.execute(
                f"SELECT {_COLS} FROM tasks WHERE status = 'running' AND lease_until IS NOT NULL "
                "AND lease_until < ?",
                (now,),
            ).fetchall()
            reaped: list[str] = []
            for row in rows:
                task = self._row_to_task(row)
                self._finish_attempt(
                    conn, task.id, task.attempts, "lost", f"lease vencida ({task.worker})", now
                )
                if task.tries >= task.retry.max_attempts:
                    conn.execute(
                        "UPDATE tasks SET status = 'failed', worker = NULL, lease_until = NULL, "
                        "error = ?, finished_at = ?, updated_at = ? WHERE id = ?",
                        (f"lease vencida {task.tries}x (última: {task.worker})", now, now, task.id),
                    )
                    self._cascade_cancel(conn, task.id, now)
                else:
                    conn.execute(
                        "UPDATE tasks SET status = 'pending', worker = NULL, lease_until = NULL, "
                        "error = ?, updated_at = ? WHERE id = ?",
                        (f"lease vencida ({task.worker})", now, task.id),
                    )
                reaped.append(task.id)
            return reaped

    # ------------------------------------------------------- operar
    def cancel(self, task_id: str, *, now: float, reason: str = "") -> str | None:
        """Pendente: cancela agora. Rodando: pede (cooperativo). Devolve o status resultante."""
        with self._tx() as conn:
            task = self._get(conn, task_id)
            if task is None:
                return None
            if task.status == TaskStatus.PENDING.value:
                conn.execute(
                    "UPDATE tasks SET status = 'cancelled', error = ?, finished_at = ?, updated_at = ? "
                    "WHERE id = ?",
                    (reason or "cancelada pelo operador", now, now, task_id),
                )
                self._cascade_cancel(conn, task_id, now)
                return TaskStatus.CANCELLED.value
            if task.status == TaskStatus.RUNNING.value:
                conn.execute(
                    "UPDATE tasks SET cancel_requested = 1, updated_at = ? WHERE id = ?", (now, task_id)
                )
                return TaskStatus.RUNNING.value
            return task.status

    def cancel_requested(self, task_id: str) -> bool:
        with self._lock:
            row = self._conn.execute(
                "SELECT cancel_requested FROM tasks WHERE id = ?", (task_id,)
            ).fetchone()
        return bool(row and row[0])

    def wake(self, task_id: str, *, now: float) -> bool:
        """Libera uma tarefa pendente em espera (`hold`): `not_before` passa a agora."""
        with self._tx() as conn:
            cur = conn.execute(
                "UPDATE tasks SET not_before = ?, updated_at = ? WHERE id = ? AND status = 'pending'",
                (now, now, task_id),
            )
            return cur.rowcount == 1

    def retry(self, task_id: str, *, now: float) -> bool:
        """O operador reabre uma tarefa falha, cancelada ou bloqueada.

        `attempts` nunca volta atrás — é o fencing token e a chave do histórico.
        O que zera é a contagem *desde a reabertura* (`Task.tries`).
        """
        with self._tx() as conn:
            cur = conn.execute(
                "UPDATE tasks SET status = 'pending', reopened_at_attempt = attempts, worker = NULL, "
                "lease_until = NULL, cancel_requested = 0, not_before = ?, error = '', result = NULL, "
                "finished_at = NULL, updated_at = ? "
                "WHERE id = ? AND status IN ('failed', 'cancelled', 'blocked')",
                (now, now, task_id),
            )
            return cur.rowcount == 1

    # ------------------------------------------------------- consultar
    def tasks(self, status: str | None = None) -> list[Task]:
        with self._lock:
            if status is None:
                rows = self._conn.execute(f"SELECT {_COLS} FROM tasks ORDER BY rowid").fetchall()
            else:
                rows = self._conn.execute(
                    f"SELECT {_COLS} FROM tasks WHERE status = ? ORDER BY rowid", (status,)
                ).fetchall()
            return [self._row_to_task(r, self._after(self._conn, r["id"])) for r in rows]

    def attempts(self, task_id: str) -> list[Attempt]:
        with self._lock:
            rows = self._conn.execute(
                "SELECT task_id, attempt, worker, started_at, finished_at, status, error "
                "FROM attempts WHERE task_id = ? ORDER BY attempt",
                (task_id,),
            ).fetchall()
        return [Attempt(*r) for r in rows]

    def counts(self) -> dict[str, int]:
        with self._lock:
            rows = self._conn.execute(
                "SELECT status, COUNT(*) FROM tasks GROUP BY status"
            ).fetchall()
        out = {s.value: 0 for s in TaskStatus}
        for status, n in rows:
            out[status] = int(n)
        return out

    def active_from(self, origin: str) -> int:
        """Quantas tarefas desta origem ainda estão pendentes ou rodando (política `overlap`)."""
        with self._lock:
            row = self._conn.execute(
                "SELECT COUNT(*) FROM tasks WHERE origin = ? AND status IN ('pending', 'running')",
                (origin,),
            ).fetchone()
        return int(row[0])

    # ------------------------------------------------------- agendas
    def put_schedule(self, sch: Schedule) -> Schedule:
        """Cria ou substitui a agenda (mesmo nome = a mesma agenda, redefinida)."""
        with self._tx() as conn:
            conn.execute(
                f"INSERT INTO schedules({_SCHED_COLS}) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?) "
                "ON CONFLICT(name) DO UPDATE SET kind=excluded.kind, payload=excluded.payload, "
                "every_s=excluded.every_s, cron=excluded.cron, tz=excluded.tz, next_at=excluded.next_at, "
                "overlap=excluded.overlap, catch_up=excluded.catch_up, jitter_s=excluded.jitter_s, "
                "ends_at=excluded.ends_at, max_runs=excluded.max_runs, paused=excluded.paused, "
                "priority=excluded.priority, retry=excluded.retry, timeout_s=excluded.timeout_s, "
                "updated_at=excluded.updated_at",
                (
                    sch.name,
                    sch.kind,
                    dumps(sch.payload),
                    sch.every_s,
                    sch.cron,
                    sch.tz,
                    sch.next_at,
                    sch.overlap,
                    sch.catch_up,
                    sch.jitter_s,
                    sch.ends_at,
                    sch.max_runs,
                    sch.runs,
                    sch.last_fired_at,
                    int(sch.paused),
                    sch.priority,
                    dumps(sch.retry.to_dict()),
                    sch.timeout_s,
                    sch.created_at,
                    sch.updated_at,
                ),
            )
            row = conn.execute(f"SELECT {_SCHED_COLS} FROM schedules WHERE name = ?", (sch.name,)).fetchone()
            return self._row_to_schedule(row)

    def get_schedule(self, name: str) -> Schedule | None:
        with self._lock:
            row = self._conn.execute(f"SELECT {_SCHED_COLS} FROM schedules WHERE name = ?", (name,)).fetchone()
        return self._row_to_schedule(row) if row else None

    def schedules(self) -> list[Schedule]:
        with self._lock:
            rows = self._conn.execute(f"SELECT {_SCHED_COLS} FROM schedules ORDER BY name").fetchall()
        return [self._row_to_schedule(r) for r in rows]

    def due_schedules(self, *, now: float) -> list[Schedule]:
        with self._lock:
            rows = self._conn.execute(
                f"SELECT {_SCHED_COLS} FROM schedules WHERE paused = 0 AND next_at <= ? "
                "AND (max_runs IS NULL OR runs < max_runs) ORDER BY next_at, name",
                (now,),
            ).fetchall()
        return [self._row_to_schedule(r) for r in rows]

    def advance_schedule(
        self, name: str, *, expected_next: float, next_at: float, fired: int, now: float
    ) -> bool:
        """Avança `next_at` só se ninguém avançou antes (CAS entre processos)."""
        with self._tx() as conn:
            cur = conn.execute(
                "UPDATE schedules SET next_at = ?, runs = runs + ?, "
                "last_fired_at = CASE WHEN ? > 0 THEN ? ELSE last_fired_at END, updated_at = ? "
                "WHERE name = ? AND next_at = ?",
                (next_at, fired, fired, now, now, name, expected_next),
            )
            return cur.rowcount == 1

    def set_schedule_paused(self, name: str, paused: bool, *, now: float) -> bool:
        with self._tx() as conn:
            cur = conn.execute(
                "UPDATE schedules SET paused = ?, updated_at = ? WHERE name = ?", (int(paused), now, name)
            )
            return cur.rowcount == 1

    def delete_schedule(self, name: str) -> bool:
        with self._tx() as conn:
            return conn.execute("DELETE FROM schedules WHERE name = ?", (name,)).rowcount == 1

    # ------------------------------------------------------- gatilhos
    def put_trigger(self, trg: Trigger) -> Trigger:
        with self._tx() as conn:
            conn.execute(
                f"INSERT INTO triggers({_TRIG_COLS}) VALUES (?,?,?,?,?,?,?,?,?,?,?,?) "
                "ON CONFLICT(name) DO UPDATE SET pattern=excluded.pattern, kind=excluded.kind, "
                "payload=excluded.payload, priority=excluded.priority, retry=excluded.retry, "
                "timeout_s=excluded.timeout_s, paused=excluded.paused, hold=excluded.hold, "
                "updated_at=excluded.updated_at",
                (
                    trg.name,
                    trg.pattern,
                    trg.kind,
                    dumps(trg.payload),
                    trg.priority,
                    dumps(trg.retry.to_dict()),
                    trg.timeout_s,
                    int(trg.paused),
                    trg.fired,
                    int(trg.hold),
                    trg.created_at,
                    trg.updated_at,
                ),
            )
            row = conn.execute(f"SELECT {_TRIG_COLS} FROM triggers WHERE name = ?", (trg.name,)).fetchone()
            return self._row_to_trigger(row)

    def get_trigger(self, name: str) -> Trigger | None:
        with self._lock:
            row = self._conn.execute(f"SELECT {_TRIG_COLS} FROM triggers WHERE name = ?", (name,)).fetchone()
        return self._row_to_trigger(row) if row else None

    def triggers(self, *, active_only: bool = False) -> list[Trigger]:
        with self._lock:
            sql = f"SELECT {_TRIG_COLS} FROM triggers" + (" WHERE paused = 0" if active_only else "") + " ORDER BY name"
            rows = self._conn.execute(sql).fetchall()
        return [self._row_to_trigger(r) for r in rows]

    def count_trigger(self, name: str, fired: int, *, now: float) -> None:
        with self._tx() as conn:
            conn.execute(
                "UPDATE triggers SET fired = fired + ?, updated_at = ? WHERE name = ?", (fired, now, name)
            )

    def set_trigger_paused(self, name: str, paused: bool, *, now: float) -> bool:
        with self._tx() as conn:
            cur = conn.execute(
                "UPDATE triggers SET paused = ?, updated_at = ? WHERE name = ?", (int(paused), now, name)
            )
            return cur.rowcount == 1

    def delete_trigger(self, name: str) -> bool:
        with self._tx() as conn:
            return conn.execute("DELETE FROM triggers WHERE name = ?", (name,)).rowcount == 1

    def close(self) -> None:
        with self._lock:
            self._conn.close()

