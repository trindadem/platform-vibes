"""O scheduler: workers que reivindicam, executam e devolvem — e sobrevivem.

    sched = Scheduler(SQLiteTaskStore("tasks.db"), handlers={"agent": AgentRunner({...})})
    a = sched.enqueue("agent", {"agent": "revisor", "task": "revise o PR 42"}, key="pr-42")
    b = sched.enqueue("agent", {"agent": "redator", "task": "escreva o changelog"}, after=[a.id])
    sched.run_until_idle()          # ou sched.start() ... sched.stop()
    sched.outcome(b.id)

## O que "resiliente" quer dizer aqui, e o que não quer

- Um worker que morre no meio deixa a lease vencer; outro worker (deste
  processo ou de outro, no mesmo arquivo) reivindica a tarefa de novo. Para
  tarefa de agente, a nova tentativa **retoma o journal** do laço
  (`run(..., resume=True)`): o que já foi confirmado não repete.
- Um worker que ficou preso, acordou tarde e terminou não sobrescreve nada:
  a fila recusa o resultado sem a lease (fencing).
- Falha transitória repete com backoff exponencial e jitter determinístico
  (Brooker, 2015). Falha permanente não repete. `StateConflict` — efeito de
  ferramenta ambíguo — **bloqueia** e espera gente: repetir um `git push`
  às cegas é pior que parar.
- O que não é resiliência: cancelar uma thread no meio. Cancelamento é
  durável e cooperativo — a tarefa pendente cancela já; a que roda vê o
  pedido na próxima `llm.request` (o provedor recusa) e fecha.

## Recorrência e gatilhos — tudo no mesmo arquivo

`schedule(nome, ...)` é a mesma tarefa de novo, por `every_s` ou por `cron`,
com política de sobreposição (`skip`/`queue`) e de disparos perdidos
(`one`/`all`/`none`). `on(nome, padrão, ...)` é um gatilho: mensagem que
casa o padrão no barramento (`Bus`) vira tarefa, com o molde preenchido pela
mensagem. Os dois são duráveis, sobrevivem ao processo e funcionam com N
processos no mesmo arquivo: o disparo enfileira **antes** de avançar a
agenda (CAS) — cair no meio só repete o que a `key` deduplica. `tick()` é o
passo do relógio; `step()` e o zelador o chamam. `drain()` e
`run_until_idle()` esvaziam a fila (agendas futuras não os prendem);
`serve_forever()` é o que mantém as agendas vivas.

## Tempo

O scheduler recebe `clock` e `sleep`; os testes injetam um relógio falso e
fazem leases vencerem sem esperar. Em produção são `time.time`/`time.sleep`.
"""

from __future__ import annotations

import contextlib
import math
import signal
import threading
import time
import traceback
from collections.abc import Callable, Iterable, Mapping
from dataclasses import dataclass, field
from typing import Any

from ..budget import Budget
from ..bus import Bus, Subscription, valid_subject
from ..loop import Outcome
from ..models.provider import ProviderError
from ..session import StateConflict
from ..subagents import Ledger
from .cron import next_fire, parse
from .store import TaskStore, new_id
from .types import (
    Cancelled,
    Permanent,
    RetryPolicy,
    Schedule,
    Task,
    TaskStatus,
    Transient,
    Trigger,
    render,
    unit,
)

__all__ = ["CATCH_UP_GRACE_S", "HOLD", "Handler", "Scheduler", "TaskContext"]

#: `catch_up="none"`: um disparo perdido só acontece se atrasou menos que isto.
CATCH_UP_GRACE_S = 60.0
#: `not_before` de uma tarefa em espera de aprovação (`hold=True`): nunca vence sozinha.
HOLD = float(1 << 40)

Handler = Callable[["TaskContext"], Any]


@dataclass
class TaskContext:
    """O que o handler recebe: a tarefa, a tentativa, e os verbos de sobrevivência."""

    task: Task
    attempt: int
    worker: str
    ledger: Ledger
    _store: TaskStore = field(repr=False)
    _clock: Callable[[], float] = field(repr=False)
    _lease_s: float = field(repr=False)
    _last_beat: float = field(default=0.0, repr=False)
    lost: bool = False
    _cancelled: bool = False
    #: o barramento do scheduler (se houver): a tarefa pode publicar e o traço pode ir para lá
    bus: Bus | None = None

    @property
    def deadline(self) -> float | None:
        if self.task.timeout_s is None or self.task.started_at is None:
            return None
        return self.task.started_at + self.task.timeout_s

    @property
    def remaining_s(self) -> float | None:
        d = self.deadline
        return None if d is None else max(0.0, d - self._clock())

    @property
    def cancelled(self) -> bool:
        """Pedido de cancelamento durável, ou lease perdida (o resultado não valeria)."""
        if self.lost or self._cancelled:
            return True
        self._cancelled = self._store.cancel_requested(self.task.id)
        return self._cancelled

    def check(self) -> None:
        """Lança `Cancelled` se for para parar. Chamar entre passos longos."""
        if self.cancelled:
            raise Cancelled("cancelada pelo operador" if not self.lost else "lease perdida")

    def heartbeat(self, *, force: bool = False) -> bool:
        """Renova a lease, no máximo a cada terço do prazo. `False` = perdida."""
        now = self._clock()
        if not force and now - self._last_beat < self._lease_s / 3:
            return not self.lost
        self._last_beat = now
        ok = self._store.heartbeat(
            self.task.id, self.worker, self.attempt, lease_until=now + self._lease_s
        )
        if not ok:
            self.lost = True
        return ok


class Scheduler:
    """Fila + workers + política. Um por processo; vários processos podem partilhar a fila."""

    def __init__(
        self,
        store: TaskStore,
        handlers: Mapping[str, Handler],
        *,
        workers: int = 4,
        lease_s: float = 60.0,
        poll_s: float = 0.5,
        budget: Budget | None = None,
        ledger: Ledger | None = None,
        name: str = "",
        clock: Callable[[], float] = time.time,
        sleep: Callable[[float], None] = time.sleep,
        on_change: Callable[[Task], None] | None = None,
        bus: Bus | None = None,
        publish_tasks: bool = True,
    ) -> None:
        self.store = store
        self.handlers = dict(handlers)
        #: barramento embarcado: ciclo de vida das tarefas sai por `task.<kind>.<status>`,
        #: e os gatilhos (`on`) entram por ele.
        self.bus = bus
        self.publish_tasks = publish_tasks
        self.workers = max(1, workers)
        self.lease_s = lease_s
        self.poll_s = poll_s
        self.ledger = ledger if ledger is not None else Ledger(limit=budget or Budget())
        self.name = name or f"sched-{new_id()[:6]}"
        self._clock = clock
        self._sleep = sleep
        self._on_change = on_change
        self._running: dict[str, TaskContext] = {}
        self._lock = threading.Lock()
        self._threads: list[threading.Thread] = []
        self._stop = threading.Event()

    # ------------------------------------------------------- produzir
    def enqueue(
        self,
        kind: str,
        payload: Mapping[str, Any] | None = None,
        *,
        key: str | None = None,
        priority: int = 0,
        after: Iterable[str | Task] = (),
        delay_s: float = 0.0,
        at: float | None = None,
        retry: RetryPolicy | None = None,
        timeout_s: float | None = None,
        meta: Mapping[str, Any] | None = None,
        origin: str = "",
        hold: bool = False,
    ) -> Task:
        """Põe uma tarefa na fila. Com `key` repetida, devolve a que já existe.

        `hold=True` a deixa pendente sem vencer nunca — até `approve()`: é o
        dial de autonomia `ask` de um perfil, ou qualquer portão humano.
        """
        if kind not in self.handlers:
            raise KeyError(f"sem handler para kind={kind!r}; registrados: {sorted(self.handlers)}")
        now = self._clock()
        task = Task(
            id=new_id(),
            kind=kind,
            payload=dict(payload or {}),
            key=key,
            priority=priority,
            not_before=HOLD if hold else (at if at is not None else now + max(0.0, delay_s)),
            retry=retry or RetryPolicy(),
            timeout_s=timeout_s,
            after=tuple(a.id if isinstance(a, Task) else str(a) for a in after),
            origin=origin,
            created_at=now,
            updated_at=now,
            meta=dict(meta or {}),
        )
        stored = self.store.add(task)
        if stored.id == task.id:  # nova de fato; a repetida por `key` já foi anunciada
            self._changed(stored)
        return stored

    # ------------------------------------------------------ recorrência
    def schedule(
        self,
        name: str,
        kind: str,
        payload: Mapping[str, Any] | None = None,
        *,
        every_s: float | None = None,
        cron: str | None = None,
        tz: str = "UTC",
        first_at: float | None = None,
        overlap: str = "skip",
        catch_up: str = "one",
        jitter_s: float = 0.0,
        ends_at: float | None = None,
        max_runs: int | None = None,
        priority: int = 0,
        retry: RetryPolicy | None = None,
        timeout_s: float | None = None,
    ) -> Schedule:
        """A mesma tarefa, de novo: por intervalo (`every_s`) ou por `cron`. Durável.

        O primeiro disparo é `first_at`, ou daqui a um intervalo (`every_s`),
        ou a próxima hora que casa o cron. Redefinir uma agenda com o mesmo
        nome substitui a definição e mantém a contagem de disparos.
        """
        if kind not in self.handlers:
            raise KeyError(f"sem handler para kind={kind!r}; registrados: {sorted(self.handlers)}")
        if (every_s is None) == (cron is None):
            raise ValueError("agenda precisa de exatamente um: every_s ou cron")
        if every_s is not None and every_s <= 0:
            raise ValueError("every_s precisa ser positivo")
        if overlap not in ("skip", "queue"):
            raise ValueError("overlap: skip | queue")
        if catch_up not in ("one", "all", "none"):
            raise ValueError("catch_up: one | all | none")
        now = self._clock()
        if cron is not None:
            parse(cron)  # valida cedo
            first = first_at if first_at is not None else next_fire(cron, now, tz)
        else:
            assert every_s is not None
            first = first_at if first_at is not None else now + every_s
        previous = self.store.get_schedule(name)
        sch = Schedule(
            name=name,
            kind=kind,
            payload=dict(payload or {}),
            every_s=every_s,
            cron=cron,
            tz=tz,
            next_at=first,
            overlap=overlap,
            catch_up=catch_up,
            jitter_s=max(0.0, jitter_s),
            ends_at=ends_at,
            max_runs=max_runs,
            runs=previous.runs if previous else 0,
            last_fired_at=previous.last_fired_at if previous else None,
            priority=priority,
            retry=retry or RetryPolicy(),
            timeout_s=timeout_s,
            created_at=previous.created_at if previous else now,
            updated_at=now,
        )
        return self.store.put_schedule(sch)

    def unschedule(self, name: str) -> bool:
        return self.store.delete_schedule(name)

    def pause(self, name: str) -> bool:
        return self.store.set_schedule_paused(name, True, now=self._clock())

    def resume(self, name: str) -> bool:
        return self.store.set_schedule_paused(name, False, now=self._clock())

    def schedules(self) -> list[Schedule]:
        return self.store.schedules()

    def _next_after(self, sch: Schedule, t: float) -> float:
        if sch.cron is not None:
            return next_fire(sch.cron, t, sch.tz)
        assert sch.every_s is not None
        return t + sch.every_s

    def _last_due(self, sch: Schedule, now: float) -> float:
        """O último slot em [next_at, now] — sem enumerar um ano de disparos perdidos."""
        if sch.every_s is not None:
            missed = math.floor((now - sch.next_at) / sch.every_s)
            return sch.next_at + missed * sch.every_s
        assert sch.cron is not None
        # Janelas crescentes para trás: a primeira que contém um slot é a densa o
        # bastante para enumerar barato (`* * * * *` cai na de 1 h: 60 passos).
        for window in (3600.0, 86400.0, 32 * 86400.0, 400 * 86400.0, 5 * 366 * 86400.0):
            start = max(sch.next_at - 1e-3, now - window)
            t = next_fire(sch.cron, start, sch.tz)
            if t > now:
                continue
            last = t
            for _ in range(100_000):
                nxt = next_fire(sch.cron, last, sch.tz)
                if nxt > now:
                    break
                last = nxt
            return last
        return sch.next_at

    def _fire_schedule(self, sch: Schedule, now: float) -> tuple[int, int]:
        """Dispara o que venceu e avança a agenda. Devolve (disparos, pulados)."""
        if sch.next_at > now:
            return 0, 0
        if sch.catch_up == "all":
            slots: list[float] = []
            t = sch.next_at
            while t <= now and len(slots) < 1000:  # backlog grande: o resto fica para o próximo tick
                slots.append(t)
                t = self._next_after(sch, t)
            fires, next_at = slots, t
        else:
            last = self._last_due(sch, now)
            next_at = self._next_after(sch, last)
            if sch.catch_up == "one":
                fires = [last]
            else:  # none: só se a agenda estava viva (atraso dentro da tolerância)
                fires = [last] if now - last <= CATCH_UP_GRACE_S else []
        if sch.ends_at is not None:
            fires = [f for f in fires if f <= sch.ends_at]
        if sch.max_runs is not None:
            fires = fires[: max(0, sch.max_runs - sch.runs)]
        skipped = 0
        origin = f"schedule:{sch.name}"
        if fires and sch.overlap == "skip" and self.store.active_from(origin) > 0:
            skipped, fires = len(fires), []
        for fire_at in fires:
            stamp = round(fire_at * 1000)  # ms: agendas sub-segundo não colidem na key
            jitter = sch.jitter_s * unit(f"{sch.name}@{stamp}") if sch.jitter_s > 0 else 0.0
            self.enqueue(
                sch.kind,
                sch.payload,
                key=f"schedule:{sch.name}@{stamp}",
                priority=sch.priority,
                at=now + jitter,
                retry=sch.retry,
                timeout_s=sch.timeout_s,
                origin=origin,
                meta={"schedule": sch.name, "fire_at": fire_at},
            )
        # Enfileirar antes de avançar: se o processo cair aqui, o próximo tick
        # recomputa os mesmos disparos e a `key` os deduplica. Avançar antes
        # perderia o disparo. CAS: só um processo avança e conta.
        self.store.advance_schedule(
            sch.name, expected_next=sch.next_at, next_at=next_at, fired=len(fires), now=now
        )
        return len(fires), skipped

    # -------------------------------------------------------- gatilhos
    def on(
        self,
        name: str,
        pattern: str,
        kind: str,
        payload: Mapping[str, Any] | None = None,
        *,
        priority: int = 0,
        retry: RetryPolicy | None = None,
        timeout_s: float | None = None,
        hold: bool = False,
        start: str | int = "new",
    ) -> Trigger:
        """Mensagem que casa `pattern` no barramento vira tarefa `kind` com o molde `payload`.

        `hold=True`: a tarefa nasce em espera de aprovação (`approve`) — o
        portão humano de um perfil com autonomia `ask`. `start`: de onde o
        consumidor durável começa **na criação** (`"new"`: só o que chegar;
        `"all"`: o backlog também); um gatilho que já existe retoma do cursor.

        O consumidor durável `trigger:<nome>` nasce agora, apontando para o
        fim do barramento: só o que chegar depois dispara. A mesma mensagem
        nunca vira duas tarefas (`key = trigger:<nome>:<seq>`), e uma mensagem
        de ciclo de vida de tarefa criada por este mesmo gatilho é ignorada
        (sem realimentação direta).
        """
        if self.bus is None:
            raise RuntimeError("gatilhos precisam de um barramento: Scheduler(bus=Bus(...))")
        if kind not in self.handlers:
            raise KeyError(f"sem handler para kind={kind!r}; registrados: {sorted(self.handlers)}")
        if not valid_subject(pattern, pattern=True):
            raise ValueError(f"padrão inválido: {pattern!r}")
        now = self._clock()
        previous = self.store.get_trigger(name)
        trg = Trigger(
            name=name,
            pattern=pattern,
            kind=kind,
            payload=dict(payload or {}),
            priority=priority,
            retry=retry or RetryPolicy(),
            timeout_s=timeout_s,
            fired=previous.fired if previous else 0,
            hold=hold,
            created_at=previous.created_at if previous else now,
            updated_at=now,
        )
        self.bus.subscribe(pattern, name=f"trigger:{name}", start=start)
        return self.store.put_trigger(trg)

    def off(self, name: str) -> bool:
        if self.bus is not None:
            self.bus.unsubscribe(f"trigger:{name}")
        return self.store.delete_trigger(name)

    def mute(self, name: str) -> bool:
        return self.store.set_trigger_paused(name, True, now=self._clock())

    def unmute(self, name: str) -> bool:
        return self.store.set_trigger_paused(name, False, now=self._clock())

    def triggers(self) -> list[Trigger]:
        return self.store.triggers()

    def _pull_trigger(self, trg: Trigger, now: float, *, limit: int = 100) -> int:
        assert self.bus is not None
        sub = Subscription(self.bus, f"trigger:{trg.name}", trg.pattern)
        msgs = sub.pull(limit)
        if not msgs:
            return 0
        origin = f"trigger:{trg.name}"
        fired = 0
        for m in msgs:
            if isinstance(m.data, dict) and m.data.get("origin") == origin:
                continue  # ciclo de vida das próprias tarefas: não realimenta
            ctx = {"subject": m.subject, "seq": m.seq, "at": m.at, "data": m.data}
            self.enqueue(
                trg.kind,
                render(trg.payload, ctx),
                key=f"{origin}:{m.seq}",
                priority=trg.priority,
                retry=trg.retry,
                timeout_s=trg.timeout_s,
                origin=origin,
                meta={"trigger": trg.name, "message": m.to_dict()},
                hold=trg.hold,
            )
            fired += 1
        sub.ack(msgs[-1].seq)  # depois de enfileirar: cair antes daqui só repete o que a key deduplica
        if fired:
            self.store.count_trigger(trg.name, fired, now=now)
        return fired

    def tick(self, now: float | None = None) -> dict[str, int]:
        """Um passo do relógio: agendas vencidas viram tarefas; mensagens viram tarefas."""
        now = self._clock() if now is None else now
        scheduled = skipped = triggered = 0
        for sch in self.store.due_schedules(now=now):
            try:
                f, k = self._fire_schedule(sch, now)
            except (ValueError, KeyError):  # cron que não dispara mais, handler que sumiu
                continue
            scheduled += f
            skipped += k
        if self.bus is not None:
            for trg in self.store.triggers(active_only=True):
                if trg.kind in self.handlers:
                    triggered += self._pull_trigger(trg, now)
        return {"scheduled": scheduled, "skipped": skipped, "triggered": triggered}

    # ------------------------------------------------------- executar
    def step(self, worker: str = "w0") -> Task | None:
        """Uma tarefa, nesta thread: reivindica, executa, fecha. `None` = nada a fazer agora."""
        now = self._clock()
        self.store.reap(now=now)
        self.tick(now)
        if self.ledger.exhausted():
            return None
        task = self.store.claim(f"{self.name}/{worker}", now=now, lease_s=self.lease_s)
        if task is None:
            return None
        self._changed(task)
        return self._execute(task, f"{self.name}/{worker}")

    def _execute(self, task: Task, worker: str) -> Task:
        ctx = TaskContext(
            task=task,
            attempt=task.attempts,
            worker=worker,
            ledger=self.ledger,
            _store=self.store,
            _clock=self._clock,
            _lease_s=self.lease_s,
            _last_beat=self._clock(),
            bus=self.bus,
        )
        with self._lock:
            self._running[task.id] = ctx
        try:
            handler = self.handlers[task.kind]
            try:
                value = handler(ctx)
                status, result, error = TaskStatus.SUCCEEDED.value, self._serialize(value), ""
                if isinstance(value, Outcome):
                    self.ledger.charge(value)
            except Cancelled as erro:
                status, result, error = TaskStatus.CANCELLED.value, None, str(erro)
            except StateConflict as erro:
                status, result, error = TaskStatus.BLOCKED.value, None, str(erro)
            except Permanent as erro:
                status, result, error = TaskStatus.FAILED.value, None, str(erro)
            except Exception as erro:  # Transient e qualquer outra: repetir, se der
                error = f"{type(erro).__name__}: {erro}"
                if not isinstance(erro, (Transient, ProviderError)):  # bug do handler: guarda o traceback
                    error += "\n" + traceback.format_exc(limit=3)
                now = self._clock()
                if task.tries < task.retry.max_attempts:
                    wait = task.retry.delay(task.tries, seed=task.id)
                    self.store.release(
                        task.id, worker, task.attempts, not_before=now + wait, error=error, now=now
                    )
                    return self._refresh(task)
                status, result = TaskStatus.FAILED.value, None
                error = f"tentativas esgotadas ({task.tries}): {error}"
            now = self._clock()
            self.store.complete(
                task.id, worker, task.attempts, status=status, result=result, error=error, now=now
            )
            return self._refresh(task)
        finally:
            with self._lock:
                self._running.pop(task.id, None)

    def _refresh(self, task: Task) -> Task:
        fresh = self.store.get(task.id) or task
        self._changed(fresh)
        return fresh

    @staticmethod
    def _serialize(value: Any) -> Any:
        if isinstance(value, Outcome):
            return value.to_dict()
        if hasattr(value, "to_dict") and callable(value.to_dict):
            return value.to_dict()
        return value

    def _changed(self, task: Task) -> None:
        if self.bus is not None and self.publish_tasks:
            with contextlib.suppress(Exception):
                self.bus.publish(
                    f"task.{task.kind}.{task.status}",
                    {
                        "id": task.id,
                        "kind": task.kind,
                        "status": task.status,
                        "key": task.key,
                        "origin": task.origin,
                        "attempts": task.attempts,
                        "error": task.error,
                        "payload": task.payload,
                        "result": task.result,
                    },
                )
        if self._on_change is not None:
            with contextlib.suppress(Exception):  # observar não é participar
                self._on_change(task)

    # ------------------------------------------------------ síncrono
    def drain(self, *, max_tasks: int | None = None, timeout_s: float | None = None) -> dict[str, Any]:
        """Roda nesta thread até a fila esvaziar (ou só sobrar o que precisa de gente)."""
        started = self._clock()
        done = 0
        stopped = ""
        while True:
            if max_tasks is not None and done >= max_tasks:
                stopped = "max_tasks"
                break
            if timeout_s is not None and self._clock() - started >= timeout_s:
                stopped = "timeout"
                break
            closed = self.ledger.exhausted()
            if closed:
                stopped = f"budget:{closed}"
                break
            task = self.step()
            if task is not None:
                done += 1
                continue
            wait = self._wait_hint()
            if wait is None:
                break
            self._sleep(min(wait, self.poll_s) if wait > 0 else self.poll_s)
        return {**self.report(), "executed": done, "stopped": stopped}

    def _triggers_have_news(self) -> bool:
        """Há mensagem que um gatilho ativo ainda não transformou em tarefa?"""
        if self.bus is None:
            return False
        for trg in self.store.triggers(active_only=True):
            if trg.kind not in self.handlers:
                continue
            sub = Subscription(self.bus, f"trigger:{trg.name}", trg.pattern)
            origin = f"trigger:{trg.name}"
            for m in sub.pull(20):
                if not (isinstance(m.data, dict) and m.data.get("origin") == origin):
                    return True
        return False

    def _wait_hint(self) -> float | None:
        """Quanto esperar antes de tentar de novo; `None` = nada vai destravar sozinho."""
        now = self._clock()
        if self._triggers_have_news():
            return 0.0
        pending = self.store.tasks(TaskStatus.PENDING.value)
        with self._lock:
            running_here = len(self._running)
        running = self.store.counts().get(TaskStatus.RUNNING.value, 0)
        if not pending:
            return self.poll_s if running else None
        status = {t.id: t.status for t in self.store.tasks()}
        soonest: float | None = None
        for t in pending:
            if t.not_before >= HOLD:
                continue  # em espera de aprovação: só gente destrava
            ups = [status.get(d, "") for d in t.after]
            if all(u == TaskStatus.SUCCEEDED.value for u in ups):
                soonest = t.not_before if soonest is None else min(soonest, t.not_before)
            elif any(u in (TaskStatus.PENDING.value, TaskStatus.RUNNING.value) for u in ups):
                soonest = now if soonest is None else min(soonest, now)  # o upstream anda
            # upstream bloqueado: só gente destrava — não conta como espera
        if soonest is None:
            return self.poll_s if (running or running_here) else None
        return max(0.0, soonest - now)

    # ------------------------------------------------------ threads
    def start(self) -> None:
        """Workers em threads; um zelador renova leases e recolhe as vencidas."""
        if self._threads:
            return
        self._stop.clear()
        for i in range(self.workers):
            t = threading.Thread(target=self._worker_loop, args=(f"w{i}",), daemon=True)
            t.start()
            self._threads.append(t)
        keeper = threading.Thread(target=self._keeper_loop, daemon=True)
        keeper.start()
        self._threads.append(keeper)

    def stop(self, *, wait: bool = True) -> None:
        self._stop.set()
        if wait:
            for t in self._threads:
                t.join()
        self._threads = []

    def _worker_loop(self, worker: str) -> None:
        while not self._stop.is_set():
            try:
                task = self.step(worker)
            except Exception:  # a fila falhou; não derruba o worker
                task = None
            if task is None:
                self._stop.wait(self.poll_s)

    def _keeper_loop(self) -> None:
        interval = max(0.05, self.lease_s / 3)
        while not self._stop.wait(interval):
            with self._lock:
                ctxs = list(self._running.values())
            for ctx in ctxs:
                ctx.heartbeat(force=True)
            with contextlib.suppress(Exception):
                self.store.reap(now=self._clock())
                self.tick()

    def wait_idle(self, timeout_s: float | None = None) -> bool:
        """Espera até nada estar rodando nem por rodar. `False` se estourou o prazo."""
        started = self._clock()
        while True:
            hint = self._wait_hint()
            if hint is None:
                return True
            if timeout_s is not None and self._clock() - started >= timeout_s:
                return False
            self._sleep(min(max(hint, 0.01), self.poll_s))

    def run_until_idle(self, timeout_s: float | None = None) -> dict[str, Any]:
        self.start()
        try:
            idle = self.wait_idle(timeout_s)
        finally:
            self.stop()
        return {**self.report(), "idle": idle}

    def serve_forever(self) -> None:
        """Workers no ar até `stop()`, Ctrl-C ou SIGTERM; as tarefas em curso terminam antes de sair.

        SIGTERM é o que um supervisor manda; sem tratá-lo o processo morreria
        no meio de uma tarefa (a lease a devolveria à fila — resiliente, mas
        desperdício). Aqui ele vira `stop()`: os workers param de reivindicar
        e o que está rodando fecha. Só a thread principal instala handlers.
        """
        self.start()
        previous: Any = None
        main_thread = threading.current_thread() is threading.main_thread()
        if main_thread:
            previous = signal.signal(signal.SIGTERM, lambda *_: self._stop.set())
        try:
            while not self._stop.wait(self.poll_s):
                pass
        except KeyboardInterrupt:
            pass
        finally:
            self.stop()
            if main_thread and previous is not None:
                signal.signal(signal.SIGTERM, previous)

    # ------------------------------------------------------- operar
    def get(self, task_id: str) -> Task | None:
        return self.store.get(task_id)

    def result(self, task_id: str) -> Any:
        t = self.store.get(task_id)
        return t.result if t else None

    def outcome(self, task_id: str) -> Outcome | None:
        r = self.result(task_id)
        return Outcome.from_dict(r) if isinstance(r, dict) and "stop_reason" in r else None

    def cancel(self, task_id: str, *, reason: str = "") -> str | None:
        status = self.store.cancel(task_id, now=self._clock(), reason=reason)
        t = self.store.get(task_id)
        if t:
            self._changed(t)
        return status

    def approve(self, task_id: str) -> bool:
        """Libera uma tarefa em espera (`hold`); `False` se não está pendente."""
        ok = self.store.wake(task_id, now=self._clock())
        t = self.store.get(task_id)
        if ok and t:
            self._changed(t)
        return ok

    def retry(self, task_id: str) -> bool:
        ok = self.store.retry(task_id, now=self._clock())
        t = self.store.get(task_id)
        if ok and t:
            self._changed(t)
        return ok

    def tasks(self, status: str | None = None) -> list[Task]:
        return self.store.tasks(status)

    def wait(self, ids: Iterable[str], *, timeout_s: float | None = None) -> list[Task]:
        """Espera as tarefas saírem de pending/running (terminal ou blocked)."""
        wanted = list(ids)
        started = self._clock()
        while True:
            tasks = [self.store.get(i) for i in wanted]
            if all(t is None or t.terminal or t.status == TaskStatus.BLOCKED.value for t in tasks):
                return [t for t in tasks if t is not None]
            if timeout_s is not None and self._clock() - started >= timeout_s:
                return [t for t in tasks if t is not None]
            self._sleep(min(0.05, self.poll_s))

    def report(self) -> dict[str, Any]:
        """Contagem por status e a conta — o custo somado dos `Outcome` gravados."""
        counts = self.store.counts()
        cost = 0.0
        turns = 0
        for t in self.store.tasks(TaskStatus.SUCCEEDED.value):
            if isinstance(t.result, dict) and "cost_usd" in t.result:
                cost += float(t.result.get("cost_usd") or 0.0)
                turns += int(t.result.get("turns") or 0)
        return {
            "scheduler": self.name,
            "counts": counts,
            "cost_usd": round(cost, 6),
            "turns": turns,
            "ledger": self.ledger.to_dict(),
            "schedules": len(self.store.schedules()),
            "triggers": len(self.store.triggers()),
        }

