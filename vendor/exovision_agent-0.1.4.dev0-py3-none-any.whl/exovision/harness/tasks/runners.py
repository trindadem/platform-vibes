"""Handlers prontos: a tarefa de agente.

`AgentRunner` liga a fila ao laço. A tarefa carrega o **nome** do agente e o
texto; o `Agent` em si é código, registrado no processo. Isso é o que faz a
tarefa sobreviver ao processo: um worker novo, com o mesmo registro, executa
a mesma tarefa.

O que a ponte com o laço compra:

- **Retomada, não repetição.** Com `state_store`, a tentativa 2 chama
  `run(..., resume=True)`: o journal do laço reusa o que já foi confirmado e
  só refaz o que faltava. Se o laço já tinha terminado (crash entre o fim do
  agente e o fechamento da tarefa), o `Outcome` gravado volta sem uma
  chamada ao modelo.
- **Falha do provedor é transitória; recusa e orçamento são permanentes.**
  Rede cai e volta; um modelo que recusou vai recusar de novo com o mesmo
  contexto, e um orçamento fechado não reabre sozinho.
- **Cancelamento cooperativo.** O provedor é embrulhado: na próxima
  `llm.request` depois do pedido, recusa; o laço fecha graciosamente, o
  journal fica consistente, e a tarefa sai como `cancelled`.
- **A lease se renova sozinha** a cada evento do traço (`turn.end`,
  `tool.result`, ...): um agente que trabalha nunca perde a tarefa por
  demorar; um que travou, sim.
"""

from __future__ import annotations

from collections.abc import Callable, Mapping
from pathlib import Path
from typing import Any

from ..budget import Budget
from ..loop import Agent, Outcome, run
from ..models.provider import Provider, ProviderError, Reply, Request
from ..seams import Event, Seams
from ..session import StateStore
from ..subagents import _with_budget
from .scheduler import TaskContext
from .types import Cancelled, Permanent, Transient

__all__ = ["AgentRunner"]

AgentSource = Agent | Callable[[], Agent]


class _Cancellable:
    """Provedor que recusa a próxima chamada quando a tarefa foi cancelada."""

    def __init__(self, inner: Provider, ctx: TaskContext) -> None:
        self._inner = inner
        self._ctx = ctx

    def __getattr__(self, name: str) -> Any:  # model, effort, cost_discount, ...
        return getattr(self._inner, name)

    def complete(self, request: Request) -> Reply:
        if self._ctx.cancelled:
            raise ProviderError("tarefa cancelada" if not self._ctx.lost else "lease perdida")
        return self._inner.complete(request)


class AgentRunner:
    """`payload = {"agent": nome, "task": texto, "session": opcional}` -> `Outcome`."""

    def __init__(
        self,
        agents: Mapping[str, AgentSource],
        *,
        state_store: StateStore | None = None,
        trace_dir: str | Path | None = None,
        publish_trace: bool = False,
    ) -> None:
        self.agents: dict[str, AgentSource] = dict(agents)
        self.state_store = state_store
        self.trace_dir = Path(trace_dir) if trace_dir else None
        #: com um barramento no scheduler, cada evento do traço vira mensagem
        #: `seam.<sessão>.<costura>` — outros agentes e gatilhos podem reagir.
        self.publish_trace = publish_trace

    def resolve(self, payload: Mapping[str, Any]) -> Agent:
        """O agente da tarefa: por padrão, `payload["agent"]` no registro. Subclasses mudam isto."""
        name = str(payload.get("agent") or "")
        src = self.agents.get(name)
        if src is None:
            raise Permanent(f"agente desconhecido: {name!r}; registrados: {sorted(self.agents)}")
        return src() if callable(src) and not isinstance(src, Agent) else src

    def __call__(self, ctx: TaskContext) -> Outcome:
        payload = ctx.task.payload
        text = str(payload.get("task") or "").strip()
        if not text:
            raise Permanent("tarefa sem texto (`payload.task`)")
        agent = self.resolve(payload)

        # Orçamento: o que sobra do teto da fila, e o prazo da tarefa como parede.
        budget = ctx.ledger.derive(agent.budget)
        remaining = ctx.remaining_s
        if remaining is not None:
            wall = min(budget.max_wall_s, remaining) if budget.max_wall_s else remaining
            budget = Budget(
                max_turns=budget.max_turns,
                max_input_tokens=budget.max_input_tokens,
                max_output_tokens=budget.max_output_tokens,
                max_cost_usd=budget.max_cost_usd,
                max_wall_s=wall,
                max_tool_calls=budget.max_tool_calls,
            )
        agent = _with_budget(agent, budget)
        agent.provider = _Cancellable(agent.provider, ctx)  # a cópia rasa não toca o original

        session = str(payload.get("session") or ctx.task.id)
        seams = Seams(session)

        def pulse(_: Event) -> None:
            ctx.heartbeat()

        seams.on("*", pulse)
        if self.publish_trace and ctx.bus is not None:
            ctx.bus.attach(seams)
        try:
            outcome = run(
                agent,
                text,
                session=session,
                state_store=self.state_store,
                resume=ctx.attempt > 1,
                seams=seams,
            )
        finally:
            if self.trace_dir is not None:
                seams.dump(self.trace_dir / f"{ctx.task.id}.{ctx.attempt}.jsonl")
        if ctx.cancelled:
            raise Cancelled("cancelada pelo operador" if not ctx.lost else "lease perdida")
        if outcome.error:
            if outcome.stop_reason == "error":
                raise Transient(outcome.error)
            raise Permanent(f"{outcome.stop_reason}: {outcome.error}")
        if outcome.stop_reason.startswith("budget:"):
            # O laço fecha por orçamento graciosamente (sem erro), mas a tarefa
            # não terminou — a mesma regra de `Delegation.ok`. Repetir com o
            # mesmo teto refaria o mesmo caminho: permanente.
            raise Permanent(f"{outcome.stop_reason}: o agente parou antes de terminar")
        return outcome
