"""`exovision-agent tasks`: a fila durável pela linha de comando.

    exovision-agent tasks add "revise o PR 42" --db fila.db --instruction revisor.md --workspace . --key pr-42
    exovision-agent tasks add "escreva o changelog" --db fila.db --system "Você redige." --after <id>
    exovision-agent tasks work --db fila.db --state journal.db --workers 4        # até esvaziar
    exovision-agent tasks work --db fila.db --forever                             # daemon: Ctrl-C para sair
    exovision-agent tasks ls --db fila.db [--status pending]
    exovision-agent tasks show <id> --db fila.db
    exovision-agent tasks cancel <id> --db fila.db
    exovision-agent tasks retry <id> --db fila.db
    exovision-agent tasks report --db fila.db

    exovision-agent tasks schedule diario "resuma os PRs" --db fila.db --cron "0 9 * * mon-fri" --tz America/Sao_Paulo ...
    exovision-agent tasks schedule ping "verifique o app" --db fila.db --every 3600 --overlap skip --catch-up one ...
    exovision-agent tasks schedules --db fila.db; tasks pause NOME; tasks resume NOME; tasks unschedule NOME
    exovision-agent tasks on revisa "pr.aberto" "revise o PR {{data.n}}" --db fila.db ...
    exovision-agent tasks triggers --db fila.db; tasks off NOME
    exovision-agent tasks publish pr.aberto "PR 42 aberto" --db fila.db --data '{"n": 42}'
    exovision-agent tasks messages "pr.>" --db fila.db --after 0

A tarefa guarda a **especificação** do agente (instrução, workspace, modelo,
teto), não o agente: qualquer worker com o mesmo código a reconstrói. Com
`--state`, o journal do laço fica no disco e a nova tentativa **retoma** em
vez de repetir. Sem rede: `--scripted roteiro.json`, como no `run`.

Tudo num arquivo: a fila, as agendas, os gatilhos e o barramento (`--bus`
só se quiser separá-lo). `work --forever` mantém agendas e gatilhos vivos.
"""

from __future__ import annotations

import argparse
import json
import sys
from collections.abc import Mapping
from pathlib import Path
from typing import Any

from ..budget import Budget
from ..bus import Bus
from ..instruction import Instruction, load_instruction
from ..loop import Agent
from ..models import make_provider
from ..models.provider import Provider
from ..policy import AllowAll, DenyRisk
from ..session import SQLiteStateStore
from ..skills import SkillLibrary, load_skills
from ..tools import Registry
from ..workbench import Workbench
from .runners import AgentRunner
from .scheduler import Scheduler
from .store import SQLiteTaskStore
from .types import RetryPolicy, Schedule, Task, Trigger

__all__ = ["SpecRunner", "add_parser", "agent_from_spec"]

SPEC_FIELDS = (
    "instruction",
    "system",
    "name",
    "workspace",
    "skills",
    "model",
    "effort",
    "max_turns",
    "max_cost",
    "deny_at",
    "memory",
    "scripted",
    "plugin",
    "evolve",
    "trust_db",
)


def agent_from_spec(spec: Mapping[str, Any]) -> Agent:
    """O mesmo agente que `exovision-agent run` montaria, a partir do que ficou na tarefa.

    Só o que não é interativo entra aqui: um worker não tem terminal para
    `--ask-at`, nem elicitação MCP. O que precisa de gente fica de fora da fila.
    """
    from ..cli import (  # tarde, para não fechar um ciclo com harness.cli
        _memory,
        _scripted,
        with_plugins,
    )

    provider: Provider = (
        _scripted(spec["scripted"])
        if spec.get("scripted")
        else make_provider(spec.get("model") or "", effort=spec.get("effort") or "")
    )
    instruction = (
        load_instruction(spec["instruction"])
        if spec.get("instruction")
        else Instruction.inline(spec.get("system") or "Você é um agente útil, preciso e direto.")
    )
    workspace = Path(spec["workspace"]).resolve() if spec.get("workspace") else None
    skills_locais = load_skills(spec["skills"]) if spec.get("skills") else []
    agent = Agent(
        provider=provider,
        instruction=instruction,
        name=str(spec.get("name") or "agent"),
        toolset=Workbench(workspace) if workspace else Registry(),
        policy=DenyRisk(at_or_above=spec["deny_at"]) if spec.get("deny_at") else AllowAll(),
        memory=_memory(str(spec.get("memory") or "default")),
        skills=SkillLibrary(skills_locais) if skills_locais else None,
        budget=Budget(max_turns=int(spec.get("max_turns") or 60), max_cost_usd=spec.get("max_cost")),
        workspace=workspace,
    )
    return with_plugins(
        agent,
        plugin_paths=list(spec.get("plugin") or []),
        workspace=workspace,
        trust_db=spec.get("trust_db"),
        evolve=bool(spec.get("evolve")),
    )


class SpecRunner(AgentRunner):
    """`payload = {"task": texto, "spec": {...}}`: o agente nasce da especificação gravada."""

    def __init__(self, **kw: Any) -> None:
        super().__init__({}, **kw)

    def resolve(self, payload: Mapping[str, Any]) -> Agent:
        return agent_from_spec(dict(payload.get("spec") or {}))


# --------------------------------------------------------------------------
# comandos
# --------------------------------------------------------------------------


def _spec_from_args(a: argparse.Namespace) -> dict[str, Any]:
    spec = {k: getattr(a, k) for k in SPEC_FIELDS if getattr(a, k, None) not in (None, [], "")}
    if spec.get("instruction"):
        spec["instruction"] = str(Path(spec["instruction"]).resolve())
    if spec.get("scripted"):
        spec["scripted"] = str(Path(spec["scripted"]).resolve())
    if spec.get("workspace"):
        spec["workspace"] = str(Path(spec["workspace"]).resolve())
    if spec.get("skills"):
        spec["skills"] = [str(Path(s).resolve()) for s in spec["skills"]]
    if spec.get("plugin"):
        spec["plugin"] = [str(Path(s).resolve()) for s in spec["plugin"]]
    if spec.get("trust_db"):
        spec["trust_db"] = str(Path(spec["trust_db"]).resolve())
    return spec


def _line(t: Task) -> str:
    erro = f"  {t.error.splitlines()[0][:60]}" if t.error else ""
    return f"{t.id}  {t.status:10s} p={t.priority:<3d} tent={t.attempts}  {t.payload.get('task', '')[:50]!s}{erro}"


def _bus(a: argparse.Namespace) -> Bus:
    return Bus(getattr(a, "bus", None) or a.db)


def _scheduler(a: argparse.Namespace) -> Scheduler:
    runner = SpecRunner(
        state_store=SQLiteStateStore(a.state) if getattr(a, "state", None) else None,
        trace_dir=getattr(a, "trace_dir", None),
        publish_trace=bool(getattr(a, "publish_trace", False)),
    )
    return Scheduler(
        SQLiteTaskStore(a.db),
        {"cli": runner},
        workers=getattr(a, "workers", 1),
        lease_s=getattr(a, "lease", 60.0),
        poll_s=getattr(a, "poll", 0.5),
        budget=Budget(max_cost_usd=getattr(a, "max_cost", None)),
        bus=_bus(a),
        publish_tasks=not getattr(a, "no_publish", False),
    )


def _sched_line(sc: Schedule) -> str:
    quando = f"cron={sc.cron!r} tz={sc.tz}" if sc.cron else f"every={sc.every_s}s"
    estado = "pausada" if sc.paused else "ativa"
    return f"{sc.name:20s} {estado:8s} {quando:34s} runs={sc.runs:<4d} next_at={sc.next_at:.0f}  {sc.payload.get('task', '')[:40]!s}"


def _trig_line(tr: Trigger) -> str:
    estado = "mudo" if tr.paused else "ativo"
    return f"{tr.name:20s} {estado:8s} {tr.pattern:30s} fired={tr.fired:<4d} {tr.payload.get('task', '')[:40]!s}"


def cmd_add(a: argparse.Namespace) -> int:
    sched = _scheduler(a)
    payload: dict[str, Any] = {"task": a.task, "spec": _spec_from_args(a)}
    if a.session:
        payload["session"] = a.session
    try:
        t = sched.enqueue(
            "cli",
            payload,
            key=a.key,
            priority=a.priority,
            after=a.after or (),
            delay_s=a.delay,
            at=a.at,
            retry=RetryPolicy(max_attempts=a.retries),
            timeout_s=a.timeout,
        )
    except KeyError as erro:
        raise SystemExit(str(erro)) from None
    if a.json:
        print(json.dumps(t.to_dict(), ensure_ascii=False, indent=2))
    else:
        print(t.id)
    return 0


def cmd_work(a: argparse.Namespace) -> int:
    sched = _scheduler(a)
    if a.once:
        t = sched.step("cli")
        if t is None:
            sys.stderr.write("nada a fazer agora\n")
            return 0
        print(_line(t))
        return 0 if t.ok else 1
    if a.forever:
        sched.serve_forever()
        sys.stderr.write("\nparado: as tarefas em curso terminaram\n")
        return 0
    if a.workers > 1:
        rel = sched.run_until_idle(timeout_s=a.timeout_s)
    else:
        rel = sched.drain(timeout_s=a.timeout_s)
    print(json.dumps(rel, ensure_ascii=False, indent=2))
    c = rel["counts"]
    return 0 if not (c["failed"] or c["blocked"]) else 1


def cmd_ls(a: argparse.Namespace) -> int:
    store = SQLiteTaskStore(a.db)
    tarefas = store.tasks(a.status)
    if a.json:
        print(json.dumps([t.to_dict() for t in tarefas], ensure_ascii=False, indent=2))
        return 0
    for t in tarefas:
        print(_line(t))
    return 0


def cmd_show(a: argparse.Namespace) -> int:
    store = SQLiteTaskStore(a.db)
    t = store.get(a.id)
    if t is None:
        raise SystemExit(f"tarefa desconhecida: {a.id}")
    hist = [x.to_dict() for x in store.attempts(a.id)]
    if a.json:
        print(json.dumps({**t.to_dict(), "attempts_log": hist}, ensure_ascii=False, indent=2))
        return 0
    print(_line(t))
    for h in hist:
        print(f"  #{h['attempt']} {h['worker']:14s} {h['status']:10s} {h['error'][:80]}")
    if isinstance(t.result, dict) and "text" in t.result:
        print("---")
        print(t.result["text"])
    elif t.result is not None:
        print("---")
        print(json.dumps(t.result, ensure_ascii=False, indent=2))
    return 0


def cmd_cancel(a: argparse.Namespace) -> int:
    status = _scheduler(a).cancel(a.id, reason=a.reason or "")
    if status is None:
        raise SystemExit(f"tarefa desconhecida: {a.id}")
    print(status)
    return 0


def cmd_retry(a: argparse.Namespace) -> int:
    ok = _scheduler(a).retry(a.id)
    print("pending" if ok else "sem efeito (só failed/cancelled/blocked reabrem)")
    return 0 if ok else 1


def cmd_report(a: argparse.Namespace) -> int:
    print(json.dumps(_scheduler(a).report(), ensure_ascii=False, indent=2))
    return 0


def cmd_schedule(a: argparse.Namespace) -> int:
    sched = _scheduler(a)
    payload: dict[str, Any] = {"task": a.task, "spec": _spec_from_args(a)}
    try:
        sc = sched.schedule(
            a.name,
            "cli",
            payload,
            every_s=a.every,
            cron=a.cron,
            tz=a.tz,
            first_at=a.first_at,
            overlap=a.overlap,
            catch_up=a.catch_up,
            jitter_s=a.jitter,
            ends_at=a.ends_at,
            max_runs=a.max_runs,
            priority=a.priority,
            retry=RetryPolicy(max_attempts=a.retries),
            timeout_s=a.timeout,
        )
    except (ValueError, KeyError) as erro:
        raise SystemExit(str(erro)) from None
    print(json.dumps(sc.to_dict(), ensure_ascii=False, indent=2) if a.json else _sched_line(sc))
    return 0


def cmd_schedules(a: argparse.Namespace) -> int:
    agendas = SQLiteTaskStore(a.db).schedules()
    if a.json:
        print(json.dumps([sc.to_dict() for sc in agendas], ensure_ascii=False, indent=2))
        return 0
    for sc in agendas:
        print(_sched_line(sc))
    return 0


def cmd_pause(a: argparse.Namespace) -> int:
    ok = _scheduler(a).pause(a.name)
    print("pausada" if ok else f"agenda desconhecida: {a.name}")
    return 0 if ok else 1


def cmd_resume(a: argparse.Namespace) -> int:
    ok = _scheduler(a).resume(a.name)
    print("ativa" if ok else f"agenda desconhecida: {a.name}")
    return 0 if ok else 1


def cmd_unschedule(a: argparse.Namespace) -> int:
    ok = _scheduler(a).unschedule(a.name)
    print("removida" if ok else f"agenda desconhecida: {a.name}")
    return 0 if ok else 1


def cmd_on(a: argparse.Namespace) -> int:
    sched = _scheduler(a)
    payload: dict[str, Any] = {"task": a.task, "spec": _spec_from_args(a)}
    try:
        tr = sched.on(
            a.name,
            a.pattern,
            "cli",
            payload,
            priority=a.priority,
            retry=RetryPolicy(max_attempts=a.retries),
            timeout_s=a.timeout,
        )
    except (ValueError, KeyError) as erro:
        raise SystemExit(str(erro)) from None
    print(json.dumps(tr.to_dict(), ensure_ascii=False, indent=2) if a.json else _trig_line(tr))
    return 0


def cmd_triggers(a: argparse.Namespace) -> int:
    gatilhos = SQLiteTaskStore(a.db).triggers()
    if a.json:
        print(json.dumps([tr.to_dict() for tr in gatilhos], ensure_ascii=False, indent=2))
        return 0
    for tr in gatilhos:
        print(_trig_line(tr))
    return 0


def cmd_off(a: argparse.Namespace) -> int:
    ok = _scheduler(a).off(a.name)
    print("removido" if ok else f"gatilho desconhecido: {a.name}")
    return 0 if ok else 1


def cmd_publish(a: argparse.Namespace) -> int:
    extra = json.loads(a.data) if a.data else {}
    try:
        m = _bus(a).publish(a.subject, {"text": a.text, **extra})
    except ValueError as erro:
        raise SystemExit(str(erro)) from None
    print(json.dumps(m.to_dict(), ensure_ascii=False) if a.json else f"#{m.seq} {m.subject}")
    return 0


def cmd_messages(a: argparse.Namespace) -> int:
    try:
        msgs = _bus(a).read(a.pattern, after=a.after, limit=a.limit)
    except ValueError as erro:
        raise SystemExit(str(erro)) from None
    if a.json:
        print(json.dumps([m.to_dict() for m in msgs], ensure_ascii=False, indent=2))
        return 0
    for m in msgs:
        print(f"#{m.seq} {m.subject}  {json.dumps(m.data, ensure_ascii=False)[:160]}")
    return 0


# --------------------------------------------------------------------------
# parser
# --------------------------------------------------------------------------


def add_parser(sub: Any) -> None:
    sp = sub.add_parser(
        "tasks",
        help="fila durável: enfileirar, trabalhar, listar, cancelar, reabrir",
        description=__doc__,
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )
    ss = sp.add_subparsers(dest="tcmd", required=True)

    def db(p: argparse.ArgumentParser) -> None:
        p.add_argument("--db", required=True, help="arquivo SQLite da fila (e do barramento)")
        p.add_argument("--bus", default=None, help="arquivo do barramento, se separado da fila")

    def spec(p: argparse.ArgumentParser) -> None:
        p.add_argument("--instruction", help="documento .md de instrução")
        p.add_argument("--system", help="instrução inline (alternativa a --instruction)")
        p.add_argument("--name", default="agent")
        p.add_argument("--workspace", help="diretório onde bash/editor/busca rodam")
        p.add_argument("--skills", nargs="*", help="diretórios de skills")
        p.add_argument("--model")
        p.add_argument("--effort")
        p.add_argument("--max-turns", type=int, default=60)
        p.add_argument("--max-cost", type=float, default=None, help="teto de custo do agente (USD)")
        p.add_argument("--deny-at", choices=["read", "write", "external", "irreversible"])
        p.add_argument("--memory", choices=["none", "default"], default="default")
        p.add_argument("--scripted", help="JSON com respostas roteirizadas (sem rede)")
        p.add_argument("--plugin", action="append", metavar="DIR", help="anexa um plugin (repetível)")
        p.add_argument("--evolve", action="store_true", help="o agente pode criar plugins e tools")
        p.add_argument("--trust-db", help="estado de confiança dos plugins")

    def policy(p: argparse.ArgumentParser) -> None:
        p.add_argument("--priority", type=int, default=0)
        p.add_argument("--retries", type=int, default=3, help="tentativas (falha transitória)")
        p.add_argument("--timeout", type=float, default=None, help="parede por tentativa (s)")
        p.add_argument("--json", action="store_true")

    ad = ss.add_parser("add", help="enfileira uma tarefa de agente")
    ad.add_argument("task")
    db(ad)
    spec(ad)
    ad.add_argument("--session", help="nome da sessão no journal (padrão: o id da tarefa)")
    ad.add_argument("--key", help="idempotência: a mesma key não entra duas vezes")
    ad.add_argument("--after", nargs="*", metavar="ID", help="só roda depois destas tarefas")
    ad.add_argument("--delay", type=float, default=0.0, help="segundos até poder rodar")
    ad.add_argument("--at", type=float, default=None, help="timestamp Unix a partir do qual pode rodar")
    policy(ad)
    ad.set_defaults(fn=cmd_add)

    sc = ss.add_parser("schedule", help="a mesma tarefa de novo: por intervalo (--every) ou cron (--cron)")
    sc.add_argument("name")
    sc.add_argument("task")
    db(sc)
    spec(sc)
    sc.add_argument("--every", type=float, default=None, help="intervalo em segundos")
    sc.add_argument("--cron", default=None, help='expressão cron de 5 campos, ex.: "0 9 * * mon-fri"')
    sc.add_argument("--tz", default="UTC", help="fuso da expressão cron (zoneinfo)")
    sc.add_argument("--first-at", type=float, default=None, help="timestamp Unix do primeiro disparo")
    sc.add_argument("--overlap", choices=["skip", "queue"], default="skip")
    sc.add_argument("--catch-up", choices=["one", "all", "none"], default="one")
    sc.add_argument("--jitter", type=float, default=0.0, help="dispersão máxima do disparo (s)")
    sc.add_argument("--ends-at", type=float, default=None, help="timestamp Unix do fim")
    sc.add_argument("--max-runs", type=int, default=None)
    policy(sc)
    sc.set_defaults(fn=cmd_schedule)

    scs = ss.add_parser("schedules", help="lista as agendas")
    db(scs)
    scs.add_argument("--json", action="store_true")
    scs.set_defaults(fn=cmd_schedules)

    for nome, fn, ajuda in (
        ("pause", cmd_pause, "pausa uma agenda"),
        ("resume", cmd_resume, "reativa uma agenda"),
        ("unschedule", cmd_unschedule, "remove uma agenda"),
        ("off", cmd_off, "remove um gatilho"),
    ):
        pp = ss.add_parser(nome, help=ajuda)
        pp.add_argument("name")
        db(pp)
        pp.set_defaults(fn=fn)

    on = ss.add_parser("on", help="gatilho: mensagem que casa o padrão vira tarefa (molde com {{data.x}})")
    on.add_argument("name")
    on.add_argument("pattern", help="padrão de assunto: '*' um token, '>' o resto")
    on.add_argument("task", help="texto da tarefa; {{subject}}, {{seq}}, {{data.campo}} são preenchidos")
    db(on)
    spec(on)
    policy(on)
    on.set_defaults(fn=cmd_on)

    trs = ss.add_parser("triggers", help="lista os gatilhos")
    db(trs)
    trs.add_argument("--json", action="store_true")
    trs.set_defaults(fn=cmd_triggers)

    pb = ss.add_parser("publish", help="publica uma mensagem no barramento")
    pb.add_argument("subject")
    pb.add_argument("text")
    db(pb)
    pb.add_argument("--data", help="JSON com campos extras")
    pb.add_argument("--json", action="store_true")
    pb.set_defaults(fn=cmd_publish)

    ms = ss.add_parser("messages", help="lê mensagens do barramento por padrão de assunto")
    ms.add_argument("pattern", nargs="?", default=">")
    db(ms)
    ms.add_argument("--after", type=int, default=0)
    ms.add_argument("--limit", type=int, default=50)
    ms.add_argument("--json", action="store_true")
    ms.set_defaults(fn=cmd_messages)

    wk = ss.add_parser("work", help="executa a fila: até esvaziar, uma vez (--once) ou sempre (--forever)")
    db(wk)
    wk.add_argument("--state", help="arquivo SQLite do journal do laço (retomada)")
    wk.add_argument("--trace-dir", help="diretório para o traço JSONL de cada tentativa")
    wk.add_argument("--workers", type=int, default=1)
    wk.add_argument("--lease", type=float, default=60.0, help="prazo da lease (s)")
    wk.add_argument("--poll", type=float, default=0.5)
    wk.add_argument("--max-cost", type=float, default=None, help="teto de custo da fila (USD)")
    wk.add_argument("--timeout-s", type=float, default=None, help="parede total desta chamada")
    wk.add_argument("--once", action="store_true", help="uma tarefa e sai")
    wk.add_argument("--forever", action="store_true", help="fica escutando a fila, as agendas e os gatilhos")
    wk.add_argument("--publish-trace", action="store_true", help="o traço de cada agente vai para o barramento")
    wk.add_argument("--no-publish", action="store_true", help="não anuncia o ciclo de vida das tarefas no barramento")
    wk.set_defaults(fn=cmd_work)

    ls = ss.add_parser("ls", help="lista tarefas")
    db(ls)
    ls.add_argument("--status", choices=["pending", "running", "succeeded", "failed", "cancelled", "blocked"])
    ls.add_argument("--json", action="store_true")
    ls.set_defaults(fn=cmd_ls)

    sh = ss.add_parser("show", help="uma tarefa, o histórico de tentativas e o resultado")
    sh.add_argument("id")
    db(sh)
    sh.add_argument("--json", action="store_true")
    sh.set_defaults(fn=cmd_show)

    ca = ss.add_parser("cancel", help="cancela (pendente: já; rodando: na próxima chamada ao modelo)")
    ca.add_argument("id")
    db(ca)
    ca.add_argument("--reason")
    ca.set_defaults(fn=cmd_cancel)

    rt = ss.add_parser("retry", help="reabre uma tarefa failed/cancelled/blocked")
    rt.add_argument("id")
    db(rt)
    rt.set_defaults(fn=cmd_retry)

    rp = ss.add_parser("report", help="contagem por status e custo somado")
    db(rp)
    rp.set_defaults(fn=cmd_report)
