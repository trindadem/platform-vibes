"""As primitivas cognitivas: uma volta, sem ferramenta, com forma garantida e conta.

Todo módulo do kernel que precisa do modelo fora do laço — HyDE e reranking
no RAG, reflexão na especialização, consolidação na memória, lances por
modelo nas equipes — chama uma destas:

    ask       texto -> texto
    extract   texto -> objeto que valida contra um JSON Schema (com reparo)
    classify  texto -> um rótulo de uma lista fechada
    judge     dois candidatos -> "a" | "b" | "tie", com posição balanceada
    rank      n candidatos -> ordem, por comparação em pares balanceada

Todas montam o `Request` no formato de fio, aceitam qualquer `Provider`
(inclusive `ScriptedProvider`, `Replay`, pilhas com limites e livro-razão) e
contam em `LLMUsage`. As decisões que não são óbvias:

- **Raciocínio livre, estrutura no fim.** Restringir o formato degrada o
  raciocínio (Tam et al., 2024). `extract` pede a resposta e um bloco JSON
  final, extrai o último objeto balanceado e valida. `strict`/`format` do
  provedor entram quando o chamador os pede — a decisão é dele.
- **Reparo com orçamento.** JSON inválido ou fora do schema volta ao modelo
  com o erro de validação e o pedido de só o JSON corrigido, no máximo
  `repairs` vezes. Cada tentativa é contada; esgotado, `ExtractionError`.
- **Posição balanceada.** Trocar a ordem dos candidatos vira o veredito de um
  juiz (Wang et al., 2023). `judge` pergunta nas duas ordens e só declara
  vencedor quando as duas concordam.
- **Schema em stdlib.** O validador cobre `type`, `properties`, `required`,
  `enum`, `items`, `minimum`/`maximum`, `minLength`/`maxLength`,
  `additionalProperties: false` — o suficiente para extração, sem instalar
  `jsonschema`.
"""

from __future__ import annotations

import json
import re
from collections.abc import Sequence
from dataclasses import dataclass, field
from typing import Any

from .catalog import estimate_cost_usd
from .provider import Provider, Reply, Request

__all__ = [
    "ExtractionError",
    "LLMUsage",
    "ask",
    "classify",
    "extract",
    "extract_json",
    "judge",
    "parse_json_list",
    "parse_ranking",
    "rank",
    "validate",
]


@dataclass(slots=True)
class LLMUsage:
    calls: int = 0
    input_tokens: int = 0
    output_tokens: int = 0
    cost_usd: float = 0.0
    log: list[dict[str, Any]] = field(default_factory=list)

    def add(self, model: str, usage: dict[str, int], *, discount: float = 1.0) -> None:
        self.calls += 1
        self.input_tokens += int(usage.get("input_tokens", 0))
        self.output_tokens += int(usage.get("output_tokens", 0))
        self.cost_usd += estimate_cost_usd(model, usage, discount=discount)

    def to_dict(self) -> dict[str, Any]:
        return {
            "calls": self.calls,
            "input_tokens": self.input_tokens,
            "output_tokens": self.output_tokens,
            "cost_usd": round(self.cost_usd, 6),
        }


class ExtractionError(ValueError):
    """A saída não validou contra o schema dentro do orçamento de reparos."""


def _complete(
    provider: Provider,
    system: str,
    messages: list[dict[str, Any]],
    *,
    max_tokens: int,
    usage: LLMUsage | None,
    role: str,
    metadata: dict[str, Any] | None = None,
) -> Reply:
    req = Request(
        system=[{"type": "text", "text": system}] if system else [],
        messages=messages,
        max_tokens=max_tokens,
        metadata={"role": role, **(metadata or {})},
    )
    reply = provider.complete(req)
    if usage is not None:
        usage.add(
            reply.model or getattr(provider, "model", ""),
            reply.usage,
            discount=float(getattr(provider, "cost_discount", 1.0)),
        )
        last = messages[-1]["content"]
        texto = last if isinstance(last, str) else json.dumps(last, ensure_ascii=False)
        usage.log.append({"system": system[:80], "user": texto[:120], "reply": reply.text[:200]})
    return reply


def _user(text: str) -> dict[str, Any]:
    return {"role": "user", "content": [{"type": "text", "text": text}]}


def ask(
    provider: Provider,
    system: str,
    user: str,
    *,
    max_tokens: int = 1024,
    usage: LLMUsage | None = None,
    role: str = "ask",
) -> str:
    """Uma volta, sem ferramenta: texto -> texto."""
    return _complete(
        provider, system, [_user(user)], max_tokens=max_tokens, usage=usage, role=role
    ).text


# --------------------------------------------------------------------------
# JSON: extração e validação
# --------------------------------------------------------------------------


def extract_json(text: str) -> Any:
    """O último objeto ou lista JSON **de topo** balanceado do texto (ou `None`).

    Aceita cercas ```json ... ```; entre candidatos de topo, vale o último
    que faz parse — o modelo raciocina antes e estrutura depois.
    """
    fenced = re.findall(r"```(?:json)?\s*(.*?)```", text, re.S)
    for bloco in reversed(fenced):
        try:
            return json.loads(bloco)
        except json.JSONDecodeError:
            continue
    ultimo: Any = None
    achou = False
    pilha: list[str] = []
    inicio = -1
    in_str = False
    esc = False
    for j, ch in enumerate(text):
        if in_str:
            if esc:
                esc = False
            elif ch == "\\":
                esc = True
            elif ch == '"':
                in_str = False
            continue
        if ch == '"':
            if pilha:
                in_str = True
            continue
        if ch in "{[":
            if not pilha:
                inicio = j
            pilha.append("}" if ch == "{" else "]")
        elif ch in "}]":
            if not pilha or pilha[-1] != ch:
                pilha.clear()
                continue
            pilha.pop()
            if not pilha:
                try:
                    ultimo = json.loads(text[inicio : j + 1])
                    achou = True
                except json.JSONDecodeError:
                    pass
    return ultimo if achou else None


_TYPES: dict[str, tuple[type, ...]] = {
    "object": (dict,),
    "array": (list,),
    "string": (str,),
    "integer": (int,),
    "number": (int, float),
    "boolean": (bool,),
    "null": (type(None),),
}


def validate(schema: dict[str, Any], value: Any, path: str = "$") -> list[str]:
    """Erros de validação de `value` contra um JSON Schema mínimo (vazio = válido)."""
    erros: list[str] = []
    t = schema.get("type")
    if t:
        tipos = t if isinstance(t, list) else [t]
        ok = False
        for tn in tipos:
            esperado = _TYPES.get(tn)
            if esperado is None:
                continue
            if isinstance(value, bool) and tn in ("integer", "number"):
                continue
            if isinstance(value, esperado):
                ok = True
                break
        if not ok:
            erros.append(f"{path}: esperado {'/'.join(tipos)}, veio {type(value).__name__}")
            return erros
    if "enum" in schema and value not in schema["enum"]:
        erros.append(f"{path}: {value!r} não está em {schema['enum']!r}")
    if isinstance(value, dict):
        props = schema.get("properties", {})
        for k in schema.get("required", []):
            if k not in value:
                erros.append(f"{path}.{k}: obrigatório e ausente")
        for k, v in value.items():
            if k in props:
                erros.extend(validate(props[k], v, f"{path}.{k}"))
            elif schema.get("additionalProperties") is False:
                erros.append(f"{path}.{k}: propriedade não prevista")
    if isinstance(value, list) and "items" in schema:
        for i, v in enumerate(value):
            erros.extend(validate(schema["items"], v, f"{path}[{i}]"))
        if "minItems" in schema and len(value) < schema["minItems"]:
            erros.append(f"{path}: menos de {schema['minItems']} itens")
        if "maxItems" in schema and len(value) > schema["maxItems"]:
            erros.append(f"{path}: mais de {schema['maxItems']} itens")
    if isinstance(value, (int, float)) and not isinstance(value, bool):
        if "minimum" in schema and value < schema["minimum"]:
            erros.append(f"{path}: {value} < mínimo {schema['minimum']}")
        if "maximum" in schema and value > schema["maximum"]:
            erros.append(f"{path}: {value} > máximo {schema['maximum']}")
    if isinstance(value, str):
        if "minLength" in schema and len(value) < schema["minLength"]:
            erros.append(f"{path}: menos de {schema['minLength']} caracteres")
        if "maxLength" in schema and len(value) > schema["maxLength"]:
            erros.append(f"{path}: mais de {schema['maxLength']} caracteres")
        if "pattern" in schema and not re.search(schema["pattern"], value):
            erros.append(f"{path}: não casa com {schema['pattern']!r}")
    return erros


EXTRACT_SYSTEM = """\
Você extrai informação em JSON. Pense livremente se precisar; termine a resposta \
com um único bloco ```json``` contendo apenas o objeto pedido, sem comentários."""


def extract(
    provider: Provider,
    schema: dict[str, Any],
    text: str,
    *,
    system: str = "",
    instruction: str = "Extraia do texto o objeto que satisfaz o schema.",
    repairs: int = 2,
    max_tokens: int = 2048,
    usage: LLMUsage | None = None,
) -> Any:
    """Texto -> objeto validado contra `schema`, com até `repairs` reparos.

    Devolve o objeto; `ExtractionError` traz os erros da última tentativa.
    O número de chamadas feitas fica em `usage.calls` (1 + reparos usados).
    """
    sys_ = (system + "\n\n" if system else "") + EXTRACT_SYSTEM
    pedido = (
        f"{instruction}\n\nSchema (JSON Schema):\n```json\n"
        f"{json.dumps(schema, ensure_ascii=False)}\n```\n\nTexto:\n{text}"
    )
    messages: list[dict[str, Any]] = [_user(pedido)]
    erros: list[str] = []
    for tentativa in range(repairs + 1):
        reply = _complete(
            provider, sys_, messages, max_tokens=max_tokens, usage=usage,
            role="extract" if tentativa == 0 else "extract.repair",
        )
        obj = extract_json(reply.text)
        erros = ["nenhum JSON na resposta"] if obj is None else validate(schema, obj)
        if not erros:
            return obj
        messages.append({"role": "assistant", "content": reply.content or [{"type": "text", "text": reply.text or "(vazio)"}]})
        messages.append(
            _user(
                "O JSON não validou:\n- " + "\n- ".join(erros)
                + "\n\nResponda apenas com o bloco ```json``` corrigido."
            )
        )
    raise ExtractionError("; ".join(erros))


def classify(
    provider: Provider,
    labels: Sequence[str],
    text: str,
    *,
    system: str = "",
    criteria: str = "",
    max_tokens: int = 256,
    usage: LLMUsage | None = None,
) -> str:
    """Texto -> um rótulo de `labels` (fechado). Fora da lista é `ExtractionError`."""
    schema = {"type": "object", "properties": {"label": {"type": "string", "enum": list(labels)}}, "required": ["label"], "additionalProperties": False}
    instr = "Classifique o texto num dos rótulos" + (f" segundo: {criteria}" if criteria else "") + "."
    obj = extract(provider, schema, text, system=system, instruction=instr, repairs=1, max_tokens=max_tokens, usage=usage)
    return str(obj["label"])


JUDGE_SYSTEM = """\
Você é um avaliador. Compare as duas respostas segundo os critérios e escolha a \
melhor. Dê primeiro as evidências (curtas), depois termine com um bloco ```json``` \
no formato {"winner": "A" | "B" | "tie"}."""


def _one_verdict(provider: Provider, criteria: str, first: str, second: str, *, task: str, max_tokens: int, usage: LLMUsage | None) -> str:
    pedido = (
        (f"Tarefa:\n{task}\n\n" if task else "")
        + f"Critérios: {criteria}\n\nResposta A:\n{first}\n\nResposta B:\n{second}"
    )
    schema = {"type": "object", "properties": {"winner": {"type": "string", "enum": ["A", "B", "tie"]}}, "required": ["winner"]}
    try:
        obj = extract(provider, schema, pedido, system=JUDGE_SYSTEM, instruction="Julgue.", repairs=1, max_tokens=max_tokens, usage=usage)
    except ExtractionError:
        return "tie"
    return str(obj["winner"])


def judge(
    provider: Provider,
    a: str,
    b: str,
    criteria: str,
    *,
    task: str = "",
    balanced: bool = True,
    max_tokens: int = 1024,
    usage: LLMUsage | None = None,
) -> str:
    """Dois candidatos -> "a" | "b" | "tie".

    Com `balanced` (padrão) pergunta nas duas ordens e só declara vencedor se
    as duas concordam — custa 2x e neutraliza o viés de posição.
    """
    v1 = _one_verdict(provider, criteria, a, b, task=task, max_tokens=max_tokens, usage=usage)
    if not balanced:
        return {"A": "a", "B": "b"}.get(v1, "tie")
    v2 = _one_verdict(provider, criteria, b, a, task=task, max_tokens=max_tokens, usage=usage)
    # Na segunda ordem, "A" é o candidato b.
    r1 = {"A": "a", "B": "b"}.get(v1, "tie")
    r2 = {"A": "b", "B": "a"}.get(v2, "tie")
    return r1 if r1 == r2 else "tie"


def rank(
    provider: Provider,
    items: Sequence[str],
    criteria: str,
    *,
    task: str = "",
    balanced: bool = True,
    max_tokens: int = 1024,
    usage: LLMUsage | None = None,
) -> list[int]:
    """n candidatos -> índices em ordem decrescente (Copeland sobre pares).

    O(n²) comparações (2x com `balanced`): é para listas curtas — reranking
    listwise de RAG fica em `rag.rerank`.
    """
    n = len(items)
    score = [0.0] * n
    for i in range(n):
        for j in range(i + 1, n):
            v = judge(provider, items[i], items[j], criteria, task=task, balanced=balanced, max_tokens=max_tokens, usage=usage)
            if v == "a":
                score[i] += 1
            elif v == "b":
                score[j] += 1
            else:
                score[i] += 0.5
                score[j] += 0.5
    return sorted(range(n), key=lambda k: (-score[k], k))


# --------------------------------------------------------------------------
# Parsers herdados do RAG (listas e rankings em texto)
# --------------------------------------------------------------------------


def parse_json_list(text: str, *, strict: bool = False) -> list[str]:
    """Extrai uma lista JSON de strings do texto; sem JSON, cai em linhas não vazias
    (ou em lista vazia com `strict=True`, para quem não pode aceitar prosa como item)."""
    m = re.search(r"\[.*\]", text, re.S)
    if m:
        try:
            data = json.loads(m.group(0))
            if isinstance(data, list):
                return [str(x).strip() for x in data if str(x).strip()]
        except json.JSONDecodeError:
            pass
    if strict:
        return []
    lines = [re.sub(r"^\s*(?:[-*\d.)]+)\s*", "", ln).strip() for ln in text.splitlines()]
    return [ln for ln in lines if ln]


def parse_ranking(text: str, n: int) -> list[int]:
    """`[3] > [1] > [2]` (RankGPT) -> [2, 0, 1]; completa com os ausentes na ordem original."""
    seen: list[int] = []
    for tok in re.findall(r"\[(\d+)\]", text):
        i = int(tok) - 1
        if 0 <= i < n and i not in seen:
            seen.append(i)
    seen.extend(i for i in range(n) if i not in seen)
    return seen
