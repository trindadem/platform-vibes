"""Os benchmarks do estudo de modelos (M1..M7), offline, sem modelo.

Cada um responde a uma pergunta da seção 10 de `docs/modelos-estudo.md` e
grava JSON em `docs/modelos/resultados/` com máquina, semente e IC. Todos
medem a **máquina** (o roteador, o balde, o cassete, a janela, o reparo, o
juiz, a auditoria) com provedores puros; onde há modelo simulado, as
hipóteses estão no JSON, em `hipoteses`.
"""

from __future__ import annotations

import json
import os
import random
import tempfile
import threading
import time
from collections.abc import Callable
from pathlib import Path
from typing import Any

from ..budget import Budget
from ..loop import Agent, run
from ..rag.eval.bench import environment
from ..rag.eval.metrics import bootstrap_ci
from ..seams import Seams
from ..tools import Registry
from .catalog import resolve
from .engine import ExtractionError, extract, judge
from .limits import Breaker, Limited, RateLimiter
from .provider import ProviderError, Reply, Request, ScriptedProvider
from .replay import Cassette, Recording, Replay
from .router import Cascade
from .window import RATIO, PrefixAudit, Window, estimate_request

__all__ = ["BENCHMARKS", "results_dir", "run_benchmark"]


def results_dir() -> str:
    here = Path(__file__).resolve()
    for parent in here.parents:
        if (parent / "pyproject.toml").is_file():
            return str(parent / "docs" / "modelos" / "resultados")
    return str(Path.cwd() / "resultados")


def _write(name: str, payload: dict[str, Any], out_dir: str | None) -> str:
    d = out_dir or results_dir()
    os.makedirs(d, exist_ok=True)
    path = os.path.join(d, f"{name}.json")
    with open(path, "w", encoding="utf-8") as fh:
        json.dump({"environment": environment(), **payload}, fh, ensure_ascii=False, indent=2)
    return path


def _ci(values: list[float], seed: int = 0) -> dict[str, float]:
    m, lo, hi = bootstrap_ci(values, seed=seed)
    return {"mean": round(m, 4), "lo": round(lo, 4), "hi": round(hi, 4), "n": len(values)}


# --------------------------------------------------------------------------
# M1 — cascata x modelo único x esforço, compute igualado
# --------------------------------------------------------------------------


class _Modelo:
    """Um 'modelo' simulado: acerta com probabilidade p e custa c por chamada."""

    effort = "high"

    def __init__(self, name: str, p: float, cost: float, rng: random.Random) -> None:
        self.model = name
        self.p = p
        self.cost = cost
        self.rng = rng
        self.calls = 0
        self.spent = 0.0

    def complete(self, request: Request) -> Reply:
        self.calls += 1
        self.spent += self.cost
        ok = self.rng.random() < self.p
        return Reply.of_text("correct" if ok else "wrong", input_tokens=1, output_tokens=1)


def bench_cascade(seed: int, out_dir: str | None) -> str:
    hip: dict[str, Any] = {
        "tarefas": 1000, "sementes": 10,
        "p_strong": 0.85, "cost_strong": 1.0,
        "p_strong_low_effort": 0.80, "cost_strong_low_effort": 0.6,
        "p_cheap": [0.5, 0.65, 0.8], "verificador_tpr_tnr": {"bom": 0.95, "medio": 0.8, "ruim": 0.6},
        "cost_verify": 0.05, "razao_de_precos": [2.5, 5.0], "penalidade_cache": [0.0, 0.3],
        "budget": "N chamadas do modelo forte; tarefas além do orçamento contam como falha",
    }
    rows = []
    n = int(hip["tarefas"])
    for vq_name, vq in hip["verificador_tpr_tnr"].items():
        for p_cheap in hip["p_cheap"]:
            for ratio in hip["razao_de_precos"]:
                for pen in hip["penalidade_cache"]:
                    solved_c, cost_c, esc = [], [], []
                    for s in range(int(hip["sementes"])):
                        # Fluxos independentes por papel: com a mesma semente, modelo e
                        # verificador ficariam perfeitamente correlacionados.
                        cheap = _Modelo("cheap", p_cheap, 1.0 / ratio, random.Random(f"{seed}:{s}:cheap"))
                        strong = _Modelo("strong", hip["p_strong"], hip["cost_strong"], random.Random(f"{seed}:{s}:strong"))
                        ver_rng = random.Random(f"{seed}:{s}:verify")
                        n_ver = [0]

                        def verify(req: Request, rep: Reply, _r: random.Random = ver_rng, _c: list[int] = n_ver, _q: float = vq) -> bool:
                            _c[0] += 1
                            ok = rep.text == "correct"
                            return _r.random() < _q if ok else _r.random() >= _q

                        casc = Cascade(cheap, strong, verify)
                        corretas = 0
                        gasto_extra = 0.0
                        for _ in range(n):
                            rep = casc.complete(Request(system=[], messages=[]))
                            corretas += rep.text == "correct"
                        gasto_extra = casc.escalations * hip["cost_strong"] * pen + n_ver[0] * hip["cost_verify"]
                        custo_total = cheap.spent + strong.spent + gasto_extra
                        custo_por_tarefa = custo_total / n
                        # compute igualado: orçamento = n chamadas do forte; o excedente vira falha
                        processadas = min(n, int(n / custo_por_tarefa)) if custo_por_tarefa > 0 else n
                        solved_c.append(corretas / n * processadas / n)
                        cost_c.append(custo_por_tarefa)
                        esc.append(casc.escalations / n)
                    forte = hip["p_strong"]
                    baixo = hip["p_strong_low_effort"]
                    media = sum(solved_c) / len(solved_c)
                    rows.append({
                        "verificador": vq_name, "p_cheap": p_cheap, "razao": ratio, "penalidade": pen,
                        "cascata_resolvidas": _ci(solved_c, seed), "cascata_custo": _ci(cost_c, seed), "escalacoes": _ci(esc, seed),
                        "forte_resolvidas": forte, "forte_custo": hip["cost_strong"],
                        "esforco_baixo_resolvidas": baixo, "esforco_baixo_custo": hip["cost_strong_low_effort"],
                        "cascata_dominada_por": "ninguém" if media > forte else ("esforço baixo" if baixo >= media and sum(cost_c) / len(cost_c) >= hip["cost_strong_low_effort"] else "forte"),
                    })
    return _write("m1_cascata_compute_igualado", {"benchmark": "M1", "seed": seed, "hipoteses": hip, "rows": rows}, out_dir)


# --------------------------------------------------------------------------
# M2 — o balde compartilhado e a tempestade de retentativas
# --------------------------------------------------------------------------


class _Servidor:
    """Uma API de mentira com balde estrito (rate r/s, rajada c) e uma janela de indisponibilidade."""

    def __init__(self, rate: float, burst: float, *, outage: tuple[float, float] | None = None) -> None:
        self.rate = rate
        self.burst = burst
        self.tokens = burst
        self.t = time.monotonic()
        self.lock = threading.Lock()
        self.outage = outage  # (início, fim) relativos ao t0
        self.t0 = time.monotonic()
        self.requests = 0
        self.rejected = 0
        self.during_outage = 0

    def call(self) -> bool:
        with self.lock:
            now = time.monotonic()
            self.requests += 1
            if self.outage and self.outage[0] <= now - self.t0 < self.outage[1]:
                self.during_outage += 1
                return False
            self.tokens = min(self.burst, self.tokens + (now - self.t) * self.rate)
            self.t = now
            if self.tokens >= 1:
                self.tokens -= 1
                return True
            self.rejected += 1
            return False


class _Driver:
    """Driver com o mesmo recuo do kernel (exponencial + jitter), contra o servidor falso."""

    effort = "high"

    def __init__(self, server: _Servidor, *, retries: int = 6, base: float = 0.02, rng: random.Random | None = None) -> None:
        self.server = server
        self.retries = retries
        self.base = base
        self.rng = rng or random.Random(0)
        self.model = "m"
        self.on_retry: Callable[[int, float, str], None] | None = None
        self.retried = 0

    def complete(self, request: Request) -> Reply:
        attempt = 0
        while True:
            if self.server.call():
                return Reply.of_text("ok", input_tokens=10, output_tokens=1)
            if attempt >= self.retries:
                raise ProviderError("429 esgotado")
            attempt += 1
            self.retried += 1
            wait = min(0.5, self.base * (2 ** (attempt - 1))) * (0.8 + 0.4 * self.rng.random())
            if self.on_retry:
                self.on_retry(attempt, wait, "http_429")
            time.sleep(wait)


def _clientes(fabrica: Callable[[int], Any], n_clients: int, per_client: int) -> dict[str, Any]:
    lat: list[float] = []
    falhas = [0]
    lock = threading.Lock()

    def worker(i: int) -> None:
        prov = fabrica(i)
        for _ in range(per_client):
            t0 = time.perf_counter()
            try:
                prov.complete(Request(system=[], messages=[{"role": "user", "content": "x" * 70}]))
            except ProviderError:
                with lock:
                    falhas[0] += 1
            with lock:
                lat.append(time.perf_counter() - t0)

    t0 = time.perf_counter()
    ts = [threading.Thread(target=worker, args=(i,)) for i in range(n_clients)]
    for t in ts:
        t.start()
    for t in ts:
        t.join()
    wall = time.perf_counter() - t0
    lat.sort()
    return {"wall_s": round(wall, 3), "p50_ms": round(lat[len(lat) // 2] * 1000, 1), "p95_ms": round(lat[int(len(lat) * 0.95)] * 1000, 1), "falhas": falhas[0]}


def _tempestade(modo: str, n_clients: int, seed: int) -> dict[str, Any]:
    srv = _Servidor(1000.0, 50, outage=(0.05, 0.65))
    recuperou: list[float | None] = [None]
    lock = threading.Lock()
    sucessos = [0]
    locais = [0]

    def worker(i: int) -> None:
        d = _Driver(srv, retries=2, base=0.02, rng=random.Random(seed + i))
        inner: Any = Limited(d, None, breaker=Breaker(failures=3, open_s=0.3)) if modo == "com disjuntor" else d
        prazo = time.monotonic() + 2.0
        feitos = 0
        while feitos < 20 and time.monotonic() < prazo:
            try:
                inner.complete(Request(system=[], messages=[]))
            except ProviderError as erro:
                if "disjuntor" in str(erro):
                    with lock:
                        locais[0] += 1
                    time.sleep(0.01)
                continue
            feitos += 1
            with lock:
                sucessos[0] += 1
                if recuperou[0] is None and time.monotonic() - srv.t0 >= 0.65:
                    recuperou[0] = round(time.monotonic() - srv.t0 - 0.65, 3)

    t0 = time.perf_counter()
    ts = [threading.Thread(target=worker, args=(i,)) for i in range(n_clients)]
    for t in ts:
        t.start()
    for t in ts:
        t.join()
    return {"modo": modo, "pedidos_ao_servidor": srv.requests, "durante_a_queda": srv.during_outage, "recusados_localmente": locais[0], "sucessos": sucessos[0], "wall_s": round(time.perf_counter() - t0, 3), "recuperou_apos_s": recuperou[0]}


def bench_limits(seed: int, out_dir: str | None) -> str:
    hip: dict[str, Any] = {"clientes": 8, "pedidos_por_cliente": 20, "servidor_rps": 100.0, "rajada": 10, "rpm_do_balde": 6000, "recuo_base_s": 0.02, "tentativas": 6}
    n, per = int(hip["clientes"]), int(hip["pedidos_por_cliente"])
    rows = []
    with tempfile.TemporaryDirectory() as tmp:
        # (a) sem coordenação: cada cliente com o seu recuo
        srv = _Servidor(hip["servidor_rps"], hip["rajada"])
        drivers: list[_Driver] = []

        def naive(i: int) -> Any:
            d = _Driver(srv, retries=hip["tentativas"], base=hip["recuo_base_s"], rng=random.Random(seed + i))
            drivers.append(d)
            return d

        r = _clientes(naive, n, per)
        rows.append({"modo": "sem coordenação", "pedidos_uteis": n * per - r["falhas"], "pedidos_ao_servidor": srv.requests, "rejeitados_429": srv.rejected, "retentativas": sum(d.retried for d in drivers), **r})
        # (b) balde compartilhado num arquivo: cada cliente com a própria conexão
        srv = _Servidor(hip["servidor_rps"], hip["rajada"])
        drivers = []
        db = Path(tmp) / "lab.db"

        def limited(i: int) -> Any:
            d = _Driver(srv, retries=hip["tentativas"], base=hip["recuo_base_s"], rng=random.Random(seed + i))
            drivers.append(d)
            lim = RateLimiter(db, model="m", rpm=hip["rpm_do_balde"], itpm=10_000_000, otpm=1_000_000, output_reserve=1, burst_s=hip["rajada"] / hip["servidor_rps"])
            return Limited(d, lim)

        r = _clientes(limited, n, per)
        rows.append({"modo": "balde compartilhado", "pedidos_uteis": n * per - r["falhas"], "pedidos_ao_servidor": srv.requests, "rejeitados_429": srv.rejected, "retentativas": sum(d.retried for d in drivers), **r})

        # tempestade: o servidor cai por 0,6 s; os clientes insistem até conseguir ou até o prazo
        tempestade = []
        for modo in ("sem disjuntor", "com disjuntor"):
            tempestade.append(_tempestade(modo, n, seed))
    return _write("m2_balde_compartilhado", {"benchmark": "M2", "seed": seed, "hipoteses": hip, "rows": rows, "tempestade": tempestade}, out_dir)


# --------------------------------------------------------------------------
# M3 — gravar e reexecutar
# --------------------------------------------------------------------------


def _reg_grande(chars: int = 2700) -> Registry:
    r = Registry()

    @r.tool(risk="read")
    def ler(caminho: str) -> str:
        """Lê."""
        return "conteúdo " * (chars // 9)

    return r


def _script_ferramentas(n_calls: int, *, chars: int = 2700) -> Callable[[Request], Reply]:
    """Pede `n_calls` leituras (contadas no próprio roteiro: a compactação não o zera) e termina."""
    feitas = [0]

    def responde(req: Request) -> Reply:
        if req.metadata.get("role") == "compaction":
            return Reply.of_text("RESUMO: li arquivos; falta responder. " * (chars // 40), input_tokens=500, output_tokens=40)
        n = feitas[0]
        if n < n_calls:
            feitas[0] += 1
            return Reply.of_tools(("ler", {"caminho": f"a{n}"}), input_tokens=100 + 50 * n, output_tokens=10)
        return Reply.of_text("fim", input_tokens=100 + 50 * n, output_tokens=5)

    return responde


def bench_replay(seed: int, out_dir: str | None) -> str:
    voltas = 6
    with tempfile.TemporaryDirectory() as tmp:
        cas = Cassette(Path(tmp) / "c.jsonl")
        real = ScriptedProvider([_script_ferramentas(voltas)] * (voltas + 2), model="claude-opus-5")
        agent = Agent(provider=Recording(real, cas), instruction="Você lê arquivos.", toolset=_reg_grande())
        s1 = Seams("g")
        t0 = time.perf_counter()
        out1 = run(agent, "leia tudo", session="g", seams=s1)
        t_grav = time.perf_counter() - t0
        rep = Replay(Path(tmp) / "c.jsonl")
        agent2 = Agent(provider=rep, instruction="Você lê arquivos.", toolset=_reg_grande())
        s2 = Seams("g")
        t0 = time.perf_counter()
        out2 = run(agent2, "leia tudo", session="g", seams=s2)
        t_rep = time.perf_counter() - t0
        identico = out1.text == out2.text and out1.turns == out2.turns and out1.usage == out2.usage and s1.counts() == s2.counts()
        # deriva: um byte a mais na instrução
        rep2 = Replay(Path(tmp) / "c.jsonl")
        agent3 = Agent(provider=rep2, instruction="Você lê arquivos!", toolset=_reg_grande())
        out3 = run(agent3, "leia tudo", session="g")
        deriva = {"ok": out3.ok, "erro": out3.error[:120], "hits": rep2.cassette.hits, "misses": rep2.cassette.misses}
        # independência da ordem: 8 laços paralelos gravam; reexecução em ordem inversa
        cas2 = Cassette(Path(tmp) / "p.jsonl")
        lock = threading.Lock()

        def rollout(i: int) -> None:
            real_i = ScriptedProvider([_script_ferramentas(2)] * 4, model="claude-opus-5")

            class Serial:
                model, effort = "claude-opus-5", "high"

                def complete(self, req: Request) -> Reply:
                    with lock:
                        return real_i.complete(req)

            run(Agent(provider=Recording(Serial(), cas2), instruction=f"Perfil {i}.", toolset=_reg_grande()), "leia", session=f"r{i}")

        ts = [threading.Thread(target=rollout, args=(i,)) for i in range(8)]
        for t in ts:
            t.start()
        for t in ts:
            t.join()
        rep3 = Replay(Path(tmp) / "p.jsonl")
        oks = 0
        for i in reversed(range(8)):
            oks += run(Agent(provider=rep3, instruction=f"Perfil {i}.", toolset=_reg_grande()), "leia", session=f"r{i}").ok
        chamadas = rep.cassette.hits
        payload = {
            "benchmark": "M3", "seed": seed,
            "gravacao": {"voltas": out1.turns, "entradas": len(cas), "ms": round(t_grav * 1000, 1)},
            "reexecucao": {"identico": identico, "hits": chamadas, "misses": rep.cassette.misses, "ms": round(t_rep * 1000, 1), "us_por_chamada": round(t_rep / max(1, chamadas) * 1e6, 1)},
            "deriva": deriva,
            "paralelo": {"laços": 8, "entradas": len(cas2), "reexecutados_ok": oks, "hits": rep3.cassette.hits, "misses": rep3.cassette.misses},
        }
    return _write("m3_gravar_reexecutar", payload, out_dir)


# --------------------------------------------------------------------------
# M4 — a janela
# --------------------------------------------------------------------------


def bench_window(seed: int, out_dir: str | None) -> str:
    voltas = 80
    chars = 6000
    rows = []
    card = resolve("claude-opus-5")
    for ctx in (0, 20_000, 50_000, 100_000):
        roteiro = _script_ferramentas(voltas, chars=chars)
        prov = ScriptedProvider([roteiro] * (voltas * 2 + 4), model="claude-opus-5")
        w = Window(context=ctx, reserve=2_000, margin=0.0) if ctx else None
        agent = Agent(provider=prov, instruction="Você lê arquivos.", toolset=_reg_grande(chars), window=w, budget=Budget(max_turns=voltas * 2))
        seams = Seams("w")
        out = run(agent, "leia tudo", session="w", seams=seams)
        pedidos = [r for r in prov.requests if r.metadata.get("role") == "loop"]
        est = [estimate_request(r) for r in pedidos]
        resumos = [r for r in prov.requests if r.metadata.get("role") == "compaction"]
        est_resumo = sum(estimate_request(r) for r in resumos)
        total = sum(est) + est_resumo
        custo = total * card.price_in / 1e6
        acima = sum(1 for e in est if ctx and e > ctx - 2_000)
        rows.append({
            "janela": ctx or "sem janela", "voltas": out.turns, "compactacoes": len(resumos),
            "tokens_estimados_total": total, "tokens_max_por_pedido": max(est), "pedidos_acima_da_janela": acima,
            "custo_entrada_usd": round(custo, 4), "ok": out.ok,
        })
    return _write("m4_janela", {"benchmark": "M4", "seed": seed, "hipoteses": {"voltas": voltas, "resultado_de_ferramenta_chars": chars, "ratio_bytes_por_token": RATIO, "preco": "claude-opus-5 entrada", "resumo": f"roteirizado, ~{chars // 40 * 40} chars"}, "rows": rows}, out_dir)


# --------------------------------------------------------------------------
# M5 — estrutura com reparo
# --------------------------------------------------------------------------


def bench_extract(seed: int, out_dir: str | None) -> str:
    schema = {"type": "object", "properties": {"nome": {"type": "string"}, "idade": {"type": "integer", "minimum": 0}, "tags": {"type": "array", "items": {"type": "string"}}}, "required": ["nome", "idade"], "additionalProperties": False}
    bom = '```json\n{"nome": "Ana", "idade": 31, "tags": ["a"]}\n```'
    ruins = ['{"nome": "Ana", "idade": "31"}', 'texto sem json', '{"nome": "Ana"}', '{"nome": "Ana", "idade": 31, "extra": 1}', '{"nome": "Ana", "idade": -3}', '{"nome": "Ana", "idade": 31, "tags": "a"}']
    rows = []
    n = 500
    for p_ruim in (0.1, 0.3, 0.5):
        for repairs in (0, 1, 2, 3):
            rng = random.Random(seed * 100 + int(p_ruim * 10))

            def resposta(req: Request, _r: random.Random = rng, _p: float = p_ruim) -> Reply:
                return Reply.of_text(_r.choice(ruins) if _r.random() < _p else bom, input_tokens=50, output_tokens=20)

            sucesso = 0
            chamadas = 0
            for _ in range(n):
                prov = ScriptedProvider([resposta] * (repairs + 1))
                try:
                    extract(prov, schema, "Ana tem 31 anos", repairs=repairs)
                    sucesso += 1
                except ExtractionError:
                    pass
                chamadas += prov.calls
            rows.append({"p_ruim": p_ruim, "reparos": repairs, "sucesso": round(sucesso / n, 4), "chamadas_por_extracao": round(chamadas / n, 3), "esperado_sem_reparo": round(1 - p_ruim, 4), "esperado_teorico": round(1 - p_ruim ** (repairs + 1), 4)})
    return _write("m5_estrutura_com_reparo", {"benchmark": "M5", "seed": seed, "hipoteses": {"extracoes": n, "modelo": "responde JSON válido com prob. 1-p_ruim; senão um de 6 defeitos (tipo, ausente, extra, mínimo, sem JSON)"}, "rows": rows}, out_dir)


# --------------------------------------------------------------------------
# M6 — o juiz com posição balanceada
# --------------------------------------------------------------------------


def bench_judge(seed: int, out_dir: str | None) -> str:
    n = 400
    rows = []
    for q in (0.7, 0.85, 0.95):
        for b in (0.0, 0.2, 0.4, 0.6):
            for modo in ("única ordem", "balanceado"):
                rng = random.Random(seed * 31 + int(q * 100) + int(b * 10))
                erros = 0
                empates = 0
                chamadas = 0

                def juiz(req: Request, _r: random.Random = rng, _q: float = q, _b: float = b) -> Reply:
                    texto = req.messages[0]["content"][0]["text"]
                    a = texto.split("Resposta A:\n")[1].split("\n\nResposta B:")[0].strip()
                    if _r.random() < _b:
                        v = "A"  # viés de posição: a primeira
                    else:
                        melhor_e_a = a == "melhor"
                        certo = _r.random() < _q
                        v = ("A" if melhor_e_a else "B") if certo else ("B" if melhor_e_a else "A")
                    return Reply.of_text(json.dumps({"winner": v}), input_tokens=30, output_tokens=5)

                for i in range(n):
                    prov = ScriptedProvider([juiz, juiz])
                    melhor_primeiro = i % 2 == 0
                    a, c = ("melhor", "pior") if melhor_primeiro else ("pior", "melhor")
                    v = judge(prov, a, c, "qualidade", balanced=(modo == "balanceado"))
                    chamadas += prov.calls
                    esperado = "a" if melhor_primeiro else "b"
                    if v == "tie":
                        empates += 1
                    elif v != esperado:
                        erros += 1
                rows.append({"q": q, "vies": b, "modo": modo, "vereditos_errados": round(erros / n, 4), "empates": round(empates / n, 4), "chamadas_por_juizo": round(chamadas / n, 2)})
    return _write("m6_juiz_posicao_balanceada", {"benchmark": "M6", "seed": seed, "hipoteses": {"juizos": n, "modelo": "com prob. b escolhe a primeira posição; senão acerta o melhor com prob. q; o melhor vem em primeiro em metade dos juízos"}, "rows": rows}, out_dir)


# --------------------------------------------------------------------------
# M7 — prefixo estável e a economia do cache
# --------------------------------------------------------------------------


def bench_prefix(seed: int, out_dir: str | None) -> str:
    voltas = 30
    card = resolve("claude-opus-5")
    rows = []
    cenarios = {
        "estável": lambda i, sys_, tools: (sys_, tools),
        "timestamp no system": lambda i, sys_, tools: (sys_ + f"\nAgora: 2026-09-16T10:00:{i:02d}", tools),
        "ferramentas embaralhadas": lambda i, sys_, tools: (sys_, list(reversed(tools)) if i % 2 else tools),
    }
    base_system = "Você lê arquivos e responde. " * 80  # ~660 tokens estimados: acima do mínimo cacheável (512)
    for nome, muta in cenarios.items():
        audit = PrefixAudit()
        msgs: list[dict[str, Any]] = [{"role": "user", "content": "leia tudo"}]
        tools = [{"name": "ler", "description": "Lê.", "input_schema": {"type": "object"}}, {"name": "gravar", "description": "Grava.", "input_schema": {"type": "object"}}]
        tokens_full = 0.0
        tokens_cached = 0.0
        prefixo_anterior = 0
        for i in range(voltas):
            s, t = muta(i, base_system, tools)
            req = Request(system=[{"type": "text", "text": s, "cache_control": {"type": "ephemeral"}}], messages=list(msgs), tools=t)
            alarm = audit.observe(req)
            total = estimate_request(req)
            tokens_full += total
            if alarm is None and i > 0:
                # prefixo intacto: o que já foi enviado lê do cache; o novo escreve
                tokens_cached += prefixo_anterior * card.cache_read_mult + (total - prefixo_anterior) * card.cache_write_mult
            else:
                tokens_cached += total * card.cache_write_mult
            prefixo_anterior = total
            msgs = [*msgs, {"role": "assistant", "content": [{"type": "tool_use", "id": f"t{i}", "name": "ler", "input": {"caminho": f"a{i}"}}]}, {"role": "user", "content": [{"type": "tool_result", "tool_use_id": f"t{i}", "content": "conteúdo " * 100}]}]
        rel = audit.report()
        primeiro = rel["alarms"][0] if rel["alarms"] else None
        rows.append({
            "cenario": nome, "voltas": voltas, "alarmes": len(rel["alarms"]),
            "primeiro_alarme": f"volta {primeiro['turn']}, {primeiro['part']}, byte {primeiro['offset']}" if primeiro else "-",
            "custo_sem_cache_usd": round(tokens_full * card.price_in / 1e6, 4),
            "custo_com_cache_usd": round(tokens_cached * card.price_in / 1e6, 4),
            "economia": round(1 - tokens_cached / tokens_full, 3) if tokens_full else 0.0,
            "system_acima_do_minimo": estimate_request(Request(system=[{"type": "text", "text": base_system}], messages=[])) >= card.cache_min_tokens,
        })
    return _write("m7_prefixo_e_cache", {"benchmark": "M7", "seed": seed, "hipoteses": {"voltas": voltas, "ratio_bytes_por_token": RATIO, "preco": "claude-opus-5: escrita 1,25x, leitura 0,1x", "modelo_de_cache": "prefixo intacto lê tudo o que já foi enviado a 0,1x e escreve o novo a 1,25x; prefixo quebrado reescreve tudo"}, "rows": rows}, out_dir)


BENCHMARKS: dict[str, Callable[[int, str | None], str]] = {
    "m1": bench_cascade,
    "m2": bench_limits,
    "m3": bench_replay,
    "m4": bench_window,
    "m5": bench_extract,
    "m6": bench_judge,
    "m7": bench_prefix,
}


def run_benchmark(name: str, *, seed: int = 0, out_dir: str | None = None) -> str:
    key = name.lower()
    if key not in BENCHMARKS:
        raise KeyError(f"benchmark desconhecido: {name!r}; opções: {sorted(BENCHMARKS)}")
    return BENCHMARKS[key](seed, out_dir)
