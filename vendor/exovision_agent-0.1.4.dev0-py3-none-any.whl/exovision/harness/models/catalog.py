"""O catálogo: o que cada modelo pode, quanto custa, e onde o cache começa a valer.

Um kernel que escalona o acesso ao modelo precisa saber a janela
(`max_input_tokens`), o teto de saída, os preços por milhão de tokens (com os
multiplicadores de escrita e leitura de cache), o **mínimo cacheável** (abaixo
dele o breakpoint é ignorado em silêncio), os níveis de esforço e o regime de
pensamento. A tabela embarcada é o valor de partida — verificada na data que
cada cartão traz; a Models API é a fonte quando há rede (`refresh`).

Preços são tabela informativa: o valor cobrado é o da fatura. Modelos de
outros provedores entram sem preço e sem janela (zeros) até o operador
registrar (`register` / `load` de um JSON): o kernel não inventa números.
"""

from __future__ import annotations

import json
from dataclasses import asdict, dataclass, replace
from pathlib import Path
from typing import Any

__all__ = [
    "ALIASES",
    "CATALOG",
    "PRICES_USD_PER_MTOK",
    "ModelCard",
    "cards",
    "estimate_cost_usd",
    "load",
    "refresh",
    "register",
    "resolve",
]

EFFORTS_FIVE = ("low", "medium", "high", "xhigh", "max")
EFFORTS_FOUR = ("low", "medium", "high", "max")


@dataclass(frozen=True, slots=True)
class ModelCard:
    """O cartão de um modelo. Zeros significam *desconhecido*, nunca "grátis"."""

    id: str
    provider: str = "anthropic"
    family: str = ""
    context: int = 0  # max_input_tokens
    max_output: int = 0
    price_in: float = 0.0  # USD por milhão de tokens de entrada
    price_out: float = 0.0
    cache_write_mult: float = 1.25
    cache_read_mult: float = 0.1
    cache_min_tokens: int = 0
    efforts: tuple[str, ...] = ()
    thinking: str = ""  # adaptive | budget | none | ""
    tools: bool = True
    vision: bool = True
    aliases: tuple[str, ...] = ()
    verified: str = ""  # data da verificação da tabela
    note: str = ""

    @property
    def known(self) -> bool:
        return self.context > 0

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)

    @classmethod
    def from_dict(cls, d: dict[str, Any]) -> ModelCard:
        kw = {k: v for k, v in d.items() if k in cls.__dataclass_fields__}
        for tk in ("efforts", "aliases"):
            if tk in kw:
                kw[tk] = tuple(kw[tk])
        return cls(**kw)


_V = "2026-09-16"


def _claude(
    id: str,
    family: str,
    price_in: float,
    price_out: float,
    *,
    context: int = 1_000_000,
    max_output: int = 128_000,
    cache_min: int,
    efforts: tuple[str, ...] = EFFORTS_FIVE,
    thinking: str = "adaptive",
    cache_read_mult: float = 0.1,
    aliases: tuple[str, ...] = (),
    note: str = "",
) -> ModelCard:
    return ModelCard(
        id=id,
        provider="anthropic",
        family=family,
        context=context,
        max_output=max_output,
        price_in=price_in,
        price_out=price_out,
        cache_read_mult=cache_read_mult,
        cache_min_tokens=cache_min,
        efforts=efforts,
        thinking=thinking,
        aliases=aliases,
        verified=_V,
        note=note,
    )


#: Verificado em 2026-09-16 contra a documentação da Claude Platform (preços,
#: janelas, tetos de saída, mínimos cacheáveis, níveis de esforço).
CATALOG: dict[str, ModelCard] = {
    c.id: c
    for c in (
        _claude(
            "claude-fable-5-1", "fable", 10.0, 50.0, cache_min=512, cache_read_mult=0.025,
            aliases=("fable",), note="pensamento sempre ligado; tool_choice forçado é 400",
        ),
        _claude("claude-fable-5", "fable", 10.0, 50.0, cache_min=512),
        _claude("claude-opus-5", "opus", 5.0, 25.0, cache_min=512, aliases=("opus",)),
        _claude("claude-opus-4-8", "opus", 5.0, 25.0, cache_min=1024),
        _claude("claude-opus-4-7", "opus", 5.0, 25.0, cache_min=2048),
        _claude("claude-opus-4-6", "opus", 5.0, 25.0, cache_min=4096, efforts=EFFORTS_FOUR),
        _claude("claude-sonnet-5", "sonnet", 2.0, 10.0, cache_min=1024, aliases=("sonnet",)),
        _claude("claude-sonnet-4-6", "sonnet", 3.0, 15.0, cache_min=1024, efforts=EFFORTS_FOUR),
        _claude(
            "claude-haiku-4-5", "haiku", 1.0, 5.0, context=200_000, max_output=64_000,
            cache_min=4096, efforts=(), thinking="budget", aliases=("haiku",),
        ),
    )
}

ALIASES: dict[str, str] = {a: c.id for c in CATALOG.values() for a in c.aliases}

#: Vista `{id: (entrada, saída)}` do catálogo — compatibilidade com quem só quer preço.
PRICES_USD_PER_MTOK: dict[str, tuple[float, float]] = {
    c.id: (c.price_in, c.price_out) for c in CATALOG.values()
}


def register(card: ModelCard) -> ModelCard:
    """Registra (ou substitui) um cartão; apelidos entram junto."""
    CATALOG[card.id] = card
    PRICES_USD_PER_MTOK[card.id] = (card.price_in, card.price_out)
    for a in card.aliases:
        ALIASES[a] = card.id
    return card


def load(path: str | Path) -> int:
    """Carrega cartões de um JSON (lista de dicts ou dict id -> dict). Devolve quantos."""
    data = json.loads(Path(path).read_text(encoding="utf-8"))
    items = data.values() if isinstance(data, dict) else data
    n = 0
    for d in items:
        register(ModelCard.from_dict(dict(d)))
        n += 1
    return n


def resolve(name: str, *, provider: str = "") -> ModelCard:
    """`opus` -> claude-opus-5; id conhecido -> o cartão; desconhecido -> cartão com zeros."""
    key = ALIASES.get(name, name)
    card = CATALOG.get(key)
    if card is not None:
        return card
    guess = provider or ("anthropic" if key.startswith("claude-") else "")
    return ModelCard(id=key, provider=guess, note="fora do catálogo: janela e preço desconhecidos")


def cards(provider: str = "") -> list[ModelCard]:
    return [c for c in CATALOG.values() if not provider or c.provider == provider]


def refresh(client: Any, ids: list[str] | None = None) -> list[str]:
    """Atualiza janela e teto de saída pela Models API (`client.models.retrieve`).

    Só toca o que a API devolve (`max_input_tokens`, `max_tokens`); preços e
    mínimos cacheáveis continuam da tabela. Devolve os ids atualizados.
    """
    done: list[str] = []
    for mid in ids or [c.id for c in cards("anthropic")]:
        try:
            m = client.models.retrieve(mid)
        except Exception:
            continue
        ctx = int(getattr(m, "max_input_tokens", 0) or 0)
        out = int(getattr(m, "max_tokens", 0) or 0)
        base = CATALOG.get(mid) or ModelCard(id=mid)
        register(replace(base, context=ctx or base.context, max_output=out or base.max_output))
        done.append(mid)
    return done


def estimate_cost_usd(model: str, usage: dict[str, int], *, discount: float = 1.0) -> float:
    """Custo estimado de um `usage` para o modelo, pela tabela.

    `discount` é o multiplicador do regime de cobrança: `1.0` na Messages API
    síncrona e `0.5` na Message Batches API. Quem informa é o provedor
    (`Provider.cost_discount`), porque é ele que sabe em que regime a chamada
    foi feita. Modelo fora do catálogo custa 0 — desconhecido, não grátis; o
    livro-razão marca isso.
    """
    card = resolve(model)
    if not card.known and card.price_in == 0.0 and card.price_out == 0.0:
        return 0.0
    return (
        discount
        * (
            usage.get("input_tokens", 0) * card.price_in
            + usage.get("cache_creation_input_tokens", 0) * card.price_in * card.cache_write_mult
            + usage.get("cache_read_input_tokens", 0) * card.price_in * card.cache_read_mult
            + usage.get("output_tokens", 0) * card.price_out
        )
        / 1_000_000
    )

