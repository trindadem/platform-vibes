"""Tradução do formato de fio: o laço fala Messages API; os outros dispositivos, não.

O kernel tem **um** formato interno — blocos da Messages API (`text`,
`tool_use`, `tool_result`, `thinking`, `image`) — porque é o que o laço, o
journal, o cassete e o traço guardam. Um driver de outro provedor traduz na
ida e na volta, e a tradução é **pura** (funções sem rede), o que a torna
testável byte a byte.

O que se perde, e está dito aqui em vez de descoberto em produção:

- `thinking`/`redacted_thinking`/`compaction` do histórico não têm equivalente
  fora da Anthropic: são descartados na ida. Um raciocínio que outro servidor
  devolva (`reasoning_content`, partes `thought`) vira bloco `thinking` sem
  assinatura — legível no traço, descartado se voltar.
- `cache_control` não existe fora: é removido (o cache de prefixo, quando há,
  é automático do lado deles).
- Ferramentas definidas pela Anthropic (`bash_20250124`,
  `text_editor_20250728`) vão **sem schema** para a Anthropic, porque o modelo
  foi treinado nelas. Outro modelo não foi: `PORTABLE_SCHEMAS` dá a cada uma um
  schema e uma descrição explícitos, e é isso que vai.
- `document` (PDF) não é traduzido: vira um marcador de texto. Imagens base64
  vão.
- O Gemini não tem mensagem `system` no meio da conversa: uma `role: system`
  intermediária vira parte de usuário marcada `[instrução do operador]`.
- A OpenAI atual recusa `reasoning_effort` junto com ferramentas em Chat
  Completions ("use /v1/responses"): o driver OpenAI fala a **Responses
  API**. O item `reasoning` (cifrado, `store: false` +
  `include: ["reasoning.encrypted_content"]`) volta ao histórico dentro do
  bloco `thinking` (`openai_reasoning`) e é ecoado intacto na volta seguinte
  — a versão deles do pensamento preservado; sem ele a conversa também
  segue (verificado ao vivo em 2026-09-17).
"""

from __future__ import annotations

import json
from typing import Any

from .provider import Reply, Request

__all__ = [
    "PORTABLE_SCHEMAS",
    "from_gemini",
    "from_openai",
    "from_responses",
    "to_gemini",
    "to_openai",
    "to_responses",
]

#: Schemas explícitos para as ferramentas que a Anthropic define sem schema.
PORTABLE_SCHEMAS: dict[str, dict[str, Any]] = {
    "bash_20250124": {
        "description": "Executa um comando no shell do workspace e devolve stdout/stderr. Use `restart: true` para reiniciar a sessão do shell.",
        "input_schema": {
            "type": "object",
            "properties": {
                "command": {"type": "string", "description": "o comando a executar"},
                "restart": {"type": "boolean", "description": "reinicia o shell"},
            },
        },
    },
    "text_editor_20250728": {
        "description": "Lê e edita arquivos do workspace. Comandos: view (path, view_range opcional), create (path, file_text), str_replace (path, old_str, new_str), insert (path, insert_line, new_str).",
        "input_schema": {
            "type": "object",
            "properties": {
                "command": {"type": "string", "enum": ["view", "create", "str_replace", "insert"]},
                "path": {"type": "string"},
                "file_text": {"type": "string"},
                "old_str": {"type": "string"},
                "new_str": {"type": "string"},
                "insert_line": {"type": "integer"},
                "view_range": {"type": "array", "items": {"type": "integer"}},
            },
            "required": ["command", "path"],
        },
    },
}


def _text_of(content: Any) -> str:
    if isinstance(content, str):
        return content
    if isinstance(content, list):
        return "\n".join(str(b.get("text", "")) for b in content if isinstance(b, dict) and b.get("type") == "text")
    return str(content)


def _blocks(content: Any) -> list[dict[str, Any]]:
    if isinstance(content, str):
        return [{"type": "text", "text": content}]
    return [b for b in content if isinstance(b, dict)]


def _result_text(block: dict[str, Any]) -> str:
    c = block.get("content", "")
    if isinstance(c, list):
        return "\n".join(str(b.get("text", "")) for b in c if isinstance(b, dict) and b.get("type") == "text")
    return str(c)


def _function_tools(tools: list[dict[str, Any]]) -> list[tuple[str, str, dict[str, Any], bool]]:
    """(nome, descrição, schema, strict) de cada ferramenta traduzível."""
    out: list[tuple[str, str, dict[str, Any], bool]] = []
    for t in tools:
        name = str(t.get("name", ""))
        if not name:
            continue
        schema = t.get("input_schema")
        desc = str(t.get("description", ""))
        if schema is None:
            portable = PORTABLE_SCHEMAS.get(str(t.get("type", "")))
            if portable is None:
                continue  # ferramenta de servidor da Anthropic: não existe fora
            schema = portable["input_schema"]
            desc = desc or portable["description"]
        out.append((name, desc, dict(schema), bool(t.get("strict", False))))
    return out


# --------------------------------------------------------------------------
# OpenAI Chat Completions (e servidores compatíveis)
# --------------------------------------------------------------------------


def to_openai(request: Request, *, model: str, max_tokens: int, max_tokens_field: str = "max_completion_tokens", reasoning_effort: str = "") -> dict[str, Any]:
    """Corpo de `POST /v1/chat/completions` a partir de um `Request`."""
    messages: list[dict[str, Any]] = []
    system = _text_of(request.system)
    if system:
        messages.append({"role": "system", "content": system})
    for m in request.messages:
        role = m.get("role")
        blocks = _blocks(m.get("content", ""))
        if role == "user":
            results = [b for b in blocks if b.get("type") == "tool_result"]
            for r in results:
                messages.append({"role": "tool", "tool_call_id": str(r.get("tool_use_id", "")), "content": _result_text(r)})
            parts: list[dict[str, Any]] = []
            for b in blocks:
                if b.get("type") == "text":
                    parts.append({"type": "text", "text": str(b.get("text", ""))})
                elif b.get("type") == "image" and isinstance(b.get("source"), dict) and b["source"].get("type") == "base64":
                    src = b["source"]
                    parts.append({"type": "image_url", "image_url": {"url": f"data:{src.get('media_type', 'image/png')};base64,{src.get('data', '')}"}})
                elif b.get("type") == "document":
                    parts.append({"type": "text", "text": "[documento omitido na tradução]"})
            if parts:
                if len(parts) == 1 and parts[0]["type"] == "text":
                    messages.append({"role": "user", "content": parts[0]["text"]})
                else:
                    messages.append({"role": "user", "content": parts})
        elif role == "assistant":
            text = "\n".join(str(b.get("text", "")) for b in blocks if b.get("type") == "text")
            calls = [
                {
                    "id": str(b.get("id", "")),
                    "type": "function",
                    "function": {"name": str(b.get("name", "")), "arguments": json.dumps(b.get("input") or {}, ensure_ascii=False)},
                }
                for b in blocks
                if b.get("type") == "tool_use"
            ]
            msg: dict[str, Any] = {"role": "assistant", "content": text or None}
            if calls:
                msg["tool_calls"] = calls
            messages.append(msg)
        elif role == "system":
            messages.append({"role": "system", "content": _text_of(m.get("content", ""))})
    body: dict[str, Any] = {"model": model, "messages": messages, max_tokens_field: max_tokens}
    tools = [
        {"type": "function", "function": {"name": n, "description": d, "parameters": s, **({"strict": True} if strict else {})}}
        for n, d, s, strict in _function_tools(request.tools)
    ]
    if tools:
        body["tools"] = tools
    if reasoning_effort:
        body["reasoning_effort"] = reasoning_effort
    return body


_OPENAI_STOP = {"stop": "end_turn", "length": "max_tokens", "tool_calls": "tool_use", "function_call": "tool_use", "content_filter": "refusal"}


def from_openai(data: dict[str, Any]) -> Reply:
    """`Reply` a partir da resposta de Chat Completions."""
    choices = data.get("choices") or []
    if not choices:
        return Reply(content=[], stop_reason="end_turn", model=str(data.get("model", "")), request_id=str(data.get("id", "")))
    choice = choices[0]
    msg = choice.get("message") or {}
    content: list[dict[str, Any]] = []
    reasoning = msg.get("reasoning_content") or msg.get("reasoning")
    if reasoning:
        content.append({"type": "thinking", "thinking": str(reasoning)})
    raw = msg.get("content")
    if isinstance(raw, list):
        raw = "\n".join(str(p.get("text", "")) for p in raw if isinstance(p, dict))
    if raw:
        content.append({"type": "text", "text": str(raw)})
    for i, call in enumerate(msg.get("tool_calls") or []):
        fn = call.get("function") or {}
        args_raw = fn.get("arguments")
        if isinstance(args_raw, str):
            try:
                args = json.loads(args_raw) if args_raw.strip() else {}
            except json.JSONDecodeError:
                args = {"_raw": args_raw}
        else:
            args = dict(args_raw or {})
        content.append({"type": "tool_use", "id": str(call.get("id") or f"call_{i}"), "name": str(fn.get("name", "")), "input": args})
    finish = str(choice.get("finish_reason") or "stop")
    stop = _OPENAI_STOP.get(finish, "end_turn")
    if any(b["type"] == "tool_use" for b in content) and stop == "end_turn":
        stop = "tool_use"
    usage_raw = data.get("usage") or {}
    cached = int((usage_raw.get("prompt_tokens_details") or {}).get("cached_tokens", 0) or 0)
    usage = {
        "input_tokens": max(0, int(usage_raw.get("prompt_tokens", 0) or 0) - cached),
        "output_tokens": int(usage_raw.get("completion_tokens", 0) or 0),
    }
    if cached:
        usage["cache_read_input_tokens"] = cached
    reasoning_tokens = int((usage_raw.get("completion_tokens_details") or {}).get("reasoning_tokens", 0) or 0)
    if reasoning_tokens:
        usage["reasoning_tokens"] = reasoning_tokens
    stop_details = {"type": "refusal", "category": finish} if stop == "refusal" else None
    return Reply(content=content, stop_reason=stop, usage=usage, model=str(data.get("model", "")), stop_details=stop_details, request_id=str(data.get("id", "")))


# --------------------------------------------------------------------------
# OpenAI Responses API
# --------------------------------------------------------------------------


def to_responses(request: Request, *, model: str, max_tokens: int, reasoning_effort: str = "", store: bool = False) -> dict[str, Any]:
    """Corpo de `POST /v1/responses` a partir de um `Request` (forma observada ao vivo)."""
    items: list[dict[str, Any]] = []
    for m in request.messages:
        role = m.get("role")
        blocks = _blocks(m.get("content", ""))
        if role == "user":
            parts: list[dict[str, Any]] = []
            for b in blocks:
                t = b.get("type")
                if t == "tool_result":
                    if parts:
                        items.append({"role": "user", "content": parts})
                        parts = []
                    items.append({"type": "function_call_output", "call_id": str(b.get("tool_use_id", "")), "output": _result_text(b)})
                elif t == "text":
                    parts.append({"type": "input_text", "text": str(b.get("text", ""))})
                elif t == "image" and isinstance(b.get("source"), dict) and b["source"].get("type") == "base64":
                    src = b["source"]
                    parts.append({"type": "input_image", "image_url": f"data:{src.get('media_type', 'image/png')};base64,{src.get('data', '')}"})
                elif t == "document":
                    parts.append({"type": "input_text", "text": "[documento omitido na tradução]"})
            if parts:
                items.append({"role": "user", "content": parts})
        elif role == "assistant":
            for b in blocks:
                t = b.get("type")
                if t == "thinking" and isinstance(b.get("openai_reasoning"), dict):
                    items.append(dict(b["openai_reasoning"]))
                elif t == "text" and b.get("text"):
                    items.append({"role": "assistant", "content": [{"type": "output_text", "text": str(b["text"])}]})
                elif t == "tool_use":
                    items.append({"type": "function_call", "call_id": str(b.get("id", "")), "name": str(b.get("name", "")), "arguments": json.dumps(b.get("input") or {}, ensure_ascii=False)})
        elif role == "system":
            items.append({"role": "developer", "content": [{"type": "input_text", "text": _text_of(m.get("content", ""))}]})
    body: dict[str, Any] = {"model": model, "input": items, "max_output_tokens": max_tokens, "store": store}
    if not store:
        body["include"] = ["reasoning.encrypted_content"]
    system = _text_of(request.system)
    if system:
        body["instructions"] = system
    tools = [
        {"type": "function", "name": n, "description": d, "parameters": s, "strict": strict}
        for n, d, s, strict in _function_tools(request.tools)
    ]
    if tools:
        body["tools"] = tools
    if reasoning_effort:
        body["reasoning"] = {"effort": reasoning_effort}
    return body


def from_responses(data: dict[str, Any]) -> Reply:
    """`Reply` a partir da resposta de `/v1/responses`."""
    content: list[dict[str, Any]] = []
    refusal = False
    for item in data.get("output") or []:
        t = item.get("type")
        if t == "reasoning":
            resumo = "\n".join(str(p.get("text", "")) for p in item.get("summary") or [] if isinstance(p, dict))
            eco = {k: item[k] for k in ("type", "id", "summary", "encrypted_content") if k in item}
            content.append({"type": "thinking", "thinking": resumo, "openai_reasoning": eco})
        elif t == "message":
            for part in item.get("content") or []:
                if part.get("type") == "output_text":
                    content.append({"type": "text", "text": str(part.get("text", ""))})
                elif part.get("type") == "refusal":
                    refusal = True
                    content.append({"type": "text", "text": str(part.get("refusal", ""))})
        elif t == "function_call":
            raw = item.get("arguments")
            try:
                args = json.loads(raw) if isinstance(raw, str) and raw.strip() else dict(raw or {})
            except json.JSONDecodeError:
                args = {"_raw": raw}
            content.append({"type": "tool_use", "id": str(item.get("call_id") or item.get("id") or ""), "name": str(item.get("name", "")), "input": args})
    status = str(data.get("status") or "completed")
    motivo = str((data.get("incomplete_details") or {}).get("reason") or "")
    if refusal:
        stop = "refusal"
    elif status == "incomplete" and motivo == "max_output_tokens":
        stop = "max_tokens"
    elif any(b["type"] == "tool_use" for b in content):
        stop = "tool_use"
    else:
        stop = "end_turn"
    u = data.get("usage") or {}
    cached = int((u.get("input_tokens_details") or {}).get("cached_tokens", 0) or 0)
    escrita = int((u.get("input_tokens_details") or {}).get("cache_write_tokens", 0) or 0)
    usage = {"input_tokens": max(0, int(u.get("input_tokens", 0) or 0) - cached), "output_tokens": int(u.get("output_tokens", 0) or 0)}
    if cached:
        usage["cache_read_input_tokens"] = cached
    if escrita:
        usage["cache_creation_input_tokens"] = escrita
    reasoning_tokens = int((u.get("output_tokens_details") or {}).get("reasoning_tokens", 0) or 0)
    if reasoning_tokens:
        usage["reasoning_tokens"] = reasoning_tokens
    stop_details = {"type": "refusal", "category": "refusal"} if refusal else None
    return Reply(content=content, stop_reason=stop, usage=usage, model=str(data.get("model", "")), stop_details=stop_details, request_id=str(data.get("id", "")))


# --------------------------------------------------------------------------
# Google Gemini generateContent
# --------------------------------------------------------------------------

_GEMINI_SCHEMA_KEYS = frozenset({
    "type", "properties", "required", "enum", "items", "description", "format",
    "minimum", "maximum", "minItems", "maxItems", "nullable", "anyOf", "pattern",
    "minLength", "maxLength",
})


def _gemini_schema(schema: Any) -> Any:
    if isinstance(schema, dict):
        out: dict[str, Any] = {}
        for k, v in schema.items():
            if k not in _GEMINI_SCHEMA_KEYS:
                continue
            if k in ("properties",) and isinstance(v, dict):
                out[k] = {pk: _gemini_schema(pv) for pk, pv in v.items()}
            elif k in ("items",):
                out[k] = _gemini_schema(v)
            elif k == "anyOf" and isinstance(v, list):
                out[k] = [_gemini_schema(x) for x in v]
            elif k == "type" and isinstance(v, list):
                tipos = [t for t in v if t != "null"]
                out[k] = tipos[0] if tipos else "string"
                if "null" in v:
                    out["nullable"] = True
            else:
                out[k] = v
        return out
    return schema


def to_gemini(request: Request, *, max_tokens: int, thinking_config: dict[str, Any] | None = None) -> dict[str, Any]:
    """Corpo de `models/{model}:generateContent` a partir de um `Request`."""
    names: dict[str, str] = {}
    for m in request.messages:
        if m.get("role") == "assistant":
            for b in _blocks(m.get("content", "")):
                if b.get("type") == "tool_use":
                    names[str(b.get("id", ""))] = str(b.get("name", ""))
    contents: list[dict[str, Any]] = []
    for m in request.messages:
        role = m.get("role")
        blocks = _blocks(m.get("content", ""))
        parts: list[dict[str, Any]] = []
        if role == "user":
            for b in blocks:
                t = b.get("type")
                if t == "text":
                    parts.append({"text": str(b.get("text", ""))})
                elif t == "tool_result":
                    tid = str(b.get("tool_use_id", ""))
                    parts.append({"functionResponse": {"name": names.get(tid, tid), "id": tid, "response": {"result": _result_text(b)}}})
                elif t == "image" and isinstance(b.get("source"), dict) and b["source"].get("type") == "base64":
                    parts.append({"inlineData": {"mimeType": b["source"].get("media_type", "image/png"), "data": b["source"].get("data", "")}})
                elif t == "document":
                    parts.append({"text": "[documento omitido na tradução]"})
            contents.append({"role": "user", "parts": parts})
        elif role == "assistant":
            for b in blocks:
                t = b.get("type")
                if t == "text" and b.get("text"):
                    parts.append({"text": str(b["text"])})
                elif t == "tool_use":
                    parts.append({"functionCall": {"name": str(b.get("name", "")), "args": dict(b.get("input") or {}), "id": str(b.get("id", ""))}})
            contents.append({"role": "model", "parts": parts or [{"text": ""}]})
        elif role == "system":
            contents.append({"role": "user", "parts": [{"text": "[instrução do operador] " + _text_of(m.get("content", ""))}]})
    body: dict[str, Any] = {"contents": contents, "generationConfig": {"maxOutputTokens": max_tokens}}
    if thinking_config:
        body["generationConfig"]["thinkingConfig"] = dict(thinking_config)
    system = _text_of(request.system)
    if system:
        body["systemInstruction"] = {"parts": [{"text": system}]}
    decls = [{"name": n, "description": d, "parameters": _gemini_schema(s)} for n, d, s, _ in _function_tools(request.tools)]
    if decls:
        body["tools"] = [{"functionDeclarations": decls}]
    return body


_GEMINI_REFUSAL = {"SAFETY", "BLOCKED_SAFETY", "RECITATION", "PROHIBITED_CONTENT", "SPII", "BLOCKLIST"}


def from_gemini(data: dict[str, Any]) -> Reply:
    """`Reply` a partir da resposta de generateContent."""
    model = str(data.get("modelVersion", ""))
    rid = str(data.get("responseId", ""))
    usage_raw = data.get("usageMetadata") or {}
    cached = int(usage_raw.get("cachedContentTokenCount", 0) or 0)
    thoughts = int(usage_raw.get("thoughtsTokenCount", 0) or 0)
    usage = {
        "input_tokens": max(0, int(usage_raw.get("promptTokenCount", 0) or 0) - cached),
        "output_tokens": int(usage_raw.get("candidatesTokenCount", 0) or 0) + thoughts,
    }
    if cached:
        usage["cache_read_input_tokens"] = cached
    if thoughts:
        usage["reasoning_tokens"] = thoughts
    block = (data.get("promptFeedback") or {}).get("blockReason")
    if block:
        return Reply(content=[], stop_reason="refusal", usage=usage, model=model, stop_details={"type": "refusal", "category": str(block)}, request_id=rid)
    cands = data.get("candidates") or []
    if not cands:
        return Reply(content=[], stop_reason="end_turn", usage=usage, model=model, request_id=rid)
    cand = cands[0]
    content: list[dict[str, Any]] = []
    n = 0
    for part in (cand.get("content") or {}).get("parts") or []:
        if "functionCall" in part:
            fc = part["functionCall"] or {}
            n += 1
            content.append({"type": "tool_use", "id": str(fc.get("id") or f"toolu_g{n:04d}"), "name": str(fc.get("name", "")), "input": dict(fc.get("args") or {})})
        elif "text" in part:
            if part.get("thought"):
                content.append({"type": "thinking", "thinking": str(part.get("text", ""))})
            else:
                content.append({"type": "text", "text": str(part.get("text", ""))})
    finish = str(cand.get("finishReason") or "STOP")
    if finish in _GEMINI_REFUSAL:
        stop = "refusal"
    elif finish == "MAX_TOKENS":
        stop = "max_tokens"
    elif any(b["type"] == "tool_use" for b in content):
        stop = "tool_use"
    else:
        stop = "end_turn"
    stop_details = {"type": "refusal", "category": finish} if stop == "refusal" else None
    return Reply(content=content, stop_reason=stop, usage=usage, model=model, stop_details=stop_details, request_id=rid)
