"""EXOVISION-I · harness.models — o subsistema do kernel que toca o modelo.

Num sistema operacional de agentes o modelo é a CPU; este módulo é o que o
kernel põe entre os agentes e ela (decorre de `docs/modelos-estudo.md`):

    provider   o driver Anthropic (SDK oficial) e o roteirizado; o formato de fio
    drivers    OpenAI, servidores compatíveis (locais ou remotos) e Google, em stdlib
    wire       a tradução pura Messages API <-> Chat Completions / generateContent
    catalog    cartões: janela, teto, preços, mínimo cacheável, esforço; apelidos
    engine     primitivas: ask, extract (schema + reparo), classify, judge (posição
               balanceada), rank
    replay     cassete por digest: gravar uma vez, reexecutar sempre igual
    limits     balde de fichas compartilhado num arquivo (rpm/itpm/otpm), disjuntor
    ledger     livro-razão durável: uma linha por chamada, custo por tarefa
    window     estimativa de tokens, compactação simples, auditoria de prefixo
    router     por papel, por verificador (cascata), por falha (fallback)

Tudo é `Provider` ou decorador de `Provider`; o laço não muda de forma:

    from exovision.harness.models import make_provider, stack, Ledger, RateLimiter, Cassette, Window
    prov = stack(make_provider("anthropic:claude-opus-5"),
                 limiter=RateLimiter("lab.db", model="claude-opus-5", rpm=1000, itpm=2_000_000, otpm=400_000),
                 cassette=Cassette("bench.jsonl"), ledger=Ledger("lab.db"))
    agent = Agent(provider=prov, window=Window(context=1_000_000), ...)

`make_provider("openai:gpt-5")`, `"google:gemini-2.5-pro"`, `"local:llama3.1"`,
`"compatible:qwen@http://host:8000/v1"` — ou só `"opus"`. A credencial vem do
ambiente; o modelo, da especificação.
"""

from __future__ import annotations

import os

from .catalog import (
    ALIASES,
    CATALOG,
    PRICES_USD_PER_MTOK,
    ModelCard,
    cards,
    estimate_cost_usd,
    load,
    refresh,
    register,
    resolve,
)
from .drivers import GoogleProvider, LocalProvider, OpenAICompatibleProvider, OpenAIProvider
from .engine import (
    ExtractionError,
    LLMUsage,
    ask,
    classify,
    extract,
    extract_json,
    judge,
    parse_json_list,
    parse_ranking,
    rank,
    validate,
)
from .ledger import Ledger, Ledgered
from .limits import Breaker, Limited, RateLimiter, TokenBucket
from .provider import (
    EFFORT,
    MAX_TOKENS,
    MODEL,
    AnthropicProvider,
    Provider,
    ProviderError,
    Reply,
    Request,
    ScriptedProvider,
    ToolUse,
)
from .replay import Cassette, Recording, Replay, canonical, redact, request_digest
from .router import Cascade, Fallback, Router
from .window import (
    RATIO,
    Alarm,
    Compaction,
    PrefixAudit,
    Window,
    compact,
    estimate_request,
    estimate_tokens,
)
from .wire import (
    PORTABLE_SCHEMAS,
    from_gemini,
    from_openai,
    from_responses,
    to_gemini,
    to_openai,
    to_responses,
)

__all__ = [
    "ALIASES",
    "CATALOG",
    "EFFORT",
    "KINDS",
    "MAX_TOKENS",
    "MODEL",
    "PORTABLE_SCHEMAS",
    "PRICES_USD_PER_MTOK",
    "RATIO",
    "Alarm",
    "AnthropicProvider",
    "Breaker",
    "Cascade",
    "Cassette",
    "Compaction",
    "ExtractionError",
    "Fallback",
    "GoogleProvider",
    "LLMUsage",
    "Ledger",
    "Ledgered",
    "Limited",
    "LocalProvider",
    "ModelCard",
    "OpenAICompatibleProvider",
    "OpenAIProvider",
    "PrefixAudit",
    "Provider",
    "ProviderError",
    "RateLimiter",
    "Recording",
    "Replay",
    "Reply",
    "Request",
    "Router",
    "ScriptedProvider",
    "TokenBucket",
    "ToolUse",
    "Window",
    "ask",
    "canonical",
    "cards",
    "classify",
    "compact",
    "estimate_cost_usd",
    "estimate_request",
    "estimate_tokens",
    "extract",
    "extract_json",
    "from_gemini",
    "from_openai",
    "from_responses",
    "judge",
    "load",
    "make_provider",
    "parse_json_list",
    "parse_ranking",
    "provider_from_env",
    "rank",
    "redact",
    "refresh",
    "register",
    "request_digest",
    "resolve",
    "stack",
    "to_gemini",
    "to_openai",
    "to_responses",
    "validate",
]

KINDS = ("anthropic", "openai", "google", "local", "compatible")


def parse_spec(spec: str) -> tuple[str, str, str]:
    """`"openai:gpt-5"` -> ("openai", "gpt-5", ""); `"compatible:m@http://h/v1"` -> (…, url); `"opus"` -> ("", "claude-opus-5", "")."""
    kind, model, url = "", spec.strip(), ""
    if ":" in model and model.split(":", 1)[0] in KINDS:
        kind, model = model.split(":", 1)
    if "@" in model:
        model, url = model.split("@", 1)
    model = ALIASES.get(model, model)
    return kind, model, url


def make_provider(spec: str = "", *, effort: str = "", max_tokens: int = 0, base_url: str = "", api_key: str = "", **kw: object) -> Provider:
    """Um driver a partir da especificação `[tipo:]modelo[@url]` e do ambiente.

    Sem tipo: `claude-*` (ou apelido do catálogo) é Anthropic; senão vale
    `EXOVISION_PROVIDER` (padrão `anthropic`). Sem modelo: o padrão do driver.
    """
    kind, model, url = parse_spec(spec)
    if not kind:
        card = resolve(model) if model else None
        kind = "anthropic" if (card is not None and card.provider == "anthropic") else (os.environ.get("EXOVISION_PROVIDER") or "anthropic")
    base = base_url or url
    if kind == "anthropic":
        return AnthropicProvider(model=model, effort=effort, max_tokens=max_tokens, **kw)  # type: ignore[arg-type]
    if kind == "openai":
        return OpenAIProvider(model=model, effort=effort, max_tokens=max_tokens, base_url=base, api_key=api_key, **kw)  # type: ignore[arg-type]
    if kind == "google":
        return GoogleProvider(model=model, effort=effort, max_tokens=max_tokens, base_url=base, api_key=api_key, **kw)  # type: ignore[arg-type]
    if kind == "local":
        return LocalProvider(model=model, effort=effort, max_tokens=max_tokens, base_url=base, api_key=api_key, **kw)
    if kind == "compatible":
        return OpenAICompatibleProvider(model=model, effort=effort, max_tokens=max_tokens, base_url=base, api_key=api_key, **kw)  # type: ignore[arg-type]
    raise ProviderError(f"tipo de provedor desconhecido: {kind!r} (use {', '.join(KINDS)})")


def provider_from_env(*, effort: str = "", max_tokens: int = 0) -> Provider:
    """`EXOVISION_PROVIDER` + `EXOVISION_MODEL` do ambiente."""
    kind = os.environ.get("EXOVISION_PROVIDER", "")
    model = os.environ.get("EXOVISION_MODEL", "")
    spec = f"{kind}:{model}" if kind and model else (model or (f"{kind}:" if kind else ""))
    return make_provider(spec, effort=effort, max_tokens=max_tokens)


def stack(
    provider: Provider,
    *,
    limiter: RateLimiter | None = None,
    breaker: Breaker | None = None,
    cassette: Cassette | None = None,
    ledger: Ledger | None = None,
    agent: str = "",
) -> Provider:
    """A pilha na ordem fixa: Ledgered(Limited(Recording(driver))).

    O livro-razão mede tudo, inclusive a espera; o limitador espera ficha;
    o cassete responde sem rede quando tem a entrada. Em `Replay` (modo
    `none`) o limitador é dispensado: não há chamada para limitar.
    """
    p: Provider = provider
    if cassette is not None:
        p = Recording(p, cassette)
    replay_only = isinstance(p, Recording) and p.cassette.mode == "none"
    if (limiter is not None or breaker is not None) and not replay_only:
        p = Limited(p, limiter, breaker=breaker)
    if ledger is not None:
        p = Ledgered(p, ledger, agent=agent)
    return p
