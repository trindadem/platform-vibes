"""Roteamento: por papel, por verificador, por falha — e nunca por palpite.

Trocar de modelo compensa quando há um verificador e a razão de preços é
grande (FrugalGPT, AutoMix, RouteLLM); e custa o que a literatura não mede:
o cache de prefixo é por modelo, e os blocos de pensamento são do modelo
que os produziu. Daí três roteadores, cada um honesto sobre o que faz:

    Router    escolhe a pilha pelo **papel** do pedido (`metadata["role"]`)
              ou por uma função do pedido — decisão do desenho, entre laços
    Cascade   chama o barato; um **verificador explícito** decide se serve;
              senão chama o forte. Conta escalações e o custo de verificar
    Fallback  troca **por indisponibilidade** (erro esgotado, disjuntor
              aberto), nunca por qualidade; registra cada troca

Os três são `Provider` e embrulham pilhas inteiras (com limites, cassete e
livro-razão dentro de cada uma). Trocar de modelo no meio de um laço perde o
cache e o pensamento: `Router` e `Cascade` são para *entre* laços ou para
chamadas de uma volta; `Fallback` aceita a perda porque a alternativa é
parar — e o traço mostra que trocou.
"""

from __future__ import annotations

from collections.abc import Callable, Mapping, Sequence
from typing import Any

from .provider import Provider, ProviderError, Reply, Request

__all__ = ["Cascade", "Fallback", "Router"]


class Router:
    """`Router({"loop": forte, "extract": barato}, default="loop")`."""

    def __init__(self, routes: Mapping[str, Provider], *, default: str, key: Callable[[Request], str] | None = None) -> None:
        if default not in routes:
            raise ValueError(f"rota padrão {default!r} não está em {sorted(routes)}")
        self.routes = dict(routes)
        self.default = default
        self.key = key or (lambda req: str(req.metadata.get("role", "")))
        base = self.routes[default]
        self.model = getattr(base, "model", "")
        self.effort = getattr(base, "effort", "")
        self.cost_discount = float(getattr(base, "cost_discount", 1.0))
        self.chosen: dict[str, int] = {}

    def route(self, request: Request) -> str:
        k = self.key(request)
        return k if k in self.routes else self.default

    def complete(self, request: Request) -> Reply:
        nome = self.route(request)
        self.chosen[nome] = self.chosen.get(nome, 0) + 1
        return self.routes[nome].complete(request)


class Cascade:
    """Barato primeiro; `verify(request, reply) -> bool` decide; senão o forte."""

    def __init__(self, cheap: Provider, strong: Provider, verify: Callable[[Request, Reply], bool], *, verify_cost_usd: float = 0.0) -> None:
        self.cheap = cheap
        self.strong = strong
        self.verify = verify
        self.verify_cost_usd = verify_cost_usd
        self.model = getattr(strong, "model", "")
        self.effort = getattr(strong, "effort", "")
        self.cost_discount = float(getattr(strong, "cost_discount", 1.0))
        self.calls = 0
        self.accepted = 0
        self.escalations = 0

    def complete(self, request: Request) -> Reply:
        self.calls += 1
        reply = self.cheap.complete(request)
        if self.verify(request, reply):
            self.accepted += 1
            return reply
        self.escalations += 1
        return self.strong.complete(request)

    def report(self) -> dict[str, Any]:
        return {"calls": self.calls, "accepted": self.accepted, "escalations": self.escalations, "verify_cost_usd": round(self.verify_cost_usd * self.calls, 6)}


class Fallback:
    """Tenta cada provedor em ordem; só avança quando o anterior **não pôde** responder."""

    def __init__(self, providers: Sequence[Provider], *, on_failover: Callable[[int, str], None] | None = None) -> None:
        if not providers:
            raise ValueError("Fallback sem provedores")
        self.providers = list(providers)
        self.on_failover = on_failover
        base = self.providers[0]
        self.model = getattr(base, "model", "")
        self.effort = getattr(base, "effort", "")
        self.cost_discount = float(getattr(base, "cost_discount", 1.0))
        self.failovers: list[dict[str, Any]] = []

    def complete(self, request: Request) -> Reply:
        ultimo: ProviderError | None = None
        for i, p in enumerate(self.providers):
            try:
                reply = p.complete(request)
            except ProviderError as erro:
                ultimo = erro
                if i + 1 < len(self.providers):
                    self.failovers.append({"from": getattr(p, "model", str(i)), "to": getattr(self.providers[i + 1], "model", str(i + 1)), "error": str(erro)[:200]})
                    if self.on_failover:
                        self.on_failover(i, str(erro))
                continue
            if i > 0:
                # O laço reporta o modelo que de fato respondeu.
                reply.model = reply.model or getattr(p, "model", "")
            return reply
        raise ProviderError(f"todos os {len(self.providers)} provedores falharam; último: {ultimo}")
