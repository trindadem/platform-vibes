"""Drivers HTTP em stdlib: OpenAI, servidores compatíveis (locais ou remotos) e Google.

Nada a instalar: `urllib` fala JSON com qualquer um deles. O contrato é o
mesmo do driver Anthropic — `complete(Request) -> Reply` no formato de fio —
e a tradução fica em `wire.py`, pura e testada. O que cada driver decide:

    OpenAIProvider            https://api.openai.com/v1  · OPENAI_API_KEY
                              Responses API (`/responses`): a Chat Completions
                              recusa `reasoning_effort` com ferramentas nos modelos
                              atuais; `reasoning.effort` pelo mapa declarado;
                              `api="chat"` volta ao Chat Completions
    OpenAICompatibleProvider  qualquer base_url (+ token opcional): vLLM, llama.cpp,
                              Ollama, LM Studio, OpenRouter, Groq … · `max_tokens`
    LocalProvider             o compatível apontado para EXOVISION_LOCAL_URL
                              (padrão http://localhost:11434/v1, Ollama), sem token
    GoogleProvider            generateContent · GEMINI_API_KEY / GOOGLE_API_KEY

Sem streaming: a mensagem chega inteira, com `timeout_s` generoso (padrão
600 s). 429/5xx/queda de conexão repetem com recuo e jitter — e `retry-after`
quando o servidor manda; 400/401/403/404 não repetem. A credencial vem do
ambiente ou do construtor, nunca de arquivo do agente.
"""

from __future__ import annotations

import json
import os
import random
import time
import urllib.error
import urllib.request
from collections.abc import Callable
from typing import Any

from .provider import BASE_WAIT, MAX_WAIT, RETRIES, ProviderError, Reply, Request
from .wire import from_gemini, from_openai, from_responses, to_gemini, to_openai, to_responses

__all__ = [
    "GoogleProvider",
    "LocalProvider",
    "OpenAICompatibleProvider",
    "OpenAIProvider",
    "post_json",
]

Transport = Callable[[str, dict[str, Any], dict[str, str], float], dict[str, Any]]


class _HTTPStatus(Exception):
    def __init__(self, status: int, body: str, retry_after: float | None) -> None:
        super().__init__(f"HTTP {status}: {body[:300]}")
        self.status = status
        self.body = body
        self.retry_after = retry_after


def post_json(url: str, body: dict[str, Any], headers: dict[str, str], timeout_s: float) -> dict[str, Any]:
    """POST JSON; devolve o JSON da resposta. Erros HTTP viram `_HTTPStatus`."""
    data = json.dumps(body, ensure_ascii=False).encode("utf-8")
    req = urllib.request.Request(url, data=data, method="POST", headers={"Content-Type": "application/json", "Accept": "application/json", **headers})
    try:
        with urllib.request.urlopen(req, timeout=timeout_s) as resp:
            raw = resp.read().decode("utf-8")
    except urllib.error.HTTPError as erro:
        try:
            texto = erro.read().decode("utf-8", "replace")
        except Exception:
            texto = ""
        ra = erro.headers.get("retry-after") if erro.headers else None
        wait: float | None = None
        if ra:
            try:
                wait = float(ra)
            except ValueError:
                wait = None
        raise _HTTPStatus(erro.code, texto, wait) from erro
    try:
        return json.loads(raw) if raw else {}
    except json.JSONDecodeError as erro:
        raise ProviderError(f"resposta não é JSON: {raw[:200]!r}") from erro


def _classify(erro: Exception) -> tuple[bool, float | None]:
    if isinstance(erro, _HTTPStatus):
        return (erro.status in (408, 409, 429) or erro.status >= 500), erro.retry_after
    if isinstance(erro, (urllib.error.URLError, TimeoutError, ConnectionError, OSError)):
        return True, None
    return False, None


class _HTTPDriver:
    """O laço de retentativa que os três drivers compartilham."""

    model: str
    effort: str
    max_tokens: int
    retries: int
    timeout_s: float
    cost_discount: float = 1.0
    on_retry: Callable[[int, float, str], None] | None
    transport: Transport
    _sleep: Callable[[float], None]

    def _post(self, url: str, body: dict[str, Any], headers: dict[str, str]) -> dict[str, Any]:
        attempt = 0
        while True:
            try:
                return self.transport(url, body, headers, self.timeout_s)
            except ProviderError:
                raise
            except Exception as erro:
                retriable, wait_hint = _classify(erro)
                if not retriable or attempt >= self.retries:
                    raise ProviderError(f"{type(erro).__name__}: {erro}") from erro
                attempt += 1
                wait = (
                    wait_hint
                    if wait_hint is not None
                    else min(MAX_WAIT, BASE_WAIT * (2 ** (attempt - 1))) * (0.8 + 0.4 * random.random())
                )
                if self.on_retry:
                    motivo = f"http_{erro.status}" if isinstance(erro, _HTTPStatus) else type(erro).__name__
                    self.on_retry(attempt, wait, motivo)
                self._sleep(wait)


def _env_model(explicit: str) -> str:
    return explicit or os.environ.get("EXOVISION_MODEL", "")


#: Esforço do kernel -> `reasoning_effort` da OpenAI. Declarado, não inferido.
REASONING_EFFORT = {"low": "low", "medium": "medium", "high": "high", "xhigh": "high", "max": "high"}


class OpenAICompatibleProvider(_HTTPDriver):
    """Chat Completions em qualquer `base_url` (com token opcional)."""

    kind = "compatible"

    def __init__(
        self,
        *,
        base_url: str = "",
        api_key: str = "",
        model: str = "",
        effort: str = "",
        max_tokens: int = 0,
        max_tokens_field: str = "max_tokens",
        reasoning: bool = False,
        headers: dict[str, str] | None = None,
        timeout_s: float = 600.0,
        retries: int = RETRIES,
        on_retry: Callable[[int, float, str], None] | None = None,
        transport: Transport | None = None,
        sleep: Callable[[float], None] = time.sleep,
    ) -> None:
        env = os.environ.get
        self.base_url = (base_url or env("EXOVISION_BASE_URL") or "").rstrip("/")
        self.api_key = api_key or env("EXOVISION_API_KEY") or ""
        self.model = _env_model(model)
        self.effort = effort or env("EXOVISION_EFFORT") or "high"
        self.max_tokens = max_tokens or int(env("EXOVISION_MAX_TOKENS") or 8192)
        self.max_tokens_field = max_tokens_field
        self.reasoning = reasoning
        self.headers = dict(headers or {})
        self.timeout_s = timeout_s
        self.retries = int(env("EXOVISION_RETRIES") or retries)
        self.on_retry = on_retry
        self.transport = transport or post_json
        self._sleep = sleep
        if not self.base_url:
            raise ProviderError("driver compatível sem base_url (EXOVISION_BASE_URL)")
        if not self.model:
            raise ProviderError("driver compatível sem modelo (EXOVISION_MODEL ou --model)")

    def build_body(self, request: Request) -> dict[str, Any]:
        return to_openai(
            request,
            model=self.model,
            max_tokens=request.max_tokens or self.max_tokens,
            max_tokens_field=self.max_tokens_field,
            reasoning_effort=REASONING_EFFORT.get(self.effort, "") if self.reasoning else "",
        )

    def _headers(self) -> dict[str, str]:
        h = dict(self.headers)
        if self.api_key:
            h["Authorization"] = f"Bearer {self.api_key}"
        return h

    def complete(self, request: Request) -> Reply:
        data = self._post(f"{self.base_url}/chat/completions", self.build_body(request), self._headers())
        if "error" in data and not data.get("choices"):
            raise ProviderError(f"erro do servidor: {json.dumps(data.get('error'))[:300]}")
        reply = from_openai(data)
        if not reply.model:
            reply.model = self.model
        return reply


class OpenAIProvider(OpenAICompatibleProvider):
    """A OpenAI pela Responses API (`api="responses"`, padrão) ou Chat Completions (`api="chat"`)."""

    kind = "openai"

    def __init__(self, *, base_url: str = "", api_key: str = "", model: str = "", reasoning: bool = True, api: str = "responses", store: bool = False, **kw: Any) -> None:
        env = os.environ.get
        super().__init__(
            base_url=base_url or env("OPENAI_BASE_URL") or "https://api.openai.com/v1",
            api_key=api_key or env("OPENAI_API_KEY") or "",
            model=model or env("OPENAI_MODEL") or "",
            max_tokens_field=kw.pop("max_tokens_field", "max_completion_tokens"),
            reasoning=reasoning,
            **kw,
        )
        if api not in ("responses", "chat"):
            raise ProviderError(f"api desconhecida para o driver OpenAI: {api!r} (responses | chat)")
        self.api = api
        self.store = store
        if not self.api_key:
            raise ProviderError("OPENAI_API_KEY ausente no ambiente")

    def build_body(self, request: Request) -> dict[str, Any]:
        if self.api == "chat":
            return super().build_body(request)
        return to_responses(
            request,
            model=self.model,
            max_tokens=request.max_tokens or self.max_tokens,
            reasoning_effort=REASONING_EFFORT.get(self.effort, "") if self.reasoning else "",
            store=self.store,
        )

    def complete(self, request: Request) -> Reply:
        if self.api == "chat":
            return super().complete(request)
        data = self._post(f"{self.base_url}/responses", self.build_body(request), self._headers())
        if data.get("error") and not data.get("output"):
            raise ProviderError(f"erro do servidor: {json.dumps(data.get('error'))[:300]}")
        reply = from_responses(data)
        if not reply.model:
            reply.model = self.model
        return reply


class LocalProvider(OpenAICompatibleProvider):
    """Um servidor local compatível (Ollama, llama.cpp, vLLM, LM Studio), sem token."""

    kind = "local"

    def __init__(self, *, base_url: str = "", model: str = "", **kw: Any) -> None:
        env = os.environ.get
        super().__init__(
            base_url=base_url or env("EXOVISION_LOCAL_URL") or "http://localhost:11434/v1",
            api_key=kw.pop("api_key", "") or env("EXOVISION_LOCAL_KEY") or "",
            model=model or env("EXOVISION_LOCAL_MODEL") or "",
            **kw,
        )


class GoogleProvider(_HTTPDriver):
    """Gemini `generateContent` pela Gemini API (chave no cabeçalho, nunca na URL)."""

    kind = "google"

    def __init__(
        self,
        *,
        model: str = "",
        api_key: str = "",
        effort: str = "",
        max_tokens: int = 0,
        base_url: str = "",
        thinking_config: dict[str, Any] | None = None,
        timeout_s: float = 600.0,
        retries: int = RETRIES,
        on_retry: Callable[[int, float, str], None] | None = None,
        transport: Transport | None = None,
        sleep: Callable[[float], None] = time.sleep,
    ) -> None:
        env = os.environ.get
        self.base_url = (base_url or env("GEMINI_BASE_URL") or "https://generativelanguage.googleapis.com/v1beta").rstrip("/")
        self.api_key = api_key or env("GEMINI_API_KEY") or env("GOOGLE_API_KEY") or ""
        self.model = _env_model(model) or env("GEMINI_MODEL") or ""
        self.effort = effort or env("EXOVISION_EFFORT") or "high"
        self.max_tokens = max_tokens or int(env("EXOVISION_MAX_TOKENS") or 8192)
        self.thinking_config = dict(thinking_config or {})
        self.timeout_s = timeout_s
        self.retries = int(env("EXOVISION_RETRIES") or retries)
        self.on_retry = on_retry
        self.transport = transport or post_json
        self._sleep = sleep
        if not self.api_key:
            raise ProviderError("GEMINI_API_KEY (ou GOOGLE_API_KEY) ausente no ambiente")
        if not self.model:
            raise ProviderError("driver Google sem modelo (GEMINI_MODEL, EXOVISION_MODEL ou --model)")

    def build_body(self, request: Request) -> dict[str, Any]:
        return to_gemini(request, max_tokens=request.max_tokens or self.max_tokens, thinking_config=self.thinking_config or None)

    def complete(self, request: Request) -> Reply:
        url = f"{self.base_url}/models/{self.model}:generateContent"
        data = self._post(url, self.build_body(request), {"x-goog-api-key": self.api_key})
        if "error" in data and not data.get("candidates"):
            raise ProviderError(f"erro do servidor: {json.dumps(data.get('error'))[:300]}")
        reply = from_gemini(data)
        if not reply.model:
            reply.model = self.model
        return reply
