"""O driver de modelo: uma chamada, uma resposta, no formato de fio.

Este é o driver do kernel (`exovision.harness.models`); os outros serviços do
módulo — catálogo, primitivas, cassete, limites, livro-razão, janela,
roteador — são decoradores ou clientes deste contrato. Os drivers HTTP de
outros provedores (OpenAI, compatíveis, Google) estão em `drivers.py` e
produzem exatamente a mesma forma.

O laço não conhece SDK nenhum. Ele conhece `Provider.complete(Request) -> Reply`
e trabalha com blocos de conteúdo no **formato de fio da Messages API**
(dicts: `text`, `tool_use`, `thinking`, `compaction`, ...). Isso tem duas
consequências deliberadas:

1. A resposta do modelo é devolvida ao histórico **inteira** (`reply.content`),
   nunca só o texto. Blocos de pensamento e de compactação precisam voltar
   intactos na próxima chamada; extrair o texto e reenviar perderia o estado.
2. Um provedor de teste (`ScriptedProvider`) produz exatamente a mesma forma
   que o real — o laço é testado sem rede e sem chave, e o traço que ele deixa
   é o mesmo.

`AnthropicProvider` fala a Messages API pelo SDK oficial (`pip install
exovision-agent[anthropic]`). Endereço, credencial e modelo são do **ambiente**,
nunca de arquivo nem de documento: um agente amarrado a um tenant não serve ao
seguinte.

    ANTHROPIC_API_KEY / ANTHROPIC_BASE_URL    resolvidos pelo SDK
    EXOVISION_MODEL        padrão claude-opus-5
    EXOVISION_EFFORT       low | medium | high | xhigh | max (padrão xhigh)
    EXOVISION_MAX_TOKENS   padrão 32000 (streaming)
    EXOVISION_RETRIES      voltas além da primeira (padrão 4)
    EXOVISION_FALLBACKS    "0" desliga o fallback de recusa do lado do servidor
    EXOVISION_COMPACT      "1" liga compactação server-side para conversa longa
    EXOVISION_CLEAR_TOOL_USES  "1" liga poda de resultados antigos de ferramenta

As alavancas ligadas, e por quê: `thinking: adaptive` (o modelo decide a
profundidade e entremeia pensamento entre ferramentas; não há orçamento para
afinar), `effort: xhigh` (o melhor ajuste para trabalho agêntico), breakpoint
de cache no fim do prefixo estático (`tools -> system -> messages`, e o que
muda entra depois), streaming (para `max_tokens` grande não estourar timeout).

**429 é rotina, não exceção.** A espera sai do `retry-after` do provedor
quando ele o manda, e do recuo exponencial quando não manda.
"""

from __future__ import annotations

import copy
import os
import random
import time
from collections.abc import Callable, Sequence
from dataclasses import dataclass, field
from typing import Any, Protocol, runtime_checkable

from .catalog import PRICES_USD_PER_MTOK, estimate_cost_usd, resolve

__all__ = [
    "EFFORT",
    "MAX_TOKENS",
    "MODEL",
    "PRICES_USD_PER_MTOK",
    "AnthropicProvider",
    "Provider",
    "ProviderError",
    "Reply",
    "Request",
    "ScriptedProvider",
    "ToolUse",
    "estimate_cost_usd",
]

MODEL = "claude-opus-5"
EFFORT = "xhigh"
MAX_TOKENS = 32_000
RETRIES = 4
BASE_WAIT = 15.0
MAX_WAIT = 90.0

class ProviderError(RuntimeError):
    """A chamada não pôde ser feita, ou voltou o que não dá para usar."""


@dataclass(frozen=True, slots=True)
class ToolUse:
    id: str
    name: str
    input: dict[str, Any]


@dataclass(slots=True)
class Request:
    """Uma chamada ao modelo. `system` é lista de blocos (para cache_control)."""

    system: list[dict[str, Any]]
    messages: list[dict[str, Any]]
    tools: list[dict[str, Any]] = field(default_factory=list)
    max_tokens: int | None = None
    metadata: dict[str, Any] = field(default_factory=dict)


@dataclass(slots=True)
class Reply:
    """O que uma volta do modelo produziu — blocos no formato de fio."""

    content: list[dict[str, Any]]
    stop_reason: str = "end_turn"
    usage: dict[str, int] = field(default_factory=dict)
    model: str = ""
    stop_details: dict[str, Any] | None = None
    request_id: str = ""

    @property
    def text(self) -> str:
        return "\n".join(b.get("text", "") for b in self.content if b.get("type") == "text")

    @property
    def tool_uses(self) -> list[ToolUse]:
        out: list[ToolUse] = []
        for b in self.content:
            if b.get("type") == "tool_use":
                raw = b.get("input") or {}
                out.append(
                    ToolUse(
                        id=str(b.get("id", "")),
                        name=str(b.get("name", "")),
                        input=dict(raw) if isinstance(raw, dict) else {"_raw": raw},
                    )
                )
        return out

    @classmethod
    def of_text(cls, text: str, *, stop_reason: str = "end_turn", **usage: int) -> Reply:
        return cls(
            content=[{"type": "text", "text": text}], stop_reason=stop_reason, usage=dict(usage)
        )

    @classmethod
    def of_tools(
        cls,
        *calls: tuple[str, dict[str, Any]],
        text: str = "",
        ids: Sequence[str] = (),
        **usage: int,
    ) -> Reply:
        """Uma resposta que pede ferramentas: `Reply.of_tools(("bash", {"command": "ls"}))`."""
        content: list[dict[str, Any]] = []
        if text:
            content.append({"type": "text", "text": text})
        for i, (name, args) in enumerate(calls):
            tid = ids[i] if i < len(ids) else f"toolu_{i:04d}"
            content.append({"type": "tool_use", "id": tid, "name": name, "input": dict(args)})
        return cls(content=content, stop_reason="tool_use", usage=dict(usage))


@runtime_checkable
class Provider(Protocol):
    model: str
    effort: str

    def complete(self, request: Request) -> Reply: ...


# --------------------------------------------------------------------------
# ScriptedProvider — para testes e reprodução de traços
# --------------------------------------------------------------------------


class ScriptedProvider:
    """Devolve respostas roteirizadas, em ordem; guarda cada `Request` recebido.

    Cada item do roteiro é um `Reply` ou um callable `Request -> Reply` (para
    respostas que dependem do que o modelo "viu", ex.: o resultado de uma
    ferramenta). Roteiro esgotado é `ProviderError`: um teste que pede mais
    voltas do que roteirizou está errado, e silenciar isso esconde laços
    infinitos.
    """

    def __init__(
        self,
        script: Sequence[Reply | Callable[[Request], Reply]] = (),
        *,
        model: str = "scripted",
        effort: str = "high",
        failures: Sequence[Exception] = (),
    ) -> None:
        self.model = model
        self.effort = effort
        self._script = list(script)
        self._failures = list(failures)
        self.requests: list[Request] = []
        self.calls = 0

    def complete(self, request: Request) -> Reply:
        self.calls += 1
        # Cópia profunda: o laço muta `messages` depois da chamada, e o que
        # se quer inspecionar num teste é o que o modelo *viu* naquela volta.
        self.requests.append(copy.deepcopy(request))
        if self._failures:
            raise self._failures.pop(0)
        if not self._script:
            raise ProviderError(f"roteiro esgotado após {self.calls - 1} respostas")
        item = self._script.pop(0)
        reply = item(request) if callable(item) else item
        if not reply.model:
            reply.model = self.model
        return reply


# --------------------------------------------------------------------------
# AnthropicProvider — SDK oficial
# --------------------------------------------------------------------------


@dataclass
class AnthropicProvider:
    """Messages API pelo SDK oficial `anthropic` (dependência opcional)."""

    model: str = ""
    effort: str = ""
    max_tokens: int = 0
    retries: int = RETRIES
    fallbacks: bool = True
    compact: bool = False
    clear_tool_uses: bool = False
    thinking_display: str = ""  # "" (omitido: padrão do modelo) | "summarized"
    #: Chamado a cada retentativa: `(tentativa, espera_s, motivo)`. Uma
    #: execução que espera 60s em silêncio parece uma execução travada.
    on_retry: Callable[[int, float, str], None] | None = None
    #: Cliente injetável (testes). Sem ele, `anthropic.Anthropic()` do ambiente.
    client: Any = None
    _sleep: Callable[[float], None] = field(default=time.sleep, repr=False)

    def __post_init__(self) -> None:
        env = os.environ.get
        self.model = self.model or env("EXOVISION_MODEL") or MODEL
        self.effort = self.effort or env("EXOVISION_EFFORT") or EFFORT
        self.max_tokens = self.max_tokens or int(env("EXOVISION_MAX_TOKENS") or MAX_TOKENS)
        if env("EXOVISION_RETRIES"):
            self.retries = int(env("EXOVISION_RETRIES") or RETRIES)
        if env("EXOVISION_FALLBACKS") == "0":
            self.fallbacks = False
        if env("EXOVISION_COMPACT") == "1":
            self.compact = True
        if env("EXOVISION_CLEAR_TOOL_USES") == "1":
            self.clear_tool_uses = True

    # ----------------------------------------------------------- cliente
    def _client(self) -> Any:
        if self.client is None:
            try:
                import anthropic
            except ImportError as erro:  # pragma: no cover
                raise ProviderError(
                    "o SDK `anthropic` não está neste ambiente: `pip install exovision-agent[anthropic]`. "
                    "O harness fala a Messages API pelo SDK oficial — nunca por um shim compatível com outra API."
                ) from erro
            # Credenciais resolvidas pelo SDK: ANTHROPIC_API_KEY, ANTHROPIC_AUTH_TOKEN
            # ou perfil de `ant auth login`. Nunca lidas aqui.
            self.client = anthropic.Anthropic(max_retries=0)
        return self.client

    # ---------------------------------------------------------- montagem
    def build_kwargs(self, request: Request) -> tuple[dict[str, Any], list[str]]:
        """O corpo da chamada e as betas necessárias. Puro: testável sem SDK."""
        betas: list[str] = []
        kwargs: dict[str, Any] = {
            "model": self.model,
            "max_tokens": request.max_tokens or self.max_tokens,
            "messages": request.messages,
        }
        # Pensamento e esforço só para quem os aceita: o cartão do catálogo diz.
        # Haiku 4.5 não faz `thinking: adaptive` — mandar assim é 400 do servidor
        # ("adaptive thinking is not supported on this model"), e quem paga o erro
        # é quem escolheu o modelo no `init`. Fora do catálogo, mantemos o padrão
        # (desconhecido não é motivo para desligar alavanca).
        card = resolve(self.model)
        if card.thinking in ("", "adaptive"):
            kwargs["thinking"] = {
                "type": "adaptive",
                **({"display": self.thinking_display} if self.thinking_display else {}),
            }
        if card.efforts or not card.verified:
            kwargs["output_config"] = {"effort": self.effort}
        if request.system:
            kwargs["system"] = request.system
        if request.tools:
            kwargs["tools"] = request.tools
        edits: list[dict[str, Any]] = []
        if self.clear_tool_uses:
            betas.append("context-management-2025-06-27")
            edits.append({"type": "clear_tool_uses_20250919"})
        if self.compact:
            betas.append("compact-2026-01-12")
            edits.append({"type": "compact_20260112"})
        if edits:
            kwargs["context_management"] = {"edits": edits}
        if self.fallbacks:
            # Recusa por classificador de segurança é 200 com stop_reason=refusal.
            # Com `fallbacks: "default"` o servidor reexecuta no modelo de
            # fallback dentro da mesma chamada, roteado por categoria.
            betas.append("server-side-fallback-2026-07-01")
            kwargs["fallbacks"] = "default"
        return kwargs, betas

    # ------------------------------------------------------------ chamada
    def complete(self, request: Request) -> Reply:
        kwargs, betas = self.build_kwargs(request)
        client = self._client()
        surface = client.beta.messages if betas else client.messages
        if betas:
            kwargs["betas"] = betas
        attempt = 0
        while True:
            try:
                with surface.stream(**kwargs) as stream:
                    message = stream.get_final_message()
                    # `MessageStream.request_id` lê o cabeçalho `request-id`;
                    # a mensagem final do stream não o carrega.
                    request_id = getattr(stream, "request_id", None) or ""
                return self._to_reply(message, request_id=request_id)
            except Exception as erro:
                retriable, wait_hint = _classify(erro)
                if not retriable or attempt >= self.retries:
                    raise ProviderError(f"{type(erro).__name__}: {erro}") from erro
                attempt += 1
                wait = (
                    wait_hint
                    if wait_hint is not None
                    else min(MAX_WAIT, BASE_WAIT * (2 ** (attempt - 1)))
                    * (0.8 + 0.4 * random.random())
                )
                if self.on_retry:
                    self.on_retry(attempt, wait, type(erro).__name__)
                self._sleep(wait)

    @staticmethod
    def _to_reply(message: Any, *, request_id: str = "") -> Reply:
        data = message.to_dict() if hasattr(message, "to_dict") else dict(message)
        usage_raw = data.get("usage") or {}
        usage = {
            k: int(v)
            for k, v in usage_raw.items()
            if isinstance(v, (int, float)) and not isinstance(v, bool)
        }
        return Reply(
            content=[dict(b) for b in data.get("content", [])],
            stop_reason=str(data.get("stop_reason") or "end_turn"),
            usage=usage,
            model=str(data.get("model") or ""),
            stop_details=data.get("stop_details"),
            request_id=str(request_id or getattr(message, "_request_id", "") or ""),
        )


def _classify(erro: Exception) -> tuple[bool, float | None]:
    """(vale repetir?, espera sugerida). 429, 5xx e queda de conexão sim; 400/401 não."""
    name = type(erro).__name__
    status = getattr(erro, "status_code", None)
    wait: float | None = None
    response = getattr(erro, "response", None)
    headers = getattr(response, "headers", None)
    if headers is not None:
        try:
            ra = headers.get("retry-after")
            if ra:
                wait = float(ra)
        except Exception:
            wait = None
    if name in ("RateLimitError", "APIConnectionError", "APITimeoutError", "InternalServerError"):
        return True, wait
    if isinstance(status, int) and (status == 429 or status >= 500):
        return True, wait
    return False, None
