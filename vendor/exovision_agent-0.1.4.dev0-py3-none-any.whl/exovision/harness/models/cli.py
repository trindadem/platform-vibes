"""`exovision-agent models …` — catálogo, livro-razão, cassete, limites, auditoria, bench, calibração.

    models catalog [--provider anthropic] [--json]
    models resolve NOME
    models ledger --db lab.db [--by model|agent|session|role|provider|day] [--session S] [--cost-per-task] [--calls N] [--json]
    models cassette bench.jsonl [--audit] [--json]
    models limits --db lab.db [--model claude-opus-5]
    models bench [all|M1..M7] [--seed 0] [--out DIR]
    models calibrate --cassette bench.jsonl [--model claude-opus-5] [--limit 50]

`calibrate` é o único que precisa de rede e do SDK: mede `count_tokens`
sobre os pedidos gravados e reporta a razão bytes/token real contra a
heurística — o número a pôr em `EXOVISION_TOKEN_RATIO`.
"""

from __future__ import annotations

import argparse
import json
import sys
from typing import Any

from .catalog import cards, resolve
from .ledger import Ledger
from .limits import TokenBucket
from .replay import Cassette
from .window import (
    DEFINED_TOOL_TOKENS,
    RATIO,
    TOOLS_OVERHEAD_TOKENS,
    PrefixAudit,
    estimate_request,
    estimate_tokens,
    estimate_tools,
)

__all__ = ["add_parser"]


def _print(obj: Any, as_json: bool) -> None:
    if as_json:
        print(json.dumps(obj, ensure_ascii=False, indent=2, default=str))
    elif isinstance(obj, list) and obj and isinstance(obj[0], dict):
        cols = list(obj[0])
        print(" | ".join(cols))
        for row in obj:
            print(" | ".join(str(row.get(c, "")) for c in cols))
    else:
        print(json.dumps(obj, ensure_ascii=False, indent=2, default=str))


def cmd_catalog(a: argparse.Namespace) -> int:
    rows = [
        {"id": c.id, "provider": c.provider, "context": c.context, "max_output": c.max_output, "in": c.price_in, "out": c.price_out, "cache_min": c.cache_min_tokens, "efforts": "/".join(c.efforts) or "-", "aliases": ",".join(c.aliases) or "-", "verified": c.verified}
        for c in cards(a.provider or "")
    ]
    _print(rows, a.json)
    return 0


def cmd_resolve(a: argparse.Namespace) -> int:
    print(json.dumps(resolve(a.name).to_dict(), ensure_ascii=False, indent=2))
    return 0


def cmd_ledger(a: argparse.Namespace) -> int:
    led = Ledger(a.db)
    try:
        if a.cost_per_task:
            _print(led.cost_per_task(agent=a.agent or ""), a.json)
            return 0
        if a.calls:
            _print(led.calls(session=a.session or "", limit=a.calls), a.json)
            return 0
        rows = led.summary(by=a.by, session=a.session or "")
        if not rows:
            print("(livro-razão vazio)")
            return 0
        _print(rows, a.json)
        if any(not r["priced"] for r in rows):
            sys.stderr.write("aviso: há chamadas a modelos sem preço no catálogo (custo 0 = desconhecido, não grátis)\n")
        return 0
    finally:
        led.close()


def cmd_cassette(a: argparse.Namespace) -> int:
    cas = Cassette(a.path, mode="none")
    out: dict[str, Any] = cas.stats()
    out["sessions"] = cas.sessions()
    if a.audit:
        auditorias = {}
        for s in cas.sessions():
            audit = PrefixAudit()
            for req in cas.requests(session=s):
                if req.metadata.get("role") not in ("loop", ""):
                    continue  # só a conversa do laço tem prefixo a preservar
                audit.observe(req)
            auditorias[s or "-"] = audit.report()
        out["audit"] = auditorias
    _print(out, a.json)
    return 0


def cmd_limits(a: argparse.Namespace) -> int:
    tb = TokenBucket(a.db)
    try:
        nomes = [n for n in tb.names() if not a.model or n.startswith(a.model + ":")]
        _print([tb.state(n) for n in nomes], a.json)
        return 0
    finally:
        tb.close()


def cmd_bench(a: argparse.Namespace) -> int:
    from .bench import BENCHMARKS, run_benchmark

    alvos = list(BENCHMARKS) if a.which in ("all", None) else [a.which.lower()]
    for w in alvos:
        if w not in BENCHMARKS:
            sys.stderr.write(f"benchmark desconhecido: {w} (há {', '.join(BENCHMARKS)})\n")
            return 2
        path = run_benchmark(w, seed=a.seed, out_dir=a.out)
        print(f"{w.upper()}: {path}")
    return 0


def cmd_calibrate(a: argparse.Namespace) -> int:
    try:
        import anthropic
    except ImportError:
        sys.stderr.write("calibrar exige o SDK e rede: `pip install exovision-agent[anthropic]` e ANTHROPIC_API_KEY\n")
        return 2
    cas = Cassette(a.cassette, mode="none")
    reqs = cas.requests()[: a.limit]
    if not reqs:
        sys.stderr.write("cassete sem pedidos\n")
        return 2
    client = anthropic.Anthropic()
    linhas: list[dict[str, Any]] = []
    for req in reqs:
        kwargs: dict[str, Any] = {"model": a.model, "messages": req.messages}
        if req.system:
            kwargs["system"] = req.system
        if req.tools:
            kwargs["tools"] = req.tools
        real = int(client.messages.count_tokens(**kwargs).input_tokens)
        fixos = estimate_tools(req.tools, ratio=1.0) - estimate_tokens(req.tools, 1.0) if req.tools else 0
        visiveis = estimate_request(req, ratio=1.0) - fixos  # bytes da parte que o fio mostra
        estimado = estimate_request(req)
        linhas.append({"real": real, "estimado": estimado, "erro": round((estimado - real) / real, 4), "bytes_visiveis": visiveis, "tokens_fixos": fixos})
    bytes_vis = sum(ln["bytes_visiveis"] for ln in linhas)
    tokens_vis = sum(ln["real"] - ln["tokens_fixos"] for ln in linhas)
    razao = bytes_vis / tokens_vis if tokens_vis > 0 else 0.0
    erros = [abs(ln["erro"]) for ln in linhas]
    print(json.dumps({
        "model": a.model, "requests": len(linhas),
        "ratio_measured": round(razao, 3), "ratio_default": RATIO,
        "mean_abs_error_estimator": round(sum(erros) / len(erros), 4),
        "fixed_tokens_model": {"tools_overhead": TOOLS_OVERHEAD_TOKENS, **DEFINED_TOOL_TOKENS},
        "per_request": linhas,
        "set": f"EXOVISION_TOKEN_RATIO={razao:.3f}",
    }, ensure_ascii=False, indent=2))
    return 0


def add_parser(sub: Any) -> None:
    p = sub.add_parser("models", help="modelos: catálogo, livro-razão, cassete, limites, bench, calibração")
    s = p.add_subparsers(dest="models_cmd", required=True)

    c = s.add_parser("catalog", help="os cartões de modelo embarcados")
    c.add_argument("--provider")
    c.add_argument("--json", action="store_true")
    c.set_defaults(fn=cmd_catalog)

    r = s.add_parser("resolve", help="o cartão de um nome ou apelido")
    r.add_argument("name")
    r.set_defaults(fn=cmd_resolve)

    led = s.add_parser("ledger", help="agregados do livro-razão")
    led.add_argument("--db", required=True)
    led.add_argument("--by", default="model", choices=["model", "agent", "session", "role", "provider", "day"])
    led.add_argument("--session")
    led.add_argument("--agent")
    led.add_argument("--cost-per-task", action="store_true")
    led.add_argument("--calls", type=int, default=0, help="lista as N últimas chamadas")
    led.add_argument("--json", action="store_true")
    led.set_defaults(fn=cmd_ledger)

    cas = s.add_parser("cassette", help="estatísticas (e auditoria de prefixo) de um cassete")
    cas.add_argument("path")
    cas.add_argument("--audit", action="store_true")
    cas.add_argument("--json", action="store_true")
    cas.set_defaults(fn=cmd_cassette)

    lim = s.add_parser("limits", help="estado dos baldes de fichas")
    lim.add_argument("--db", required=True)
    lim.add_argument("--model")
    lim.add_argument("--json", action="store_true")
    lim.set_defaults(fn=cmd_limits)

    b = s.add_parser("bench", help="benchmarks M1..M7 (offline)")
    b.add_argument("which", nargs="?", default="all")
    b.add_argument("--seed", type=int, default=0)
    b.add_argument("--out")
    b.set_defaults(fn=cmd_bench)

    cal = s.add_parser("calibrate", help="mede bytes/token com count_tokens sobre um cassete (rede)")
    cal.add_argument("--cassette", required=True)
    cal.add_argument("--model", default="claude-opus-5")
    cal.add_argument("--limit", type=int, default=50)
    cal.set_defaults(fn=cmd_calibrate)
