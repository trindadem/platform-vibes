"""A janela: estimar o que vai, compactar por resumo e reinício, vigiar o prefixo.

Três serviços, todos sem rede:

**Estimativa de tokens.** A contagem é específica do modelo e só o endpoint
`count_tokens` a dá. Sem rede, o kernel usa bytes por token mais o que o
fio **não mostra**: as ferramentas definidas pela Anthropic (`bash`,
editor) vão sem schema e custam centenas de tokens do lado do servidor, e
qualquer ferramentaria traz um preâmbulo fixo. Os números vêm de
`count_tokens` sobre cassetes reais (Opus 5, 2026-09-17): prosa em
português 2,76 bytes/token, código Python 2,34, JSON 2,54; preâmbulo de
ferramentas ~295 tokens; `bash_20250124` ~316; `text_editor_20250728`
~965. `RATIO` (2,6) é o valor conservador para a mistura; `models
calibrate` mede o resíduo sobre um cassete e `EXOVISION_TOKEN_RATIO` fixa
outro. Quem depende da estimativa (a janela, o limitador) trabalha com
margem.

**Compactação simples.** Quando o pedido estimado ultrapassa `context -
reserve`, o laço resume a conversa inteira numa mensagem e **recomeça** —
não edita o histórico: os blocos de pensamento estão ligados ao prefixo que
os produziu, e apagar uma volta anterior invalida todos os posteriores
(400 para contas novas). Nada da conversa antiga é replicado; a antiga fica
arquivada no journal. Nunca no meio de uma rodada de ferramenta — o laço só
compacta antes de `llm.request`, com as ferramentas já respondidas.

**Auditoria de prefixo.** O cache de prefixo casa byte a byte, na ordem
`tools → system → messages`. `PrefixAudit` guarda o fingerprint de cada
parte a cada volta e acusa quando tools ou system mudaram, ou quando as
mensagens deixaram de ser extensão das anteriores — com o deslocamento do
primeiro byte diferente. É como um timestamp no system ou um `json.dumps`
sem ordem aparecem antes da fatura.
"""

from __future__ import annotations

import hashlib
import json
import math
import os
from collections.abc import Callable
from dataclasses import dataclass, field
from typing import Any

from .engine import LLMUsage
from .provider import Provider, Reply, Request

__all__ = [
    "COMPACTION_PROMPT",
    "DEFINED_TOOL_TOKENS",
    "RATIO",
    "TOOLS_OVERHEAD_TOKENS",
    "Alarm",
    "Compaction",
    "PrefixAudit",
    "Window",
    "compact",
    "estimate_request",
    "estimate_tokens",
    "estimate_tools",
]

#: Bytes (UTF-8) por token da parte visível no fio. Medido com `count_tokens`
#: (Opus 5, 2026-09-17): prosa pt 2,76; código 2,34; JSON 2,54 — 2,6 é o
#: valor conservador para a mistura. `EXOVISION_TOKEN_RATIO` fixa outro.
RATIO = float(os.environ.get("EXOVISION_TOKEN_RATIO") or 2.6)

#: O que o fio não mostra: tokens que o servidor acrescenta por ferramenta
#: definida pela Anthropic (vai sem schema) e o preâmbulo de qualquer
#: ferramentaria. Medidos por diferença com `count_tokens` (Opus 5, 2026-09-17).
DEFINED_TOOL_TOKENS: dict[str, int] = {"bash_20250124": 316, "text_editor_20250728": 965}
TOOLS_OVERHEAD_TOKENS = 295


def estimate_tokens(obj: Any, ratio: float = RATIO) -> int:
    """Tokens estimados de um texto ou de qualquer estrutura serializável."""
    if isinstance(obj, str):
        n = len(obj.encode("utf-8"))
    else:
        n = len(json.dumps(obj, ensure_ascii=False, separators=(",", ":")).encode("utf-8"))
    return math.ceil(n / ratio) if n else 0


def estimate_tools(tools: list[dict[str, Any]], ratio: float = RATIO) -> int:
    """Tokens das ferramentas: schema no fio por bytes; as da Anthropic pela tabela; mais o preâmbulo."""
    if not tools:
        return 0
    total = TOOLS_OVERHEAD_TOKENS
    for t in tools:
        fixo = DEFINED_TOOL_TOKENS.get(str(t.get("type", "")))
        total += fixo if fixo is not None and "input_schema" not in t else estimate_tokens(t, ratio)
    return total


def estimate_request(request: Request, ratio: float = RATIO) -> int:
    """Tokens estimados do pedido inteiro (system + tools + messages)."""
    return estimate_tokens(request.system, ratio) + estimate_tools(request.tools, ratio) + estimate_tokens(request.messages, ratio)


COMPACTION_PROMPT = """\
A conversa acima vai ser substituída por um resumo — tudo o que não estiver \
no resumo será esquecido. Escreva um resumo fiel e denso, em texto corrido \
ou tópicos, com: (1) a tarefa original, palavra por palavra quando possível; \
(2) o estado atual: o que já foi feito e verificado; (3) decisões tomadas e \
por quê; (4) o que falta, na ordem; (5) arquivos, comandos, nomes e valores \
exatos que serão necessários; (6) erros encontrados e o que não funcionou. \
Não invente; não omita pendências; não inclua este pedido no resumo."""

CONTINUE_PROMPT = """\
<compaction>
A conversa anterior foi compactada. Este é o resumo do que aconteceu até aqui:

{summary}
</compaction>

Continue a tarefa a partir desse estado. Tarefa original:

{task}"""


@dataclass(slots=True)
class Compaction:
    """O que uma compactação deixou: o resumo, quanto arquivou, quanto custou."""

    summary: str
    archived_messages: int
    estimated_before: int
    estimated_after: int
    usage: dict[str, int] = field(default_factory=dict)
    generation: int = 1


def compact(
    provider: Provider,
    system: list[dict[str, Any]],
    messages: list[dict[str, Any]],
    *,
    task: str,
    max_tokens: int = 4096,
    usage: LLMUsage | None = None,
    prompt: str = COMPACTION_PROMPT,
    metadata: dict[str, Any] | None = None,
) -> tuple[str, str, Reply]:
    """Resume a conversa e devolve `(resumo, mensagem de continuação, reply)`.

    A chamada de resumo é um pedido **novo** (system + conversa + o pedido de
    resumo), não a continuação da conversa — nada dela é replicado depois.
    """
    conversa = [*messages, {"role": "user", "content": [{"type": "text", "text": prompt}]}]
    req = Request(system=system, messages=conversa, max_tokens=max_tokens, metadata={"role": "compaction", **(metadata or {})})
    reply = provider.complete(req)
    if usage is not None:
        usage.add(reply.model or getattr(provider, "model", ""), reply.usage, discount=float(getattr(provider, "cost_discount", 1.0)))
    summary = reply.text.strip() or "(o modelo não produziu resumo)"
    return summary, CONTINUE_PROMPT.format(summary=summary, task=task), reply


@dataclass
class Window:
    """Quanto cabe, quanto reservar, e a decisão por pedido."""

    context: int
    reserve: int = 32_000
    ratio: float = RATIO
    #: fração da janela acima da qual se compacta (margem sobre a estimativa).
    margin: float = 0.25
    summary_max_tokens: int = 4096
    compactions: int = 0

    @property
    def limit(self) -> int:
        """Tokens estimados a partir dos quais se compacta."""
        return int((self.context - self.reserve) * (1.0 - self.margin))

    def estimate(self, request: Request) -> int:
        return estimate_request(request, self.ratio)

    def plan(self, request: Request) -> str:
        """`"ok"` ou `"compact"`."""
        if self.context <= 0:
            return "ok"
        return "compact" if self.estimate(request) > self.limit else "ok"

    def compact(self, provider: Provider, system: list[dict[str, Any]], messages: list[dict[str, Any]], *, task: str, metadata: dict[str, Any] | None = None) -> tuple[list[dict[str, Any]], Compaction]:
        """As mensagens novas (uma só) e o registro da compactação."""
        antes = self.estimate(Request(system=system, messages=messages))
        summary, continuation, reply = compact(provider, system, messages, task=task, max_tokens=self.summary_max_tokens, metadata=metadata)
        novas = [{"role": "user", "content": [{"type": "text", "text": continuation}]}]
        self.compactions += 1
        depois = self.estimate(Request(system=system, messages=novas))
        return novas, Compaction(summary=summary, archived_messages=len(messages), estimated_before=antes, estimated_after=depois, usage=dict(reply.usage), generation=self.compactions)


# --------------------------------------------------------------------------
# Auditoria de prefixo
# --------------------------------------------------------------------------


def _canon(obj: Any) -> str:
    return json.dumps(obj, sort_keys=True, ensure_ascii=False, separators=(",", ":"))


def _fp(s: str) -> str:
    return hashlib.sha256(s.encode("utf-8")).hexdigest()[:16]


def _first_diff(a: str, b: str) -> int:
    n = min(len(a), len(b))
    for i in range(n):
        if a[i] != b[i]:
            return i
    return n if len(a) != len(b) else -1


@dataclass(frozen=True, slots=True)
class Alarm:
    turn: int
    part: str  # tools | system | messages
    offset: int
    excerpt: str

    def to_dict(self) -> dict[str, Any]:
        return {"turn": self.turn, "part": self.part, "offset": self.offset, "excerpt": self.excerpt}


class PrefixAudit:
    """Acusa a volta em que o prefixo enviado deixou de ser extensão do anterior."""

    def __init__(self, *, on_alarm: Callable[[Alarm], None] | None = None) -> None:
        self.turn = 0
        self._tools = ""
        self._system = ""
        self._messages = ""
        self.alarms: list[Alarm] = []
        self.on_alarm = on_alarm
        self.stable_turns = 0
        self.generations = 1

    def reset(self) -> None:
        """Depois de uma compactação o prefixo recomeça de propósito: sem alarme."""
        self._messages = ""

    def observe(self, request: Request) -> Alarm | None:
        self.turn += 1
        tools = _canon(request.tools)
        system = _canon(request.system)
        # A canônica das mensagens é a concatenação em ordem: ser prefixo em
        # bytes equivale a ser extensão em mensagens.
        messages = "".join(_canon(m) + "\n" for m in request.messages)
        alarm: Alarm | None = None
        if self.turn > 1 and len(request.messages) == 1 and self._messages:
            # Uma mensagem só depois de várias: geração nova (compactação), não deriva.
            self.generations += 1
            self._messages = ""
        if self.turn > 1:
            if tools != self._tools:
                pos = _first_diff(tools, self._tools)
                alarm = Alarm(self.turn, "tools", pos, tools[max(0, pos - 20) : pos + 40])
            elif system != self._system:
                pos = _first_diff(system, self._system)
                alarm = Alarm(self.turn, "system", pos, system[max(0, pos - 20) : pos + 40])
            elif self._messages and not messages.startswith(self._messages):
                pos = _first_diff(messages, self._messages)
                alarm = Alarm(self.turn, "messages", pos, messages[max(0, pos - 20) : pos + 40])
        self._tools, self._system, self._messages = tools, system, messages
        if alarm is not None:
            self.alarms.append(alarm)
            if self.on_alarm:
                self.on_alarm(alarm)
        else:
            self.stable_turns += 1 if self.turn > 1 else 0
        return alarm

    def fingerprints(self) -> dict[str, str]:
        return {"tools": _fp(self._tools), "system": _fp(self._system), "messages": _fp(self._messages)}

    def report(self) -> dict[str, Any]:
        return {"turns": self.turn, "stable_turns": self.stable_turns, "generations": self.generations, "alarms": [a.to_dict() for a in self.alarms], "fingerprints": self.fingerprints()}
