"""O cassete: gravar uma chamada real uma vez, reexecutá-la sempre igual.

Reprodutibilidade não vem do modelo (temperatura 0 não repete; o lote do
servidor muda o número) — vem de gravar e reexecutar. Uma linha JSONL por
chamada: o **digest** do pedido canônico (modelo, esforço, system, tools,
messages, max_tokens), o pedido redigido (segredos viram `[REDACTED]`), a
resposta inteira em formato de fio, e quando. Os modos são os do VCR.py:

    once   reexecuta o gravado; grava o que falta          (o padrão)
    none   só reexecuta; ausência é `ProviderError` com a posição da deriva
    all    sempre chama e grava (para renovar o cassete)

A reexecução é **por digest, não por ordem**: K laços paralelos gravam num
arquivo só e reexecutam em qualquer ordem. O mesmo digest pedido duas vezes
consome duas entradas, em ordem — duas amostras do mesmo pedido são duas
respostas. Um byte de diferença no prompt é um *miss*, reportado com o
deslocamento do primeiro caractere diferente em relação à entrada mais
próxima — nunca uma resposta velha servida em silêncio.
"""

from __future__ import annotations

import hashlib
import json
import re
import threading
import time
from pathlib import Path
from typing import Any

from .provider import Provider, ProviderError, Reply, Request

__all__ = [
    "Cassette",
    "Recording",
    "Replay",
    "canonical",
    "redact",
    "reply_from_dict",
    "reply_to_dict",
    "request_digest",
]

_SECRET_PATTERNS = [
    re.compile(r"sk-ant-[A-Za-z0-9_\-]{10,}"),
    re.compile(r"sk-[A-Za-z0-9_\-]{20,}"),
    re.compile(r"AIza[0-9A-Za-z_\-]{30,}"),
    re.compile(r"(?i)bearer\s+[A-Za-z0-9._\-]{16,}"),
    re.compile(r"ghp_[A-Za-z0-9]{20,}"),
    re.compile(r"xox[baprs]-[A-Za-z0-9\-]{10,}"),
]
_SECRET_KEYS = re.compile(r"(?i)^(api[_-]?key|token|authorization|password|secret|x-api-key)$")
REDACTED = "[REDACTED]"


def redact(obj: Any) -> Any:
    """Cópia de `obj` com segredos conhecidos substituídos (valores e chaves sensíveis)."""
    if isinstance(obj, str):
        out = obj
        for pat in _SECRET_PATTERNS:
            out = pat.sub(REDACTED, out)
        return out
    if isinstance(obj, list):
        return [redact(x) for x in obj]
    if isinstance(obj, dict):
        return {k: (REDACTED if isinstance(k, str) and _SECRET_KEYS.match(k) else redact(v)) for k, v in obj.items()}
    return obj


def canonical(request: Request, *, model: str, effort: str) -> str:
    """O pedido como string canônica: chaves ordenadas, sem espaços, sem `metadata`."""
    doc = {
        "model": model,
        "effort": effort,
        "system": request.system,
        "tools": request.tools,
        "messages": request.messages,
        "max_tokens": request.max_tokens,
    }
    return json.dumps(doc, sort_keys=True, ensure_ascii=False, separators=(",", ":"))


def request_digest(request: Request, *, model: str, effort: str) -> str:
    return hashlib.sha256(canonical(request, model=model, effort=effort).encode("utf-8")).hexdigest()


def reply_to_dict(reply: Reply) -> dict[str, Any]:
    return {
        "content": reply.content,
        "stop_reason": reply.stop_reason,
        "usage": dict(reply.usage),
        "model": reply.model,
        "stop_details": reply.stop_details,
        "request_id": reply.request_id,
    }


def reply_from_dict(d: dict[str, Any]) -> Reply:
    return Reply(
        content=[dict(b) for b in d.get("content") or []],
        stop_reason=str(d.get("stop_reason") or "end_turn"),
        usage={k: int(v) for k, v in (d.get("usage") or {}).items()},
        model=str(d.get("model") or ""),
        stop_details=d.get("stop_details"),
        request_id=str(d.get("request_id") or ""),
    )


def _first_diff(a: str, b: str) -> int:
    n = min(len(a), len(b))
    for i in range(n):
        if a[i] != b[i]:
            return i
    return n if len(a) != len(b) else -1


class Cassette:
    """Entradas por digest, em ordem de gravação; escrita append-only em JSONL."""

    def __init__(self, path: str | Path, mode: str = "once") -> None:
        if mode not in ("once", "none", "all"):
            raise ValueError(f"modo de cassete desconhecido: {mode!r}")
        self.path = Path(path)
        self.mode = mode
        self._entries: dict[str, list[dict[str, Any]]] = {}
        self._cursor: dict[str, int] = {}
        self._lock = threading.Lock()
        self.hits = 0
        self.misses = 0
        self.recorded = 0
        if self.path.exists():
            for line in self.path.read_text(encoding="utf-8").splitlines():
                if line.strip():
                    e = json.loads(line)
                    self._entries.setdefault(str(e["digest"]), []).append(e)

    def __len__(self) -> int:
        return sum(len(v) for v in self._entries.values())

    @property
    def digests(self) -> list[str]:
        return list(self._entries)

    def take(self, digest: str) -> dict[str, Any] | None:
        """A próxima entrada não consumida deste digest, ou None."""
        with self._lock:
            entries = self._entries.get(digest) or []
            i = self._cursor.get(digest, 0)
            if i < len(entries):
                self._cursor[digest] = i + 1
                self.hits += 1
                return entries[i]
            self.misses += 1
            return None

    def rewind(self) -> None:
        with self._lock:
            self._cursor.clear()

    def record(self, digest: str, *, request: Request, reply: Reply, model: str, effort: str) -> dict[str, Any]:
        entry = {
            "digest": digest,
            "at": time.time(),
            "model": model,
            "effort": effort,
            "session": str(request.metadata.get("session", "")),
            "role": str(request.metadata.get("role", "")),
            "request": redact({"system": request.system, "tools": request.tools, "messages": request.messages, "max_tokens": request.max_tokens}),
            "canonical_len": len(canonical(request, model=model, effort=effort)),
            "reply": reply_to_dict(reply),
        }
        with self._lock:
            self._entries.setdefault(digest, []).append(entry)
            # A entrada recém-gravada já conta como consumida nesta sessão.
            self._cursor[digest] = self._cursor.get(digest, 0) + 1
            self.recorded += 1
            self.path.parent.mkdir(parents=True, exist_ok=True)
            with self.path.open("a", encoding="utf-8") as fh:
                fh.write(json.dumps(entry, ensure_ascii=False) + "\n")
        return entry

    def nearest(self, request: Request, *, model: str, effort: str) -> tuple[dict[str, Any] | None, int]:
        """A entrada cujo pedido canônico mais se parece com este, e onde divergem."""
        alvo = canonical(request, model=model, effort=effort)
        best: dict[str, Any] | None = None
        best_pos = -1
        for entries in self._entries.values():
            for e in entries:
                doc = e.get("request") or {}
                cand = canonical(
                    Request(system=doc.get("system") or [], messages=doc.get("messages") or [], tools=doc.get("tools") or [], max_tokens=doc.get("max_tokens")),
                    model=str(e.get("model", "")),
                    effort=str(e.get("effort", "")),
                )
                pos = _first_diff(alvo, cand)
                if pos == -1:
                    return e, -1
                if pos > best_pos:
                    best, best_pos = e, pos
        return best, best_pos

    def requests(self, *, session: str | None = None) -> list[Request]:
        """Os pedidos gravados (redigidos), na ordem de gravação — para auditorias."""
        out: list[Request] = []
        for e in self.entries():
            if session is not None and str(e.get("session", "")) != session:
                continue
            doc = e.get("request") or {}
            out.append(Request(system=doc.get("system") or [], messages=doc.get("messages") or [], tools=doc.get("tools") or [], max_tokens=doc.get("max_tokens"), metadata={"session": str(e.get("session", "")), "role": str(e.get("role", ""))}))
        return out

    def sessions(self) -> list[str]:
        vistas: list[str] = []
        for e in self.entries():
            s = str(e.get("session", ""))
            if s not in vistas:
                vistas.append(s)
        return vistas

    def entries(self) -> list[dict[str, Any]]:
        todas = [e for es in self._entries.values() for e in es]
        todas.sort(key=lambda e: float(e.get("at", 0.0)))
        return todas

    def stats(self) -> dict[str, Any]:
        return {"path": str(self.path), "mode": self.mode, "entries": len(self), "digests": len(self._entries), "hits": self.hits, "misses": self.misses, "recorded": self.recorded}


class Recording:
    """Um `Provider` que consulta o cassete antes de chamar o de dentro."""

    def __init__(self, provider: Provider | None, cassette: Cassette, *, model: str = "", effort: str = "") -> None:
        self.inner = provider
        self.cassette = cassette
        self.model = model or (getattr(provider, "model", "") if provider is not None else "") or self._model_from_cassette()
        self.effort = effort or (getattr(provider, "effort", "") if provider is not None else "") or self._effort_from_cassette()
        self.cost_discount = float(getattr(provider, "cost_discount", 1.0)) if provider is not None else 1.0

    def _model_from_cassette(self) -> str:
        es = self.cassette.entries()
        return str(es[0].get("model", "")) if es else "replay"

    def _effort_from_cassette(self) -> str:
        es = self.cassette.entries()
        return str(es[0].get("effort", "")) if es else "high"

    def complete(self, request: Request) -> Reply:
        digest = request_digest(request, model=self.model, effort=self.effort)
        if self.cassette.mode != "all":
            entry = self.cassette.take(digest)
            if entry is not None:
                return reply_from_dict(entry["reply"])
        if self.cassette.mode == "none" or self.inner is None:
            near, pos = self.cassette.nearest(request, model=self.model, effort=self.effort)
            if near is None:
                raise ProviderError(f"cassete {self.cassette.path.name}: vazio, e o modo é `none` (digest {digest[:12]})")
            if pos == -1:
                raise ProviderError(f"cassete {self.cassette.path.name}: as entradas do digest {digest[:12]} já foram consumidas")
            alvo = canonical(request, model=self.model, effort=self.effort)
            trecho = alvo[max(0, pos - 30) : pos + 30]
            raise ProviderError(
                f"cassete {self.cassette.path.name}: pedido não gravado (digest {digest[:12]}); "
                f"diverge da entrada mais próxima no caractere {pos}: …{trecho}…"
            )
        reply = self.inner.complete(request)
        self.cassette.record(digest, request=request, reply=reply, model=self.model, effort=self.effort)
        return reply


def Replay(cassette: Cassette | str | Path, *, model: str = "", effort: str = "") -> Recording:
    """Só reexecução: `Replay("bench.jsonl")` é um `Provider` sem rede."""
    cas = cassette if isinstance(cassette, Cassette) else Cassette(cassette, mode="none")
    cas.mode = "none"
    return Recording(None, cas, model=model, effort=effort)
