"""O livro-razão: uma linha por chamada ao modelo, durável, entre execuções.

As costuras medem *uma* execução. Entre execuções — por modelo, agente,
sessão, papel, dia, equipe — não havia registro. Aqui há: uma tabela no
mesmo arquivo dos outros serviços, no vocabulário das convenções GenAI do
OpenTelemetry (`gen_ai.request.model`, `gen_ai.usage.input_tokens`,
`gen_ai.usage.output_tokens`, `gen_ai.response.finish_reasons`), mais o que
o kernel sabe e o OTel não pede: leitura e escrita de cache, custo estimado
pela tabela, latência, espera no limitador, `request_id`, papel da chamada
(`loop`, `compaction`, `extract`, `judge`, …), erro.

`attach(seams)` grava o desfecho de cada laço (`shutdown`) na tabela
`outcomes`; com as duas, "custo por tarefa concluída" é uma consulta
(`cost_per_task`), não uma estimativa.
"""

from __future__ import annotations

import sqlite3
import threading
import time
from collections.abc import Callable
from pathlib import Path
from typing import Any

from ..seams import Event, Seams
from ..session import enable_wal
from .catalog import estimate_cost_usd, resolve
from .provider import Provider, ProviderError, Reply, Request

__all__ = ["Ledger", "Ledgered"]

_SCHEMA = """
CREATE TABLE IF NOT EXISTS calls (
  id INTEGER PRIMARY KEY,
  at REAL NOT NULL,
  session TEXT NOT NULL DEFAULT '',
  agent TEXT NOT NULL DEFAULT '',
  turn INTEGER NOT NULL DEFAULT 0,
  role TEXT NOT NULL DEFAULT 'loop',
  provider TEXT NOT NULL DEFAULT '',
  model TEXT NOT NULL DEFAULT '',
  effort TEXT NOT NULL DEFAULT '',
  input_tokens INTEGER NOT NULL DEFAULT 0,
  output_tokens INTEGER NOT NULL DEFAULT 0,
  cache_read INTEGER NOT NULL DEFAULT 0,
  cache_creation INTEGER NOT NULL DEFAULT 0,
  cost_usd REAL NOT NULL DEFAULT 0,
  priced INTEGER NOT NULL DEFAULT 1,
  latency_ms REAL NOT NULL DEFAULT 0,
  wait_ms REAL NOT NULL DEFAULT 0,
  stop_reason TEXT NOT NULL DEFAULT '',
  request_id TEXT NOT NULL DEFAULT '',
  error TEXT NOT NULL DEFAULT ''
);
CREATE INDEX IF NOT EXISTS calls_session ON calls(session);
CREATE INDEX IF NOT EXISTS calls_model ON calls(model);
CREATE TABLE IF NOT EXISTS outcomes (
  id INTEGER PRIMARY KEY,
  at REAL NOT NULL,
  session TEXT NOT NULL DEFAULT '',
  agent TEXT NOT NULL DEFAULT '',
  status TEXT NOT NULL DEFAULT '',
  stop_reason TEXT NOT NULL DEFAULT '',
  turns INTEGER NOT NULL DEFAULT 0,
  tool_calls INTEGER NOT NULL DEFAULT 0,
  cost_usd REAL NOT NULL DEFAULT 0,
  error TEXT NOT NULL DEFAULT ''
);
"""

GROUPS = {"model", "agent", "session", "role", "provider", "day"}


class Ledger:
    """Tabelas `calls` e `outcomes` num SQLite (WAL); um objeto por processo."""

    def __init__(self, db: str | Path, *, clock: Callable[[], float] = time.time, busy_timeout_s: float = 30.0) -> None:
        self.path = Path(db)
        self.path.parent.mkdir(parents=True, exist_ok=True)
        self._conn = sqlite3.connect(str(self.path), timeout=busy_timeout_s, check_same_thread=False, isolation_level=None)
        self._conn.execute(f"PRAGMA busy_timeout={int(busy_timeout_s * 1000)}")
        enable_wal(self._conn, timeout_s=busy_timeout_s)
        self._conn.executescript(_SCHEMA)
        self._lock = threading.Lock()
        self._clock = clock

    def close(self) -> None:
        self._conn.close()

    # ------------------------------------------------------------ escrita
    def record(
        self,
        *,
        model: str,
        usage: dict[str, int] | None = None,
        provider: str = "",
        effort: str = "",
        session: str = "",
        agent: str = "",
        turn: int = 0,
        role: str = "loop",
        latency_ms: float = 0.0,
        wait_ms: float = 0.0,
        stop_reason: str = "",
        request_id: str = "",
        error: str = "",
        discount: float = 1.0,
    ) -> int:
        u = usage or {}
        card = resolve(model)
        priced = 1 if (card.price_in or card.price_out) else 0
        cost = estimate_cost_usd(model, u, discount=discount)
        with self._lock:
            cur = self._conn.execute(
                "INSERT INTO calls(at, session, agent, turn, role, provider, model, effort, input_tokens, output_tokens, cache_read, cache_creation, cost_usd, priced, latency_ms, wait_ms, stop_reason, request_id, error) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)",
                (
                    self._clock(), session, agent, turn, role, provider or card.provider, model, effort,
                    int(u.get("input_tokens", 0)), int(u.get("output_tokens", 0)),
                    int(u.get("cache_read_input_tokens", 0)), int(u.get("cache_creation_input_tokens", 0)),
                    cost, priced, latency_ms, wait_ms, stop_reason, request_id, error,
                ),
            )
            return int(cur.lastrowid or 0)

    def record_outcome(self, *, session: str, agent: str = "", status: str, stop_reason: str = "", turns: int = 0, tool_calls: int = 0, cost_usd: float = 0.0, error: str = "") -> int:
        with self._lock:
            cur = self._conn.execute(
                "INSERT INTO outcomes(at, session, agent, status, stop_reason, turns, tool_calls, cost_usd, error) VALUES (?,?,?,?,?,?,?,?,?)",
                (self._clock(), session, agent, status, stop_reason, turns, tool_calls, cost_usd, error),
            )
            return int(cur.lastrowid or 0)

    def attach(self, seams: Seams, *, agent: str = "") -> None:
        """Grava o `shutdown` de cada laço em `outcomes`."""

        def on_shutdown(e: Event) -> None:
            meter = e.data.get("meter") or {}
            self.record_outcome(
                session=e.session, agent=agent or str(e.data.get("agent", "")), status=str(e.data.get("status", "")),
                stop_reason=str(e.data.get("stop_reason", "")), turns=int(meter.get("turns", 0)), tool_calls=int(meter.get("tool_calls", 0)),
                cost_usd=float(meter.get("cost_usd", 0.0)), error=str(e.data.get("error", "")),
            )

        seams.on("shutdown", on_shutdown)

    # ------------------------------------------------------------ leitura
    def summary(self, by: str = "model", *, session: str = "", since: float = 0.0) -> list[dict[str, Any]]:
        """Agregados por `model|agent|session|role|provider|day`: chamadas, tokens, custo, cache, latência."""
        if by not in GROUPS:
            raise ValueError(f"agrupamento desconhecido: {by!r} (use {sorted(GROUPS)})")
        chave = "date(at, 'unixepoch')" if by == "day" else by
        cond = ["at >= ?"]
        args: list[Any] = [since]
        if session:
            cond.append("session = ?")
            args.append(session)
        rows = self._conn.execute(
            f"SELECT {chave} AS k, COUNT(*), SUM(input_tokens), SUM(output_tokens), SUM(cache_read), SUM(cache_creation), SUM(cost_usd), AVG(latency_ms), SUM(wait_ms), SUM(CASE WHEN error != '' THEN 1 ELSE 0 END), MIN(priced) FROM calls WHERE {' AND '.join(cond)} GROUP BY k ORDER BY SUM(cost_usd) DESC, k",
            args,
        ).fetchall()
        out = []
        for k, n, inp, outp, cr, cc, cost, lat, wait, errs, priced in rows:
            total_in = (inp or 0) + (cr or 0) + (cc or 0)
            out.append({
                by: k, "calls": n, "input_tokens": inp or 0, "output_tokens": outp or 0,
                "cache_read": cr or 0, "cache_creation": cc or 0,
                "cache_hit_ratio": round((cr or 0) / total_in, 4) if total_in else 0.0,
                "cost_usd": round(cost or 0.0, 6), "priced": bool(priced),
                "latency_ms_avg": round(lat or 0.0, 2), "wait_ms": round(wait or 0.0, 2), "errors": errs or 0,
            })
        return out

    def cost_per_task(self, *, agent: str = "") -> dict[str, Any]:
        """Custo por tarefa concluída: soma das chamadas / desfechos `completed`."""
        cond = "WHERE agent = ?" if agent else ""
        args = [agent] if agent else []
        done, failed, custo_outcomes = self._conn.execute(
            f"SELECT SUM(CASE WHEN status='completed' THEN 1 ELSE 0 END), SUM(CASE WHEN status='failed' THEN 1 ELSE 0 END), SUM(cost_usd) FROM outcomes {cond}", args
        ).fetchone()
        custo_calls, n_calls = self._conn.execute(f"SELECT SUM(cost_usd), COUNT(*) FROM calls {cond}", args).fetchone()
        done = done or 0
        return {
            "completed": done, "failed": failed or 0, "calls": n_calls or 0,
            "cost_usd": round(custo_calls or 0.0, 6),
            "cost_per_completed_task": round((custo_calls or 0.0) / done, 6) if done else None,
            "outcome_cost_usd": round(custo_outcomes or 0.0, 6),
        }

    def calls(self, *, session: str = "", limit: int = 100) -> list[dict[str, Any]]:
        cond = "WHERE session = ?" if session else ""
        args: list[Any] = [session] if session else []
        cur = self._conn.execute(f"SELECT * FROM calls {cond} ORDER BY id DESC LIMIT ?", [*args, limit])
        cols = [d[0] for d in cur.description]
        return [dict(zip(cols, r, strict=True)) for r in cur.fetchall()]

    def count(self) -> int:
        return int(self._conn.execute("SELECT COUNT(*) FROM calls").fetchone()[0])


class Ledgered:
    """`Provider` que registra cada chamada (inclusive as que falham) no livro-razão."""

    def __init__(self, provider: Provider, ledger: Ledger, *, agent: str = "", role: str = "", clock: Callable[[], float] = time.perf_counter) -> None:
        self.inner = provider
        self.ledger = ledger
        self.agent = agent
        self.role = role
        self.model = getattr(provider, "model", "")
        self.effort = getattr(provider, "effort", "")
        self.cost_discount = float(getattr(provider, "cost_discount", 1.0))
        self._clock = clock

    def complete(self, request: Request) -> Reply:
        meta = request.metadata
        t0 = self._clock()
        try:
            reply = self.inner.complete(request)
        except ProviderError as erro:
            self.ledger.record(
                model=self.model, provider=str(getattr(self.inner, "kind", "")), effort=self.effort,
                session=str(meta.get("session", "")), agent=self.agent or str(meta.get("agent", "")), turn=int(meta.get("turn", 0)),
                role=self.role or str(meta.get("role", "loop")), latency_ms=round((self._clock() - t0) * 1000, 3),
                wait_ms=float(meta.get("wait_ms", 0.0)), error=str(erro)[:500], discount=self.cost_discount,
            )
            raise
        self.ledger.record(
            model=reply.model or self.model, provider=str(getattr(self.inner, "kind", "")), effort=self.effort, usage=reply.usage,
            session=str(meta.get("session", "")), agent=self.agent or str(meta.get("agent", "")), turn=int(meta.get("turn", 0)),
            role=self.role or str(meta.get("role", "loop")), latency_ms=round((self._clock() - t0) * 1000, 3),
            wait_ms=float(meta.get("wait_ms", 0.0)), stop_reason=reply.stop_reason, request_id=reply.request_id, discount=self.cost_discount,
        )
        return reply
