"""Limites: o balde de fichas compartilhado num arquivo, e o disjuntor.

O provedor limita por modelo em três eixos — requisições, tokens de entrada
e tokens de saída por minuto — com um balde de fichas reposto continuamente.
N agentes do mesmo nó com a mesma chave, cada um com o seu recuo, são a
tempestade de retentativas de manual: todos batem no 429, todos esperam,
todos voltam juntos. A transposição do princípio do kernel: **o balde mora
numa tabela do mesmo SQLite** (fila, barramento, livro-razão) e todo
processo do nó passa por ele antes de chamar. Quem não tem ficha espera;
não retenta.

    buckets(name, capacity, rate, tokens, updated_at, blocked_until)

`acquire` é uma transação `BEGIN IMMEDIATE` (um escritor por vez, entre
processos): repõe pelo relógio, debita se há fichas, senão calcula quanto
esperar e dorme fora da transação. O balde aprende com o provedor: um 429
com `retry-after` bloqueia os três baldes até o prazo — todos os processos
veem. Só o **não cacheado** conta na entrada (`input_tokens` +
`cache_creation_input_tokens`), como no provedor.

`Breaker` é por processo: depois de `failures` falhas de infraestrutura
consecutivas, abre por `open_s` e recusa localmente (rápido, sem fila);
depois sonda com uma chamada (meia-abertura). `Limited` compõe os dois em
torno de qualquer `Provider`.
"""

from __future__ import annotations

import sqlite3
import threading
import time
from collections.abc import Callable
from pathlib import Path
from typing import Any

from ..session import enable_wal
from .provider import Provider, ProviderError, Reply, Request
from .window import RATIO, estimate_request

__all__ = ["Breaker", "Limited", "RateLimiter", "TokenBucket"]

MAX_SLEEP_STEP = 5.0


class TokenBucket:
    """Baldes nomeados em SQLite; um objeto por processo, seguro entre threads."""

    def __init__(self, db: str | Path, *, clock: Callable[[], float] = time.time, sleep: Callable[[float], None] = time.sleep, busy_timeout_s: float = 30.0) -> None:
        self.path = Path(db)
        self.path.parent.mkdir(parents=True, exist_ok=True)
        self._conn = sqlite3.connect(str(self.path), timeout=busy_timeout_s, check_same_thread=False, isolation_level=None)
        self._conn.execute(f"PRAGMA busy_timeout={int(busy_timeout_s * 1000)}")
        enable_wal(self._conn, timeout_s=busy_timeout_s)
        self._conn.execute(
            "CREATE TABLE IF NOT EXISTS buckets (name TEXT PRIMARY KEY, capacity REAL NOT NULL, rate REAL NOT NULL, tokens REAL NOT NULL, updated_at REAL NOT NULL, blocked_until REAL NOT NULL DEFAULT 0)"
        )
        self._lock = threading.Lock()
        self._clock = clock
        self._sleep = sleep
        self.waits = 0
        self.waited_s = 0.0

    def close(self) -> None:
        self._conn.close()

    def ensure(self, name: str, capacity: float, rate: float) -> TokenBucket:
        """Cria o balde cheio (ou ajusta capacidade/taxa de um existente)."""
        with self._lock:
            self._conn.execute("BEGIN IMMEDIATE")
            now = self._clock()
            try:
                row = self._conn.execute("SELECT capacity, rate, tokens FROM buckets WHERE name=?", (name,)).fetchone()
                if row is None:
                    self._conn.execute("INSERT INTO buckets(name, capacity, rate, tokens, updated_at) VALUES (?,?,?,?,?)", (name, capacity, rate, capacity, now))
                elif (row[0], row[1]) != (capacity, rate):
                    self._conn.execute("UPDATE buckets SET capacity=?, rate=?, tokens=MIN(tokens, ?) WHERE name=?", (capacity, rate, capacity, name))
                self._conn.execute("COMMIT")
            except BaseException:
                self._conn.execute("ROLLBACK")
                raise
        return self

    def try_acquire(self, name: str, n: float) -> tuple[bool, float]:
        """Debita `n` se há fichas; senão `(False, segundos até haver)`."""
        with self._lock:
            self._conn.execute("BEGIN IMMEDIATE")
            # O relógio é lido DENTRO da transação: lido antes de esperar o lock,
            # um `now` mais antigo que o `updated_at` de outro escritor rebobinaria
            # o relógio do balde e a reposição seria contada duas vezes.
            now = self._clock()
            try:
                row = self._conn.execute("SELECT capacity, rate, tokens, updated_at, blocked_until FROM buckets WHERE name=?", (name,)).fetchone()
                if row is None:
                    self._conn.execute("COMMIT")
                    raise KeyError(name)
                cap, rate, tokens, updated, blocked = row
                tokens = min(cap, tokens + max(0.0, now - updated) * rate)
                if blocked > now:
                    self._conn.execute("UPDATE buckets SET tokens=?, updated_at=? WHERE name=?", (tokens, now, name))
                    self._conn.execute("COMMIT")
                    return False, blocked - now
                if tokens >= n:
                    self._conn.execute("UPDATE buckets SET tokens=?, updated_at=? WHERE name=?", (tokens - n, now, name))
                    self._conn.execute("COMMIT")
                    return True, 0.0
                self._conn.execute("UPDATE buckets SET tokens=?, updated_at=? WHERE name=?", (tokens, now, name))
                self._conn.execute("COMMIT")
                falta = n - tokens
                return False, (falta / rate) if rate > 0 else float("inf")
            except BaseException:
                self._conn.execute("ROLLBACK")
                raise

    def acquire(self, name: str, n: float, *, max_wait_s: float | None = None) -> float:
        """Espera até debitar `n`; devolve quanto esperou. `max_wait_s` estourado é `ProviderError`."""
        waited = 0.0
        while True:
            ok, wait = self.try_acquire(name, n)
            if ok:
                if waited:
                    self.waits += 1
                    self.waited_s += waited
                return waited
            if max_wait_s is not None and waited + wait > max_wait_s:
                raise ProviderError(f"limite {name}: esperaria {wait:.1f}s além do máximo de {max_wait_s:.1f}s")
            passo = min(wait, MAX_SLEEP_STEP) if wait != float("inf") else MAX_SLEEP_STEP
            passo = max(passo, 0.001)
            self._sleep(passo)
            waited += passo

    def settle(self, name: str, delta: float) -> None:
        """Acerta o balde depois do uso real: `delta > 0` debita mais (pode ficar em dívida), `< 0` devolve."""
        if not delta:
            return
        with self._lock:
            self._conn.execute("BEGIN IMMEDIATE")
            now = self._clock()
            try:
                # Repõe até agora antes de acertar: a dívida se conta sobre o saldo real.
                self._conn.execute(
                    "UPDATE buckets SET tokens = MIN(capacity, MIN(capacity, tokens + MAX(0, ? - updated_at) * rate) - ?), updated_at = ? WHERE name=?",
                    (now, delta, now, name),
                )
                self._conn.execute("COMMIT")
            except BaseException:
                self._conn.execute("ROLLBACK")
                raise

    def block(self, name: str, until: float) -> None:
        """Ninguém passa até `until` (o `retry-after` do provedor, visto por todos)."""
        with self._lock:
            self._conn.execute("BEGIN IMMEDIATE")
            try:
                self._conn.execute("UPDATE buckets SET blocked_until = MAX(blocked_until, ?) WHERE name=?", (until, name))
                self._conn.execute("COMMIT")
            except BaseException:
                self._conn.execute("ROLLBACK")
                raise

    def state(self, name: str) -> dict[str, Any]:
        row = self._conn.execute("SELECT capacity, rate, tokens, updated_at, blocked_until FROM buckets WHERE name=?", (name,)).fetchone()
        if row is None:
            raise KeyError(name)
        cap, rate, tokens, updated, blocked = row
        now = self._clock()
        return {"name": name, "capacity": cap, "rate_per_s": rate, "tokens": min(cap, tokens + max(0.0, now - updated) * rate), "blocked_for_s": max(0.0, blocked - now)}

    def names(self) -> list[str]:
        return [r[0] for r in self._conn.execute("SELECT name FROM buckets ORDER BY name")]


class RateLimiter:
    """Três baldes por modelo (rpm, itpm, otpm) sobre um `TokenBucket`."""

    def __init__(self, db: str | Path | TokenBucket, *, model: str, rpm: float, itpm: float, otpm: float, output_reserve: int = 1024, ratio: float = RATIO, burst_s: float = 10.0, max_wait_s: float | None = None, clock: Callable[[], float] = time.time, sleep: Callable[[float], None] = time.sleep) -> None:
        """`burst_s`: quantos segundos de taxa cabem na rajada (a capacidade do balde).

        O provedor repõe continuamente e aplica os limites em janelas curtas
        ("60 RPM pode valer 1 por segundo"); o tamanho da rajada dele não é
        publicado. Um balde local menos permissivo que o do servidor nunca
        provoca 429; um mais permissivo, sim — daí o padrão conservador.
        """
        self.bucket = db if isinstance(db, TokenBucket) else TokenBucket(db, clock=clock, sleep=sleep)
        self.model = model
        self.output_reserve = output_reserve
        self.ratio = ratio
        self.max_wait_s = max_wait_s
        self._clock = clock
        self.names = {"rpm": f"{model}:rpm", "itpm": f"{model}:itpm", "otpm": f"{model}:otpm"}
        frac = max(0.0, min(1.0, burst_s / 60.0))
        self.bucket.ensure(self.names["rpm"], max(1.0, rpm * frac), rpm / 60.0)
        self.bucket.ensure(self.names["itpm"], max(1.0, itpm * frac), itpm / 60.0)
        self.bucket.ensure(self.names["otpm"], max(1.0, otpm * frac), otpm / 60.0)
        self.blocks = 0

    def estimate(self, request: Request) -> int:
        return estimate_request(request, self.ratio)

    def acquire(self, request: Request, estimated_input: int | None = None) -> float:
        est = self.estimate(request) if estimated_input is None else estimated_input
        waited = self.bucket.acquire(self.names["rpm"], 1, max_wait_s=self.max_wait_s)
        waited += self.bucket.acquire(self.names["itpm"], est, max_wait_s=self.max_wait_s)
        waited += self.bucket.acquire(self.names["otpm"], self.output_reserve, max_wait_s=self.max_wait_s)
        return waited

    def settle(self, estimated_input: int, reply: Reply | None) -> None:
        if reply is None:
            # A chamada não aconteceu: devolve o que foi reservado.
            self.bucket.settle(self.names["itpm"], -estimated_input)
            self.bucket.settle(self.names["otpm"], -self.output_reserve)
            return
        real_in = int(reply.usage.get("input_tokens", 0)) + int(reply.usage.get("cache_creation_input_tokens", 0))
        self.bucket.settle(self.names["itpm"], real_in - estimated_input)
        self.bucket.settle(self.names["otpm"], int(reply.usage.get("output_tokens", 0)) - self.output_reserve)

    def block(self, seconds: float) -> None:
        until = self._clock() + seconds
        for n in self.names.values():
            self.bucket.block(n, until)
        self.blocks += 1

    def on_retry(self, attempt: int, wait: float, reason: str) -> None:
        """Encaixa no `on_retry` do driver: um 429 bloqueia os baldes para todos."""
        if reason in ("RateLimitError", "http_429"):
            self.block(wait)

    def state(self) -> dict[str, dict[str, Any]]:
        return {k: self.bucket.state(n) for k, n in self.names.items()}


class Breaker:
    """Disjuntor por processo: fechado -> aberto (após N falhas) -> meia-abertura (sonda)."""

    def __init__(self, *, failures: int = 5, open_s: float = 30.0, clock: Callable[[], float] = time.time) -> None:
        self.failures = failures
        self.open_s = open_s
        self._clock = clock
        self._consecutive = 0
        self._opened_at: float | None = None
        self._probing = False
        self._lock = threading.Lock()
        self.trips = 0
        self.rejected = 0

    @property
    def state(self) -> str:
        with self._lock:
            if self._opened_at is None:
                return "closed"
            if self._clock() - self._opened_at >= self.open_s:
                return "half-open"
            return "open"

    def allow(self) -> bool:
        with self._lock:
            if self._opened_at is None:
                return True
            if self._clock() - self._opened_at >= self.open_s and not self._probing:
                self._probing = True
                return True
            self.rejected += 1
            return False

    def record_success(self) -> None:
        with self._lock:
            self._consecutive = 0
            self._opened_at = None
            self._probing = False

    def record_failure(self) -> None:
        with self._lock:
            self._consecutive += 1
            if self._probing or self._consecutive >= self.failures:
                self._opened_at = self._clock()
                self._probing = False
                self.trips += 1


class Limited:
    """`Provider` que passa pelo limitador (e pelo disjuntor) antes de chamar o de dentro."""

    def __init__(self, provider: Provider, limiter: RateLimiter | None = None, *, breaker: Breaker | None = None) -> None:
        self.inner = provider
        self.limiter = limiter
        self.breaker = breaker
        self.model = getattr(provider, "model", "")
        self.effort = getattr(provider, "effort", "")
        self.cost_discount = float(getattr(provider, "cost_discount", 1.0))
        if limiter is not None and hasattr(provider, "on_retry"):
            anterior = provider.on_retry

            def encadeado(attempt: int, wait: float, reason: str, _prev: Any = anterior) -> None:
                limiter.on_retry(attempt, wait, reason)
                if _prev:
                    _prev(attempt, wait, reason)

            provider.on_retry = encadeado

    def complete(self, request: Request) -> Reply:
        if self.breaker is not None and not self.breaker.allow():
            raise ProviderError(f"disjuntor aberto para {self.model or 'o modelo'}: {self.breaker.failures} falhas seguidas; sonda em {self.breaker.open_s:.0f}s")
        est = 0
        if self.limiter is not None:
            est = self.limiter.estimate(request)
            waited = self.limiter.acquire(request, est)
            request.metadata["wait_ms"] = round(waited * 1000, 3)
        try:
            reply = self.inner.complete(request)
        except ProviderError:
            if self.breaker is not None:
                self.breaker.record_failure()
            if self.limiter is not None:
                self.limiter.settle(est, None)
            raise
        if self.breaker is not None:
            self.breaker.record_success()
        if self.limiter is not None:
            self.limiter.settle(est, reply)
        return reply
